export type CompanyResponse = {
  /** Unique identifier assigned to the object */
  id: string;
  /** Company link nickname */
  company_link: string;
  /** Company name */
  company_name: string;
  /** Company profile image description */
  profile_image?: string;
};
