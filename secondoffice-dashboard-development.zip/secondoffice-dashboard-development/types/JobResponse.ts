// Mirrors serialization strategy done on backend for job
import { CompanyResponse } from "./CompanyResponse";
import { TagResponse } from "./TagResponse";

export type JobListResponse = {
  /** Unique identifier assigned to the object */
  id: string;
  /** Number of applicants */
  applicant_count: string | number;
  /** Job description */
  job_description: string;
  /** Employment type of the job */
  nature_of_job: string;
  /** Starting value of job's experience range  */
  experience_range_start: number | string;
  /** Ending value of job's experience range  */
  experience_range_end: number | string;
  /** Job position location */
  job_location?: string;
  /** Count of people needed */
  no_of_opening?: number | string;
  /** Job position title */
  job_title: string;
  /** Job posted date */
  job_deadline: string;
  /** Starting value of job's salary range  */
  salary_range_start: number | string;
  /** Ending value of job's salary range  */
  salary_range_end: number | string;
  /** Tag data list to be displayed as chips  */
  job_tags: Array<TagResponse>;
  /** Posted date */
  created_at: string;
  /** Last updated date */
  modified_at: string;
};

export type JobAuthor = {
  /** Unique identifier assigned to the object */
  id: string;
  /** Author's profile image */
  profile_image?: string;
  /** Author's name */
  user_fullname?: string;
  /** Author's position */
  user_position?: string;
};

export type JobDetailResponse = {
  /** Company data */
  company: CompanyResponse;
  /** Bookmarked status */
  is_bookmarked?: boolean;
  /** Callback called when `Apply Now` button is clicked */
  onApply?: () => void;
  /** Callback called when bookmark icon is clicked */
  onBookmark?: () => void;
  /** Callback callend when `Withdraw button is clicked` */
  onWithdraw?: () => void;
  /** Person who posted the job */
  posted_by: JobAuthor;
} & JobListResponse;
