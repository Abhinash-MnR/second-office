import { TagResponse } from "./TagResponse";

export type User = {
  /** Unique identifier assigned to the object */
  id: string;
  /** Profile image URL */
  avatar?: string;
  /** User's current position */
  designation?: string;
  /** Total experience in decimaled years */
  experience?: number;
  /** First name of the user */
  first_name?: string;
  /** Annotated value for bookmark status */
  is_bookmarked?: boolean;
  /** First name of the user */
  last_name?: string;
  /** User residence location */
  location?: string;
  /** Bottom range of salary */
  salary_range_end?: number;
  /** Upper range of salary */
  salary_range_start: number;
  /** SKill tags */
  tags?: Array<TagResponse>;
  /** User's pdf resume */
  resume?: string;
  /** Unique user profile link */
  user_link?: string;
};
