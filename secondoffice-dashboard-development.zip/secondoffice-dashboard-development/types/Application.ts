export type ApplicationType = {
  /** Unique identifier assigned to the object */
  id: string;
};

export type ApplicationListParams = {
  /** Current page number in Django Pagination class */
  page?: number;
  /** If present, filters applications to specified job post with the id */
  job_post?: string;
  /** If present, filters applications to specified status */
  application_status?: "applied" | "accepted" | "rejected";
};

export type ApplicationDetailPayload = {
  /** If present, changes the status of the specified application */
  application_status?: "applied" | "accepted" | "rejected";
};
