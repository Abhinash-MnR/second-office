export type ModalFormProps = {
  open: boolean;
  onClose: () => void;
  initialValues?: any;
  handleSubmit?: (value?: any) => void;
}