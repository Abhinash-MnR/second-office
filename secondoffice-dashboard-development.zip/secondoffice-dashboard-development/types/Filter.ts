export type Filter = {
  tags?: string[];
  positions?: string[];
  experience_start?: number;
  experience_end?: number;
  place_id?: string;
  type?: string;
}
