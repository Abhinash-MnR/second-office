export type InvitationResponse = {
  /** Unique identifier assigned to the object */
  id: string;
  /** Creation timestamp */
  created_at: string;
  /** Email receiving invitation */
  email: string;
  /** Permission assigned to the member */
  permission?: string;
  /** Last edit timestamp */
  modified_at: number | string;
  /** Invitation status */
  status: string;
};
