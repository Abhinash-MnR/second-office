export type TagResponse = {
  /** Unique identifier assigned to the tag object */
  id: string;
  /** Tag string */
  tag: string;
};
