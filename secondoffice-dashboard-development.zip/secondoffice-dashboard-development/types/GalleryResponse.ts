export type GalleryResponse = {
  /** Unique identifier assigned to the object */
  id: string;
  /** Gallery caption */
  caption: string;
  /** Creation timestamp */
  created_at: string;
  /** Gallery description */
  description?: string;
  /** Gallery image file url  */
  image: string;
  /** Last edit timestamp */
  modified_at: number | string;
  /** Gallery title */
  title: string;
};
