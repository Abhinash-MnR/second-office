export type ProfileResponse = {
  /** Unique identifier assigned to the object */
  id: string;
  /** Profile image */
  profile_image?: string;
  /** User full name */
  user_fullname?: string;
  /** User position */
  user_position?: string;
  /** User location */
  user_location?: string;
  /** User salary range start */
  salary_range_start: string;
  /** User salary range end */
  salary_range_end: string;
};
