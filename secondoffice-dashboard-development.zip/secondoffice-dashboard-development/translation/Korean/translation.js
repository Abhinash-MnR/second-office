export const TRANSLATIONS_KR = {
  dashboard_menu_title: "대시보드",
  dashboard_location_dropdown_title: "사무실 위치",
  dashboard_office_location_your_emp_title: "직원 ",
  dashboard_office_location_your_freelancer_title: "프리랜서",
  dashboard_management_menu_title1: "채용",
  dashboard_management_menu_title2: "상담 신청",
  dashboard_management_menu_title3: "출결 관리",
  dashboard_management_menu_title3: "출결 관리",
  dashboard_management_menu_title4: "장비 및 복지 혜택 요청",
  dashboard_management_menu_title5: "업무 평가",
  dashboard_management_menu_title6: "청구서 확인",
  recruit_menu_title: "채용",
  recruit_summary_card_title1: "전체 채용공고",
  recruit_summary_card_title2: "채용 중인 공고 ",
  recruit_summary_card_title3: "채용 종료된 공고",
  recruit_summary_card_title4: "전체 후보",
  recruit_open_jobs_title: "채용 중인 공고 ",
  recruit_closed_jobs_title: "채용 종료된 공고",
  recruit_jobs_post_button_title: "채용공고 작성하기",
  office_management_menu: "오피스 관리",
  office_management_submenu_team: "팀 관리",
  office_management_submenu_attendance: "출결 관리",
  office_management_submenu_performance: "직원 평가",
  office_management_submenu_log: "운영회의 보고서",
  task_management_menu: "업무 관리",
  store: "스토어",
  office_expense_menu: "청구서",
  settings: "설정",
  settings_save: "저장",
  help_center: "고객센터",
  dashboard_management_title: "서비스",
  //profile
  profile_backIcon_title: "프로필",
  profile_basic_info: "기본정보",
  company_name: "회사명",
  comapny_location: "위치",
  company_email: "이메일",
  company_contact: "연락처",
  comapny_desc: "회사 소개",
  edit_profile_button_title: "프로필 수정",
  profile_logout: "로그아웃",
  edit_profile_save: "변경 사항을 저장하기",
  //** dashboard page language translation */
  quick_action_card_title_1: "지금 바로 귀사의 세컨드오피스를 구축하세요",
  quick_action_card_title_2: "직원 채용하기",
  quick_action_card_title_3: "귀사의 팀에 대해 자세히 알아보기",
  quick_action_card_title_4: "월별 지출 확인하기",
  book_a_call: "상담 신청하기",
  quick_action_button_title: "둘러보기",
  blogs: "블로그",
  office_title: "귀사의 세컨드오피스 위치",
  //**recruit page language translation */
  recruit_banner_title: "공고 등록하기",
  recruit_banner_desc:
    "채용 요건만 공유해주세요. 나머지는 저희가 처리해 드립니다.",
  recruit_button_title: "채용공고 작성하기",
  recruit_open_joblist_title: "등록된 공고",
  recruit_closed_joblist_title: "만료된 공고",
  recruit_backIcon_title: "채용하기 (뒤로가기)",
  post_job_form_title: "포지션 요구사항 작성하기",
  post_job_form_subtitle: "아래에 정보를 기입해주세요",
  job_position_name: "직책 이름",
  job_position_location: "근무 위치(선택사항)",
  job_position_location_placeholder: "근무 위치",
  notice_period: "퇴사 예고 기간",
  job_skills: "필수 기술 스택(최대 5개)",
  job_skills_placeholder: "기술 추가",
  job_skill_seprated_alert_text: "쉼표로 각 기술 스택을 나눠주세요",
  priority: "우선순위(선택사항)",
  view_priority: "우선순위",
  education: "학력",
  jobs_experiance: "필수 경력 연차",
  number_of_openings: "채용 인원 수",
  salary_per_annum: "연봉",
  salary_min_range: "최소",
  salary_max_range: "최대",
  salary_no_bar_text: "연봉 상한선 없음",
  job_post_button_title: "게시하기",
  recruit_this_field_empty_warning_title: "필수 기입 항목입니다.",
  view_job_posted_title: "등록 날짜",
  job_post_reset_button_title: "초기화",
  view_candidate_button_title: "후보 조회",
  view_job_post_button_title: "채용공고 보기",
  view_job_edit_button_title: "채용공고 수정하기",
  view_job_education_title: "학력",
  view_job_experiance_title: "경력 연차",
  view_job_salary_title: "급여(연봉)",
  view_job_notice_period_title: "퇴사 예고 기간(일)",
  view_job_skills_title: "보유 기술",
  view_job_description_title: "담당 업무 소개",
  job_edit_history_backIcon_title: "채용공고 수정 기록",
  job_edit_history_table_head_date: "날짜",
  job_edit_history_table_head_time: "시간",
  job_edit_history_table_head_job: "채용 공고",
  job_edit_history_table_head_modified: "수정된 사항",
  job_edit_history_table_head_modifiedby: "수정한 사람",
  jobs_edit_history_emptybox_title:
    "수정 기록은 아래에서 확인하실 수 있습니다.",
  view_candiates_backIcon_title: "채용하기",
  view_candidates_job_application_title: "채용 공고: ",
  view_candidates_job_application_position_title: "",
  view_candidates_table_head_candidate: "후보자",
  view_candidates_table_head_notice: "퇴사예고기간",
  view_candidates_table_head_exp: "경력",
  view_candidates_table_head_ctc: " 현재 연봉",
  view_candidates_table_head_ectc: "희망 연봉",
  view_candidates_table_head_resume: "이력서/포트폴리오",
  view_candidates_table_head_cultural: "인성 면접",
  view_candidates_table_head_comments: "리크루팅팀 피드백",
  view_candidates_table_head_technical: "기술면접",
  view_candidates_table_head_action: "결정 사항",
  view_candidates_table_head_status: "채용 진행 현황",
  view_candidates_table_head_offer: "최종 합격 통지 날짜",
  view_candidate_view_resume_title: "이력서 보기",
  view_candidate_view_portfolio_title: "포트폴리오 보기",
  view_candidates_emptybox_title: "지원자 현황을 확인하세요",
  view_candidate_summary_card_tittle1: "전체 지원자",
  view_candidate_summary_card_tittle2: "예비 합격자",
  view_candidate_summary_card_tittle3: "합격자",
  view_candidate_summary_card_tittle4: "입사 예정 지원자",
  edit_jobs_discard_button_title: "변경사항 취소",
  edit_jobs_save_changes_title: "변경사항 저장",
  recruit_empty_screen_title: "작성된 채용공고 없음",
  view_candidate_list_not_found: "후보를 찾을 수 없습니다.",
  recruit_empty_screen_subtitle: "이제 작성하시면 됩니다.",
  view_candidate_notice_period_tooltip:
    "퇴사예고기간이란, 해당 후보가 합격 시 현 직장에서 퇴사하여 입사하기까지 소요되는 기간입니다. 인수인계 등 정리를 위한 근로계약 상 통상적인 기간입니다. ",
  view_candidate_ctc_tooltip: "해당 후보의 현 직장 연봉에 대한 안내입니다.",
  view_candidate_ectc_tooltip:
    "해당 후보가 희망하는 연봉을 나타내며, 이 때 연봉에 세금, 보험 등 부대 비용은 포함되지 않습니다. ",
  view_candidate_culture_fit_tooltip:
    "세컨드오피스 리크루팅 팀이 자체적으로 진행하는 인성 면접으로, 후보의 의사소통 능력 및 업무 태도를 종합적으로 판단하여 합격/불합격 을 결정합니다.",
  view_candidate_actions_tooltip:
    "해당 후보를 통과시켜 면접을 진행할지 여부를 결정해주세요. 단, 고객사 측에서 합격 처리하더라도, 해당 후보가 리크루팅 팀의 인성 면접(필수)을 통과하지 못한다면 불합격 처리 됩니다. ",
  view_candidate_status_tooltip:
    "해당 후보의 채용 진행 현황입니다. 1차 합격, 보류, 지원 철회, 합격 오퍼, 입사 예정 등 현황을 리크루팅 팀이 실시간 업데이트합니다. ",

  //** Office management korean content */
  office_management_team_title: "팀 관리",
  office_management_team_roaster_title: "직원 명단",
  office_management_team_roaster_table_head_emp: "직원",
  office_management_team_roaster_table_head_position: "직책",
  office_management_team_roaster_table_head_ctc: "연봉",
  office_management_team_roaster_table_head_joining: "입사일",
  office_management_team_roaster_table_head_resigned: "퇴사일",
  office_management_team_roaster_table_head_resume: "이력서",
  office_management_team_roaster_table_head_hr_actions: "인사 결정",
  office_management_team_actions_tooltip_title:
    "해당 직원에 대해 인사 결정을 해 주신 사항이 반영됩니다.",
  hr_actions_no_needed: "-",
  hr_actions_bonus: "보너스/상여",
  hr_actions_termination: "해고 ",
  hr_actions_promotion: " 승진 ",
  office_management_expected_newjoiners_title: "입사 예정자",
  office_management_expected_newjoiners_table_head_emp: "직원",
  office_management_expected_newjoiners_table_head_position: "직책",
  office_management_expected_newjoiners_table_head_ctc: "연봉",
  office_management_expected_newjoiners_table_head_joining: "입사예정일",
  office_management_expected_newjoiners_table_head_hired: "입사예정일",
  office_management_expected_newjoiners_table_head_emp_status: "현황",
  office_management_expected_newjoiners_table_head_resume: "이력서",
  office_management_historic_emp_title: "퇴사자 기록",
  office_management_historic_emp_table_head_emp: "직원",
  office_management_historic_emp_table_head_position: "직책",
  office_management_historic_emp_table_head_salary: "연봉",
  office_management_historic_emp_table_head_joining: "입사일",
  office_management_historic_emp_table_head_resign: "퇴사일",
  office_management_historic_emp_table_head_resign_on: "퇴사일",
  office_management_historic_emp_table_head_resume: "이력서",
  office_management_attendance_title: "출결",
  office_management_attendance_table_head_date: "날짜",
  office_management_attendance_table_head_log: "출결 로그",
  office_management_attendance_table_data_view_log: "로그 보기",
  offie_management_performance_title: "업무 평가",
  offie_management_eveluation_button_title: "평가 세션 추가하기",
  office_management_evaluation_popup_desc: "평가 세션 생성 날짜 선택",
  office_management_evaluation_popup_button_title_title: "평가 세션 생성하기",
  office_management_performance_popup_title: "직원 평가 추가하기",
  office_management_performance_popup_title1: "회원 실적 추가",
  office_management_performance_popup_desc: "아래 내용을 작성해주세요",
  office_management_performance_popup_button_title: "평가 제출",
  office_management_performance_table_head_emp: "직원 ",
  office_management_performance_table_head_score: "점수(10)",
  office_management_performance_table_head_comments: "본사 피드백",
  office_management_performance_table_head_action: "인사 결정",
  team_performance_hr_actions_tooltip:
    "해당 직원에 대해 인사 결정을 해 주신 사항이 반영됩니다.",
  team_performance_popup_form_emp_name_label: "직원 이름",
  team_performance_popup_form_score_label: "평가 점수",
  team_performance_popup_form_feedback_label: "피드백",
  team_performance_empty_date_added:
    "여기에서 직원의 의견과 점수를 보려면 팀 성과를 추가하십시오.",
  office_management_log_title: "운영회의 보고서",
  office_management_team_summarycard_title1: "전체 팀원",
  office_management_team_summarycard_title2: "입사예정자",
  office_management_team_summarycard_title3: "퇴사자",
  office_management_team_attendance_summarycard_title1: "전체 팀원",
  office_management_team_attendance_summarycard_title2: "근무 중",
  office_management_team_attendance_summarycard_title3: "휴가 중",
  teamRoaster_empty_screen_title: "직원 목록을 이곳에서 확인하세요.",
  expectedJoiners_empty_screen_title: "직원 목록을 이곳에서 확인하세요.",
  formerEmployee_empty_screen_title: "퇴사자.",
  attendance_logs_title: "보고서",
  attendance_empty_screen_title: "직원들의 출결 기록을 확인하세요.",
  team_performance_empty_screen_title: "업무 평가 내역을 확인하세요.",
  management_logs_empty_screen_title: "운영 현황 보고서를 확인하세요.",
  //**store page content */
  store_title: "서비스 준비 중",
  store_desc:
    "팀에 필요한 새로운 장비들을 이 곳에서 요청하고, 업데이트되는 장비 목록을 확인하세요.",
  device_management_title: "장비 관리",
  submit_new_request_title: "장비 요청",
  submit_request_title: "요청 제출",
  employee_name_title: "직원 이름",
  device_type_title: "장비 종류",
  device_name_title: "제품 명",
  device_cost: "비용",
  seller_name: "제품 브랜드",
  description: "제품 설명",
  quantity: "수량",
  store_new_request_form_title: "자세한 사항을 아래에 입력하세요. ",
  store_request_back_icon_title: "신규 요청",
  store_request_device_category_title: "구분",
  store_request_device_brand_title: "제품 브랜드",
  store_request_device_quantity_title: "수량",
  store_request_device_empName_title: "직원",
  store_request_device_desc_title: "제품 설명 ",
  store_requested_device_title: "신청된 장비",
  read_more_title: "더 보기",
  show_less_title: "덜 보기",
  store_empty_screen_title:
    "팀에 필요한 새로운 장비들을 이 곳에서 요청하고, 업데이트 되는 장비 목록을 확인하세요.",
  //** office expenses content */
  office_expense_title: "운영비용",
  office_expense_standard_package_title: "스탠다드 패키지",
  office_expense_standard_package_desc: "기본 채용 서비스",
  office_expense_inclusive_package_title: "올인원 패키지",
  year: "연도",
  month: "월",
  search: "검색",
  office_expense_inclusive_package_desc:
    "채용과 관리가 포함된 올인원 통합 서비스",
  office_expense_enterprise_title: "기업 단위",
  office_expense_enterprise_desc: "해외 지사 설립보다 나은 방법입니다.",
  office_expense_button_title: "더 자세히 알아보기",
  office_expense_banner1_title: "유연한 확장",
  office_expense_banner1_desc:
    "새로운 직원을 채용하고, 장비를 요청하고, 사무실 자리를 늘릴 때마다 비용을 납부할 번거로움 없이 지갑에 충전된 금액으로 간편하게 운영할 수 있어요.",
  office_expense_banner2_title: "투명한 지출 추적",
  office_expense_banner2_desc:
    "보험을 포함한 부대비용부터 직원 급여까지, 사무실 운영에 소요되는 지출을 한 눈에 관리해요.",
  office_expense_banner3_ttile: "직관적인 예산 관리",
  office_expense_banner3_desc:
    "현재 환율 기준으로 사무실 운영을 위해 매월 얼마가 필요할지 미리 알려드려요. 임금체불 등 의도치 않은 국제 노동법 위반으로부터 보호해드립니다.",
  office_expense_tooltip: "사무실 운영으로 월별 청구되는 지출을 확인하세요.",
  applied_funds_tooltip: "충전된 금액은 영업일 기준 1일 이내로 표시됩니다.",
  office_expense_current_balance_title: "현재 남은 지갑 잔액입니다.",
  office_expense_table_head_date: "청구 날짜",
  office_expense_table_head_total: "청구 금액",
  office_expense_table_head_payment: "납입 현황",
  office_expense_table_head_invoice: "청구서",
  office_expense_view_invoice: "인보이스 보기",
  office_expense_applied_funds_title: "충전 내역",
  office_expense_applied_funds_table_head_date: "날짜",
  office_expense_applied_funds_table_head_amount: "금액",
  office_expense_empty_title: "여기에서 모든 월별 지출을 확인하세요.",
  office_expense_applied_funds_empty_title: "이 곳에서 비용 내역을 확인하세요.",
  office_expense_applied_funds_tooltip:
    "충전된 금액은 영업일 기준 1일 이내로 표시됩니다.",
  //**settings page content */
  setting_title: "설정",
  customize_interview_module_title: "면접 과정 선택",
  customize_interview_module_desc:
    "채용 진행 중 실시될 면접 과정을 정할 수 있습니다.",
  customize_currency_mode_title: "통화 설정",
  customize_currency_mode_desc: "편의에 따라 통화를 선택할 수 있습니다.",
  customize_language_mode_title: "언어 설정",
  customize_language_mode_desc: "편의에 따라 언어를 설정할 수 있습니다.",
  customize_usefull_link_title: "유용한 링크",
  customize_usefull_link_desc: "운영 현황 링크",
  cultural_round_title: "인성 면접",
  technical_round_title: "기술 면접 ",
  client_round_title: "최종 면접",
  online_tech_assessment_title: "온라인 기술 과제",
  currency_title: "환율",
  language_title: "언어",
  management_log_link_title: "운영 현황 보고서 링크",
  //**help center english language */
  help_center_title: "지원 센터",
  tutorial_title: "튜토리얼 블로그",
  tutorial_seemore: "더보기",
  faq_title: "자주 묻는 질문",
  faq_q1_title: "세컨드오피스 전문가들과 예약하는 방법은 어떻게 되나요?",
  faq_q1_content:
    "세컨드오피스 전문가들과의 미팅 예약 방법은 다음과 같습니다: ",
  faq_q1_content_steps:
    "로그인 > 예약하기 > 날짜 시간 선택하기 > 확인 > 게스트 추가 > 이벤트 스케줄 잡기",
  faq_q2_title: "세컨드오피스 전문가들과 예약하는 방법은 어떻게 되나요?",
  faq_q2_content:
    "세컨드오피스 전문가들과의 미팅 예약 방법은 다음과 같습니다: ",
  faq_q2_content_steps:
    "로그인 > 예약하기 > 날짜 시간 선택하기 > 확인 > 게스트 추가 > 이벤트 스케줄 잡기",
  faq_q3_title: "팀을 꾸리기 위해 채용 공고는 어떻게 올리나요?",
  faq_q3_content: "채용 공고를 올리는 방법은 다음과 같습니다:",
  faq_q3_content_steps: "로그인 > 채용 > 채용 공고 올리기 > 변경 사항 저장",
  faq_q4_title: "출석 체크는 어떻게 하나요?",
  faq_q4_content: "출석 체크하는 방법은 다음과 같습니다: ",
  faq_q4_content_steps: "개발 사무소 관리 > 출석 > 로그 확인하기",
  faq_q5_title: "지갑 잔액은 어떻게 확인하나요?",
  faq_q5_content:
    "운영 비용을 클릭하시면 화면 우측 상단에 현재 잔액을 확인하실 수 있습니다. ",
  faq_q5_content_steps: "-",
  faq_q6_title: "후보자 선별은 어떻게 하나요?",
  faq_q6_content: "후보자를 선별하는 방법은 다음과 같습니다:",
  faq_q6_content_steps:
    "채용 > 채용 공고 열기 > 후보자 보기 > 액션/현황 > 합격 또는 불합격 처리",
  faq_q7_title: "운영 비용 기록은 어디에 있나요?",
  faq_q7_content:
    "운영 비용을 클릭하시면 화면 우측 상단에 현재 잔액을 확인하실 수 있습니다. ",
  faq_q7_content_steps: "-",
  faq_q8_title: "면접 과정은 어떻게 변경하나요?",
  faq_q8_content: "채용 진행 중 실시될 면접 과정 변경은 다음과 같습니다:",
  faq_q8_content_steps:
    "설정 > 면접 과정 선택 > 인성 면접 > 기술 면접 > 최종 면접",
  faq_q9_title: "평가 주기 변경 방법?",
  faq_q9_content:
    "평가는 매주,격주,월별, 분기별 단위로 원하는 주기에 맞게 설정할 수 있습니다:",
  faq_q9_content_steps: "설정 > 추가 설정 > 평가 주기.",
  faq_q10_title: "기본 통화는 어떻게 설정하나요?",
  faq_q10_content: "기본 통화 설정 방법은 다음과 같습니다:",
  faq_q10_content_steps: "설정 > 기타 설정 > 통화",
  //** tutorial 1  Book call  */
  book_a_call_tutoial_title:
    "세컨드오피스 전문가들과의 상담을 통해 최적의 팀을 채용하세요.",
  book_a_call_tutoial_detail: `<div>
   세컨드오피스 전문가와의 미팅을 통해 우수한 후보자를 채용하는 방법에 대한 컨설팅을 받아보세요. 
    <br />
    <br />

  세컨드오피스 전문가와의 상담을 신청하는 방법은 다음과 같습니다.
    <br />
    <br />

    <span style="font-weight: 700">Step 1:</span>  세컨드오피스 계정 로그인하기
    <br />
이메일과 비밀번호를 입력하여 세컨드오피스 대시보드에 로그인해주세요.

    <br />
    <br />
    <span style="font-weight: 700">Step 2:</span> 상담 신청하기 클릭하기

    <br />
    <span style="font-weight: 700; font-style: italic;">
    상담 신청하기
    </span>
 를 클릭해주세요.
    <br />
    <br />

    <span style="font-weight: 700">Step 3:</span> 날짜 및 시간 선택하기
    
    <br />
  캘린더에 표시된 날짜와 시간을 선택해주세요. 
    <br />
    <br />

    <span style="font-weight: 700">Step 4:</span> 확인 클릭하기
    <br />
확인을 클릭하고 귀하의 성함과 이메일 주소를 입력해 주세요.
    <br />
    <br />

    <span style="font-weight: 700">Step 5:</span> 게스트 추가하기
    <br />
    귀하와 함께 미팅에 참석할 분들의 이메일 계정을 최대 10개까지 추가할 수 있습니다. 
    <br />
    <br />

    <span style="font-weight: 700">Step 6:</span>  예약하기 클릭하기
    <br />
    예약하기를 클릭하면 상담 신청이 완료되며 해당 신청을 전달받은 컨설턴트가 귀하에게 연락을 취하게 됩니다. 
    <br />
    <br />
  </div>`,
  office_management_tutoial_title:
    "개발 사무소 관리에서 팀원들의 정보를 확인하세요",
  office_management_tutoial_detail: `<div>

    개발 사무소 관리에서 다음과 같은 정보를 확인하실 수 있습니다:
    <br/>
  현 직원 또는 퇴사한 직원들의 직책, 연봉, 입사/퇴사 날짜, 이력서 등의 인적사항 정보를 확인하실 수 있습니다.
또한, 직원의 업무 성과 평가와 해당 직원에 대한 코멘트 등을 확인하실 수 있습니다.
    <br/>
    <br/>
    
직원 명단과 각 직원의 성과에 대한 평가를 확인하실 수 있는 방법은 다음과 같습니다.
    <br/>
    <br/>
    
    <span style="font-weight: 700">Step 1:</span> 세컨드오피스 계정 로그인하기
    <br/>
   이메일과 비밀번호를 입력하여 세컨드오피스 대시보드에 로그인해주세요.
    <br/>
    <br/>

    <span style="font-weight: 700">Step 2:</span> 둘러보기 클릭하기
    <br/>
   '팀에 대해 자세히 알아보기' 항목에서<span style="font-weight: 700; font-style: italic;">둘러보기</span> 를 클릭하세요.
    <br/>
    <br/>
    
    <span style="font-weight: 700">Step 3:</span> 직원 명단 확인하기
    <br/>
<span style="font-weight: 700; font-style: italic;">팀 관리</span>항목을 클릭해 귀사의 직원 명단을 포함한 직원들의 이름, 직책, 연봉, 이력서, 입사/퇴사 날짜를 확인 할 수 있습니다.
    <br/>
    <br/>
    
    <span style="font-weight: 700">Step 4:</span> 출결 확인하기
    <br/>
    <span style="font-weight: 700; font-style: italic;">출결 관리</span>를 클릭해 귀사 팀의 출결을 확인하세요.
    <br/>
    <br/>
    
    <span style="font-weight: 700">Step 5:</span> 업무 성과 평가 확인하기
    <br/>
  <span style="font-weight: 700; font-style: italic;">업무 성과 평가</span> 항목에서 각 직원의 업무에 대한 성과 평가 점수와 해당 직원에 대한 코멘트를 확인하세요.
    <br/>
    <br/>
    
    <span style="font-weight: 700">Step 6:</span> 운영 현황 보고서 확인하기
    <br/>
   <span style="font-weight: 700; font-style: italic;">운영 현황 보고서</span> 를 클릭하여 귀사의 개발 사무소 운영 현황을 확인하세요.
    <br/>
    <br/>
    </div>`,
  recruit_tutoial_title: "채용 공고를 등록해 개발 팀을 채용하세요.",
  recruit_tutoial_detail: `<div>

    귀사에서 원하시는 개발자 스펙 기술 요구사항을 공유해주세요. 이후의 채용 프로세스는 저희 세컨드오피스의 채용 전문가들이 관리해드립니다.
    <br/>
    <br/>
    
채용공고를 등록하는 방법은 다음과 같습니다.
    <br/>
    <br/>
    
    <span style="font-weight: 700">Step 1:</span> 세컨드오피스 계정 로그인하기
    <br/>
    이메일과 비밀번호를 입력하여 세컨드오피스 대시보드에 로그인해주세요.
    <br/>
    <br/>

    <span style="font-weight: 700">Step 2:</span> 둘러보기 클릭하기
    <br/>
 <span style="font-weight: 700; font-style: italic;">직원 채용하기</span>항목 아래의 <span style="font-weight: 700; font-style: italic;">둘러보기</span>를 클릭하세요. 좌측 메뉴에 있는
     <span style="font-weight: 700; font-style: italic;">채용</span> 을 클릭하셔도 됩니다.
    <br/>
    <br/>
    
    <span style="font-weight: 700">Step 3:</span> 채용공고 작성하기
<span style="font-weight: 700; font-style: italic;">채용공고 작성하기</span> 를 클릭하세요. 
    <br/>
    <br/>
    
    <span style="font-weight: 700">Step 4:</span> 채용 정보 기입하기
    <br/>
    직책 이름, 근무 위치(선택사항), 퇴사 예고 기간, 필수 기술 스택(최대 5개) 등 직무 정보를 기입해주세요. 직책의 범위, 의무 및 책임을 설명하는 포괄적인 직무 설명도 기입해주세요.
    <br/>
    <br/>
    
    <span style="font-weight: 700">Step 5:</span> 변경사항 저장하기
    <br/>
  오른쪽 하단의<span style="font-weight: 700; font-style: italic;">변경사항 저장하기</span> 를 클릭하여 작성하신 채용 공고를 등록하세요.
    <br/>
    <br/>
    
    </div>`,
  office_expense_tutorial_title: "운영비용",
  office_expense_tutorial_detail: `<div>
    운영비용 항목에서 귀사의 개발 팀에 대한 비용과 충전 내역을 확인하실 수 있는 방법은 다음과 같습니다. 
      <br />
      <br />
      <span style="font-weight: 700">Step 1:</span> 세컨드오피스 계정 로그인하기
      <br />
     이메일과 비밀번호를 입력하여 세컨드오피스 대시보드에 로그인해주세요.
      <br />
      <br />
      <span style="font-weight: 700">Step 2:</span> 운영비용 클릭하기
      <br />
    좌측 메뉴에서 <span style="font-weight: 700; font-style: italic;">운영비용</span> 을 클릭하세요.  
      <br />
      <br />
      <span style="font-weight: 700">Step 3:</span> 현재 보유하고 있는 잔액 확인하기
      <br />
      화면의 오른쪽에 있는 남색 박스에서 귀사의 현재 잔액을 확인하실 수 있습니다. 잔액 오른쪽에 위치한 ⓘ를 클릭해 최신 환율에 대한 정보도 확인이 가능합니다.
      <br />
      <br />
      <span style="font-weight: 700">Step 4:</span>운영비용 확인하기
      <br />
     비용이 발생하면 해당 비용에 대한 청구서가 생성되며 해당 비용의 금액과 지불 상태 또한 확인하실 수 있습니다. <span style="font-weight: 700; font-style: italic;">청구서 확인하기</span> 를 클릭해 생성된 청구서를 확인하세요.
      <br />
      <br />
      <span style="font-weight: 700">Step 5:</span>  충전 내역 확인하기
      <br />
      이 항목에서는 귀사의 세컨드오피스 지갑으로 이체된 금액 내역을 확인하실 수 있습니다. 영업일 기준 1일 이내에 귀사에서 이체한 금액 내역이 자동으로 해당 항목에 표시됩니다.
      <br />
      <br />
    </div>`,
  view_candidate_tutorial_title: "후보자 확인하기",
  view_candidate_tutorial_detail: `<div>

    귀사의 채용 공고 현황과 후보자들을 확인하실 수 있는 방법은 다음과 같습니다.
    <br/>
    <br/>
    
    <span style="font-weight: 700">Step 1:</span> 세컨드오피스 계정 로그인하기
    <br/>
   이메일과 비밀번호를 입력하여 세컨드오피스 대시보드에 로그인해주세요.
    <br/>
    <br/>
    
    <span style="font-weight: 700">Step 2:</span> 채용 클릭하기
    <br/>
  왼쪽 메뉴에 있는<span style="font-weight: 700; font-style: italic;">채용 </span> 클릭하기.
    <br/>
    <br/>
    
    <span style="font-weight: 700">Step 3:</span> 후보자 확인하기
    <br/>
  등록된 공고에서 <span style="font-weight: 700; font-style: italic;">후보자 확인하기</span>클릭하기.
    <br/>
    <br/>
    
    <span style="font-weight: 700">Step 4:</span> 해당 포지션의 후보자들 확인하기
    <br/>
    해당 포지션에 지원한 후보자들의 정보를 확인하실 수 있습니다.
    <br/>
    <ul>
        <li>퇴사 예고 기간: 후보자가 현 회사에서 퇴사를 결정한 날을 기준으로 의무적으로 퇴사 전까지 현직에서 근무를 수행해야 하는 날의 일 수를 뜻합니다.</li>
        <li>경력: 후보자의 총 경력 년 수를 확인하실 수 있습니다.</li>
        <li>CTC: 후보자가 현 회사에서 지급받는 연봉 금액입니다.</li>
        <li>ECTC: 후보자의 희망 연봉 금액입니다.</li>
        <li>이력서/포트폴리오: 후보자의 이력서 또는 포트폴리오를 확인하실 수 있습니다. 이력서 확인하기 혹은 포트폴리오 확인하기를 클릭해 확인이 가능합니다.</li>
        <li>인성 면접: 인도 현지 채용 팀이 내부적으로 각 후보자들의 인성 면접을 진행합니다. 해당 면접의 진행 상태와 결과를 확인하실 수 있습니다.</li>
        <li>코멘트: 각 후보자에 대한 인도 채용 팀의 코멘트를 확인하실 수 있습니다.</li>
        <li>기술 면접: 인도 현지 채용 팀이 내부적으로 진행한 기술 면접의 결과를 확인하실 수 있습니다.</li>
        <li>결정 사항: 해당 메뉴를 드랍다운하여 후보자의 합격과 불합격을 결정하실 수 있습니다.</li>
        도움말:인성 면접 단계에서 불합격한 후보자는 최종 불합격 처리가 되기 때문에 귀사에서의 추가적인 합격과 불합격 통보는 요구되지 않습니다.
        <li>채용 진행 현황:  인도 현지 채용 팀에서 후보자의 채용 진행 현황을 실시간으로 업데이트되며, 후보자의 채용 진행 현황에 따라 해당 후보자 칸의 색이 변경됩니다. 각 색이 나타내는 진행 현황은 다음과 같습니다.</li>
    </ul>
    <ul>
    <span style="font-weight: 700; font-style: italic;">→ 흰색:</span> 서류면접 단계에서 통과하여 후보 목록에는 올라와 있으나 이후의 면접은 아직 거치지 않은 후보자를 의미합니다. 해당 후보자가 이후의 면접 단계를 진행하기 전에도 귀사에서 합격과 불합격 여부를 선택할 수 있습니다.
    <br/>
    <span style="font-weight: 700; font-style: italic;">→  노란색:</span> 인성 면접, 기술 면접 또는 온라인 기술 과제와 같은 서류 면접 단계 이후의 면접 단계에 접어든 후보자를 의미합니다.
    <br/>
    <span style="font-weight: 700; font-style: italic;">→ 파란색:</span>최종 면접 후 고객사로부터 합격 오퍼를 전달받은 후보자를 의미합니다.
    <br/>
    <span style="font-weight: 700; font-style: italic;">→ 초록색:</span>채용 프로세스가 완료되어 최종 채용된 후보자를 의미합니다.
    <br/>
    <span style="font-weight: 700; font-style: italic;">→ 빨강색 :</span>최종 탈락/재검토 필요/지원철회한 후보를 의미합니다. 
    <br/>
    </ul>
    <br/>
    <br/>
    
    </div>`,
  performance_tutorial_title: "평가 세션",
  performance_tutorial_detail: `<div>

개발 사무소 관리 항목에서는 다음과 같은 내용을 확인하실 수 있습니다:
    <br/>
    <br/>
    
    <ul>
        <li>각 직원의 업무에 대한 성과 평가와 해당 직원에 대한 코멘트 등을 확인하실 수 있습니다.</li>
    </ul>
    <br/>
    
평가된 직원들의 점수 및 코멘트를 확인하실 수 있는 방법은 다음과 같습니다.
    <br/>
    -
    <br/>
    <br/>
    
    <span style="font-weight: 700">Step 1:</span>세컨드오피스 계정 로그인하기
    <br/>
이메일과 비밀번호를 입력하여 세컨드오피스 대시보드에 로그인해주세요.
    <br/>
    <br/>
    <span style="font-weight: 700">Step 2:</span> 개발 사무소 관리 클릭하기
    <br/>
좌측 메뉴에서 개발 사무소 관리 를 클릭하세요. 
    <br/>
    <br/>
    
    <span style="font-weight: 700">Step 3:</span> 업무 성과 평가 확인하기
    <br/>
   <span style="font-weight: 700; font-style: italic;">업무 성과 평가 </span> 항목에서 평가 세션을 생성하고 귀사 직원의 업무 성과에 평가 점수를 줄 수 있습니다.
    <br/>
    <br/>
    <br/>
    
    <span style="font-weight: 700; font-style: italic;">평가 세션 추가</span>,를 클릭하고 <span style="font-weight: 700; font-style: italic;"> 시작 날짜를 선택</span> 한 다음<span style="font-weight: 700; font-style: italic;">성과 평가 그룹 생성</span> 을 클릭하면 평가 세션이 추가됩니다.
    <br/>
    <br/>
    
   <span style="font-weight: 700; font-style: italic;">업무 성과 평가 추가하기</span> 를 클릭하고 <span style="font-weight: 700; font-style: italic;"> 해당 직원 이름, 해당 직원의 업무 평가 점수, 그리고 해당 직원의 성과에 대한 피드백을 입력 후 제출</span>을 클릭하여 해당 직원의 성과에 대한 평가를 기록하세요. 이러한 평가 조치를 통해 귀사에서는 해당 직원에 대해 필요한 조치를 취할 수 있습니다.
   
    <br/>
    <br/>
    
    </div>`,
  team_roaster_tutorial_title: "직원 명단",
  team_roaster_tutorial_detail: `<div>

개발 사무소 관리 항목에서 확인하실 수 있는 부분은 다음과 같습니다. 
    <br/>
    <br/>
    
    <ul>
        <li>신규 직원 또는 퇴사한 직원의 직책, 연봉, 입사일 또는 퇴사일, 그리고 이력서를 확인하실 수 있습니다.</li>
    </ul>
    <br/>
    
  직원 명단 확인 방법은 다음과 같습니다.
    <br/>
    -
    <br/>
    <br/>
    
    <span style="font-weight: 700">Step 1:</span> 세컨드오피스 계정 로그인하기
    <br/>
  이메일과 비밀번호를 입력하여 세컨드오피스 대시보드에 로그인해주세요.
    
    <span style="font-weight: 700">Step 2:</span> 개발 사무소 관리 클릭하기
    <br/>
 좌측 메뉴에서<span style="font-weight: 700; font-style: italic;">개발 사무소 관리</span>를 누르세요. 
    <br/>
    <br/>
    
    <span style="font-weight: 700">Step 3:</span> 직원 명단 확인하기
    <br/>
  <span style="font-weight: 700; font-style: italic;"> 팀 관리</span>를 클릭해 귀사의 직원 명단을 포함한 직원들의 이름, 직책, 연봉, 이력서, 입사/퇴사 날짜를 확인 할 수 있습니다.
    <br/>
    <br/>
    
    <span style="font-weight: 700">Step 4:</span> 입사 예정자 확인하기
    <br/>
   <span style="font-weight: 700; font-style: italic;">입사 예정자 확인</span>항목에서는 입사 예정자 이름, 포지션, 연봉, 입사 날짜, 현황 및 이력서를 확인하실 수 있습니다. 
    <br/>
    <br/>
    
    <span style="font-weight: 700">참고:</span> 연봉은 기본급만 포함된 금액을 말합니다. 
    <br/>
    <br/>
    
    </div>`,
  // view candidate page language translation in card and table view/
  candidate_status_pending: "미결정",
  candidate_status_shortlisted: "예비 합격 ",
  candidate_status_offer_made: "합격 오퍼",
  candidate_status_tech_round: "기술 면접",
  candidate_status_client_review: "고객사 검토",
  candidate_status_client_round: "최종 면접",
  candidate_status_online_tech_asses: "온라인 과제",
  candidate_status_withdrew_application: "지원 철회",
  candidate_status_hired: "최종 합격",
  candidate_status_culture_fit: "인성 면접",
  candidate_status_rejected: "불합격",
  candidate_exp: " 년차",
  candidate_cvr_status_pass: "합격",
  candidate_cvr_status_pending: "Pending",
  candidate_cvr_status_fail: "불합격",
  candidate_cvr_status_na: "NA",
  payment_status_completed: "완료",
  payment_status_pending: "미납",
  pagination_text: "한 페이지당 개수",
  // month list translation
  january_title: "1월",
  february_title: "2월",
  march_title: "3월",
  april_title: "4월",
  may_title: "5월",
  june_title: "6월",
  july_title: "7월",
  august_title: "8월",
  september_title: "9월",
  october_title: "10월",
  november_title: "11월",
  december_title: "12월",
  // toast notification title
  login_success: "로그인되었습니다.",
  hr_action_updated: "업데이트되었습니다.",
  team_performance_date_added: "직원 평가 날짜가 추가되었습니다.",
  team_performance_submit_rating: "직원 평가 세션이 추가되었습니다.",
  jobs_post_added: "채용 공고가 등록되었습니다.",
  setting_updated: "설정이 업데이트되었습니다.",
  settings_save_warning: "페이지 이동 전 하단의 저장 버튼을 클릭해주세요.",
  language_eng: "English",
  language_kor: "한국어",
  search_message: "검색 결과입니다. ",
  exchange_rate: "환율(USD)",
  request_device_added: "장비 신청이 추가되었습니다.",
  openings: "명 채용 예정",
  // device category list
  misc_software: "기타 소프트웨어",
  data_storage_system: "데이터 저장 시스템 (예. AWS클라우드)",
  headphone: "헤드폰",
  keyboard: "키보드",
  mouse: "마우스",
  keyboard_combo: "키보드/마우스 콤보",
  printer: "프린터",
  power_backup: "파워 백업 시스템 (백업 발전기)",
  power_cord: "전원 코드",
  power_adaptor: "전원 어댑터",
  laptop_stand: "노트북 스탠드",
  iot: "IoT",
  cable: "케이블",
  monitor: "모니터",
  mobile_device: "모바일 기기",
  laptop: "노트북 컴퓨터",
  other: "기타",
};
