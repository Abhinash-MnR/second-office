import i18n from "i18next";
import { initReactI18next } from "react-i18next";
import LanguageDetector from "i18next-browser-languagedetector";
import { TRANSLATIONS_EN } from "translation/English/translation";
import { TRANSLATIONS_KR } from "translation/Korean/translation";

i18n
  .use(LanguageDetector)
  .use(initReactI18next)
  .init({
    resources: {
      English: {
        translation: TRANSLATIONS_EN,
      },
      Korean: {
        translation: TRANSLATIONS_KR,
      },
    },
    fallbackLng: "English",
  });
