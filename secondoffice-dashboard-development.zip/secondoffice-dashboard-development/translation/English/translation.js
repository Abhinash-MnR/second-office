export const TRANSLATIONS_EN = {
  so_og_title: "SecondOffice",
  dashboard_menu_title: "Dashboard",
  dashboard_location_dropdown_title: "Locations",
  dashboard_office_location_your_emp_title: "Your Employees ",
  dashboard_office_location_your_freelancer_title: "Your Freelancers ",
  dashboard_management_menu_title1: "Hire Your Employees",
  dashboard_management_menu_title2: "Contact Your Globalization Specialist",
  dashboard_management_menu_title3: "Check Attendance Records",
  dashboard_management_menu_title4: "Request Supplies & Benefits",
  dashboard_management_menu_title5: "Conduct Performance Evaluations",
  dashboard_management_menu_title6: "View Expense Reports",
  recruit_menu_title: "Recruit",
  recruit_summary_card_title1: "Total Job Posts",
  recruit_summary_card_title2: "Open Job Posts",
  recruit_summary_card_title3: "Closed Job Posts",
  recruit_summary_card_title4: "Total Candidates",
  recruit_open_jobs_title: "Open Job Posts",
  recruit_closed_jobs_title: "Closed Job Posts",
  recruit_jobs_post_button_title: "Post Job",
  office_management_menu: "Office Management",
  office_management_submenu_team: "Team",
  office_management_submenu_attendance: "Attendance",
  office_management_submenu_performance: "Performance",
  office_management_submenu_log: "Management Log",
  task_management_menu: "Task Management",
  store: "Store",
  office_expense_menu: "Office Expenses",
  settings: "Settings",
  settings_save: "Save",
  help_center: "Help Center",
  dashboard_management_title: "Managements",
  //profile
  profile_backIcon_title: "Profile",
  profile_basic_info: "Basic Information",
  company_name: "Company Name",
  comapny_location: "Location",
  company_email: "Email",
  company_contact: "Contact",
  comapny_desc: "Company Description",
  edit_profile_button_title: "Edit Profile",
  profile_logout: "Logout",
  edit_profile_save: "Save Changes",
  //dashboard page language translation
  quick_action_card_title_1: "Instantly Deploy Your SecondOffice",
  quick_action_card_title_2: "Recruit New Team Members",
  quick_action_card_title_3: "Know More About Your Team",
  quick_action_card_title_4: "View Your Monthly Expenses",
  book_a_call: "Book a Call Now",
  quick_action_button_title: "Explore",
  blogs: "Blogs",
  office_title: "Your Offices",
  settings_save: "Save",
  //**recruit page language translation */
  recruit_banner_title: "Post a Job",
  recruit_banner_desc:
    "Share your requirement and we will take care of everything else.",
  recruit_button_title: "Post Now",
  recruit_open_joblist_title: "Open Job Posts",
  recruit_closed_joblist_title: "Closed Job Post",
  recruit_backIcon_title: "Recruit Your Team",
  post_job_form_title: "Post a Job",
  post_job_form_subtitle: "Add Job Information",
  job_position_name: "Job Position Name",
  job_position_location: "Location(Optional)",
  job_position_location_placeholder: "Location",
  notice_period: "Notice Period",
  job_skills: "Skills (Max 5 Skills)",
  job_skills_placeholder: "Add Skills",
  job_skill_seprated_alert_text: "Separate Tags by Comma’s",
  priority: "Priority(Optional)",
  view_priority: "Priority",
  education: "Education",
  jobs_experiance: "Year of Experience Required",
  number_of_openings: "Number of Openings",
  salary_per_annum: "Salary per Annum",
  salary_min_range: "Min",
  salary_max_range: "Max",
  salary_no_bar_text: "Salary No Bar",
  job_post_button_title: "Post",
  recruit_this_field_empty_warning_title: "This field cannot be empty",
  job_post_reset_button_title: "Reset",
  view_candidate_button_title: "View Candidates",
  view_job_post_button_title: "View Job Post",
  view_job_edit_button_title: "Edit Job Post ",
  view_job_education_title: "Education",
  view_job_experiance_title: "Year of Experience",
  view_job_salary_title: "Salary ( per annum ) ",
  view_job_notice_period_title: "Notice Period(Days) ",
  view_job_skills_title: "Skills",
  view_job_posted_title: "Posted",
  view_job_description_title: "Job Description",
  job_edit_history_backIcon_title: "Job Edit History",
  job_edit_history_table_head_date: "Date",
  job_edit_history_table_head_time: "Time",
  job_edit_history_table_head_job: "Job Post",
  job_edit_history_table_head_modified: "Modified Changes",
  job_edit_history_table_head_modifiedby: "Modified By",
  jobs_edit_history_emptybox_title: "Your job edit history will be listed here",
  view_candiates_backIcon_title: "Recruit Your Team",
  view_candidates_job_application_title: "Job Applications for",
  view_candidates_job_application_position_title: "Position",
  view_candidates_table_head_candidate: "Candidate",
  view_candidates_table_head_notice: "Notice Period",
  view_candidates_table_head_exp: "Experience",
  view_candidates_table_head_ctc: "Current Salary",
  view_candidates_table_head_ectc: "Expected Salary",
  view_candidates_table_head_resume: "Resume/Portfolio",
  view_candidates_table_head_cultural: "Culture Fit",
  view_candidates_table_head_comments: "Second Office Comments",
  view_candidates_table_head_technical: "Expertise Round",
  view_candidates_table_head_action: "Action",
  view_candidates_table_head_status: "Status",
  view_candidates_table_head_offer: "Offered Date & Time",
  view_candidate_view_resume_title: "View Resume",
  view_candidate_view_portfolio_title: "View Portfolio",
  view_candidates_emptybox_title: "Keep an eye on all job applications here!",
  view_candidate_summary_card_tittle1: "Total Candidates",
  view_candidate_summary_card_tittle2: "Shortlisted Candidate",
  view_candidate_summary_card_tittle3: "Offer Made Candidates",
  view_candidate_summary_card_tittle4: "Hired Candidates",
  edit_jobs_discard_button_title: " Discard Changes",
  edit_jobs_save_changes_title: "Save Changes",
  recruit_empty_screen_title: "No Jobs Posted!",
  recruit_empty_screen_subtitle: "No worries, you can post it now.",
  view_candidate_list_not_found: "No candidate found",
  view_candidate_notice_period_tooltip:
    "It is the period between receiving the letter of dismissal and the end of the last working day.",
  view_candidate_ctc_tooltip:
    "It is the cost a company incurs when hiring an employee, and includes all monthly components such as basic pay, reimbursements, various allowances, etc.",
  view_candidate_ectc_tooltip:
    "It is a term used to understand what a candidate is expecting from the organization in terms of their all-inclusive CTC.",
  view_candidate_culture_fit_tooltip:
    "The operations team can either shortlist or reject a candidate, post which, you can check the Discovery Round here. No further action will be possible.",
  view_candidate_actions_tooltip:
    "You can shortlist or reject a candidate from the dropdown list in the column. Note: If the Discovery Round shows that the candidate has been rejected, no further action can be taken here.",
  view_candidate_status_tooltip:
    "The status of the candidate will be visible here after recruiter chooses the appropriate action such as 'shortlist', 'pending', 'Employer Review', 'offer made', 'withdrew application', and more.",

  //** Office management english content */
  office_management_team_title: "Office Management",
  office_management_team_roaster_title: "Team Roster",
  office_management_team_roaster_table_head_emp: "Employee",
  office_management_team_roaster_table_head_position: "Position",
  office_management_team_roaster_table_head_ctc: "CTC",
  office_management_team_roaster_table_head_joining: "Joining Date",
  office_management_team_roaster_table_head_resigned: "Resigned Date",
  office_management_team_roaster_table_head_resume: "Resume",
  office_management_team_roaster_table_head_hr_actions: "HR Actions",
  office_management_team_actions_tooltip_title:
    "Prompt the HR Team to take appropriate action with respect to an employee’s performance through this section.",
  hr_actions_no_needed: "No action needed",
  hr_actions_bonus: "Bonus",
  hr_actions_termination: "Termination ",
  hr_actions_promotion: "Promotion ",
  office_management_expected_newjoiners_title: "Expected New Joiners",
  office_management_expected_newjoiners_table_head_emp: "Employee",
  office_management_expected_newjoiners_table_head_position: "Position ",
  office_management_expected_newjoiners_table_head_ctc: "CTC",
  office_management_expected_newjoiners_table_head_joining: "Joining Date",
  office_management_expected_newjoiners_table_head_hired: "Hired Date",
  office_management_expected_newjoiners_table_head_emp_status: "Status",
  office_management_expected_newjoiners_table_head_resume: "Resume",
  office_management_historic_emp_title: "Historic Employee",
  office_management_historic_emp_table_head_emp: "Employee",
  office_management_historic_emp_table_head_position: "Position ",
  office_management_historic_emp_table_head_salary: "Salary ",
  office_management_historic_emp_table_head_joining: "Joining Date",
  office_management_historic_emp_table_head_resign: "Resigned Date",
  office_management_historic_emp_table_head_resign_on: "Resigned On",
  office_management_historic_emp_table_head_resume: "Resume",
  office_management_attendance_title: "Attendance",
  office_management_attendance_table_head_date: "Date",
  office_management_attendance_table_head_log: "Log",
  office_management_attendance_table_data_view_log: "View Log",
  offie_management_performance_title: "Team Performance",
  offie_management_eveluation_button_title: "Add Evaluation Session",
  office_management_evaluation_popup_desc:
    "Choose a date when your evaluation starts",
  office_management_evaluation_popup_button_title_title:
    "Create Performance Evaluation Group",
  office_management_performance_popup_title: "Add Team Performance",
  office_management_performance_popup_title1: "Add Member Performance",
  office_management_performance_popup_desc: "Enter the below details",
  office_management_performance_popup_button_title: "Submit Rating",
  office_management_performance_table_head_emp: "Employee ",
  office_management_performance_table_head_score: "Score(10)",
  office_management_performance_table_head_comments: "HQ Comments",
  office_management_performance_table_head_action: "HR Actions",
  team_performance_hr_actions_tooltip:
    "Prompt the HR Team to take appropriate action with respect to an employee’s performance through this section.",
  team_performance_popup_form_emp_name_label: "Employee Name",
  team_performance_popup_form_score_label: "Score",
  team_performance_popup_form_feedback_label: "Feedback",
  team_performance_empty_date_added:
    "Add team performance to see the comments and scores for your employees here.",
  office_management_log_title: "Management Log",
  office_management_team_summarycard_title1: "Total Employee",
  office_management_team_summarycard_title2: "Expected joiner",
  office_management_team_summarycard_title3: "Former Employee",
  office_management_team_attendance_summarycard_title1: "Total Employee",
  office_management_team_attendance_summarycard_title2: "Present Today",
  office_management_team_attendance_summarycard_title3: "On Leave Today",
  teamRoaster_empty_screen_title:
    "Start building your team to see the list of your employees here.",
  expectedJoiners_empty_screen_title:
    "Start building your team to see the list of your employees here.",
  formerEmployee_empty_screen_title: "Former employees.",
  attendance_logs_title: "Logs",
  attendance_empty_screen_title:
    "Check the attendance status of your employees here.",
  team_performance_empty_screen_title:
    "See the comments/scores for your employees here.",
  management_logs_empty_screen_title:
    "Keep track of your management logs here.",
  //** store page content */
  store_title: "Coming Soon! ",
  store_desc:
    "Share requirements for new devices and keep up with their updates here.",
  device_management_title: "Device Management",
  submit_new_request_title: "Submit New Request",
  submit_request_title: "Submit Request",
  employee_name_title: "Employee Name",
  device_type_title: "Device Type",
  device_name_title: "Device Name",
  device_cost: "Device Cost",
  seller_name: "Seller",
  description: "Description",
  quantity: "Quantity",
  store_new_request_form_title: "Enter the details below",
  store_request_back_icon_title: "New Request",
  store_request_device_category_title: "Choose Category",
  store_request_device_brand_title: "Brand Name",
  store_request_device_quantity_title: "Quantity",
  store_request_device_empName_title: "Employee Name",
  store_request_device_desc_title: "Description ",
  store_requested_device_title: "Requested Devices",
  read_more_title: " Read More",
  show_less_title: "Show Less",
  store_empty_screen_title:
    "Share requirement for new device and keep up with their updates here.",
  //** office expense content */
  office_expense_title: "Office Expenses",
  office_expense_standard_package_title: "Standard Package ",
  office_expense_standard_package_desc: "The basic essentials ",
  office_expense_inclusive_package_title: "All-Inclusive Package ",
  year: "Year",
  month: "Month",
  search: "Search",
  office_expense_inclusive_package_desc:
    "Best practices to attract the best talent ",
  office_expense_enterprise_title: "Enterprise ",
  office_expense_enterprise_desc: "Better than a subsidiary ",
  office_expense_button_title: "Know more ",
  office_expense_banner1_title: "Top up your wallet balance at once ",
  office_expense_banner1_desc:
    "Track records of your applied funds with a user-friendly dashboard. ",
  office_expense_banner2_title: "Never lose track of your office expenses ",
  office_expense_banner2_desc:
    "Track records of your applied funds with a user-friendly dashboard. ",
  office_expense_banner3_ttile: "Stay informed about your wallet balance ",
  office_expense_banner3_desc:
    "Track your balance and keep yourself abreast of the latest exchange rate, all in one place! ",
  office_expense_tooltip:
    "Your incurred expenses and invoices can be found here.",
  applied_funds_tooltip:
    "The amount transferred by you will appear here within one working day.",
  office_expense_current_balance_title: "Your current available balance ",
  office_expense_table_head_date: "Date ",
  office_expense_table_head_total: "Total",
  office_expense_table_head_payment: "Payment Status",
  office_expense_table_head_invoice: "Invoice",
  office_expense_applied_funds_title: "Applied Funds",
  office_expense_view_invoice: "View Invoice",
  office_expense_applied_funds_table_head_date: "Date",
  office_expense_applied_funds_table_head_amount: "Amount",
  office_expense_empty_title: "See all your monthly expenses here.",
  office_expense_applied_funds_empty_title:
    "Keep an eye on your applied funds here.",
  office_expense_applied_funds_tooltip:
    "The amount transferred by you will appear here within one working day.",
  //** settings page content */
  setting_title: "Settings",
  customize_interview_module_title: "Customize Interview Module",
  customize_interview_module_desc:
    "You can customize which interview rounds should take place with the applicants for better control or according to your preference. ",
  customize_currency_mode_title: "Currency Mode",
  customize_currency_mode_desc:
    "Here you can Select the Currency as per your convenience or as per your country. ",
  customize_language_mode_title: "Language Mode",
  customize_language_mode_desc:
    "Here you can Select the Language as per your convenience or as per your country.",
  customize_usefull_link_title: "Useful Link",
  customize_usefull_link_desc:
    "Here you can look at the management log link that will give access to the mastersheet.",
  cultural_round_title: "Discovery Round",
  technical_round_title: "Technical  Round ",
  client_round_title: "Employer Round",
  online_tech_assessment_title: "Online Technical Assessment",
  currency_title: "Currencies",
  language_title: "Language",
  management_log_link_title: "Management Log Link ",
  //**help center english language */
  help_center_title: "Help Center",
  tutorial_title: "Tutorial Blogs",
  tutorial_seemore: "See more",
  faq_title: "Frequently Asked Question (FAQs)",
  faq_q1_title: "How to book a call with SecondOffice experts?",
  faq_q1_content:
    "To book a call with SecondOffice experts, follow these steps:",
  faq_q1_content_steps:
    "Log in > Book a Call Now > Select Date and Time > Confirm > Add Guests > Schedule Event.",
  faq_q2_title: "How to create or change my SecondOffice profile?",
  faq_q2_content:
    "To create or change your SecondOffice profile, follow these steps:",
  faq_q2_content_steps:
    "Log in > Profile > Edit Profile > Add Photo > Save Changes.",
  faq_q3_title: "How to post a job to build my team?",
  faq_q3_content: "To post a job, follow these steps:",
  faq_q3_content_steps: "Log in > Recruit > Post Now > Save Changes.",
  faq_q4_title: "How to check the attendance log for the day?",
  faq_q4_content: "To check the attendance log, follow these steps: ",
  faq_q4_content_steps: "Office Management > Attendance > View Log",
  faq_q5_title: "How to check the current available wallet balance?",
  faq_q5_content:
    "Go to ‘Office Expense’ and check the current available balance at the top right corner of the screen. ",
  faq_q5_content_steps: "-",
  faq_q6_title: "How to shortlist or reject a candidate?",
  faq_q6_content: "To shortlist or reject a candidate, follow these steps: ",
  faq_q6_content_steps:
    "Recruit > Open Job Posts > View Candidates > Action/Status > Shortlist or Reject.",
  faq_q7_title: "Where are office expenses recorded?",
  faq_q7_content:
    "The history of applied funds and office expenses is available for your perusal. Click on Office Expenses to view a detailed history of wallet balance, monthly expenses, and applied funds.",
  faq_q7_content_steps: "-",
  faq_q8_title: "How to customize the interview modules?",
  faq_q8_content:
    "You can choose which interview round should take place as per your preference. To customize your interview modules, follow these steps:",
  faq_q8_content_steps:
    "Settings > Customize Interview Module > Discovery Round > Expertise Round > Employer Round",
  faq_q9_title: "How to change the frequency of performance reviews?",
  faq_q9_content:
    "You can choose the frequency of performance evaluation from weekly, bi-weekly, monthly, and quarterly. To change the frequency of performance reviews, follow these steps:",
  faq_q9_content_steps:
    "Settings > Other Settings > Performance Review Frequency.",
  faq_q10_title: "How to set default currency?",
  faq_q10_content: "To set default currency, follow these steps: ",
  faq_q10_content_steps: "Settings > Other Settings > Currency.",
  //** tutorial 1  Book call  */
  book_a_call_tutoial_title: "Book a call to deploy your secondoffice",
  book_a_call_tutoial_detail: `<div>
    You can expand your office globally and meet your growth goals by hiring
    from the international talent pool. The prospect of global hiring is
    very complex and confusing for a layperson. To get a better
    understanding of employing great candidates cross-border, you can set up
    a call with our SecondOffice experts.
    <br />
    <br />

    Book a call to deploy your satellite office
    <br />
    <br />

    <span style="font-weight: 700">Step 1:</span> Log in to SecondOffice
    <br />
    Enter your email address and password in the given space to log into
    your SecondOffice account.

    <br />
    <br />
    <span style="font-weight: 700">Step 2:</span> Click on Book a Call Now

    <br />
    Click on the 
    <span style="font-weight: 700; font-style: italic;">
    Book a Call Now 
    </span>
    icon
    <br />
    <br />

    <span style="font-weight: 700">Step 3:</span> Select Date and Time
    
    <br />
    Select the date and time from the calendar.
    <br />
    <br />

    <span style="font-weight: 700">Step 4:</span> Click on Confirm 
    <br />
    Click on <span style="font-weight: 700; font-style: italic;">
    confirm 
    </span> and then add your name and email.
    <br />
    <br />

    <span style="font-weight: 700">Step 5:</span> Add Guests 
    <br />
    You can add up to 10 guest emails.
    <br />
    <br />

    <span style="font-weight: 700">Step 6:</span> Click on Schedule Event
    <br />

    Click on <span style="font-weight: 700; font-style: italic;">Schedule Event,</span> and our SecondOffice expert will reach out to
    you.
    <br />
    <br />
  </div>`,
  office_management_tutoial_title:
    "Know more about your team in office management",
  office_management_tutoial_detail: `<div>

    In the Office Management section, you can learn the following:
    <br/>
    The details about new or old employees, such as their position within the company, salary, joining or resignation date, and resumes.
    <br/>
    How to track their team performance by evaluating their HR scores, HR comments, and more from this section.
    <br/>
    <br/>
    
    Learn how to view the team roster and track team performance.
    <br/>
    <br/>
    
    <span style="font-weight: 700">Step 1:</span> Log in to SecondOffice
    <br/>
    Enter your email address and password in the given space to log into your SecondOffice account.
    <br/>
    <br/>

    <span style="font-weight: 700">Step 2:</span> Click Explore
    <br/>
    Click on the <span style="font-weight: 700; font-style: italic;">Explore</span> button under the ‘Know More About Your Team’ section.
    <br/>
    <br/>
    
    <span style="font-weight: 700">Step 3:</span> View Team Roster
    <br/>
    By clicking on <span style="font-weight: 700; font-style: italic;">Team</span>, you can view employee team rosters, including employee name, position, salary, joining date, and resignation date. You can also view employee resumes.
    <br/>
    <br/>
    
    <span style="font-weight: 700">Step 4:</span> View Attendance
    <br/>
    Click on <span style="font-weight: 700; font-style: italic;">Attendance</span>, to keep a track of your team attendance.
    <br/>
    <br/>
    
    <span style="font-weight: 700">Step 5:</span> View Performance
    <br/>
    You can scroll down to the <span style="font-weight: 700; font-style: italic;">Team Performace</span> section to view employee performance scores, HR comments, and HQ comments.
    <br/>
    <br/>
    
    <span style="font-weight: 700">Step 6:</span> View Management log
    <br/>
    Click on <span style="font-weight: 700; font-style: italic;">Management Log</span> to access log maintained by management.
    <br/>
    <br/>
    
    </div>`,
  recruit_tutoial_title: "Post a job to recruit your team",
  recruit_tutoial_detail: `<div>

    Now that you have decided to deploy your satellite office in India, it’s time to post the job to recruit your dream team. To hire from the pool of Indian talent, you need to share your requirements with us, and our experts will take over from there. 
    <br/>
    <br/>
    
    To post a job, follow the below-mentioned steps:
    <br/>
    <br/>
    
    <span style="font-weight: 700">Step 1:</span> Log in to SecondOffice
    <br/>
    Enter your email address and password in the given space to log into your SecondOffice account.
    <br/>
    <br/>

    <span style="font-weight: 700">Step 2:</span> Click Explore
    <br/>
    Click on the Explore button under the <span style="font-weight: 700; font-style: italic;">Recruit New Team Members</span> section.
    Alternatively, you can also click on the <span style="font-weight: 700; font-style: italic;">Recruit</span> button from the sidebar on the left.
    <br/>
    <br/>
    
    <span style="font-weight: 700">Step 3:</span> Click on Post Now
    <br/>
    Click on the <span style="font-weight: 700; font-style: italic;">Post Now</span> button 
    <br/>
    <br/>
    
    <span style="font-weight: 700">Step 4:</span> Add job information
    <br/>
    Add job information like Job Position Name, Location, Notice Period, Skills (Max 5 Skills), etc.
    Also, add a comprehensive job description comprising plain English that explains the position's scope, duties, and responsibilities.
    <br/>
    <br/>
    
    <span style="font-weight: 700">Step 5:</span> Click on Save Changes
    <br/>
    To post the respected job, click on the <span style="font-weight: 700; font-style: italic;">Save Changes</span> button at the lower right corner of the page.
    <br/>
    <br/>
    
    </div>`,
  office_expense_tutorial_title: "Office expenses",
  office_expense_tutorial_detail: `<div>
      The process of deploying your SecondOffice is very economical, and
      we ensure that you can create a team of the best talents at a
      fraction of the cost. You can also keep track of your expenses and
      funds by following the given steps:
      <br />
      <br />
      <span style="font-weight: 700">Step 1:</span> Log in to
      SecondOffice
      <br />
      Enter your email address and password in the given space to log
      into your SecondOffice account.
      <br />
      <br />
      <span style="font-weight: 700">Step 2:</span> Click Office
      Expenses
      <br />
      Click on the <span style="font-weight: 700; font-style: italic;">Office Expenses</span> button from the sidebar menu on the
      left.
      <br />
      <br />
      <span style="font-weight: 700">Step 3:</span> View Your Current
      Available Balance
      <br />
      Check your current wallet balance on the right side of the screen.
      You can also click on the to stay informed about the latest
      exchange rates.
      <br />
      <br />
      <span style="font-weight: 700">Step 4:</span> Check Office
      Expenses
      <br />
      Once an expense is incurred, an invoice is generated. You can see
      that expense along with its payment status in this section. To
      check the generated invoice, click the <span style="font-weight: 700; font-style: italic;">View Invoice</span> button.
      <br />
      <br />
      <span style="font-weight: 700">Step 5:</span> Check Applied
      Funds
      <br />
      In this section, you can find the history of the amount
      transferred to your wallet. All you need to do is transfer the
      amount, which will be displayed here automatically within one
      working day.
      <br />
      <br />
    </div>`,
  view_candidate_tutorial_title: "View candidate page",
  view_candidate_tutorial_detail: `<div>

    After receiving the requirements for a specific job post, we keep employers updated about the prospective candidates who have applied for the same. The employers can check the status of their job post by following the given steps:
    <br/>
    <br/>
    
    <span style="font-weight: 700">Step 1:</span> Log in to SecondOffice
    <br/>
    Enter your email address and password in the given space to log into your SecondOffice account.
    <br/>
    <br/>
    
    <span style="font-weight: 700">Step 2:</span> Click Recruit
    <br/>
    Click on the <span style="font-weight: 700; font-style: italic;">Recruit</span> button from the sidebar on the left.
    <br/>
    <br/>
    
    <span style="font-weight: 700">Step 3:</span> View Candidates
    <br/>
    Click on the <span style="font-weight: 700; font-style: italic;">View Candidates</span> button in the Open Job Posts section.
    <br/>
    <br/>
    
    <span style="font-weight: 700">Step 4:</span> View Job Applications for the Position
    <br/>
    Scroll down to view the list of candidates who have applied for the position; here, you can check their names along with other information:
    <br/>
    <ul>
        <li>Notice period: It is the amount of time an employee has to serve in an organization from their date of resignation.</li>
        <li>Experience: Time period an employee has served in their last organizations.</li>
        <li>CTC: It is the cost a company incurs when hiring an employee and includes all monthly components such as basic pay, reimbursements, various allowances, etc.</li>
        <li>ECTC: It is a term used to understand what a candidate expects from the organization regarding their CTC.</li>
        <li>Resume/portfolio: You can view the resume or portfolio of the prospective employee by clicking on <span style="font-weight: 700; font-style: italic;">View Resume or View Portfolio</span>, respectively.</li>
        <li>Discovery Round: The operations team can either shortlist or reject a candidate, post which, you can check the Discovery Round here. No further action will be possible.</li>
        <li>Additional Comments: You can find any additional comments made by HR from the backend.</li>
        <li>Expertise Round: Any comment made by HR in the Expertise Round is visible here.</li>
        <li>Action: You can shortlist or reject a candidate from the dropdown list in the column.</li>
        Note: If the Discovery Round shows that the candidate has been rejected, no further action can be taken here.
        <li>Status: The status of the candidate will be visible here after HR chooses the appropriate action from the dropdown menu. The row will change color in accordance with the status. The following colors reflect the given statuses:</li>
    </ul>
    <ul>
    <span style="font-weight: 700; font-style: italic;">→ White:</span> When a candidate is shortlisted, and if their status is pending, the row will stay white. When the row is white, the client has the power to take action, i.e, to shortlist or reject the candidate.
    <br/>
    <span style="font-weight: 700; font-style: italic;">→  Yellow:</span> Once the candidate reaches any interview round such as Culture Round, Expertise Round, or Online Tech Round, the row will turn yellow. In other words, yellow means that the hiring is in process.
    <br/>
    <span style="font-weight: 700; font-style: italic;">→ Blue:</span>At the time of Employer Review, Employer Round, and when the candidate has been offered a position, the row will stay blue. It means that the hiring is pending completion.
    <br/>
    <span style="font-weight: 700; font-style: italic;">→ Green:</span>When the hiring is completed and the candidate is hired, the row will turn green.
    <br/>
    <span style="font-weight: 700; font-style: italic;">→ Red:</span>The row will turn red if the hiring is completed & not hired due to the candidate being rejected, if they withdraw their application, or being reconsidered for the position.
    <br/>
    </ul>
    <br/>
    <br/>
    
    </div>`,
  performance_tutorial_title: "Performance evaluation",
  performance_tutorial_detail: `<div>

    In the <span style="font-weight: 700; font-style: italic;">Office Management</span> section, you can learn the following:
    <br/>
    <br/>
    
    <ul>
        <li>How to track their team performance by evaluating their HR scores, HR comments, and more from this section.</li>
    </ul>
    <br/>
    
    Learn how to track team performance.
    <br/>
    -
    <br/>
    <br/>
    
    <span style="font-weight: 700">Step 1:</span> Log in to SecondOffice
    <br/>
    Enter your email address and password in the given space to log into your SecondOffice account.
<br/>
    <br/>
    <span style="font-weight: 700">Step 2:</span> Click on Office Management
    <br/>
    Click on <span style="font-weight: 700; font-style: italic;">Office Management</span> from the left navigation panel.
    <br/>
    <br/>
    
    <span style="font-weight: 700">Step 3:</span> View Performance
    <br/>
    You can scroll down to the <span style="font-weight: 700; font-style: italic;">Performance</span> section to set the duration of employee evaluation and add  employee performance scores.
    <br/>
    <br/>
    <br/>
    
    To set the duration of the evaluation process, click on <span style="font-weight: 700; font-style: italic;">Add Evaluation Session</span>, select the start date, and click on <span style="font-weight: 700; font-style: italic;">Create Performance</span> Evaluation Group. 
    This will let you create a time frame during which an employee or team will be evaluated basis their work performance.
    <br/>
    <br/>
    
    To score an employee’s performance, click on <span style="font-weight: 700; font-style: italic;">Add Team Performance</span> and enter employee name, their score, and feedback on their employee performance. Click on <span style="font-weight: 700; font-style: italic;">Submit</span> to successfully record their performance evaluation. 
    This will let you review an employee or team’s work performance and allow you to be able to take the necessary action.
    <br/>
    <br/>
    
    </div>`,
  team_roaster_tutorial_title: "Team Roster",
  team_roaster_tutorial_detail: `<div>

    In the Office Management section, you can learn the following:
    <br/>
    <br/>
    
    <ul>
        <li>The details about new or old employees, such as their position within the company, salary, joining or resignation date, and resumes.</li>
    </ul>
    <br/>
    
    Learn how to view the team roster.
    <br/>
    -
    <br/>
    <br/>
    
    <span style="font-weight: 700">Step 1:</span> Log in to SecondOffice
    <br/>
    Enter your email address and password in the given space to log into your SecondOffice account.
    
    <span style="font-weight: 700">Step 2:</span> Click on Office Management
    <br/>
    Click on <span style="font-weight: 700; font-style: italic;">Office Management</span> from the left navigation panel.
    <br/>
    <br/>
    
    <span style="font-weight: 700">Step 3:</span> View Team Roster
    <br/>
    You can view employee team rosters by clicking on <span style="font-weight: 700; font-style: italic;">Team</span>, including employee name, position, salary, joining date, and resignation date. You can also view employee resumes.
    <br/>
    <br/>
    
    <span style="font-weight: 700">Step 4:</span> View Expected New Joiners
    <br/>
    Scroll down to view the <span style="font-weight: 700; font-style: italic;">expected new joiners</span> section, where you can check their names, the position in which they would be joining the company, their CTC, their expected joining date, and their employment status. You can also view candidate resumes.
    <br/>
    <br/>
    
    <span style="font-weight: 700">NOTE:</span> CTC is the cost a company incurs when hiring an employee, and includes all monthly components such as basic pay, reimbursements, various allowances, etc
    <br/>
    <br/>
    
    </div>`,

  // view candidate page language translation in card and table view/
  candidate_status_pending: "Pending",
  candidate_status_shortlisted: "Shortlisted ",
  candidate_status_offer_made: "Offer Made ",
  candidate_status_tech_round: "Expertise Round ",
  candidate_status_client_review: "Employer Review ",
  candidate_status_client_round: "Employer Round ",
  candidate_status_online_tech_asses: "Online Technical Assess...",
  candidate_status_withdrew_application: "Withdrew Application",
  candidate_status_hired: "Hired",
  candidate_status_online_culture_fit: "Discovery Round",
  candidate_status_rejected: "Rejected",
  candidate_exp: " Years",
  candidate_cvr_status_pass: "Pass",
  candidate_cvr_status_pending: "Pending",
  candidate_cvr_status_fail: "Fail",
  candidate_cvr_status_na: "NA",
  payment_status_completed: "Completed",
  payment_status_pending: "Pending",
  pagination_text: "Rows Per Page",

  // month list translation
  january_title: "January",
  february_title: "February",
  march_title: "March",
  april_title: "April",
  may_title: "May",
  june_title: "June",
  july_title: "July",
  august_title: "August",
  september_title: "September",
  october_title: "October",
  november_title: "November",
  december_title: "December",
  // toast notification title
  login_success: "Login Successfully",
  hr_action_updated: "HR action has been updated.",
  team_performance_date_added: "Team Performance Date added",
  team_performance_submit_rating: "Team Performance Added",
  jobs_post_added: "Your job post has been added.",
  setting_updated: "Your setting has been updated.",
  settings_save_warning: "Save the changes you've made before leaving.",
  language_eng: "English",
  language_kor: "한국어",
  search_message:
    "Based on your search and filters, we found the following results.",
  exchange_rate: "Exchange Rate (USD)",
  request_device_added: "Request Device Added.",
  openings: "openings",
  // device category list
  misc_software: "Misc Software",
  data_storage_system: "Data Storage System",
  headphone: "Headphone",
  keyboard: "Keyboard",
  mouse: "Mouse",
  keyboard_combo: "Keyboard/Mouse Combo",
  printer: "Printer",
  power_backup: "Power Backup System",
  power_cord: "Power Cord",
  power_adaptor: "Power Adaptor",
  laptop_stand: "Laptop Stand",
  iot: "IoT",
  cable: "Cable",
  monitor: "Monitor",
  mobile_device: "Mobile Devices",
  laptop: "Computing Device | Laptop",
  other: "Other",
};
