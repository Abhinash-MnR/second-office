export default [
  {
    label: "0-50",
    value: "0-3",
  },
  {
    label: "50-100",
    value: "3-6",
  },
  {
    label: "100-167",
    value: "6-10",
  },
  {
    label: "167-250",
    value: "10-15",
  },
  {
    label: "250-365",
    value: "15-22",
  },
  {
    label: "365+",
    value: "22-100",
  },
  {
    label: "Salary No Bar",
    value: "0-0",
  },
  {
    label: "As per the market standards",
    value: "1-1",
  },
];
