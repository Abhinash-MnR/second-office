export default [

  {
    label: "Pending",
    value: "Pending",
  },
  {
    label: "Pass",
    value: "Pass",
  },
  {
    label: "Fail",
    value: "Fail",
  },
];