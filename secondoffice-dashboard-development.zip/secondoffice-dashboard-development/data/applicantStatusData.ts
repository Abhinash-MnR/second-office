export default [
  {
    label: "Pending",
    value: "Pending",
  },
  {
    label: "Shortlisted",
    value: "Shortlisted",
  },
  {
    label: "Rejected",
    value: "Rejected",
  },
];
