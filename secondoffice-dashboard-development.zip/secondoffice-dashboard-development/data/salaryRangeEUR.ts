export default [
  {
    label: "0-0.036",
    value: "0-3",
  },
  {
    label: "0.036-0.072",
    value: "3-6",
  },
  {
    label: "0.072-0.12",
    value: "6-10",
  },
  {
    label: "0.12-0.18",
    value: "10-15",
  },
  {
    label: "0.18-0.026",
    value: "15-22",
  },
  {
    label: "0.026+",
    value: "22-100",
  },
  {
    label: "Salary No Bar",
    value: "0-0",
  },
  {
    label: "As per the market standards",
    value: "1-1",
  },
];
