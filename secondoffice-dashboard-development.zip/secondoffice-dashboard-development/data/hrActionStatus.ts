export default [
    {
        label: "No action needed",
        value: "No action needed",
    },
    {
        label: "Bonus",
        value: "Bonus",
    },
    {
        label: "Termination",
        value: "Termination",
    },
    {
        label: "Promotion",
        value: "Promotion",
    },
];



