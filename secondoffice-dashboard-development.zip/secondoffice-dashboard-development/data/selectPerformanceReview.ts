export default [
    {
        label: "Weekly",
        value: "Weekly",
    },
    {
        label: "Bi-weekly",
        value: "Bi-weekly",
    },
    {
        label: "Monthly",
        value: "Monthly",
    },
    {
        label: "Quarterly",
        value: "Quarterly",
    },
];