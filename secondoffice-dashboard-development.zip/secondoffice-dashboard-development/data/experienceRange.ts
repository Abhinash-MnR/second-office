export default [
  {
    label: "0-1",
    value: "0-1",
  },
  {
    label: "1-3",
    value: "1-3",
  },
  {
    label: "3-6",
    value: "3-6",
  },
  {
    label: "6-10",
    value: "6-10",
  },
  {
    label: "10+",
    value: "10-100",
  },
];
