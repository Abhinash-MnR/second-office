export default [
    {
        label: "INR",
        value: "INR",
    },
    {
        label: "KRW",
        value: "KRW",
    },
    {
        label: "USD",
        value: "USD",
    },
    {
        label: "EUR",
        value: "EUR",
    },
];