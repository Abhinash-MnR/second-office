export default [
  {
    id: 0,
    title: "Book a call to deploy your secondoffice",
    slug: "book-a-call-to-deploy-your-secondoffice",
    details: `<div>
    You can expand your office globally and meet your growth goals by hiring
    from the international talent pool. The prospect of global hiring is
    very complex and confusing for a layperson. To get a better
    understanding of employing great candidates cross-border, you can set up
    a call with our SecondOffice experts.
    <br />
    <br />

    Book a call to deploy your satellite office
    <br />
    <br />

    <span style="font-weight: 700">Step 1:</span> Log in to SecondOffice
    <br />
    Enter your email address and password in the given space to log into
    your SecondOffice account.

    <br />
    <br />
    <span style="font-weight: 700">Step 2:</span> Click on Book a Call Now

    <br />
    Click on the 
    <span style="font-weight: 700; font-style: italic;">
    Book a Call Now 
    </span>
    icon
    <br />
    <br />

    <span style="font-weight: 700">Step 3:</span> Select Date and Time
    
    <br />
    Select the date and time from the calendar.
    <br />
    <br />

    <span style="font-weight: 700">Step 4:</span> Click on Confirm 
    <br />
    Click on <span style="font-weight: 700; font-style: italic;">
    confirm 
    </span> and then add your name and email.
    <br />
    <br />

    <span style="font-weight: 700">Step 5:</span> Add Guests 
    <br />
    You can add up to 10 guest emails.
    <br />
    <br />

    <span style="font-weight: 700">Step 6:</span> Click on Schedule Event
    <br />

    Click on <span style="font-weight: 700; font-style: italic;">Schedule Event,</span> and our SecondOffice expert will reach out to
    you.
    <br />
    <br />
  </div>`,
  },
  {
    id: 1,
    title: "Know more about your team in office management",
    slug: "know-more-about-your-team-in-office-management",
    details: `<div>

    In the Office Management section, you can learn the following:
    <br/>
    The details about new or old employees, such as their position within the company, salary, joining or resignation date, and resumes.
    <br/>
    How to track their team performance by evaluating their HR scores, HR comments, and more from this section.
    <br/>
    <br/>
    
    Learn how to view the team roster and track team performance.
    <br/>
    <br/>
    
    <span style="font-weight: 700">Step 1:</span> Log in to SecondOffice
    <br/>
    Enter your email address and password in the given space to log into your SecondOffice account.
    <br/>
    <br/>

    <span style="font-weight: 700">Step 2:</span> Click Explore
    <br/>
    Click on the <span style="font-weight: 700; font-style: italic;">Explore</span> button under the ‘Know More About Your Team’ section.
    <br/>
    <br/>
    
    <span style="font-weight: 700">Step 3:</span> View Team Roster
    <br/>
    By clicking on <span style="font-weight: 700; font-style: italic;">Team</span>, you can view employee team rosters, including employee name, position, salary, joining date, and resignation date. You can also view employee resumes.
    <br/>
    <br/>
    
    <span style="font-weight: 700">Step 4:</span> View Attendance
    <br/>
    Click on <span style="font-weight: 700; font-style: italic;">Attendance</span>, to keep a track of your team attendance.
    <br/>
    <br/>
    
    <span style="font-weight: 700">Step 5:</span> View Performance
    <br/>
    You can scroll down to the <span style="font-weight: 700; font-style: italic;">Team Performace</span> section to view employee performance scores, HR comments, and HQ comments.
    <br/>
    <br/>
    
    <span style="font-weight: 700">Step 6:</span> View Management log
    <br/>
    Click on <span style="font-weight: 700; font-style: italic;">Management Log</span> to access log maintained by management.
    <br/>
    <br/>
    
    </div>`,
  },

  {
    id: 2,
    title: "Post a job to recruit your team",
    slug: "post-a-job-to-recruit-your-team",
    details: `<div>

    Now that you have decided to deploy your satellite office in India, it’s time to post the job to recruit your dream team. To hire from the pool of Indian talent, you need to share your requirements with us, and our experts will take over from there. 
    <br/>
    <br/>
    
    To post a job, follow the below-mentioned steps:
    <br/>
    <br/>
    
    <span style="font-weight: 700">Step 1:</span> Log in to SecondOffice
    <br/>
    Enter your email address and password in the given space to log into your SecondOffice account.
    <br/>
    <br/>

    <span style="font-weight: 700">Step 2:</span> Click Explore
    <br/>
    Click on the Explore button under the <span style="font-weight: 700; font-style: italic;">Recruit New Team Members</span> section.
    Alternatively, you can also click on the <span style="font-weight: 700; font-style: italic;">Recruit</span> button from the sidebar on the left.
    <br/>
    <br/>
    
    <span style="font-weight: 700">Step 3:</span> Click on Post Now
    <br/>
    Click on the <span style="font-weight: 700; font-style: italic;">Post Now</span> button 
    <br/>
    <br/>
    
    <span style="font-weight: 700">Step 4:</span> Add job information
    <br/>
    Add job information like Job Position Name, Location, Notice Period, Skills (Max 5 Skills), etc.
    Also, add a comprehensive job description comprising plain English that explains the position's scope, duties, and responsibilities.
    <br/>
    <br/>
    
    <span style="font-weight: 700">Step 5:</span> Click on Save Changes
    <br/>
    To post the respected job, click on the <span style="font-weight: 700; font-style: italic;">Save Changes</span> button at the lower right corner of the page.
    <br/>
    <br/>
    
    </div>`,
  },
  {
    id: 3,
    title: "Office expenses",
    slug: "office-expenses",
    details: `<div>
      The process of deploying your SecondOffice is very economical, and
      we ensure that you can create a team of the best talents at a
      fraction of the cost. You can also keep track of your expenses and
      funds by following the given steps:
      <br />
      <br />
      <span style="font-weight: 700">Step 1:</span> Log in to
      SecondOffice
      <br />
      Enter your email address and password in the given space to log
      into your SecondOffice account.
      <br />
      <br />
      <span style="font-weight: 700">Step 2:</span> Click Office
      Expenses
      <br />
      Click on the <span style="font-weight: 700; font-style: italic;">Office Expenses</span> button from the sidebar menu on the
      left.
      <br />
      <br />
      <span style="font-weight: 700">Step 3:</span> View Your Current
      Available Balance
      <br />
      Check your current wallet balance on the right side of the screen.
      You can also click on the to stay informed about the latest
      exchange rates.
      <br />
      <br />
      <span style="font-weight: 700">Step 4:</span> Check Office
      Expenses
      <br />
      Once an expense is incurred, an invoice is generated. You can see
      that expense along with its payment status in this section. To
      check the generated invoice, click the <span style="font-weight: 700; font-style: italic;">View Invoice</span> button.
      <br />
      <br />
      <span style="font-weight: 700">Step 5:</span> Check Applied
      Funds
      <br />
      In this section, you can find the history of the amount
      transferred to your wallet. All you need to do is transfer the
      amount, which will be displayed here automatically within one
      working day.
      <br />
      <br />
    </div>`,
  },
  {
    id: 4,
    title: "View candidate page",
    slug: "view-candidate-page",
    details: `<div>

    After receiving the requirements for a specific job post, we keep employers updated about the prospective candidates who have applied for the same. The employers can check the status of their job post by following the given steps:
    <br/>
    <br/>
    
    <span style="font-weight: 700">Step 1:</span> Log in to SecondOffice
    <br/>
    Enter your email address and password in the given space to log into your SecondOffice account.
    <br/>
    <br/>
    
    <span style="font-weight: 700">Step 2:</span> Click Recruit
    <br/>
    Click on the <span style="font-weight: 700; font-style: italic;">Recruit</span> button from the sidebar on the left.
    <br/>
    <br/>
    
    <span style="font-weight: 700">Step 3:</span> View Candidates
    <br/>
    Click on the <span style="font-weight: 700; font-style: italic;">View Candidates</span> button in the Open Job Posts section.
    <br/>
    <br/>
    
    <span style="font-weight: 700">Step 4:</span> View Job Applications for the Position
    <br/>
    Scroll down to view the list of candidates who have applied for the position; here, you can check their names along with other information:
    <br/>
    <ul>
        <li>Notice period: It is the amount of time an employee has to serve in an organization from their date of resignation.</li>
        <li>Experience: Time period an employee has served in their last organizations.</li>
        <li>CTC: It is the cost a company incurs when hiring an employee and includes all monthly components such as basic pay, reimbursements, various allowances, etc.</li>
        <li>ECTC: It is a term used to understand what a candidate expects from the organization regarding their CTC.</li>
        <li>Resume/portfolio: You can view the resume or portfolio of the prospective employee by clicking on <span style="font-weight: 700; font-style: italic;">View Resume or View Portfolio</span>, respectively.</li>
        <li>Cultural round: The operations team can either shortlist or reject a candidate, post which, you can check the Cultural Round here. No further action will be possible.</li>
        <li>Additional Comments: You can find any additional comments made by HR from the backend.</li>
        <li>Technical Round: Any comment made by HR in the technical round is visible here.</li>
        <li>Action: You can shortlist or reject a candidate from the dropdown list in the column.</li>
        Note: If the Cultural Round shows that the candidate has been rejected, no further action can be taken here.
        <li>Status: The status of the candidate will be visible here after HR chooses the appropriate action from the dropdown menu. The row will change color in accordance with the status. The following colors reflect the given statuses:</li>
    </ul>
    <ul>
    <span style="font-weight: 700; font-style: italic;">→ White:</span> When a candidate is shortlisted, and if their status is pending, the row will stay white. When the row is white, the client has the power to take action, i.e, to shortlist or reject the candidate.
    <br/>
    <span style="font-weight: 700; font-style: italic;">→  Yellow:</span> Once the candidate reaches any interview round such as Culture Round, Technical Round, or Online Tech Round, the row will turn yellow. In other words, yellow means that the hiring is in process.
    <br/>
    <span style="font-weight: 700; font-style: italic;">→ Blue:</span>At the time of client review, client round, and when the candidate has been offered a position, the row will stay blue. It means that the hiring is pending completion.
    <br/>
    <span style="font-weight: 700; font-style: italic;">→ Green:</span>When the hiring is completed and the candidate is hired, the row will turn green.
    <br/>
    <span style="font-weight: 700; font-style: italic;">→ Red:</span>The row will turn red if the hiring is completed & not hired due to the candidate being rejected, if they withdraw their application, or being reconsidered for the position.
    <br/>
    </ul>
    <br/>
    <br/>
    
    </div>`,
  },

  {
    id: 5,
    title: "Performance evaluation",
    slug: "performance-evaluation",
    details: `<div>

    In the <span style="font-weight: 700; font-style: italic;">Office Management</span> section, you can learn the following:
    <br/>
    <br/>
    
    <ul>
        <li>How to track their team performance by evaluating their HR scores, HR comments, and more from this section.</li>
    </ul>
    <br/>
    
    Learn how to track team performance.
    <br/>
    -
    <br/>
    <br/>
    
    <span style="font-weight: 700">Step 1:</span> Log in to SecondOffice
    <br/>
    Enter your email address and password in the given space to log into your SecondOffice account.
    
    <span style="font-weight: 700">Step 2:</span> Click on Office Management
    <br/>
    Click on <span style="font-weight: 700; font-style: italic;">Office Management</span> from the left navigation panel.
    <br/>
    <br/>
    
    <span style="font-weight: 700">Step 3:</span> View Performance
    <br/>
    You can scroll down to the <span style="font-weight: 700; font-style: italic;">Performance</span> section to set the duration of employee evaluation and add  employee performance scores.
    <br/>
    <br/>
    <br/>
    
    To set the duration of the evaluation process, click on <span style="font-weight: 700; font-style: italic;">Add Evaluation Session</span>, select the start date, and click on <span style="font-weight: 700; font-style: italic;">Create Performance</span> Evaluation Group. 
    This will let you create a time frame during which an employee or team will be evaluated basis their work performance.
    <br/>
    <br/>
    
    To score an employee’s performance, click on <span style="font-weight: 700; font-style: italic;">Add Team Performance</span> and enter employee name, their score, and feedback on their employee performance. Click on <span style="font-weight: 700; font-style: italic;">Submit</span> to successfully record their performance evaluation. 
    This will let you review an employee or team’s work performance and allow you to be able to take the necessary action.
    <br/>
    <br/>
    
    </div>`,
  },

  {
    id: 6,
    title: "Team Roster",
    slug: "team-roster",
    details: `<div>

    In the Office Management section, you can learn the following:
    <br/>
    <br/>
    
    <ul>
        <li>The details about new or old employees, such as their position within the company, salary, joining or resignation date, and resumes.</li>
    </ul>
    <br/>
    
    Learn how to view the team roster.
    <br/>
    -
    <br/>
    <br/>
    
    <span style="font-weight: 700">Step 1:</span> Log in to SecondOffice
    <br/>
    Enter your email address and password in the given space to log into your SecondOffice account.
    
    <span style="font-weight: 700">Step 2:</span> Click on Office Management
    <br/>
    Click on <span style="font-weight: 700; font-style: italic;">Office Management</span> from the left navigation panel.
    <br/>
    <br/>
    
    <span style="font-weight: 700">Step 3:</span> View Team Roster
    <br/>
    You can view employee team rosters by clicking on <span style="font-weight: 700; font-style: italic;">Team</span>, including employee name, position, salary, joining date, and resignation date. You can also view employee resumes.
    <br/>
    <br/>
    
    <span style="font-weight: 700">Step 4:</span> View Expected New Joiners
    <br/>
    Scroll down to view the <span style="font-weight: 700; font-style: italic;">expected new joiners</span> section, where you can check their names, the position in which they would be joining the company, their CTC, their expected joining date, and their employment status. You can also view candidate resumes.
    <br/>
    <br/>
    
    <span style="font-weight: 700">NOTE:</span> CTC is the cost a company incurs when hiring an employee, and includes all monthly components such as basic pay, reimbursements, various allowances, etc
    <br/>
    <br/>
    
    </div>`,
  },
];
