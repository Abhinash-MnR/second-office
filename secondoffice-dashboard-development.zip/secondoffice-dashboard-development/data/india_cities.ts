export default ["Pune", "Noida", "Hyderabad", "Bangalore"];
