export const markers = [
  // {
  //   city: "Ahmedabad",
  //   country: "India",
  //   address1: "The First, A block, 11F",
  //   address2: "Vastrapur, Gujarat 380015",
  //   coordinates: [72, 25],
  //   images: [
  //     "https://imageproxy-v2.services.lokalebasen.dk/330x255/lb-images-asia/in/5257666/9416275-the-first-b-h-keshav-baugh-party-plot-nr-shivalik-high-street-vastrapur-ahmedabad.jpg?v=m1625704724",
  //     "https://img.staticmb.com/mbimages/project/Photo_h310_w462/2019/04/24/Project-Photo-18-The-First-Ahmedabad-5085229_345_1366_310_462.jpg",
  //   ],
  // },
  {
    city: "Bengaluru",
    country: "India",
    address1: "No. 19, 4th C Cross Koramangala Industrial",
    address2: "5th Block, Area, Karnataka 560095",
    coordinates: [77, 15],
    images: [
      "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcR1C-n7RBztGlWhH6c95AhqaxMkw2iHynEm6qmDG4_UzX_U_JKU7WC8tE2y1kjmdSb79PA&usqp=CAU",
      "https://www.fleco.in/wp-content/uploads/2021/11/bhive-5block-870x555.jpg",
    ],
  },
  {
    city: "Hyderabad",
    country: "India",
    address1: "Botanical Garden Rd Kondapur 4F",
    address2: "192, Telangana 500084",
    coordinates: [77, 20],
    images: [
      "https://is1-2.housingcdn.com/01c16c28/2458192e4341ceb069d90d7cfaad7b38/v0/medium/3_bhk_apartment-for-sale-kondapur_hyderabad-Hyderabad-others.jpg",
      "https://is1-3.housingcdn.com/01c16c28/0b18ac2ab6a03e032ddb9296fb26479a/v0/medium/2_bhk_apartment-for-sale-kondapur_hyderabad-Hyderabad-others.jpg",
    ],
  },
  {
    city: "Noida",
    country: "India",
    address1: "Logix Cyber Park Tower B, 9F",
    address2:
      "Tower - A, Office No, i-Thum, 602, Block A, Industrial Area, Sector 62, Noida, Uttar Pradesh 201309",
    coordinates: [80, 28],
    images: [
      // "https://jsgofficespace.co.in/wp-content/uploads/2021/07/logix.jpg",
      "https://ithumworld.com/wp-content/uploads/2022/04/ithum-elevation.jpg",
      "https://instahyre-2.s3-ap-south-1.amazonaws.com/media/CACHE/images/images/office-photos/base/32712/b403cb54cd/christmas-celebration/42d0862148e0c1e1cddda9ac15e6315d.jpg",
    ],
  },
  {
    city: "Pune",
    country: "India",
    address1: "StartHub, 2F",
    address2: "Koregaon Park Rd, Maharashtra 411001",
    coordinates: [73, 21],
    images: [
      "https://www.coworkingers.com/wp-content/uploads/2020/07/Starthub-Cowork-space-05-min.jpg",
      "https://instahyre-2.s3-ap-south-1.amazonaws.com/media/CACHE/images/images/office-photos/base/32712/f0e3a9dc1e/142366180_3814608955302800_7154327757571120073/1f4aa96f59f847c776ac942c46ed190e.jpg",
    ],
  },
  {
    city: "Seoul",
    country: "South Korea",
    address1: "Sinwoong Tower 5F",
    address2: "Teheran-ro, Gangnam-gu, 06221",
    coordinates: [126, 40],
    images: [
      "https://www.newofficeasia.com/images/offices/4f-5f-shinil-building-425-teheran-ro-1278-1.jpg",
      "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSlYmlFWQpwZ5aCBCRxbJH8cJE_otnbeGoEDjqg515iQLeCaLL0xko1ulkw02t-6quXVUc&usqp=CAU",
    ],
  },
];
