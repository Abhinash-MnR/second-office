export default [
  {
    label: "Salary No Bar",
    value: "0-0",
  },
];
