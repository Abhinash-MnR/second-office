export default [
  "Coding Test",
  "Years Of Experience",
  "College Ranking",
  "Past Work Experience",
];
