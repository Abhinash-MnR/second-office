export default [
  {
    label: "0-0.04",
    value: "0-3",
  },
  {
    label: "0.04-0.08",
    value: "3-6",
  },
  {
    label: "0.08-0.13",
    value: "6-10",
  },
  {
    label: "0.13-0.20",
    value: "10-15",
  },
  {
    label: "0.20-0.29",
    value: "15-22",
  },
  {
    label: "0.29+",
    value: "22-100",
  },
  {
    label: "Salary No Bar",
    value: "0-0",
  },
  {
    label: "As per the market standards",
    value: "1-1",
  },
];
