export default [
  {
    label: "Full Time",
    value: "full_time",
  },
  {
    label: "Part Time",
    value: "part_time",
  },
  {
    label: "Intern",
    value: "intern",
  },
  {
    label: "Contract",
    value: "contract",
  },
  {
    label: "Volunteer",
    value: "volunteer",
  },
];
