export default [
  {
    id: "1",

    img_url: "/svg/1.svg",
  },
  {
    id: "2",

    img_url: "/svg/2.svg",
  },
  {
    id: "3",

    img_url: "/svg/3.svg",
  },
];
