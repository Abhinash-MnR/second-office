export default [
    {
      label: "Bachelors from Top 5% University",
      value: "Bachelors from Top 5% University",
    },
    {
      label: "Masters from Top 5% University",
      value: "Masters from Top 5% University",
    },
    {
      label: "Ph.D or Beyond",
      value: "Ph.D or Beyond",
    },
    {
      label: "Doesn’t Matter",
      value: "Doesn’t Matter",
    },
  ];
  