export default [
  {
    id: "1",
    img_url: "/Images/Slide1.jpg",
  },
  {
    id: "2",
    img_url: "/Images/Slide2.svg",
  },
  {
    id: "3",
    img_url: "/Images/Slide 3.svg",
  },
];
