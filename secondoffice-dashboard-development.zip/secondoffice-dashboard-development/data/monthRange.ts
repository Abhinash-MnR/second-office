export default [
  {
    label: "10",
    value: "10",
  },
  {
    label: "15",
    value: "15",
  },
  {
    label: "30",
    value: "30",
  },
  {
    label: "45",
    value: "45",
  },
  {
    label: "90",
    value: "90",
  },
  {
    label: "Immediate Joiner",
    value: "0",
  },
];
