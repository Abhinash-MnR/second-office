//React,Next Js Packages
import React, { FC } from "react";
//MUI Packages
import { Box, Grid, Stack, Button } from "@mui/material";
// Third Party Packages
import { Form, FormProps, Field } from "react-final-form";
import { useSnackbar } from "notistack";
import { useTranslation } from "react-i18next";
import "translation/i18n";
//Custom Components
import { SelectDropdownField, TextField } from "@common/FormField";
import { StringValidator } from "lib/form-validations";
import brandName from "data/brandName";
import deviceCategory from "data/deviceCategory";
import deviceQuantity from "data/deviceQuantity";

const validator = new StringValidator();

export type ResumesFormProps = {} & FormProps;

export const RequestForm: FC<ResumesFormProps> = (props: ResumesFormProps) => {
  const { enqueueSnackbar } = useSnackbar();
  //** Language translation hooks */
  const { t } = useTranslation();
  /** props */
  const { onSubmit, employeeDataList, intialOptions } = props;
  //** Initial values */
  // const initalValue = {
  //   category: "",
  //   brand: "",
  //   quantity: "",
  //   employee: "",
  //   description: "",
  // };

  const deviceCategoryList = [
    `${t("misc_software")}`,
    `${t("data_storage_system")}`,
    `${t("headphone")}`,
    `${t("keyboard")}`,
    `${t("mouse")}`,
    `${t("keyboard_combo")}`,
    `${t("printer")}`,
    `${t("power_backup")}`,
    `${t("power_cord")}`,
    `${t("power_adaptor")}`,
    `${t("laptop_stand")}`,
    `${t("iot")}`,
    `${t("cable")}`,
    `${t("monitor")}`,
    `${t("mobile_device")}`,
    `${t("laptop")}`,
    `${t("other")}`,
  ];

  return (
    <Box>
      <Form initialValues={intialOptions} onSubmit={onSubmit}>
        {({ handleSubmit, pristine, form, submitting }) => (
          <form onSubmit={handleSubmit}>
            <Grid container spacing={3} marginBottom={4}>
              <Grid item xs={12} lg={6}>
                <Field
                  component={SelectDropdownField}
                  fullWidth
                  domain={deviceCategoryList}
                  name="category"
                  required
                  size="small"
                  title={`${t("store_request_device_category_title")}`}
                  variant="outlined"
                  validate={validator.validateRequiredMax64}
                  warning={`${t("recruit_this_field_empty_warning_title")}`}
                />
              </Grid>
              <Grid item xs={12} lg={6}>
                <Field
                  component={SelectDropdownField}
                  domain={brandName}
                  fullWidth
                  name="brand"
                  required
                  size="small"
                  title={`${t("store_request_device_brand_title")}`}
                  variant="outlined"
                  validate={validator.validateRequiredMax64}
                  warning={`${t("recruit_this_field_empty_warning_title")}`}
                />
              </Grid>
              <Grid item xs={12} lg={6}>
                <Field
                  component={SelectDropdownField}
                  domain={deviceQuantity}
                  fullWidth
                  name="quantity"
                  required
                  size="small"
                  title={`${t("store_request_device_quantity_title")}`}
                  variant="outlined"
                  validate={validator.validateRequiredMax64}
                  warning={`${t("recruit_this_field_empty_warning_title")}`}
                />
              </Grid>
              <Grid item xs={12} lg={6} height="100px">
                <Field
                  component={TextField}
                  fullWidth
                  multiline
                  rows={4.5}
                  placeholder={`${t("description")}`}
                  name="description"
                  required
                  size="small"
                  title={`${t("store_request_device_desc_title")}`}
                  type="textarea"
                  variant="outlined"
                  validate={validator.validateRequiredMax2024}
                  warning={`${t("recruit_this_field_empty_warning_title")}`}
                />
              </Grid>
              <Grid item xs={12} lg={6} mt={{ xs: 9, sm: -2 }} height="50px">
                <Field
                  component={SelectDropdownField}
                  domain={employeeDataList}
                  fullWidth
                  name="employee"
                  required
                  size="small"
                  title={`${t("store_request_device_empName_title")}`}
                  variant="outlined"
                  validate={validator.validateRequiredMax64}
                  warning={`${t("recruit_this_field_empty_warning_title")}`}
                />
              </Grid>
            </Grid>
            <Stack alignItems="flex-end" direction="column" mt={9}>
              <Button type="submit" variant="contained">
                {t("submit_request_title")}
              </Button>
            </Stack>
          </form>
        )}
      </Form>
    </Box>
  );
};

export default RequestForm;
