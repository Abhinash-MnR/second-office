// React , Next js packages
import React, { useEffect, useState } from "react";
import { useRouter } from "next/router";
import { connect } from "react-redux";
import { Dispatch } from "redux";
// MUI packages
import {
  Box,
  Button,
  Stack,
  Typography,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  Paper,
  styled,
  Pagination,
} from "@mui/material";
import ReadMore from "@common/ReadMore";
// Third party packages
import { useSnackbar } from "notistack";
import { useTranslation } from "react-i18next";
import "translation/i18n";
// Custom packages
import { RootState } from "reducers";
import { deviceMangementList } from "@reducers/deviceManagementSlice";
import { EmptyTable } from "features/officeManagement/NoOfficeData";
import DialogBox from "@common/DialogBox";
import {
  EURIconColor,
  INRIconColor,
  KRWIconColor,
  USDIconColor,
} from "@common/Icon";
import useCompany from "@lib/useCompany";
import useCurrency from "@lib/useCurrency";

type Props = {};

const StyledTableRow = styled(TableRow)(({ theme }) => ({
  "&:nth-of-type(odd)": {
    // backgroundColor: theme.palette.action.hover,
  },
  // hide last border
  "&:last-child td, &:last-child th": {
    border: 0,
  },
}));

const StyledTableCell = styled(TableCell)(({ theme }) => ({
  fontSize: 14,
  lineHeight: 1.5,
  padding: "18px",
}));

function ApprovedDeviceList(props) {
  //**useRouter hooks */
  const router = useRouter();
  /** props - actions */
  const { deviceMangementList } = props;
  /** props - states */
  const { result, count } = props;

  /** third-party hooks */
  const { enqueueSnackbar } = useSnackbar();

  //** Language translation hooks */
  const { t } = useTranslation();

  const { company } = useCompany({
    redirectTo: "/",
  });

  const { currency } = useCurrency();

  // Convert number with commas
  const numberWithCommas = (x: string) => {
    return x.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",");
  };

  //** pagination page size */
  const pageNumber = Math.ceil(count / 10);
  //**useState hooks */
  const [devicePageList, setDevicePageList] = useState(1);

  /** useEffect hooks */
  useEffect(() => {
    const deviceList = async () => {
      deviceMangementList({ page: devicePageList, page_size: 10 });
    };

    try {
      deviceList();
    } catch (error: any) {
      enqueueSnackbar(error.toString(), { variant: "error" });
    }
  }, [devicePageList]);

  console.log("check get device list dataset", result);
  return (
    <Box color="primary.main">
      <Stack
        direction={`row`}
        justifyContent="space-between"
        alignItems={`center`}
        marginBottom={3.75}
      >
        <Typography variant="h3" color={`primary.main`}>
          {t("device_management_title")}
        </Typography>
        <Button variant="outlined" onClick={() => router.push("/store/device")}>
          {t("submit_new_request_title")}
        </Button>
      </Stack>
      <Box>
        <TableContainer component={Paper} sx={{ boxShadow: "none" }}>
          <Table sx={{ minWidth: 1050 }} aria-label="simple table">
            <TableHead sx={{ background: "#ECEDF4" }}>
              <StyledTableRow>
                <StyledTableCell
                  sx={{
                    fontSize: 16,
                    lineHeight: 1.5,
                    fontWeight: 700,
                  }}
                >
                  {t("employee_name_title")}
                </StyledTableCell>
                <StyledTableCell
                  sx={{ fontSize: 16, lineHeight: 1.5, fontWeight: 700 }}
                >
                  {t("device_type_title")}
                </StyledTableCell>
                <StyledTableCell
                  sx={{ fontSize: 16, lineHeight: 1.5, fontWeight: 700 }}
                >
                  {t("device_name_title")}
                </StyledTableCell>
                <StyledTableCell
                  sx={{ fontSize: 16, lineHeight: 1.5, fontWeight: 700 }}
                >
                  {t("device_cost")}
                </StyledTableCell>
                <StyledTableCell
                  sx={{ fontSize: 16, lineHeight: 1.5, fontWeight: 700 }}
                >
                  {t("seller_name")}
                </StyledTableCell>
                <StyledTableCell
                  sx={{ fontSize: 16, lineHeight: 1.5, fontWeight: 700 }}
                >
                  {t("description")}
                </StyledTableCell>
                <StyledTableCell
                  sx={{ fontSize: 16, lineHeight: 1.5, fontWeight: 700 }}
                >
                  {t("quantity")}
                </StyledTableCell>
              </StyledTableRow>
            </TableHead>
            {count > 0 ? (
              <TableBody>
                {result.map((row, index) => (
                  <TableRow
                    key={index}
                    sx={{ "&:last-child td, &:last-child th": { border: 0 } }}
                  >
                    <StyledTableCell sx={{ fontWeight: 700 }}>
                      {row.employee_name}
                    </StyledTableCell>
                    <StyledTableCell sx={{ fontWeight: 700 }}>
                      {row.device_type}
                    </StyledTableCell>
                    <StyledTableCell>{row.device_name}</StyledTableCell>
                    <StyledTableCell>
                      {company && currency && company.currency === "KRW" ? (
                        <KRWIconColor sx={{ fontSize: "10px" }} />
                      ) : company && currency && company.currency === "USD" ? (
                        <USDIconColor sx={{ fontSize: "10px" }} />
                      ) : company && currency && company.currency === "EUR" ? (
                        <EURIconColor sx={{ fontSize: "10px" }} />
                      ) : (
                        <INRIconColor sx={{ fontSize: "10px" }} />
                      )}

                      {company && currency && company.currency === "KRW"
                        ? numberWithCommas(
                            (row.device_cost * currency.currency_krw).toFixed(2)
                          )
                        : company && currency && company.currency === "USD"
                        ? numberWithCommas(
                            (row.device_cost * currency.currency_usd).toFixed(2)
                          )
                        : company && currency && company.currency === "EUR"
                        ? numberWithCommas(
                            (row.device_cost * currency.currency_eur).toFixed(2)
                          )
                        : numberWithCommas(row.device_cost)}

                      {company && currency && company.currency === "KRW"
                        ? ""
                        : company && currency && company.currency === "USD"
                        ? ""
                        : company && currency && company.currency === "EUR"
                        ? ""
                        : ""}
                    </StyledTableCell>
                    <StyledTableCell>{row.seller}</StyledTableCell>
                    <StyledTableCell width={`22%`}>
                      {/* {row.description.length > 20 ? (
                        <ReadMore sliceTextLength={20}>
                          {row.description}
                        </ReadMore>
                      ) : (
                        row.description
                      )} */}
                      {row.description.length > 0 && (
                        <Box display={`flex`}>
                          <Typography component={`span`}></Typography>
                          {row.description.slice(0, 16)}...{" "}
                          <DialogBox description={row.description} />
                        </Box>
                      )}
                    </StyledTableCell>
                    <StyledTableCell width={`5%`}>
                      {row.quantity}
                    </StyledTableCell>
                  </TableRow>
                ))}
              </TableBody>
            ) : (
              <TableBody>
                <StyledTableRow
                  sx={{
                    "&:last-child td, &:last-child th": { border: 0 },
                    height: 500,
                    visibility: "hidden",
                  }}
                >
                  <Typography visibility={`hidden`}>text</Typography>
                </StyledTableRow>
              </TableBody>
            )}
          </Table>
        </TableContainer>
      </Box>

      {count >= 10 && (
        <Box sx={{ display: "flex", justifyContent: "center" }}>
          <Stack
            direction="row"
            alignItems="center"
            justifyContent="center"
            paddingTop={5}
            paddingBottom={3}
          >
            <Pagination
              count={pageNumber}
              color="secondary"
              onChange={(e, value) => setDevicePageList(value)}
              sx={{
                background: "#ECEDF4",
                borderRadius: "10px",
                padding: { xs: "5px", sm: "10px" },
              }}
            />
          </Stack>
        </Box>
      )}
      {count == 0 && (
        <EmptyTable
          title={`${t("store_empty_screen_title")}`}
          imgName="empty_table"
        />
      )}
    </Box>
  );
}

const mapStateToProps = (state: RootState) => ({
  result: state.employeeDeviceList.results,
  count: state.employeeDeviceList.count,
});

const mapDispatchToProps = (dispatch: Dispatch) => {
  return {
    deviceMangementList: (params: any) => deviceMangementList(dispatch, params),
  };
};

export default connect(mapStateToProps, mapDispatchToProps)(ApprovedDeviceList);
