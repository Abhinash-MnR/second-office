// React , Next js packages
import React, { useEffect, useState } from "react";
import { useRouter } from "next/router";
import { connect } from "react-redux";
import { Dispatch } from "redux";
// MUI packages
import {
  Box,
  Stack,
  Typography,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  Paper,
  styled,
  Pagination,
} from "@mui/material";
//  Third party packages
import { useSnackbar } from "notistack";
import { useTranslation } from "react-i18next";
import "translation/i18n";
// Custom packages
import { RootState } from "reducers";
import { deviceList } from "@reducers/deviceSlice";
import { employeeList } from "@reducers/employeeListSlice";
import { EmptyTable } from "features/officeManagement/NoOfficeData";
import DialogBox from "@common/DialogBox";

type Props = {};

const StyledTableRow = styled(TableRow)(({ theme }) => ({
  "&:nth-of-type(odd)": {
    // backgroundColor: theme.palette.action.hover,
  },
  // hide last border
  "&:last-child td, &:last-child th": {
    border: 0,
  },
}));

const StyledTableCell = styled(TableCell)(({ theme }) => ({
  fontSize: 14,
  lineHeight: 1.5,
  padding: "18px",
}));

function RequestDeviceList(props) {
  //**useRouter hooks */
  const router = useRouter();
  /** props - actions */
  const { deviceList, employeeList } = props;
  /** props - states */
  const { result, count, employeeListData } = props;

  //** Language translation hooks */
  const { t } = useTranslation();

  /** third-party hooks */
  const { enqueueSnackbar } = useSnackbar();

  const pageNumber = Math.ceil(count / 10);
  const [requestDeviceList, setRequestDeviceList] = useState(1);

  /** useEffect hooks */
  useEffect(() => {
    const device = async () => {
      deviceList({ page: requestDeviceList, page_size: 10 });
    };
    // const employeeName = async () => {
    //   employeeList({ page: requestDeviceList, page_size: 1 });
    // };
    try {
      device();
      // employeeName();
    } catch (error: any) {
      enqueueSnackbar(error.toString(), { variant: "error" });
    }
  }, [requestDeviceList]);

  useEffect(() => {
    const employeeName = async () => {
      employeeList();
    };
    try {
      employeeName();
    } catch (error: any) {
      enqueueSnackbar(error.toString(), { variant: "error" });
    }
  }, [result]);

  return (
    <Box position={`relative`}>
      <Typography variant="h3" mb={3.75} mt={5}>
        {t("store_requested_device_title")}
      </Typography>
      <TableContainer component={Paper} sx={{ boxShadow: "none" }}>
        <Table sx={{ minWidth: 1050 }} aria-label="simple table">
          <TableHead sx={{ background: "#ECEDF4" }}>
            <StyledTableRow>
              <StyledTableCell
                sx={{
                  fontSize: 16,
                  lineHeight: 1.5,
                  fontWeight: 700,
                }}
              >
                {t("store_request_device_category_title")}
              </StyledTableCell>
              <StyledTableCell
                sx={{ fontSize: 16, lineHeight: 1.5, fontWeight: 700 }}
              >
                {t("store_request_device_brand_title")}
              </StyledTableCell>
              <StyledTableCell
                sx={{ fontSize: 16, lineHeight: 1.5, fontWeight: 700 }}
              >
                {t("store_request_device_quantity_title")}
              </StyledTableCell>
              <StyledTableCell
                sx={{ fontSize: 16, lineHeight: 1.5, fontWeight: 700 }}
              >
                {t("store_request_device_empName_title")}
              </StyledTableCell>
              <StyledTableCell
                sx={{ fontSize: 16, lineHeight: 1.5, fontWeight: 700 }}
              >
                {t("store_request_device_desc_title")}
              </StyledTableCell>
            </StyledTableRow>
          </TableHead>
          {count > 0 ? (
            <TableBody>
              {result.map((row, index) => (
                <TableRow
                  key={row.id}
                  sx={{ "&:last-child td, &:last-child th": { border: 0 } }}
                >
                  <StyledTableCell sx={{ fontWeight: 700 }}>
                    {row.category_name}
                  </StyledTableCell>
                  <StyledTableCell>{row.brand_name}</StyledTableCell>
                  <StyledTableCell>{row.quantity}</StyledTableCell>
                  <StyledTableCell>{row.employee_name}</StyledTableCell>
                  <StyledTableCell width={`30%`}>
                    {row.description.length > 0 && (
                      <Box display={`flex`}>
                        <Typography component={`span`}></Typography>
                        {row.description.slice(0, 34)}...
                        <DialogBox description={row.description} />
                      </Box>
                    )}
                  </StyledTableCell>
                </TableRow>
              ))}
            </TableBody>
          ) : (
            <TableBody>
              <StyledTableRow
                sx={{
                  "&:last-child td, &:last-child th": { border: 0 },
                  height: 500,
                  visibility: "hidden",
                }}
              >
                <Typography visibility={`hidden`}>text</Typography>
              </StyledTableRow>
            </TableBody>
          )}
        </Table>
      </TableContainer>
      {count >= 10 && (
        <Box sx={{ display: "flex", justifyContent: "center" }}>
          <Stack
            direction="row"
            alignItems="center"
            justifyContent="center"
            paddingTop={5}
            paddingBottom={3}
          >
            <Pagination
              count={pageNumber}
              color="secondary"
              onChange={(e, value) => setRequestDeviceList(value)}
              sx={{
                background: "#ECEDF4",
                borderRadius: "10px",
                padding: { xs: "5px", sm: "10px" },
              }}
            />
          </Stack>
        </Box>
      )}
      {count == 0 && (
        <EmptyTable
          title={`${t("store_empty_screen_title")}`}
          imgName="empty_table"
        />
      )}
    </Box>
  );
}
const mapStateToProps = (state: RootState) => ({
  result: state.requestDevice.results,
  count: state.requestDevice.count,
  employeeListData: state.employeeList.results,
});

const mapDispatchToProps = (dispatch: Dispatch) => {
  return {
    deviceList: (params: any) => deviceList(dispatch, params),
    employeeList: (params: any) => employeeList(dispatch, params),
  };
};

export default connect(mapStateToProps, mapDispatchToProps)(RequestDeviceList);
