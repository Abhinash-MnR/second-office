// React, Next packages
import React from "react";
// Mui packages
import {
  styled,
  Box,
  Button,
  Grid,
  Typography,
  useMediaQuery,
} from "@mui/material";

const SectionContainer = styled("div")(({ theme }) => ({
  display: "flex",
  flexDirection: "column",
}));

const ImageContainer = styled("div")(({ theme }) => ({
  display: "flex",
  flexDirection: "column",
}));

function StoreComingSoon(props: any) {
  // Media Quiery Hooks
  const isMobile = useMediaQuery("(max-width:600px)");
  // Props
  const { title, imgName, content } = props;
  return (
    <Grid container spacing={1}>
      <Grid item xs={12} sm={12}>
        <Box
          sx={{
            display: "flex",
            justifyContent: "center",
            alignItems: "center",
            flexDirection: "column",
            width: "100%",
            height: "500px",
            background: "#fff",
            borderRadius: "10px",
            marginTop: "20px",
          }}
        >
          <ImageContainer>
            <img src={`/svg/${imgName}.svg`} />
          </ImageContainer>
          <Typography
            component="h4"
            variant="h4"
            justifyContent={isMobile ? "center" : "center"}
            alignItems={isMobile ? "center" : "center"}
            marginTop={isMobile ? "24px" : "16px"}
            color="primary.main"
            width={isMobile ? "300px" : "400px"}
            textAlign="center"
          >
            {title}
          </Typography>
          <Typography
            component="p"
            variant="body1"
            justifyContent={isMobile ? "center" : "center"}
            alignItems={isMobile ? "center" : "center"}
            marginTop={isMobile ? "12px" : "12px"}
            color="#222222"
            width={isMobile ? "300px" : "620px"}
            textAlign="center"
          >
            {content}
          </Typography>
        </Box>
      </Grid>
    </Grid>
  );
}

export default StoreComingSoon;
