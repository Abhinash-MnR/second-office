// React, Next packages
import React, { FC, HTMLAttributes } from "react";
// Mui packages
import { Avatar, styled, Typography } from "@mui/material";
// Third-party packages
import dayjs from "dayjs";

export type NotificationProps = {
  /** Timestamp of when the notification was triggered */
  createdAt: string;
  /** Setting to `true` will mark the background white */
  isRead?: boolean;
  /** Text content of the notification */
  message: string;
  /** Unique identifer of the notification */
  notificationId: string;
  /** Callback triggered when the notification is clicked */
  onClick?: (data: any) => void;
  /** Thumbnail to render for the notification */
  thumbnail?: string;
};
interface NotificationContainerProps extends HTMLAttributes<HTMLDivElement> {
  isRead?: boolean;
}

const NotificationContainer = styled("div", {
  shouldForwardProp: (prop) => prop !== "isRead",
})<NotificationContainerProps>(({ isRead, theme }) => ({
  alignItems: "center",
  backgroundColor: "rgba(86, 100, 241, 0.1)",
  cursor: "pointer",
  display: "flex",
  flexDirection: "row",
  padding: theme.spacing(2),
  ...(isRead && {
    backgroundColor: "#ffffff",
  }),
}));

export const Notification: FC<NotificationProps> = ({
  createdAt,
  isRead,
  message,
  notificationId,
  onClick,
  thumbnail,
}: NotificationProps) => {
  // third-party hooks

  // custom handlers
  const handleOnClick = () => onClick && onClick(notificationId);

  return (
    <NotificationContainer isRead={isRead} onClick={handleOnClick}>
      <Avatar
        src={thumbnail}
        sx={{ width: 50, height: 50, marginRight: 2 }}
        variant="rounded"
      />
      <div>
        <Typography
          variant="body1"
          dangerouslySetInnerHTML={{
            __html: message,
          }}
        />
        <Typography component="span" variant="caption">
          {dayjs(createdAt).fromNow()}
        </Typography>
      </div>
    </NotificationContainer>
  );
};
