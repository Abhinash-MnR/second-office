// React, Next packages
import { FC } from "react";
import Link from "next/link";

// Mui packages
import {
  Avatar,
  AvatarGroup,
  Box,
  Button,
  Stack,
  Typography,
} from "@mui/material";

// Third-party packages
import { markers } from "data/markers";
import { useTranslation } from "react-i18next";
import "translation/i18n";

type OfficeDetailProps = {
  /** List of current employees */
  employees?: any[];
  /** If present, display item data */
  selectedCity?: string;
};

export const OfficeDetail: FC<OfficeDetailProps> = (
  props: OfficeDetailProps
) => {
  /** props */
  const { employees, selectedCity } = props;
  //** Language translation hooks */
  const { t } = useTranslation();
  /** custom handlers */
  const office = markers.find((marker) => marker.city === selectedCity);

  /** custom renderers */
  const renderOfficeImage = (image) => (
    <Avatar
      key={image}
      sx={{ width: 140, height: 100, borderRadius: 1 }}
      src={image}
    />
  );

  const renderEmployee = (employee) => (
    <Avatar key={employee.id} src={employee.employee_avatar}>
      {employee.employee_name.substring(0, 2)}
    </Avatar>
  );

  const renderDemoEmployee = () => {
    switch (office.city) {
      case "Noida":
        return (
          <AvatarGroup sx={{ justifyContent: "flex-end" }}>
            {employees?.slice(0, 2).map(renderEmployee)}
          </AvatarGroup>
        );
      case "Ahmedabad":
        return (
          <AvatarGroup sx={{ justifyContent: "flex-end" }}>
            {employees?.slice(3, 4).map(renderEmployee)}
          </AvatarGroup>
        );
      case "Hyderabad":
        return (
          <AvatarGroup sx={{ justifyContent: "flex-end" }}>
            {employees?.slice(2, 4).map(renderEmployee)}
          </AvatarGroup>
        );
      case "Bengaluru":
        return (
          <AvatarGroup sx={{ justifyContent: "flex-end" }}>
            {employees?.slice(4, 5).map(renderEmployee)}
          </AvatarGroup>
        );
      case "Pune":
        return (
          <AvatarGroup sx={{ justifyContent: "flex-end" }}>
            {employees?.slice(0, 1).map(renderEmployee)}
          </AvatarGroup>
        );
      default:
        return (
          <Link href="/applications/jobs/add" passHref>
            <Button component="a" color="secondary" variant="outlined">
              {t("quick_action_card_title_2")}
            </Button>
          </Link>
        );
    }
  };

  return (
    <Box
      bgcolor="#13152D"
      color="white"
      width={500}
      borderRadius={1}
      padding={2.5}
      paddingBottom={4}
    >
      <Typography variant="h4" marginBottom={1.25}>
        {office?.city}, {office?.country}
      </Typography>
      <Typography fontWeight="bold" color="#8A8EBA" marginBottom={0.625}>
        {office.address1}
      </Typography>
      <Typography marginBottom={2}>{office.address2}</Typography>
      <Stack direction="row" spacing={2.5} marginBottom={2}>
        {office?.images?.map(renderOfficeImage)}
      </Stack>
      <Typography variant="h6" marginBottom={1.25}>
        {t("dashboard_office_location_your_emp_title")}
      </Typography>
      {/* <AvatarGroup
        total={employees?.length}
        sx={{ justifyContent: "flex-end" }}
      >
        {employees?.map(renderEmployee)}
      </AvatarGroup> */}
      {renderDemoEmployee()}
      {/* <Typography variant="h6" marginTop={2.5} marginBottom={1.25}>
        {t("dashboard_office_location_your_freelancer_title")}
      </Typography> */}
      {/* <AvatarGroup total={8} sx={{ justifyContent: "flex-end" }}>
        <Avatar />
        <Avatar />
        <Avatar />
      </AvatarGroup> */}
    </Box>
  );
};
