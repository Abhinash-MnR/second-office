// React, Next packages
import { FC, useState } from "react";
// Mui packages
import { ButtonBase, Collapse, Stack, Typography } from "@mui/material";
// Third-party packages
import { ChevronDownIcon, LocationIcon } from "@common/Icon";
import { markers } from "data/markers";
import i18next from "i18next";
import { useTranslation } from "react-i18next";
import "translation/i18n";

type OfficeListProps = {
  /** If present, highlight item */
  selectedCity?: string;
  /** Callback triggered on city changed */
  onCityClicked?: (...params: any) => void;
};

export const OfficeList: FC<OfficeListProps> = (props: OfficeListProps) => {
  /*** props */
  const { selectedCity, onCityClicked } = props;
  //*** language translation hooks */
  const { t } = useTranslation();
  /** useState hooks */
  const [open, setOpen] = useState(false);

  /** custom handlers */
  const toggleCollapse = () => setOpen((prev) => !prev);

  /** custom renderers */
  const renderOfficeItem = (office) => {
    return (
      <Stack
        key={office.city}
        alignItems="center"
        color={office.city === selectedCity ? "warning.main" : "text.primary"}
        direction="row"
        justifyContent="space-between"
        marginBottom={0.625}
        sx={{
          userSelect: "none",
          MozUserSelect: "none",
          msUserSelect: "none",
          WebkitUserSelect: "none",
          cursor: "pointer",
        }}
        onClick={() => onCityClicked(office.city)}
      >
        <Stack alignItems="center" direction="row">
          <LocationIcon sx={{ fontSize: 18 }} />
          <Typography marginLeft={0.625}>{office.city}</Typography>
        </Stack>
        <Typography>{office.country}</Typography>
      </Stack>
    );
  };

  return (
    <>
      <ButtonBase
        disableRipple={false}
        sx={{ borderRadius: 0.5 }}
        onClick={toggleCollapse}
      >
        <Stack
          alignItems="center"
          bgcolor="#FFFFFF"
          boxShadow="2px 2px 20px rgba(34, 34, 34, 0.1)"
          borderRadius={0.5}
          direction="row"
          justifyContent="space-between"
          padding={1.25}
          width={300}
        >
          <Typography color="primary.main" variant="h6">
            {t("dashboard_location_dropdown_title")}
          </Typography>
          <ChevronDownIcon
            sx={{ fontSize: 20, transform: open ? "rotate(-180deg)" : "none" }}
          />
        </Stack>
      </ButtonBase>
      <Collapse in={open}>
        <Stack
          bgcolor="#FFFFFF"
          borderRadius={0.5}
          boxShadow="2px 2px 20px rgba(34, 34, 34, 0.1)"
          padding={1.25}
          paddingBottom={0.625}
          width={300}
          marginTop={0.625}
        >
          {markers.map(renderOfficeItem)}
        </Stack>
      </Collapse>
    </>
  );
};
