// React, Next packages
import { FC } from "react";
import Link from "next/link";
import { UrlObject } from "url";
// Mui packages
import { Stack, Typography } from "@mui/material";
// Third-party packages

type ManagementMenuProps = {
  /** Menu link path */
  href?: UrlObject | string;
  /** Menu icon */
  icon?: string;
  /** Menu title */
  label?: string;
};

export const ManagementMenu: FC<ManagementMenuProps> = (
  props: ManagementMenuProps
) => {
  const { href, icon, label } = props;

  return (
    <Link href={href} passHref>
      <Stack
        alignItems="center"
        bgcolor="#FFFFFF"
        borderRadius={0.5}
        component="a"
        direction="row"
        height={1}
        paddingY={3}
        paddingX={2}
      >
        <img src={icon} />

        <Typography fontWeight={500} variant="body2" marginLeft={1.25}>
          {label}
        </Typography>
      </Stack>
    </Link>
  );
};
