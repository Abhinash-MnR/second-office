// React, Next packages
import { FC } from "react";
// Mui packages
import { Box } from "@mui/material";
// Third-party packages
import {
  ComposableMap,
  Geographies,
  Geography,
  Marker,
  ZoomableGroup,
} from "react-simple-maps";
import { markers } from "data/markers";

type WorldMapProps = {
  /** If present, highlight marker with yellow */
  selectedCity?: string;
  /** Callback triggered on city changed */
  onCityClicked?: (...params: any) => void;
};

const offices = [
  "India",
  "South Korea",
  "Malaysia",
  "Vietnam",
  "Philippines",
  "Indonesia",
];

const geoUrl = "/data/countries.json";
const mapWidth = 1800;
const mapHeight = 800;

export const WorldMap: FC<WorldMapProps> = (props: WorldMapProps) => {
  /** props */
  const { selectedCity, onCityClicked } = props;

  /** custom renders */
  const renderGeography = (geography) => {
    const canClick = offices.includes(geography?.properties?.name);

    return (
      <Geography
        key={geography.rsmKey}
        geography={geography}
        fill={canClick ? "#696E9C" : "#f1f1f1"}
        stroke="white"
        style={{
          default: { outline: "none" },
          hover: { outline: "none" },
          pressed: { outline: "none" },
        }}
      />
    );
  };

  const renderMarker = (marker) => {
    return (
      <Marker
        key={marker.city}
        coordinates={marker.coordinates}
        onClick={() => onCityClicked(marker.city)}
      >
        <g clipPath="url(#clip0_3054_24427)" style={{ cursor: "pointer" }}>
          <path
            d="M3.97652 10.6134C3.42172 10.6134 3.28395 9.99625 3.21692 9.70026C3.20575 9.65383 3.19644 9.60933 3.18713 9.57258C3.11639 9.31334 3.00654 9.06185 2.85388 8.80842C2.64536 8.46019 2.39216 8.14679 2.12407 7.81405C1.97326 7.62639 1.81501 7.431 1.66793 7.22787C1.09079 6.44243 0.537843 5.568 0.401935 4.51366C0.273473 3.50768 0.562046 2.52491 1.21739 1.74721C1.93417 0.896001 3.01213 0.387207 4.09754 0.387207C4.70261 0.387207 5.27417 0.540039 5.7936 0.841832C6.89949 1.48218 7.61813 2.77447 7.62558 4.13642C7.62744 4.51946 7.57159 4.89477 7.45802 5.24686C7.17503 6.1329 6.6314 6.78292 6.10638 7.40972C5.59998 8.01331 5.12151 8.58594 4.84597 9.36558C4.82921 9.41394 4.81618 9.51454 4.80314 9.60353C4.76405 9.90532 4.70447 10.3638 4.28371 10.5457C4.17945 10.5921 4.0752 10.6134 3.97652 10.6134V10.6134Z"
            fill={selectedCity === marker.city ? "#DFA718" : "#4D4D4D"}
          />
          <path
            d="M4.09793 0.773831C4.61178 0.773831 5.13307 0.901513 5.61341 1.17816C6.61876 1.76046 7.24804 2.95023 7.25548 4.13612C7.25548 4.46887 7.20894 4.80355 7.1084 5.12082C6.59083 6.74006 5.10328 7.5255 4.49821 9.22793C4.39768 9.51231 4.46842 10.0443 4.14261 10.1855C4.08118 10.2126 4.02718 10.2242 3.97878 10.2242C3.666 10.2242 3.61573 9.71738 3.54685 9.46395C3.46121 9.15635 3.33461 8.8739 3.17264 8.60113C2.82635 8.02269 2.36277 7.53131 1.96621 6.98963C1.41327 6.23514 0.89756 5.42068 0.772822 4.4592C0.502866 2.37373 2.26782 0.773831 4.09793 0.773831ZM4.09793 0C2.9064 0 1.72418 0.557158 0.938519 1.49156C0.210569 2.35438 -0.109654 3.44548 0.0337017 4.5656C0.180781 5.70894 0.763513 6.63366 1.37231 7.4636C1.52497 7.67253 1.68509 7.87179 1.83961 8.06332C2.0984 8.38639 2.34415 8.69012 2.53777 9.01513C2.67182 9.2376 2.76677 9.45621 2.82821 9.68062C2.83752 9.71157 2.84496 9.75027 2.85427 9.79089C2.9213 10.0908 3.12609 11.0039 3.97692 11.0039C4.12586 11.0039 4.27666 10.971 4.42746 10.9052C5.04557 10.6363 5.13121 9.97661 5.17217 9.65741C5.17962 9.60324 5.18893 9.52392 5.19637 9.4949C5.44957 8.78491 5.9057 8.2413 6.38604 7.66479C6.93526 7.00897 7.5031 6.32993 7.81029 5.37038C7.93689 4.97767 7.99833 4.56367 7.99646 4.13612C7.98902 2.63683 7.19405 1.21104 5.97273 0.504924C5.40489 0.176046 4.75513 0.00193458 4.09421 0.00193458L4.09793 0Z"
            fill="white"
          />
          <path
            d="M3.91533 5.32373C4.49731 5.32373 4.96909 4.83349 4.96909 4.22876C4.96909 3.62402 4.49731 3.13379 3.91533 3.13379C3.33336 3.13379 2.86157 3.62402 2.86157 4.22876C2.86157 4.83349 3.33336 5.32373 3.91533 5.32373Z"
            fill="white"
          />
        </g>
        <defs>
          <clipPath id="clip0_3054_24427">
            <rect width="8" height="11" fill="white" />
          </clipPath>
        </defs>
      </Marker>
    );
  };

  return (
    <Box borderRadius={1} bgcolor="#ecedf4" height={514} overflow="hidden">
      <ComposableMap
        projection="geoMercator"
        width={mapWidth}
        height={mapHeight}
        projectionConfig={{ scale: 160 }}
      >
        <ZoomableGroup
          center={[130, 10]}
          minZoom={2}
          zoom={3}
          maxZoom={6}
          translateExtent={[
            [700, mapHeight / 6],
            [mapWidth, mapHeight - 200],
          ]}
        >
          <Geographies geography={geoUrl}>
            {({ geographies }) => geographies.map(renderGeography)}
          </Geographies>

          {markers.map(renderMarker)}
        </ZoomableGroup>
      </ComposableMap>
    </Box>
  );
};
