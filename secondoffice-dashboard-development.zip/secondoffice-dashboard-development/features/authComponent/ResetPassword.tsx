import React, { useState, useEffect } from "react";
import Link from "next/link";
// Mui packages
import { Grid, TextField, Button, styled, Typography } from "@mui/material";
import { resetPassword } from "api/auth";
import { useRouter } from "next/router";
// Third-party packages
import { useSnackbar } from "notistack";

const CustomContainer = styled("div")(({ theme }) => ({
  display: "flex",
  justifyContent: "center",
  alignItems: "center",
  [theme.breakpoints.down("sm")]: {
    display: "flex",
    flexDirection: "row",
    width: "100%",
  },
}));

const LoginWrapper = styled("div")(({ theme }) => ({
  width: 552,
  // height: 584,
  background: "#fff",
  padding: "36px",
  borderRadius: 10,
  display: "flex",
  flexDirection: "column",
  [theme.breakpoints.down("sm")]: {
    display: "flex",
    flexDiraction: "column",
    maxWidth: "600px",
    padding: 20,
  },
}));

const ContentContainer = styled("div")(({ theme }) => ({
  display: "flex",
  flexDirection: "column",
  // padding: "36px 36px 20px 36px",
  paddingBottom: "36px",
  color: "#2C3058",
  [theme.breakpoints.down("sm")]: {
    display: "flex",
    flexDirection: "column",
    // padding: "40px 20px 40px 20px",
    paddingBottom: 20,
  },
}));

const FormContainer = styled("div")(({ theme }) => ({
  display: "flex",
  justifyContent: "center",
  alignItems: "center",
  // padding: "0px 36px",
  [theme.breakpoints.down("sm")]: {
    display: "flex",
    flexDirection: "column",
    alignItem: "center",
    justifyContent: "center",
  },
}));

const ResetPassword = () => {
  /** third-party hooks */
  const { enqueueSnackbar } = useSnackbar();
  const router = useRouter();
  const [passwordValue, setPasswordValue] = useState("");
  const [confirmPasswordValue, setConfirmPasswordValue] = useState("");

  const [showPassword, setshowPassword] = useState(false);
  /** useState hooks */
  const [isUpdating, setIsUpdating] = useState<boolean>(false);
  /** custom handlers  */
  const handleSubmit = async (data: any) => {
    try {
      setIsUpdating(true);
      // Create form payload
      const payload = {
        uid: location.href.split("/")[5].split("=")[2],
        token: location.href.split("/")[5].split("=")[1].slice(0, -4),
        new_password: confirmPasswordValue,
      };
      const loginData = await resetPassword(payload);
      enqueueSnackbar("Success", {
        variant: "info",
      });
      router.push(`/`);
      //   console.log(
      //     "access_token",
      //     JSON.stringify(loginData.data.auth_token),
      //     "access_token1:-",
      //     JSON.stringify(loginData.data)
      //   );
      //   localStorage.setItem(
      //     "access_token",
      //     JSON.stringify(loginData.data.auth_token)
      //   );
      // router.push(`/`);
    } catch (error: any) {
      enqueueSnackbar(error.toString(), { variant: "error" });
      setIsUpdating(false);
    }
  };

  return (
    <CustomContainer>
      <LoginWrapper>
        <ContentContainer>
          <Typography component="h3" variant="h3" paddingBottom={1}>
            Create new password
          </Typography>
          <Typography sx={{ color: "#222222" }} component="p" variant="body1">
            Create new password
          </Typography>
        </ContentContainer>
        <FormContainer>
          <Grid container spacing={3}>
            <Grid item xs={12}>
              <TextField
                label="Enter Password"
                value={passwordValue}
                onChange={(e) => {
                  setPasswordValue(e.currentTarget.value);
                }}
                variant="outlined"
                placeholder="Enter Password"
                fullWidth
              />
            </Grid>
            <Grid item xs={12}>
              <TextField
                label="Confirm Password"
                value={confirmPasswordValue}
                onChange={(e) => {
                  setConfirmPasswordValue(e.currentTarget.value);
                }}
                variant="outlined"
                placeholder="Confirm Password"
                fullWidth
              />
            </Grid>
            <Grid item xs={12}>
              <Button variant="contained" fullWidth onClick={handleSubmit}>
                Save Password
              </Button>
            </Grid>
            <Grid item xs={12}>
              <Button
                sx={{ background: "#FFFFFF", color: "#2C3058" }}
                variant="outlined"
                fullWidth
                onClick={() => router.push(`/`)}
              >
                Back
              </Button>
            </Grid>
          </Grid>
        </FormContainer>
      </LoginWrapper>
    </CustomContainer>
  );
};

export default ResetPassword;
