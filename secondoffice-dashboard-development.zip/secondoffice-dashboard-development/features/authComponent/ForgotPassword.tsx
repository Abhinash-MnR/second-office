import React, { useState } from "react";
import Link from "next/link";
// Mui packages
import {
  Grid,
  TextField,
  Button,
  styled,
  Typography,
  Box,
} from "@mui/material";
import { forgotPassword } from "api/auth";
import { useRouter } from "next/router";
// Third-party packages
import { Formik } from "formik";
import { useSnackbar } from "notistack";

const CustomContainer = styled("div")(({ theme }) => ({
  display: "flex",
  justifyContent: "center",
  alignItems: "center",
  [theme.breakpoints.down("sm")]: {
    display: "flex",
    flexDirection: "row",
    width: "100%",
  },
}));

const ForgotPassWrapper = styled("div")(({ theme }) => ({
  width: 552,
  // height: 584,
  background: "#fff",
  padding: "36px",
  borderRadius: 10,
  [theme.breakpoints.down("sm")]: {
    display: "flex",
    flexDiraction: "column",
    maxWidth: "600px",
    padding: 20,
  },
}));

const ContentContainer = styled("div")(({ theme }) => ({
  display: "flex",
  flexDirection: "column",
  paddingBottom: "36px",
  color: "#2C3058",
  [theme.breakpoints.down("sm")]: {
    display: "flex",
    flexDirection: "column",
    paddingBottom: "20px",
  },
}));

const FormContainer = styled("div")(({ theme }) => ({
  display: "block",
  justifyContent: "center",
  alignItems: "center",
  // padding: "0px 36px",
  [theme.breakpoints.down("sm")]: {
    display: "flex",
    flexDirection: "column",
    alignItem: "center",
    justifyContent: "center",
  },
}));

const ForgotPassword = () => {
  /** third-party hooks */
  const { enqueueSnackbar } = useSnackbar();
  const router = useRouter();
  const [emailValue, setEmailValue] = useState("");
  /** useState hooks */
  const [isUpdating, setIsUpdating] = useState<boolean>(false);
  /** custom handlers  */
  const handleSubmitNew = async (data: any) => {
    try {
      setIsUpdating(true);
      // Create form payload
      const payload = {
        email: data.email,
      };
      const loginData = await forgotPassword(payload);
      enqueueSnackbar("Success", {
        variant: "info",
      });
      router.back();
      // console.log(
      //   "access_token",
      //   JSON.stringify(loginData.data.auth_token),
      //   "access_token1:-",
      //   JSON.stringify(loginData.data)
      // );
      // localStorage.setItem(
      //   "access_token",
      //   JSON.stringify(loginData.data.auth_token)
      // );
      // router.push(`/`);
    } catch (error: any) {
      enqueueSnackbar(error.toString(), { variant: "error" });
      setIsUpdating(false);
    }
  };

  return (
    <CustomContainer>
      <ForgotPassWrapper>
        <Grid container>
          <Grid item xs={12}>
            <ContentContainer>
              <Typography component="h3" variant="h3" paddingBottom={1}>
                Forgot Your Password?
              </Typography>
              <Typography component="p" variant="body1">
                Please enter the email address associated with your account, and
                we'll email you a link to reset your password.
              </Typography>
            </ContentContainer>
            <FormContainer>
              <Formik
                initialValues={{ email: "" }}
                validate={(values) => {
                  const errors: any = {};
                  if (!values.email) {
                    errors.email = "*Required";
                  } else if (
                    !/^[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}$/i.test(
                      values.email
                    )
                  ) {
                    errors.email =
                      "Incorrect Email. Try with your registered email id.";
                  }
                  return errors;
                }}
                onSubmit={(values, { setSubmitting }) => {
                  handleSubmitNew(values);
                  // setTimeout(() => {
                  //   alert(JSON.stringify(values, null, 2));
                  //   setSubmitting(false);
                  // }, 400);
                }}
              >
                {({
                  values,
                  errors,
                  touched,
                  handleChange,
                  handleBlur,
                  handleSubmit,
                  isSubmitting,
                  /* and other goodies */
                }) => (
                  <form onSubmit={handleSubmit}>
                    <Grid container spacing={2}>
                      <Grid item xs={12}>
                        <TextField
                          type="email"
                          name="email"
                          onChange={handleChange}
                          onBlur={handleBlur}
                          value={values.email}
                          error={
                            !(errors.email && touched.email && errors.email)
                              ? false
                              : true
                          }
                          label="Email Address"
                          variant="outlined"
                          placeholder="Email Address"
                          fullWidth
                        />
                        <Box color="#D20000" fontSize="12px" height="8px">
                          {errors.email && touched.email && errors.email}
                        </Box>
                      </Grid>
                      <Grid item xs={12}>
                        <Button variant="contained" fullWidth type="submit">
                          Send Link
                        </Button>
                      </Grid>
                      <Grid item xs={12}>
                        <Button
                          sx={{ background: "#FFFFFF", color: "#2C3058" }}
                          variant="outlined"
                          fullWidth
                          onClick={() => router.back()}
                        >
                          Back
                        </Button>
                      </Grid>
                    </Grid>
                  </form>
                )}
              </Formik>
            </FormContainer>
          </Grid>
        </Grid>
      </ForgotPassWrapper>
    </CustomContainer>
  );
};

export default ForgotPassword;
