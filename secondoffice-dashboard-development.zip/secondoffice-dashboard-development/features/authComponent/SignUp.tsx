import React, { useState, useEffect } from "react";
import Link from "next/link";
import { connect } from "react-redux";
import { Dispatch } from "redux";
// Mui packages
import {
  Grid,
  TextField,
  OutlinedInput,
  InputAdornment,
  IconButton,
  FormControl,
  InputLabel,
  Button,
  Checkbox,
  FormControlLabel,
  styled,
  Typography,
  Box,
} from "@mui/material";
import { signup, login } from "api/auth";
import { useRouter } from "next/router";
// Third-party packages
import { Formik } from "formik";
import { useSnackbar } from "notistack";
import { Email, Visibility, VisibilityOff } from "@mui/icons-material";
import GoogleIcon from "@mui/icons-material/Google";
import { GoogleLogin } from "react-google-login";
//Custom Packages
import { updateCompany } from "reducers/profileSlice";
import { RootState } from "reducers";

const CustomContainer = styled("div")(({ theme }) => ({
  display: "flex",
  justifyContent: "center",
  alignItems: "center",
  [theme.breakpoints.down("sm")]: {
    display: "flex",
    flexDirection: "row",
    margin: "unset",
    width: "100%",
  },
}));

const SignUpWrapper = styled("div")(({ theme }) => ({
  width: 552,
  // height: 620,
  padding: "36px",
  borderRadius: 10,
  background: "#fff",
  [theme.breakpoints.down("sm")]: {
    display: "flex",
    flexDiraction: "column",
    maxWidth: "600px",
    boxShadow: "none",
    padding: 20,
  },
}));

const ContentContainer = styled("div")(({ theme }) => ({
  display: "flex",
  flexDirection: "column",
  // padding: "36px 36px 36px 36px",
  paddingBottom: "36px",
  color: "#2C3058",
  [theme.breakpoints.down("sm")]: {
    display: "flex",
    flexDirection: "column",
    // padding: "40px 20px 20px 20px",
    paddingBottom: 20,
  },
}));

const FormContainer = styled("div")(({ theme }) => ({
  display: "flex",
  justifyContent: "center",
  alignItems: "center",
  // padding: "0px 36px",
  [theme.breakpoints.down("sm")]: {
    display: "flex",
    flexDirection: "column",
    alignItem: "center",
    justifyContent: "center",
  },
}));

const Signup = (props: any) => {
  /** third-party hooks */
  const { enqueueSnackbar } = useSnackbar();
  const router = useRouter();
  const [fullNameValue, setFullNameValue] = useState("");
  // const [companyNameValue, setCompanyNameValue] = useState('');
  // const [emailValue, setEmailValue] = useState('');
  // const [passwordValue, setPasswordValue] = useState('');

  const [showPassword, setshowPassword] = useState(false);
  /** useState hooks */
  const [isUpdating, setIsUpdating] = useState<boolean>(false);
  const [isEmail, setIsEmail] = useState("");
  /** props - actions */
  const { updateCompany } = props;
  /** custom handlers  */
  const handleSubmitNew = async (data: any) => {
    try {
      setIsUpdating(true);
      // Create form payload
      const payload = {
        company_name: data.companyName,
        full_name: data.fullName,
        email: data.email,
        password: data.password,
      };
      const signupData: any = await signup(payload);
      console.log("Signup Details", JSON.stringify(signupData.data));
      const encodedString = window.btoa(data.password);
      localStorage.setItem("pass_token", encodedString);
      localStorage.setItem("pass_email", signupData.data.email);
      enqueueSnackbar("Signup Successfully", {
        variant: "info",
      });
      console.log("Signup Details", JSON.stringify(signupData.data));
      localStorage.setItem("email", signupData.data.email);
      localStorage.setItem("company_name", signupData.data.company_name);
      router.push("/");
    } catch (error: any) {
      console.log("error:-", error);
      localStorage.removeItem("pass_token");
      enqueueSnackbar("User with this email address already exists.", {
        variant: "error",
      });
      setIsUpdating(false);
    }
  };
  /** useEffect hooks */
  useEffect(() => {
    console.log("Email:-", isEmail);
  }, [isEmail]);

  // Google Success Handler
  const responseGoogleSuccess = (response: any) => {
    console.log(response);
    const data = {
      email: response.profileObj.email,
      password: localStorage.getItem("pass_token")
        ? localStorage.getItem("pass_token")
        : "",
    };
    handleLoginSubmit(data);
    setIsEmail(response.profileObj.email);
    setFullNameValue(response.profileObj.name);
    console.log(
      "Email",
      response.profileObj.email,
      "name",
      response.profileObj.name
    );
    // router.push("/dashboard");
  };
  /** custom Login handlers  */
  const handleLoginSubmit = async (data: any) => {
    try {
      setIsUpdating(true);
      // Create form payload
      const payload = {
        email: data.email,
        password: data.password,
      };
      const loginData = await login(payload);
      enqueueSnackbar("Login Successfully", {
        variant: "info",
      });
      console.log(
        "access_token",
        JSON.stringify(loginData.data.auth_token),
        "access_token1:-",
        JSON.stringify(loginData.data)
      );
      localStorage.setItem("access_token", loginData.data.auth_token);
      const email = localStorage.getItem("email");
      const companyName = localStorage.getItem("company_name");
      if (email !== null && email !== "" && data.email === email) {
        const payload = { company_email: data.email, company_name: companyName };
        await updateCompany(payload);
        localStorage.removeItem("email");
      }
      router.push("/dashboard");
    } catch (error: any) {
      console.log("error:-", error);
      enqueueSnackbar("Please enter correct email and password.", {
        // Unable to log in with provided credentials.
        variant: "error",
      });
      // enqueueSnackbar(error.toString(), { variant: "error" });
      setIsUpdating(false);
    }
  };

  // Google Error Handler
  const responseGoogleError = (response: any) => {
    console.log(response);
  };

  return (
    <CustomContainer>
      <SignUpWrapper>
        <Grid container>
          <Grid item xs={12}>
            <ContentContainer>
              <Typography component="h3" variant="h3">
                Create Your Account
              </Typography>
              <Typography component="p" variant="body1">
                Enter your details below
              </Typography>
            </ContentContainer>
            <FormContainer>
              <Formik
                initialValues={{
                  email: "",
                  password: "",
                  fullName: "",
                  companyName: "",
                }}
                validate={(values) => {
                  const errors: any = {};
                  if (!values.email) {
                    errors.email = "*Required";
                  } else if (
                    !/^[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}$/i.test(
                      values.email
                    )
                  ) {
                    errors.email =
                      "Incorrect Email. Try with your registered email id.";
                  } else if (!values.password) {
                    errors.password = "*Required";
                  }
                  if (!/^(?=.{8,})/i.test(values.password)) {
                    errors.password = "Password must be 8 digits.";
                  }
                  if (!values.fullName) {
                    errors.fullName = "*Required";
                  }
                  if (!values.companyName) {
                    errors.companyName = "*Required";
                  }
                  return errors;
                }}
                onSubmit={(values, { setSubmitting }) => {
                  handleSubmitNew(values);
                  // setTimeout(() => {
                  //   alert(JSON.stringify(values, null, 2));
                  //   setSubmitting(false);
                  // }, 400);
                }}
              >
                {({
                  values,
                  errors,
                  touched,
                  handleChange,
                  handleBlur,
                  handleSubmit,
                  isSubmitting,
                  /* and other goodies */
                }) => (
                  <form onSubmit={handleSubmit}>
                    <Grid container spacing={2}>
                      <Grid item xs={12} sm={6}>
                        <TextField
                          label="Full Name"
                          type="fullName"
                          name="fullName"
                          onChange={(e) => {
                            setFullNameValue(e.target.value), handleChange;
                          }}
                          onBlur={handleBlur}
                          value={(values.fullName = fullNameValue)}
                          error={
                            !(
                              errors.fullName &&
                              touched.fullName &&
                              errors.fullName
                            )
                              ? false
                              : true
                          }
                          variant="outlined"
                          fullWidth
                        />
                        <Box color="#D20000" fontSize="12px" height="8px">
                          {errors.fullName &&
                            touched.fullName &&
                            errors.fullName}
                        </Box>
                      </Grid>
                      <Grid item xs={12} sm={6}>
                        <TextField
                          label="Company Name"
                          type="companyName"
                          name="companyName"
                          onChange={handleChange}
                          onBlur={handleBlur}
                          value={values.companyName}
                          error={
                            !(
                              errors.companyName &&
                              touched.companyName &&
                              errors.companyName
                            )
                              ? false
                              : true
                          }
                          variant="outlined"
                          fullWidth
                        />
                        <Box color="#D20000" fontSize="12px" height="8px">
                          {errors.companyName &&
                            touched.companyName &&
                            errors.companyName}
                        </Box>
                      </Grid>
                      <Grid item xs={12}>
                        <TextField
                          label="Email Address"
                          type="email"
                          name="email"
                          onChange={(e) => {
                            setIsEmail(e.target.value), handleChange;
                          }}
                          onBlur={handleBlur}
                          value={(values.email = isEmail)}
                          error={
                            !(errors.email && touched.email && errors.email)
                              ? false
                              : true
                          }
                          variant="outlined"
                          fullWidth
                        />
                        <Box color="#D20000" fontSize="12px" height="8px">
                          {errors.email && touched.email && errors.email}
                        </Box>
                      </Grid>
                      <Grid item xs={12}>
                        <FormControl variant="outlined" fullWidth>
                          <InputLabel htmlFor="outlined-adornment-password">
                            Password
                          </InputLabel>
                          <OutlinedInput
                            label="Password"
                            name="password"
                            onChange={handleChange}
                            onBlur={handleBlur}
                            value={values.password}
                            error={
                              !(
                                errors.password &&
                                touched.password &&
                                errors.password
                              )
                                ? false
                                : true
                            }
                            type={showPassword ? "text" : "password"}
                            endAdornment={
                              <InputAdornment position="end">
                                <IconButton
                                  onClick={() => setshowPassword(!showPassword)}
                                  edge="end"
                                >
                                  {showPassword ? (
                                    <VisibilityOff />
                                  ) : (
                                    <Visibility />
                                  )}
                                </IconButton>
                              </InputAdornment>
                            }
                          />
                        </FormControl>
                        <Box color="#D20000" fontSize="12px" height="8px">
                          {errors.password &&
                            touched.password &&
                            errors.password}
                        </Box>
                      </Grid>
                      <Grid item xs={12}>
                        <Grid container alignItems="center">
                          <Typography
                            component="span"
                            sx={{ fontSize: 14, lineHeight: 1.5 }}
                          >
                            By registering, I agree to SecondOffice of Service
                            and Privacy Policy.
                          </Typography>
                        </Grid>
                      </Grid>
                      <Grid item xs={12}>
                        <Button variant="contained" fullWidth type="submit">
                          Sign Up
                        </Button>
                      </Grid>
                      <Grid
                        item
                        xs={12}
                        sx={{ display: "flex", justifyContent: "center" }}
                      >
                        <Typography
                          component="span"
                          sx={{
                            fontSize: 14,
                            lineHeight: 1.5,
                            paddingRight: 0.5,
                          }}
                        >
                          Already have an account?
                        </Typography>
                        <Typography
                          component="span"
                          sx={{
                            fontSize: 14,
                            lineHeight: 1.5,
                            fontWeight: "bold",
                            color: "#2C3058",
                          }}
                        >
                          <Link href="/">
                            <a>Log In</a>
                          </Link>
                        </Typography>
                      </Grid>
                      <Grid
                        item
                        xs={12}
                        sx={{
                          display: "flex",
                          justifyContent: "center",
                          fontSize: 14,
                          lineHeight: 1.5,
                        }}
                      >
                        OR
                      </Grid>
                      <Grid item xs={12}>
                        <GoogleLogin
                          clientId="107695082191-19bjqqbjerocb9q2lv83v9vvjrsajq52.apps.googleusercontent.com"
                          render={(renderProps) => (
                            <Button
                              onClick={renderProps.onClick}
                              disabled={renderProps.disabled}
                              variant="outlined"
                              fullWidth
                              startIcon={<GoogleIcon />}
                            >
                              Continue via Google
                            </Button>
                          )}
                          buttonText="Login"
                          onSuccess={(response) =>
                            responseGoogleSuccess(response)
                          }
                          onFailure={(response) =>
                            responseGoogleError(response)
                          }
                          cookiePolicy={"single_host_origin"}
                        />
                      </Grid>
                    </Grid>
                  </form>
                )}
              </Formik>
            </FormContainer>
          </Grid>
        </Grid>
      </SignUpWrapper>
    </CustomContainer>
  );
};

const mapStateToProps = (state: RootState) => ({
  company: state.profile.company,
});

const mapDispatchToProps = (dispatch: Dispatch) => {
  return {
    updateCompany: (payload: any) => updateCompany(dispatch, payload),
  };
};

export default connect(mapStateToProps, mapDispatchToProps)(Signup);
