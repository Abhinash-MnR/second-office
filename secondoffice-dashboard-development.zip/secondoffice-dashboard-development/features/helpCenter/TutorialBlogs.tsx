// React, Next packages
import React from "react";
// Mui packages
import { Box, Typography } from "@mui/material";
// Third-party packages
import Slider from "react-slick";
import "slick-carousel/slick/slick.css";
import "slick-carousel/slick/slick-theme.css";
import { useRouter } from "next/router";
import { useTranslation } from "react-i18next";
import "translation/i18n";
// Custom packages
import tutorialBlogsData from "data/tutorialBlogsData";

export const TutorialBlogs = () => {
  //** Language translation hooks */
  const { t } = useTranslation();

  const tutorialBlogDataTitle = [
    {
      id: "0",
      title: `${t("book_a_call_tutoial_title")}`,
      slug: "book-a-call-to-deploy-your-secondoffice",
    },
    {
      id: "1",
      title: `${t("office_management_tutoial_title")}`,
      slug: "know-more-about-your-team-in-office-management",
    },
    {
      id: "2",
      title: `${t("recruit_tutoial_title")}`,
      slug: "post-a-job-to-recruit-your-team",
    },
    {
      id: "3",
      title: `${t("office_expense_tutorial_title")}`,
      slug: "office-expenses",
    },
    {
      id: "4",
      title: `${t("view_candidate_tutorial_title")}`,
      slug: "view-candidate-page",
    },
    {
      id: "5",
      title: `${t("performance_tutorial_title")}`,
      slug: "performance-evaluation",
    },
    {
      id: "6",
      title: `${t("team_roaster_tutorial_title")}`,
      slug: "team-roster",
    },
  ];

  const router = useRouter();

  const settings = {
    dots: true,
    infinite: true,
    speed: 500,
    slidesToShow: 3,
    slidesToScroll: 3,
    autoplay: true,
    arrows: false,
    dotsClass: "custom-slick-dots-help-center",

    responsive: [
      {
        breakpoint: 600,
        settings: {
          slidesToShow: 1,
          slidesToScroll: 1,
        },
      },
    ],
  };

  return (
    <Box sx={{ overflow: "hidden" }}>
      <Typography
        sx={{
          fontSize: { xs: "18px", sm: "24px" },
          color: "#2C3058",
          lineHeight: "150%",
          fontWeight: 700,
          marginTop: "30px",
        }}
      >
        {t("tutorial_title")}
      </Typography>

      <Box
        sx={{
          padding: "30px",
          marginTop: { xs: "20px", sm: "30px" },
          borderRadius: "10px",
          backgroundColor: "#FFFFFF",
        }}
      >
        {/* [Slider] */}
        <Slider {...settings}>
          {tutorialBlogDataTitle.map((item, index) => (
            <Box key={index}>
              <Typography
                sx={{
                  fontSize: { xs: "14px", sm: "16px" },
                  color: "#2C3058",
                  lineHeight: "150%",
                  fontWeight: 700,
                }}
              >
                {item.title}
              </Typography>

              <Typography
                sx={{
                  fontSize: { xs: "12px", sm: "14px" },
                  color: "#2C3058",
                  lineHeight: "150%",
                  fontWeight: 500,
                  marginTop: "24px",
                  opacity: 0.5,
                  textDecoration: "underline",
                  cursor: "pointer",
                }}
                onClick={() => router.push("help_center/" + item.slug)}
              >
                {t("tutorial_seemore")}
              </Typography>
            </Box>
          ))}
        </Slider>
      </Box>

      <Typography
        sx={{
          fontSize: { xs: "12px", sm: "16px" },
          color: "#2C3058",
          lineHeight: "150%",
          fontWeight: 400,
          opacity: 0.5,
          marginTop: "64px",
          marginBottom: "20px",
          textAlign: "center",
        }}
      >
        Something else in your mind,{" "}
        <span
          style={{
            textDecoration: "underline",
            cursor: "pointer",
          }}
        >
          <a href="mailto:gmc@mckinleyrice.co">gmc@mckinleyrice.co</a>
        </span>
      </Typography>
    </Box>
  );
};
