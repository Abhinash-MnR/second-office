// React, Next packages
import React, { useState } from "react";
// Mui packages
import Collapse from "@material-ui/core/Collapse";
import { AddIcon, RemoveIcon } from "@common/Icon";
import { Box, Typography, ListItem } from "@mui/material";
// Third party packages
import { useTranslation } from "react-i18next";
import "translation/i18n";

export const FaqList = () => {
  //** Language translation hooks */
  const { t } = useTranslation();
  //**useState hooks */
  const [faqClicked, setFaqClicked] = useState(null);

  const faqData = [
    {
      id: 0,
      title: `${t("faq_q1_title")}`,
      content: `${t("faq_q1_content")}`,
      contentSteps: `${t("faq_q1_content_steps")}`,
    },
    {
      id: 1,
      title: `${t("faq_q2_title")}`,
      content: `${t("faq_q2_content")}`,
      contentSteps: `${t("faq_q2_content_steps")}`,
    },
    {
      id: 2,
      title: `${t("faq_q3_title")}`,
      content: `${t("faq_q3_content")}`,
      contentSteps: `${t("faq_q3_content_steps")}`,
    },
    {
      id: 3,
      title: `${t("faq_q4_title")}`,
      content: `${t("faq_q4_content")}`,
      contentSteps: `${t("faq_q4_content_steps")}`,
    },
    {
      id: 4,
      title: `${t("faq_q5_title")}`,
      content: `${t("faq_q5_content")}`,
      contentSteps: `${t("faq_q5_content_steps")}`,
    },
    {
      id: 5,
      title: `${t("faq_q6_title")}`,
      content: `${t("faq_q6_content")}`,
      contentSteps: `${t("faq_q6_content_steps")}`,
    },
    {
      id: 6,
      title: `${t("faq_q7_title")}`,
      content: `${t("faq_q7_content")}`,
      contentSteps: `${t("faq_q7_content_steps")}`,
    },
    {
      id: 7,
      title: `${t("faq_q8_title")}`,
      content: `${t("faq_q8_content")}`,
      contentSteps: `${t("faq_q8_content_steps")}`,
    },

    {
      id: 8,
      title: `${t("faq_q9_title")}`,
      content: `${t("faq_q9_content")}`,
      contentSteps: `${t("faq_q9_content_steps")}`,
    },

    {
      id: 9,
      title: `${t("faq_q10_title")}`,
      content: `${t("faq_q10_content")}`,
      contentSteps: `${t("faq_q10_content_steps")}`,
    },
  ];

  return (
    <Box>
      <Typography
        sx={{
          fontSize: { xs: "18px", sm: "24px" },
          color: "#2C3058",
          lineHeight: "150%",
          fontWeight: 700,
        }}
      >
        {t("help_center_title")}
      </Typography>

      <Box
        sx={{
          padding: { xs: "10px", sm: "30px 34px" },
          marginTop: { xs: "20px", sm: "30px" },
          borderRadius: "10px",
          backgroundColor: "#FFFFFF",
        }}
      >
        <Typography
          sx={{
            fontSize: { xs: "16px", sm: "18px" },
            color: "#2C3058",
            lineHeight: "150%",
            fontWeight: 600,
          }}
        >
          {t("faq_title")}
        </Typography>

        {faqData.map((item, index) => (
          <Box
            key={index}
            sx={{
              borderLeft: "3px solid #8A8EBA",
              marginTop: { xs: "24px", sm: "30px" },
            }}
          >
            <ListItem
              button
              onClick={() => {
                if (faqClicked !== index) {
                  setFaqClicked(index);
                } else {
                  setFaqClicked(null);
                }
              }}
              disableRipple
              sx={{
                padding: "12px",
                width: "100%",
                display: "flex",
                justifyContent: "space-between",
              }}
            >
              <Typography
                sx={{
                  fontSize: { xs: "14px", sm: "16px" },
                  color: "#2C3057",
                  lineHeight: "150%",
                  fontWeight: 600,
                }}
              >
                {item.title}
              </Typography>
              {faqClicked === index ? <RemoveIcon /> : <AddIcon />}
            </ListItem>

            <Collapse in={faqClicked === index} timeout="auto" unmountOnExit>
              <Box
                sx={{
                  marginTop: { xs: "16px", sm: "20px" },
                  padding: "0 12px 12px 12px",
                }}
              >
                <Typography
                  sx={{
                    fontSize: { xs: "12px", sm: "14px" },
                    color: "#222222",
                    lineHeight: "150%",
                    fontWeight: 400,
                  }}
                >
                  {item.content}
                </Typography>
                {item.contentSteps !== "-" && (
                  <Typography
                    sx={{
                      fontSize: { xs: "12px", sm: "14px" },
                      color: "#222222",
                      lineHeight: "150%",
                      fontWeight: 700,
                    }}
                  >
                    {item.contentSteps}
                  </Typography>
                )}
              </Box>
            </Collapse>
          </Box>
        ))}
      </Box>
    </Box>
  );
};
