// React, Next packages
import React from "react";

// Mui packages
import { BackIcon } from "@common/Icon";
import { Box, Typography } from "@mui/material";
import { useRouter } from "next/router";
import tutorialBlogsData from "data/tutorialBlogsData";
// Third party packages
import { useTranslation } from "react-i18next";
import "translation/i18n";

export const TutorialBlogsDetail = () => {
  //** Language translation hooks */
  const { t } = useTranslation();
  //**useRouter hooks */
  const router = useRouter();

  //**Tutorial translated data */
  const tutorialBlogData = [
    {
      id: 0,
      title: `${t("book_a_call_tutoial_title")}`,
      slug: "book-a-call-to-deploy-your-secondoffice",
      details: `${t("book_a_call_tutoial_detail")}`,
    },
    {
      id: 1,
      title: `${t("office_management_tutoial_title")}`,
      slug: "know-more-about-your-team-in-office-management",
      details: `${t("office_management_tutoial_detail")}`,
    },

    {
      id: 2,
      title: `${t("recruit_tutoial_title")}`,
      slug: "post-a-job-to-recruit-your-team",
      details: `${t("recruit_tutoial_detail")}`,
    },
    {
      id: 3,
      title: `${t("office_expense_tutorial_title")}`,
      slug: "office-expenses",
      details: `${t("office_expense_tutorial_detail")}`,
    },
    {
      id: 4,
      title: `${t("view_candidate_tutorial_title")}`,
      slug: "view-candidate-page",
      details: `${t("view_candidate_tutorial_detail")}`,
    },

    {
      id: 5,
      title: `${t("performance_tutorial_title")}`,
      slug: "performance-evaluation",
      details: `${t("performance_tutorial_detail")}`,
    },

    {
      id: 6,
      title: `${t("team_roaster_tutorial_title")}`,
      slug: "team-roster",
      details: `${t("team_roaster_tutorial_detail")}`,
    },
  ];

  const blogDetail = tutorialBlogData.filter(
    (item) => item.slug === router.asPath.slice(13, router.asPath.length)
  );

  return (
    <Box>
      {/* [Title] */}
      <Box
        sx={{ display: "flex", align: "center", cursor: "pointer" }}
        onClick={() => router.back()}
      >
        <Typography component="span">
          <BackIcon
            sx={{
              fontSize: { xs: "11px", sm: "12px" },
              marginRight: { xs: "5px", sm: "10px" },
              marginTop: "0.5px",
            }}
          />
        </Typography>
        <Typography component="h6" variant="h6">
          {t("help_center_title")}
        </Typography>
      </Box>

      {/* [Detail] */}

      <Box
        sx={{
          backgroundColor: "#FFFFFF",
          borderRadius: "10px",
          marginTop: "30px",
          padding: { xs: "30px 30px 30px 0", sm: "30px 55px 40px 0" },
        }}
      >
        {/* [Title] */}
        <Box
          sx={{
            display: "flex",
          }}
        >
          <Typography
            sx={{
              fontSize: { xs: "16px", sm: "24px" },
              color: "#FFFFFF",
              lineHeight: "150%",
              fontWeight: 700,
              backgroundColor: "#2C3058",
              borderRadius: "0 100px 100px 0",
              padding: { xs: "12px 20px", sm: "11px 42px 11px 55px" },
            }}
          >
            {blogDetail.length > 0 && blogDetail[0].title}
          </Typography>
        </Box>

        {/* [Desc] */}
        <Box
          sx={{
            padding: { xs: "16px 0 0 30px", sm: "30px 0 0 55px" },
          }}
        >
          <Typography
            sx={{
              fontSize: { xs: "12px", sm: "16px" },
              color: "#222222",
              lineHeight: "150%",
              fontWeight: 400,
            }}
            dangerouslySetInnerHTML={{
              __html: blogDetail.length > 0 && blogDetail[0].details,
            }}
          />
        </Box>
      </Box>
    </Box>
  );
};
