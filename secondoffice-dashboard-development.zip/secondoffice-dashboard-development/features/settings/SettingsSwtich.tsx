// React, Next Packages
import React, { useState, useEffect } from "react";
// Mui packages
import { Grid, styled, Typography, Switch, Divider, Box } from "@mui/material";
// Third party packages
import { useTranslation } from "react-i18next";
import { useSnackbar } from "notistack";
// Custom Packages
import useCompany from "@lib/useCompany";

const SettingsContainer = styled("div")(({ theme }) => ({
  display: "flex",
  flexDirection: "column",
  background: "#fff",
  borderRadius: 10,
  padding: 20,
  [theme.breakpoints.down("sm")]: {
    display: "flex",
    padding: 15,
  },
}));

const SettingsInnerContainer = styled("div")(({ theme }) => ({
  display: "flex",
  flexDirection: "row",
  width: "100%",
  justifyContent: "space-between",
  paddingBottom: 17,
  [theme.breakpoints.down("sm")]: {
    display: "flex",
    width: "100%",
  },
}));

const CustomSwitch = styled(Switch)(({ theme }) => ({
  width: 51,
  height: 31,
  padding: 0,
  "& .MuiSwitch-switchBase": {
    padding: 0,
    margin: 2,
    transitionDuration: "300ms",
    "&.Mui-checked": {
      // transform: "translateX(16px)",
      color: "#fff",
      "& + .MuiSwitch-track": {
        backgroundColor: "#DFA718",
        opacity: 1,
        border: 0,
      },
      "&.Mui-disabled + .MuiSwitch-track": {
        opacity: 0.5,
      },
    },
  },
  "& .MuiSwitch-thumb": {
    boxSizing: "border-box",
    width: 27,
    height: 27,
  },
  "& .MuiSwitch-track": {
    borderRadius: "16px",
    opacity: 1,
    backgroundColor: "rgba(138, 142, 186, 0.3)",
  },
}));

function SettingsSwtich(props: any) {
  const {
    clientRoundSelected,
    culturalRoundSelected,
    technicalRoundSelected,
    technicalAssesmentSelected,
  } = props;
  const { company, isLoading, isError } = useCompany();

  //**language translation hooks */
  const { t } = useTranslation();
  //**third party hooks */
  const { enqueueSnackbar } = useSnackbar();
  /** useEffect hooks */
  useEffect(() => {
    setChecked(company?.cultural_round === "False" ? false : true);
    setCheckedTechnical(company?.technical_round === "False" ? false : true);
    setCheckedClient(company?.client_round === "False" ? false : true);
    setCheckedTechnicalAssesment(
      company?.online_technical_assessment === "False" ? false : true
    );
    console.log(company);
  }, [company]);

  // Settings Switch
  const [checked, setChecked] = useState(
    company?.cultural_round === "False" ? false : true
  );
  const [checkedTechnical, setCheckedTechnical] = useState(
    company?.technical_round === "False" ? false : true
  );
  const [checkedClient, setCheckedClient] = useState(
    company?.client_round === "False" ? false : true
  );
  const [checkedTechnicalAssesment, setCheckedTechnicalAssesment] = useState(
    company?.online_technical_assessment === "False" ? false : true
  );
  const handleChange = (event: React.ChangeEvent<HTMLInputElement>) => {
    enqueueSnackbar(`${t("settings_save_warning")}`, {
      variant: "warning",
    });
    culturalRoundSelected(event.target.checked === true ? "True" : "False");
    setChecked(event.target.checked);
  };
  const handleChangeTechnicalRound = (
    event: React.ChangeEvent<HTMLInputElement>
  ) => {
    enqueueSnackbar(`${t("settings_save_warning")}`, {
      variant: "warning",
    });
    technicalRoundSelected(event.target.checked === true ? "True" : "False");
    setCheckedTechnical(event.target.checked);
  };
  const handleChangeClientRound = (
    event: React.ChangeEvent<HTMLInputElement>
  ) => {
    enqueueSnackbar(`${t("settings_save_warning")}`, {
      variant: "warning",
    });
    clientRoundSelected(event.target.checked === true ? "True" : "False");
    setCheckedClient(event.target.checked);
  };

  const handleChangeTechnicalAssesment = (
    event: React.ChangeEvent<HTMLInputElement>
  ) => {
    enqueueSnackbar(`${t("settings_save_warning")}`, {
      variant: "warning",
    });
    technicalAssesmentSelected(
      event.target.checked === true ? "True" : "False"
    );
    setCheckedTechnicalAssesment(event.target.checked);
  };

  console.log(checked, " checked value ");

  return (
    <Grid container>
      <Grid item xs={12} sm={6}>
        <Typography component="h6" variant="h6" sx={{ marginBottom: "10px" }}>
          {t("customize_interview_module_title")}
        </Typography>
        <Typography
          component="p"
          variant="body1"
          sx={{
            width: { sm: "436px", xs: "100%" },
            marginBottom: { xs: "30px", sm: "0px" },
          }}
        >
          {t("customize_interview_module_desc")}
        </Typography>
      </Grid>
      <Grid item xs={12} sm={6}>
        <SettingsInnerContainer>
          <Typography component="p" variant="body1">
            {t("cultural_round_title")}
          </Typography>

          <CustomSwitch
            checked={checked}
            onChange={handleChange}
            inputProps={{ "aria-label": "ant design" }}
          />
        </SettingsInnerContainer>
        <SettingsInnerContainer>
          <Typography component="p" variant="body1">
            {t("technical_round_title")}
          </Typography>
          <CustomSwitch
            checked={checkedTechnical}
            onChange={handleChangeTechnicalRound}
            inputProps={{ "aria-label": "controlled" }}
          />
        </SettingsInnerContainer>
        <SettingsInnerContainer>
          <Typography component="p" variant="body1">
            {t("client_round_title")}
          </Typography>
          <CustomSwitch
            checked={checkedClient}
            onChange={handleChangeClientRound}
            inputProps={{ "aria-label": "controlled" }}
          />
        </SettingsInnerContainer>
        <SettingsInnerContainer>
          <Typography component="p" variant="body1">
            {t("online_tech_assessment_title")}
          </Typography>
          <CustomSwitch
            checked={checkedTechnicalAssesment}
            onChange={handleChangeTechnicalAssesment}
            inputProps={{ "aria-label": "controlled" }}
          />
        </SettingsInnerContainer>
      </Grid>
    </Grid>
  );
}

export default SettingsSwtich;
