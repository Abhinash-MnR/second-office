// React, Next packages
import React, { useState, useEffect } from "react";
import { connect } from "react-redux";
import { Dispatch } from "redux";
import dynamic from "next/dynamic";
import Link from "next/link";
// Mui packages
import {
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  Paper,
  Typography,
  styled,
  Stack,
  FormControl,
  MenuItem,
  Select,
  SelectChangeEvent,
  Grid,
  Box,
  Pagination,
} from "@mui/material";
// 3Rd Party Component/Packages
import { useSnackbar } from "notistack";
import moment from "moment";
// Custom packages
import { RootState } from "reducers";
import { expensesList } from "@reducers/expensesSlice";
import NoOfficeData from "features/officeManagement/NoOfficeData";

const CustomContainer = styled("div")(({ theme }) => ({
  display: "flex",
  flexDirection: "column",
  marginTop: 40,
}));
const CustomTableContainer = styled("div")(({ theme }) => ({
  display: "flex",
}));

const StyledTableRow = styled(TableRow)(({ theme }) => ({
  "&:nth-of-type(odd)": {
    // backgroundColor: theme.palette.action.hover,
  },
  // hide last border
  "&:last-child td, &:last-child th": {
    border: 0,
  },
}));

const StyledTableCell = styled(TableCell)(({ theme }) => ({
  fontSize: 14,
  padding: "18px",
}));

const CustomSelectContainer = styled("div")(({ theme }) => ({
  display: "flex",
  justifyContent: "space-between",
  paddingBottom: "20px",
  [theme.breakpoints.down("sm")]: {
    display: "flex",
    flexDirection: "column",
  },
}));

const TableData = [
  {
    id: "1",
    date: "May 10, 2022",
    before_changes: "Cultural round on",
    after_changes: "Cultural Round Off",
    status: "Success",
  },
  {
    id: "2",
    date: "May 10, 2022",
    before_changes: "Technical round on",
    after_changes: "Technical Round Off",
    status: "Success",
  },
  {
    id: "3",
    date: "May 10, 2022",
    before_changes: "Cultural round on",
    after_changes: "Cultural Round Off",
    status: "Success",
  },
  {
    id: "4",
    date: "May 10, 2022",
    before_changes: "Client round on",
    after_changes: "Client Round Off",
    status: "Success",
  },
  {
    id: "5",
    date: "May 10, 2022",
    before_changes: "Technical round on",
    after_changes: "Technical Round Off",
    status: "Success",
  },
];

function SettingsHistory() {
  return (
    <CustomContainer>
      <Box>
        <Typography component="h3" variant="h3" sx={{ marginBottom: 3.75 }}>
          Settings History
        </Typography>
      </Box>
      <CustomTableContainer>
        <TableContainer component={Paper} sx={{ boxShadow: "none" }}>
          <Table sx={{ minWidth: 1050 }} aria-label="simple table">
            <TableHead sx={{ background: "#ECEDF4" }}>
              <StyledTableRow>
                <StyledTableCell
                  sx={{ fontSize: 16, lineHeight: 1.5, fontWeight: 700 }}
                >
                  Date
                </StyledTableCell>
                <StyledTableCell
                  sx={{ fontSize: 16, lineHeight: 1.5, fontWeight: 700 }}
                >
                  Before Changes
                </StyledTableCell>
                <StyledTableCell
                  sx={{ fontSize: 16, lineHeight: 1.5, fontWeight: 700 }}
                >
                  After Changes
                </StyledTableCell>
                <StyledTableCell
                  sx={{ fontSize: 16, lineHeight: 1.5, fontWeight: 700 }}
                >
                  Status
                </StyledTableCell>
              </StyledTableRow>
            </TableHead>
            <TableBody>
              {TableData?.map((row, index) => (
                <TableRow
                  key={row?.id}
                  sx={{ "&:last-child td, &:last-child th": { border: 0 } }}
                >
                  <StyledTableCell
                    sx={{
                      fontSize: 14,
                      fontWeight: 600,
                      lineHeight: 1.5,
                      color: "#222222",
                    }}
                  >
                    {moment(row?.date).format("MMMM DD, YYYY")}
                  </StyledTableCell>
                  <StyledTableCell>{row?.before_changes}</StyledTableCell>
                  <StyledTableCell>{row?.after_changes}</StyledTableCell>
                  <StyledTableCell>
                    <Stack direction="row" alignItems="center">
                      <Typography
                        component="span"
                        sx={{
                          fontSize: 14,
                          fontWeight: 700,
                          lineHeight: 1.5,
                          color: "#2c3058",
                        }}
                      >
                        {row?.status}
                      </Typography>
                    </Stack>
                  </StyledTableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </TableContainer>
      </CustomTableContainer>
    </CustomContainer>
  );
}

export default SettingsHistory;
