// React, Next packages
import React from "react";
import dynamic from "next/dynamic";
import Link from "next/link";
// Mui packages
import {
  Grid,
  styled,
  TextField,
  Box,
  Typography,
  Button,
  Stack,
} from "@mui/material";
// Third party packages
import { useTranslation } from "react-i18next";

const SettingsContainer = styled("div")(({ theme }) => ({
  display: "flex",
  flexDirection: "column",
  paddingTop: 20,
  [theme.breakpoints.down("sm")]: {
    display: "flex",
  },
}));

function SettingsLinks() {
  const handleSubmit = () => {
    console.log("Settings Submited");
  };

  //**language translation hooks */
  const { t } = useTranslation();

  return (
    <SettingsContainer>
      <Grid container>
        <Grid item xs={12} sm={6}>
          <Typography component="h6" variant="h6" sx={{ marginBottom: "10px" }}>
            {t("customize_usefull_link_title")}
          </Typography>
          <Typography
            component="p"
            variant="body1"
            sx={{
              width: { sm: "436px", xs: "100%" },
              marginBottom: { xs: "30px", sm: "0px" },
            }}
          >
            {t("customize_usefull_link_desc")}
          </Typography>
        </Grid>
        <Grid item sm={6} xs={12}>
          <Box sx={{ display: "flex", flexDirection: "column" }}>
            <Typography
              component="p"
              sx={{
                fontSize: "12px",
                lineHeight: "150%",
                marginBottom: "8px",
              }}
            >
              {t("management_log_link_title")}
            </Typography>
            <TextField
              required
              id="outlined-required"
              value="https:/www.drive.co/file_tech_drive_link_do_copy"
              disabled
              sx={{ width: { sm: "100%", xs: "100%" } }}
            />
            <Stack
              direction="row"
              justifyContent="flex-end"
              sx={{ width: { sm: "100%", xs: "100%" } }}
            >
              <Button
                component="a"
                variant="contained"
                rel="noopener noreferrer"
                size="medium"
                sx={{
                  marginTop: 3.75,
                  width: "134px",
                }}
                onClick={handleSubmit}
              >
                Save
              </Button>
            </Stack>
          </Box>
        </Grid>
      </Grid>
    </SettingsContainer>
  );
}

export default SettingsLinks;
