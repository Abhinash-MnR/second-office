// React , Next js packages
import React, { useState, useEffect } from "react";
import { useRouter } from "next/router";
// MUI packages
import {
  Box,
  Grid,
  Typography,
  MenuItem,
  FormControl,
  Select,
  Stack,
} from "@mui/material";
// Custom packages
import useCompany from "@lib/useCompany";
// Third party packages
import { useTranslation } from "react-i18next";
import { useSnackbar } from "notistack";

function LanguageSwitch({ languageSelected, language }) {
  const { company } = useCompany();
  //**third party hooks */
  const { enqueueSnackbar } = useSnackbar();

  useEffect(() => {
    setLang(company?.language);
  }, [company]);

  //**useState hooks */
  const [lang, setLang] = useState("");

  //**language translation hooks */
  const { t } = useTranslation();
  //** handle Language */
  const handleLanguage = (e) => {
    enqueueSnackbar(`${t("settings_save_warning")}`, {
      variant: "warning",
    });
    setLang(e.target.value);
  };

  useEffect(() => {
    languageSelected(lang);
  }, [lang]);

  console.log(lang, "language switch page");

  return (
    <Box>
      <Grid container>
        <Grid item xs={12} sm={6}>
          <Typography variant="h6">
            {t("customize_language_mode_title")}
          </Typography>
          <Typography
            variant="body1"
            color="text.primary"
            mt={1.5}
            mb={{ xs: 2, sm: 0 }}
            width={{ xs: "100%", sm: `436px` }}
          >
            {t("customize_language_mode_desc")}
          </Typography>
        </Grid>
        <Grid item xs={12} sm={6}>
          <Stack direction={`row`} justifyContent="space-between">
            <Typography> {t("language_title")}</Typography>
            <FormControl sx={{ width: { xs: "40%", sm: "30%" } }}>
              <Select
                value={lang}
                onChange={handleLanguage}
                sx={{
                  height: "44px",
                  color: "#222222",
                  fontSize: "16px !important",
                }}
              >
                <MenuItem value="English" selected>
                  <Typography variant="body1" color="text.primary">
                    {t("language_eng")}
                  </Typography>
                </MenuItem>
                <MenuItem value="Korean" selected color="text.primary">
                  <Typography variant="body1"> {t("language_kor")}</Typography>
                </MenuItem>
              </Select>
            </FormControl>
          </Stack>
        </Grid>
      </Grid>
    </Box>
  );
}

export default LanguageSwitch;
