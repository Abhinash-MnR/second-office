// React, Next Packages
import React, { useState, useEffect } from "react";
// Mui packages
import {
  Grid,
  styled,
  Typography,
  FormControl,
  MenuItem,
  Select,
  SelectChangeEvent,
  useMediaQuery,
} from "@mui/material";
// Third party packages
import { useTranslation } from "react-i18next";
import { useSnackbar } from "notistack";
// Custom Packages
import useCompany from "@lib/useCompany";
import selectPerformanceReview from "data/selectPerformanceReview";
import selectCurrency from "data/selectCurrency";

const SettingsContainer = styled("div")(({ theme }) => ({
  display: "flex",
  flexDirection: "column",
  padding: "10px 0",
  [theme.breakpoints.down("sm")]: {
    display: "flex",
    padding: "0",
  },
}));

const SettingsInnerContainer = styled("div")(({ theme }) => ({
  display: "flex",
  flexDirection: "row",
  width: "100%",
  paddingRight: "8px",
  justifyContent: "space-between",
  [theme.breakpoints.down("sm")]: {
    display: "flex",
    width: "100%",
    marginTop: "16px",
  },
}));

function OthersSettings({ currencySelected, performanceReviewSelected }) {
  /* Mobile View Responsive   */
  const IsMobile = useMediaQuery("(max-width:600px)");

  const { company, isLoading, isError } = useCompany();

  //**language translation hooks */
  const { t } = useTranslation();
  //**third party hooks */
  const { enqueueSnackbar } = useSnackbar();
  /** useEffect hooks */
  useEffect(() => {
    setIsMonthSelected(company?.performance_review_frequency);
    setCurrency(company?.currency);
  }, [company]);

  // Performance Settings
  const [isMonthSelected, setIsMonthSelected] = useState<string>("1");
  const [currency, setCurrency] = useState("");

  const handleChangeMonth = (event: SelectChangeEvent) => {
    enqueueSnackbar(`${t("settings_save_warning")}`, {
      variant: "warning",
    });
    performanceReviewSelected(event.target.value);
    setIsMonthSelected(event.target.value);
  };

  const handleChangeCurrency = (e) => {
    enqueueSnackbar(`${t("settings_save_warning")}`, {
      variant: "warning",
    });
    currencySelected(e.target.value);
    setCurrency(e.target.value);
  };

  return (
    <SettingsContainer>
      <Grid container>
        <Grid item xs={12} sm={6}>
          <Typography component="h6" variant="h6">
            {t("customize_currency_mode_title")}
          </Typography>
          <Typography
            component="p"
            variant="body1"
            sx={{
              width: { sm: "436px", xs: "100%" },
              marginTop: "10px",
            }}
          >
            {t("customize_currency_mode_desc")}
          </Typography>
        </Grid>
        <Grid item xs={12} sm={6}>
          {/* Performance Review Component */}
          {/* <SettingsInnerContainer>
            <Typography
              component="p"
              variant="body1"
              sx={{ width: { sm: "252px", xs: "147px" } }}
            >
              Performance Review Frequency
            </Typography>

            <Select
              labelId="demo-simple-select-label"
              id="demo-simple-select"
              value={isMonthSelected ? isMonthSelected : "Monthly"}
              onChange={handleChangeMonth}
              sx={{ width: { sm: "160px", xs: "130px" }, height: "40px" }}
            >
              {selectPerformanceReview.map((item, index) => (
                <MenuItem value={item.value}>{item.label}</MenuItem>
              ))}
            </Select>
          </SettingsInnerContainer> */}

          {/* currency list dropdown Component */}
          <SettingsInnerContainer>
            <Typography component="p" variant="body1">
              {t("currency_title")}
            </Typography>
            <Select
              labelId="demo-simple-select-label"
              id="demo-simple-select"
              value={currency ? currency : "USD"}
              onChange={handleChangeCurrency}
              sx={{ width: { sm: "160px", xs: "130px" }, height: "40px" }}
            >
              {selectCurrency.map((item, index) => (
                <MenuItem value={item.value}>{item.label}</MenuItem>
              ))}
            </Select>
          </SettingsInnerContainer>
        </Grid>
      </Grid>
    </SettingsContainer>
  );
}

export default OthersSettings;
