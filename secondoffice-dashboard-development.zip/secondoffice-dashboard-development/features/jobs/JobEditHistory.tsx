// React, Next packages
import React, { useEffect, useState } from "react";
import dynamic from "next/dynamic";
import Link from "next/link";
import { useRouter } from "next/router";
// import { useRouter } from "next/router";
import { connect } from "react-redux";
import { Dispatch } from "redux";
// Mui packages
import {
  Paper,
  Box,
  Grid,
  Button,
  Typography,
  styled,
  Stack,
  useMediaQuery,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  Pagination,
} from "@mui/material";
// 3Rd Party Component/Packages
import { useSnackbar } from "notistack";
import moment from "moment";
import { useTranslation } from "react-i18next";
import "translation/i18n";
// custom Packages
import { BackIcon } from "@common/Icon";
import { jobsHistoryList } from "reducers/jobsHistorySlice";
import { RootState } from "reducers";
import NoOfficeData from "features/officeManagement/NoOfficeData";
import useCompany from "@lib/useCompany";

const EditHistoryContainer = styled("div")(({ theme }) => ({
  display: "flex",
  flexDirection: "column",
  width: "100%",
  paddingLeft: "8px",
  paddingTop: 8,
  [theme.breakpoints.down("sm")]: {
    display: "flex",
    flexDirection: "column",
    paddingLeft: "0px",
  },
}));

const EditHistoryTitleContainer = styled("div")(({ theme }) => ({
  display: "flex",
  flexDirection: "row",
  justifyContent: "space-between",
  alignItems: "center",
  marginBottom: 40,
  [theme.breakpoints.down("sm")]: {
    display: "flex",
    flexDirection: "column",
  },
}));

const ViewJobsTitle = styled("div")(({ theme }) => ({
  display: "flex",
  flexDirection: "row",
  marginBottom: 40,
  alignItems: "center",
  [theme.breakpoints.down("sm")]: {
    display: "flex",
    flexDirection: "row",
  },
}));

const CustomTableContainer = styled("div")(({ theme }) => ({
  display: "flex",
}));

const StyledTableRow = styled(TableRow)(({ theme }) => ({
  "&:nth-of-type(odd)": {
    // backgroundColor: theme.palette.action.hover,
  },
  // hide last border
  "&:last-child td, &:last-child th": {
    border: 0,
  },
}));

const StyledTableCell = styled(TableCell)(({ theme }) => ({
  fontSize: 14,
  padding: "18px",
}));

function JobEditHistory(props) {
  //SnackBar
  const { enqueueSnackbar } = useSnackbar();
  /** props - actions */
  const { jobsHistoryList } = props;
  /** props - states */
  const { result, count } = props;
  const pageNumber = Math.ceil(count / 10);
  const [attendanceLogListPage, setAttendanceLogListPage] = useState(1);
  const { company } = useCompany();
  // const { index } = props;
  const router = useRouter();
  //**language translation hooks */
  const { t } = useTranslation();

  useEffect(() => {
    console.log(result, ":-index:-", result);
  }, [result]);

  /** useState hooks */
  const [isUpdating, setIsUpdating] = useState<boolean>(false);
  const [job, setJob] = useState();
  const [index, setIndex] = useState<any>();

  // useEffect(() => {
  //   debugger
  //   for (var i = 0; i < jobs.length; i++) {
  //     if (jobs[i].id === location.href.split("/")[5]) {
  //       setJob(jobs[i]);
  //       setIndex(i);
  //     }
  //   }
  // }, [jobs]);

  /** useEffect hooks */
  useEffect(() => {
    const roaster = async () => {
      await jobsHistoryList({ page: attendanceLogListPage, page_size: 10 });
    };

    try {
      roaster();
    } catch (error: any) {
      enqueueSnackbar(error.toString(), { variant: "error" });
    }
  }, [attendanceLogListPage]);

  // -----------Edit difference----------
  const jobEditHistoryData = result.filter(
    (item: any) => item.id === location.href.split("/")[5]
  );

  console.log("jobEditHistoryData: ", jobEditHistoryData);
  // const [editedKeys, setEditedKeys] = useState<any>([]);

  // let editedKeys = [];

  // const difference = (obj1, obj2) => {
  //   var keyFound = [];
  //   Object.keys(obj1).forEach((key) => {
  //     if (obj1[key] !== obj2[key]) {
  //       return keyFound.push(key);
  //     }
  //   });
  //   console.log("difference:" + typeof keyFound, keyFound);
  //   editedKeys = keyFound;
  //   return keyFound || -1;
  // };

  // jobEditHistoryData.forEach((item, index) => {
  //   if (index !== jobEditHistoryData.length - 1) {
  //     difference(item, jobEditHistoryData[index + 1]);
  //   }
  // });

  return (
    <EditHistoryContainer>
      <ViewJobsTitle>
        <Typography component="span">
          <BackIcon
            sx={{
              fontSize: { xs: "11px", sm: "12px" },
              marginRight: { xs: "5px", sm: "10px" },
              marginTop: "0.5px",
            }}
          />
        </Typography>
        <Typography
          component="h6"
          variant="h6"
          sx={{ cursor: "pointer" }}
          onClick={() => router.replace("/applications/")}
        >
          {t("job_edit_history_backIcon_title")}
        </Typography>
      </ViewJobsTitle>
      <CustomTableContainer>
        <TableContainer component={Paper} sx={{ boxShadow: "none" }}>
          <Table sx={{ minWidth: 1050 }} aria-label="simple table">
            <TableHead sx={{ background: "#ECEDF4" }}>
              <StyledTableRow>
                <StyledTableCell
                  sx={{ fontSize: 16, lineHeight: 1.5, fontWeight: 700 }}
                >
                  {t("job_edit_history_table_head_date")}
                </StyledTableCell>
                <StyledTableCell
                  sx={{ fontSize: 16, lineHeight: 1.5, fontWeight: 700 }}
                >
                  {t("job_edit_history_table_head_time")}
                </StyledTableCell>
                <StyledTableCell
                  sx={{ fontSize: 16, lineHeight: 1.5, fontWeight: 700 }}
                >
                  {t("job_edit_history_table_head_job")}
                </StyledTableCell>
                <StyledTableCell
                  sx={{ fontSize: 16, lineHeight: 1.5, fontWeight: 700 }}
                >
                  {t("job_edit_history_table_head_modified")}
                </StyledTableCell>
                <StyledTableCell
                  sx={{ fontSize: 16, lineHeight: 1.5, fontWeight: 700 }}
                >
                  {t("job_edit_history_table_head_modifiedby")}
                </StyledTableCell>
              </StyledTableRow>
            </TableHead>
            <TableBody>
              {result
                .filter((item: any) => item.id === location.href.split("/")[5])
                .map((row, index) => (
                  <TableRow
                    key={index}
                    sx={
                      jobEditHistoryData.length > 0 &&
                      index !== jobEditHistoryData.length - 1
                        ? { "&:last-child td, &:last-child th": { border: 0 } }
                        : { display: "none" }
                    }
                  >
                    <StyledTableCell
                      component="th"
                      scope="row"
                      sx={{
                        fontSize: 14,
                        fontWeight: 400,
                        lineHeight: 1.5,
                        color: "#222222",
                      }}
                    >
                      {moment(row?.modified_at).format("MMMM DD, YYYY")}
                    </StyledTableCell>
                    <StyledTableCell>
                      {moment(row?.modified_at).format("HH:MM a")}
                    </StyledTableCell>
                    <StyledTableCell>{row?.job_title}</StyledTableCell>
                    <StyledTableCell>
                      <Stack
                        direction="row"
                        alignItems="center"
                        justifyContent="start"
                      >
                        {jobEditHistoryData.length > 0 &&
                          index !== jobEditHistoryData.length - 1 && (
                            <Typography
                              component="span"
                              sx={{
                                fontSize: 14,

                                lineHeight: 1.5,
                              }}
                            >
                              {Object.keys(jobEditHistoryData[index + 1]).map(
                                (key) => {
                                  return (
                                    <div>
                                      {jobEditHistoryData[index + 1][key] !==
                                        row[key] &&
                                      key !== "modified_at" &&
                                      key !== "edited_by_admin"
                                        ? key.split("_").join(" ")
                                        : null}
                                    </div>
                                  );
                                }
                              )}
                            </Typography>
                          )}
                      </Stack>
                    </StyledTableCell>
                    <StyledTableCell>
                      <Stack
                        direction="row"
                        alignItems="center"
                        justifyContent="start"
                      >
                        <Typography
                          component="span"
                          sx={{
                            fontSize: 14,

                            lineHeight: 1.5,
                          }}
                        >
                          {row?.edited_by_admin
                            ? "Recruitment Team"
                            : company?.company_name + " Team"}
                        </Typography>
                      </Stack>
                    </StyledTableCell>
                  </TableRow>
                ))}
            </TableBody>
          </Table>
        </TableContainer>
      </CustomTableContainer>

      {/* Empty State when data not available  */}
      <Box>
        {jobEditHistoryData.length > 1 ? null : (
          <NoOfficeData
            title={`${t("jobs_edit_history_emptybox_title")}`}
            imgName="job_history_empty"
          />
        )}
      </Box>

      {/* Pagination for Team Expenses List   */}
      {/* {count > 10 ? (
        <Grid container spacing={1}>
          <Grid item xs={12}>
            <Box sx={{ display: "flex", justifyContent: "center" }}>
              <Stack
                direction="row"
                alignItems="center"
                justifyContent="center"
                paddingTop={5}
                paddingBottom={3}
              >
                <Pagination
                  count={pageNumber}
                  color="secondary"
                  onChange={(e, value) => setAttendanceLogListPage(value)}
                  sx={{
                    background: "#ECEDF4",
                    borderRadius: "10px",
                    padding: { xs: "5px", sm: "10px" },
                  }}
                />
              </Stack>
            </Box>
          </Grid>
        </Grid>
      ) : (
        ""
      )} */}
    </EditHistoryContainer>
  );
}

const mapStateToProps = (state: RootState) => ({
  result: state.jobsHistory.results,
  count: state.jobsHistory.count,
});

const mapDispatchToProps = (dispatch: Dispatch) => {
  return {
    jobsHistoryList: (id: string) => jobsHistoryList(dispatch, id),
  };
};

export default connect(mapStateToProps, mapDispatchToProps)(JobEditHistory);
