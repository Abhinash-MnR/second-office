// React, Next packages
import React, { FC, MouseEvent } from "react";
// Mui packages
import {
  Box,
  Button,
  Chip,
  Grid,
  Stack,
  styled,
  Typography,
} from "@mui/material";
// Third-party packages
import dayjs from "dayjs";
// Custom packages
import { ClockIcon, LocationIcon, PaperIcon, RupeeIcon } from "@common/Icon";
import { formatUnderscore } from "@lib/formatter";
import { JobListResponse } from "types/JobResponse";

type JobCardProps = {
  /** Job object returned from the API */
  data?: JobListResponse;
  /** If `true`, show the applicant analytics */
  hasPermission?: boolean;
  /** Callback triggered on card click */
  onClick?: (...params: any) => void;
  /** Callback triggered when `View Applicants` button is clicked */
  onViewApplicants?: (...params: any) => void;
  /** Callback triggered when `Saved Candidates` button is clicked */
  onViewSaved?: (...params: any) => void;
  /** Callback triggered when `Search Candidates` button is clicked */
  onViewSearch?: (...params: any) => void;
};

const JobCardContainer = styled("div")(({ theme }) => ({
  display: "flex",
  justifyContent: "space-between",
  flexDirection: "column",
  borderRadius: theme.shape.borderRadius,
  border: "1px solid #DDDDDD",
  background: "#ffffff",
  height: "100%",
  padding: theme.spacing(2),
  paddingBottom: theme.spacing(2.5),
  KhtmlUserSelect: "none",
  MozUserSelect: "-moz-none",
  WebkitUserSelect: "none",
  MsUserSelect: "none",
  userSelect: "none",
  "&:hover": {
    background: "#efefef",
    cursor: "pointer",
  },
}));

const StackItem = styled("div")(({ theme }) => ({
  alignItems: "center",
  color: theme.palette.grey[500],
  display: "flex",
  marginBottom: 10,
  marginRight: 30,

  "& :first-of-type": {
    fontSize: 14,
    marginRight: 5,
  },
}));

export const JobCard: FC<JobCardProps> = (props: JobCardProps) => {
  /** custom hooks */

  /** props */
  const {
    data,
    hasPermission,
    onClick,
    onViewApplicants,
    onViewSaved,
    onViewSearch,
  } = props;

  /** custom handlers */
  const handleViewApplicants = (e: MouseEvent<HTMLElement>) => {
    e.preventDefault();
    e.stopPropagation();
    onViewApplicants && onViewApplicants(data);
  };

  const handleViewSaved = (e: MouseEvent<HTMLElement>) => {
    e.preventDefault();
    e.stopPropagation();
    onViewSaved && onViewSaved(data);
  };

  const handleViewSearch = (e: MouseEvent<HTMLElement>) => {
    e.preventDefault();
    e.stopPropagation();
    onViewSearch && onViewSearch(data);
  };

  return (
    <JobCardContainer onClick={onClick}>
      <div>
        <Stack
          alignItems="center"
          direction="row"
          flexWrap="wrap"
          marginBottom={0.625}
          justifyContent="space-between"
        >
          <Typography variant="h6" fontWeight="600">
            {data?.job_title}
          </Typography>
          <Typography color="secondary.dark" variant="button">
            {data?.applicant_count} Applicants
          </Typography>
        </Stack>

        <Stack direction="row" flexWrap="wrap">
          {/* Salary information */}
          <StackItem>
            <RupeeIcon />
            <Typography variant="body2">
              {`${data?.salary_range_start}-${data?.salary_range_end} LPA`}
            </Typography>
          </StackItem>
          {/* Nature of Job */}
          <StackItem>
            <LocationIcon />
            <Typography variant="body2">{data?.job_location}</Typography>
          </StackItem>
          {/* Job location */}
          <StackItem>
            <ClockIcon />
            <Typography variant="body2">
              {formatUnderscore(data?.nature_of_job as string)}
            </Typography>
          </StackItem>
        </Stack>
        <StackItem>
          <PaperIcon />
          <Typography variant="body2" noWrap maxWidth={600}>
            {data?.job_description}
          </Typography>
        </StackItem>
        <Box
          alignItems="center"
          display="flex"
          flexWrap="wrap"
          marginTop={2}
          marginBottom={2}
        >
          {data?.job_tags &&
            data?.job_tags.map(({ id, tag }) => (
              <Chip
                key={id}
                sx={{
                  backgroundColor: "#F3F5F9",
                  marginRight: 1.25,
                  marginBottom: 0.5,
                }}
                label={tag && tag.trim()}
              />
            ))}
        </Box>
      </div>
      <Grid container alignItems="center">
        <Grid item xs={4}>
          <Typography color="grey.400" variant="caption">
            Posted {dayjs(data?.created_at as string).fromNow()}
          </Typography>
        </Grid>
        <Grid item xs={8} display="flex" justifyContent="flex-end">
          {onViewApplicants && (
            <Button
              color="primary"
              onClick={handleViewApplicants}
              size="small"
              variant="contained"
            >
              View Applicants
            </Button>
          )}
          {onViewSearch && (
            <Button
              color="primary"
              onClick={handleViewSearch}
              size="small"
              variant="contained"
            >
              Search Candidates
            </Button>
          )}
          {onViewSaved && (
            <Button
              color="primary"
              fullWidth
              onClick={handleViewSaved}
              size="small"
            >
              Saved Candidates
            </Button>
          )}
        </Grid>
      </Grid>
    </JobCardContainer>
  );
};
