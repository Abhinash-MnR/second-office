// React, Next packages
import React, { FC } from "react";
import { Form, FormProps, Field } from "react-final-form";
// Mui packages
import { Button, Grid } from "@mui/material";
// Custom packages
import numberOfOpening from "data/numberOfOpening";
import salaryRange from "data/salaryRange";
import experienceRange from "data/experienceRange";
import { DialogForm, DialogFormProps } from "@common/DialogForm";
import {
  ChipGroupField,
  LocationField,
  TagField,
  TextField,
} from "@common/FormField";
import {
  ArrayValidator,
  DateValidator,
  StringValidator,
} from "@lib/form-validations";
import { TagResponse } from "types/TagResponse";

type IFormData = {
  /** Job description */
  job_description: string;
  /** Employment type of the job */
  nature_of_job: string;
  /** Experience range  */
  experience_range: Array<number | string>;
  /** Job position location */
  job_location?: string;
  /** Count of people needed */
  no_of_opening?: number | string;
  /** Job position title */
  job_title: string;
  /** Job posted date */
  job_deadline: string;
  /** Job's salary range  */
  salary_range: Array<number | string>;
  /** Tag data list to be displayed as chips  */
  job_tags: Array<TagResponse>;
};

export type JobDetailFormProps = {} & FormProps & DialogFormProps;

const arrayValidator = new ArrayValidator();
const dateValidator = new DateValidator();
const stringValidator = new StringValidator();

export const JobDetailForm: FC<JobDetailFormProps> = (props) => {
  /** props */
  const { onSubmit, open, onClose, title, initialValues } = props;

  return (
    <DialogForm open={open} onClose={onClose} title={title}>
      <Form onSubmit={onSubmit} initialValues={initialValues}>
        {({ handleSubmit }) => (
          <form id="job_position_form" onSubmit={handleSubmit}>
            <Grid container spacing={3.75}>
              <Grid item xs={12}>
                <Field
                  component={TextField}
                  fullWidth
                  name="job_title"
                  placeholder="Job Position Name"
                  size="small"
                  title="What is the name of your job position?*"
                  variant="outlined"
                  validate={stringValidator.validateRequiredMax128}
                />
              </Grid>
              <Grid item xs={12}>
                <Field
                  component={LocationField}
                  fullWidth
                  name="job_location"
                  required
                  placeholder="Job Position Location"
                  title="For which location are your hiring for?*"
                  variant="outlined"
                  validate={stringValidator.validateRequiredMax128}
                />
              </Grid>
              <Grid item xs={12}>
                <Field
                  component={ChipGroupField}
                  name="no_of_opening"
                  options={numberOfOpening}
                  title="How many people are you hiring?*"
                  validate={stringValidator.validateRequired}
                />
              </Grid>
              <Grid item xs={12}>
                <Field
                  component={ChipGroupField}
                  name="salary_range"
                  options={salaryRange}
                  title="Which range are you offering the salary in? (in LPA)*"
                  validate={stringValidator.validateRequired}
                />
              </Grid>
              <Grid item xs={12}>
                <Field
                  component={ChipGroupField}
                  name="experience_range"
                  options={experienceRange}
                  title="How many years of experience should the applicant have?*"
                  validate={stringValidator.validateRequired}
                />
              </Grid>
              <Grid item xs={12}>
                <Field
                  component={TagField}
                  name="job_tags"
                  title="Which skills do you think are important for the applicant to hone?*"
                  validate={arrayValidator.validateMin1}
                />
              </Grid>
              <Grid item xs={12}>
                <Field
                  component={TextField}
                  fullWidth
                  InputLabelProps={{
                    shrink: true,
                  }}
                  name="job_deadline"
                  type="date"
                  size="small"
                  title="Till when do you keep position open? (Max for 3 months)*"
                  variant="outlined"
                  validate={dateValidator.validateFutureMax3}
                />
              </Grid>
              <Grid item xs={12}>
                <Field
                  component={TextField}
                  fullWidth
                  inputProps={{ maxLength: 4000 }}
                  multiline
                  name="job_description"
                  placeholder="Describe your job position within 4000 characters."
                  minRows={4}
                  maxRows={4}
                  title="Give the job description below in detail*"
                  validate={stringValidator.validateRequiredMax4000}
                  variant="outlined"
                />
              </Grid>
              <Grid item xs={12}>
                <Button
                  color="primary"
                  type="submit"
                  fullWidth
                  variant="contained"
                >
                  Save
                </Button>
              </Grid>
            </Grid>
          </form>
        )}
      </Form>
    </DialogForm>
  );
};
