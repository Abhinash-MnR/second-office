// React, Next packages
import React, { FC } from "react";
// Mui packages
import {
  Box,
  Button,
  Chip,
  Skeleton,
  Stack,
  styled,
  Typography,
} from "@mui/material";
// Custom packages
import {
  CalendarIcon,
  ClockIcon,
  LocationIcon,
  PeopleIcon,
  RupeeIcon,
} from "@common/Icon";
import { DialogForm, DialogFormProps } from "@common/DialogForm";
import { formatUnderscore } from "@lib/formatter";
import { JobListResponse } from "types/JobResponse";

export type JobDetailDialogProps = {
  /** Callback triggered when close job button is clicked */
  onDelete?: (...params: any) => void;
  /** Callback triggered when edit button is clicked  */
  onEdit?: (...params: any) => void;
  /** Job data from API */
  jobData: JobListResponse;
} & DialogFormProps;

const StackItem = styled("div")(({ theme }) => ({
  alignItems: "center",
  color: theme.palette.grey[500],
  display: "flex",
  marginBottom: 15,
  marginRight: 30,

  "& :first-of-type": {
    color: theme.palette.grey[600],
    fontSize: 14,
    marginRight: 10,
  },
}));

export const JobDetailDialog: FC<JobDetailDialogProps> = (props) => {
  /** props */
  const { jobData, open, onClose, onDelete, onEdit } = props;

  return (
    <DialogForm
      open={open}
      onClose={onClose}
      title={jobData ? jobData.job_title : <Skeleton width={300} height={50} />}
      footer={
        <Stack
          alignItems="center"
          direction="row"
          justifyContent="flex-end"
          width={{ xs: "100%", md: "60%" }}
          marginLeft="auto"
        >
          {onDelete && (
            <Button disabled={!jobData} fullWidth onClick={onDelete}>
              Close the position
            </Button>
          )}
          {onEdit && (
            <Button
              disabled={!jobData}
              color="primary"
              fullWidth
              variant="contained"
              onClick={onEdit}
            >
              Edit
            </Button>
          )}
        </Stack>
      }
    >
      <Stack direction="row" flexWrap="wrap" marginBottom={1.25}>
        {/* Salary information */}
        <StackItem>
          <RupeeIcon />
          {jobData ? (
            <Typography variant="body1">
              {`${jobData.salary_range_start}-${jobData.salary_range_end} LPA`}
            </Typography>
          ) : (
            <Skeleton width={80} height={30} />
          )}
        </StackItem>

        {/* Nature of Job */}
        <StackItem>
          <CalendarIcon />
          {jobData ? (
            <Typography variant="body1">
              {formatUnderscore(jobData.nature_of_job)}
            </Typography>
          ) : (
            <Skeleton width={80} height={30} />
          )}
        </StackItem>

        {/* Job location */}
        <StackItem>
          <LocationIcon />
          {jobData ? (
            <Typography variant="body1">{jobData.job_location}</Typography>
          ) : (
            <Skeleton width={80} height={30} />
          )}
        </StackItem>

        {/* No. of opening */}
        <StackItem>
          <PeopleIcon />
          {jobData ? (
            <Typography variant="body1">
              {jobData.no_of_opening} People Needed
            </Typography>
          ) : (
            <Skeleton width={80} height={30} />
          )}
        </StackItem>

        {/* Experience range */}
        <StackItem>
          <ClockIcon />
          {jobData ? (
            <Typography variant="body1">
              {`${jobData.experience_range_start}-${jobData.experience_range_end} Years`}
            </Typography>
          ) : (
            <Skeleton width={80} height={30} />
          )}
        </StackItem>
      </Stack>

      {/* Tags */}
      {jobData ? (
        <Box alignItems="center" display="flex" flexWrap="wrap" mb={2.5}>
          {jobData.job_tags &&
            jobData.job_tags.map(({ id, tag }) => (
              <Box key={id} mr={0.75} mb={0.75}>
                <Chip
                  sx={{ backgroundColor: "#F3F5F9" }}
                  label={tag && tag.trim()}
                />
              </Box>
            ))}
        </Box>
      ) : (
        <Skeleton width={60} height={30} />
      )}

      {/* Job description */}
      {jobData ? (
        <Box whiteSpace="pre-line" mb={3}>
          <Typography variant="body1">{jobData.job_description}</Typography>
        </Box>
      ) : (
        <Skeleton width={300} height={30} />
      )}
    </DialogForm>
  );
};
