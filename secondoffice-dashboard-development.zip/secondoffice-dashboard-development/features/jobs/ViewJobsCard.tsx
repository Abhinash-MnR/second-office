// React, Next packages
import React, { useEffect, useState } from "react";
import dynamic from "next/dynamic";
import Link from "next/link";
import { Dispatch } from "redux";
import { connect } from "react-redux";
import { useRouter } from "next/router";
// Mui packages
import {
  Box,
  Grid,
  Button,
  Typography,
  styled,
  useMediaQuery,
} from "@mui/material";
// Third-party packages
import { useSnackbar } from "notistack";
import { RootState } from "reducers";
import { fetchJob } from "reducers/jobsSlice";
import useCurrency from "@lib/useCurrency";
import useCompany from "@lib/useCompany";
import { useTranslation } from "react-i18next";
import "translation/i18n";

const JobsContainer = styled("div")(({ theme }) => ({
  display: "flex",
  flexDirection: "column",
  width: "100%",
  paddingLeft: 8,
  [theme.breakpoints.down("sm")]: {
    paddingLeft: "0px",
  },
}));

const JobsDescription = styled("div")(({ theme }) => ({
  display: "flex",
  flexDirection: "column",
  padding: "unset",
  [theme.breakpoints.down("sm")]: {
    padding: "15px",
  },
}));

const SkillsWrapper = styled("div")(({ theme }) => ({
  display: "flex",
  flexDirection: "column",
  padding: "unset",
  [theme.breakpoints.down("sm")]: {
    padding: "15px",
  },
}));

const ViewJobsSection = styled("div")(({ theme }) => ({
  display: "flex",
  flexDirection: "column",
  background: "#FFFFFF",
  // boxShadow: " 0px 16px 23px -4px rgba(145, 158, 171, 0.24)",
  borderRadius: theme.shape.borderRadius,
  padding: 20,
  marginTop: "20px",
  [theme.breakpoints.down("sm")]: {
    padding: 1,
  },
}));

const ViewJobsRequirementContainer = styled("div")(({ theme }) => ({
  display: "flex",
  flexDirection: "row",
  justifyContent: "center",
  alignItems: "center",
  height: "100px",
  [theme.breakpoints.down("sm")]: {
    display: "flex",
    flexDirection: "column",
    height: "auto",
  },
}));

const CustomJobsDetailsWrapper = styled("div")(({ theme }) => ({
  display: "flex",
  flexDirection: "column",
  justifyContent: "space-between",
  borderRight: "1px solid #8A8EBA",
  height: "58px",
  alignItems: "center",
  margin: "50px 0px",
  [theme.breakpoints.down("sm")]: {
    margin: "30px 0px",
    height: "auto",
  },
}));
const CustomJobsDetailsWrapperLast = styled("div")(({ theme }) => ({
  display: "flex",
  flexDirection: "column",
  justifyContent: "space-between",
  borderRight: "none",
  height: "58px",
  alignItems: "center",
  margin: "50px 0px",
  [theme.breakpoints.down("sm")]: {
    margin: "30px 0px",
    height: "auto",
  },
}));

function ViewJobCard(props: any) {
  /** third-party hooks */
  const { enqueueSnackbar } = useSnackbar();
  const router = useRouter();
  const isMobile = useMediaQuery("(max-width:600px)");
  /** props - actions */
  const { fetchJob } = props;
  /** props - states */
  const { jobs } = props;

  //**language translation hooks */
  const { t } = useTranslation();

  /** third-party hooks */
  const { company } = useCompany({
    redirectTo: "/",
  });

  const { currency } = useCurrency();

  /** useState hooks */
  const [isUpdating, setIsUpdating] = useState<boolean>(false);
  const [job, setJob] = useState();
  const [jobSkills, setJobSkills] = useState();
  const [index, setIndex] = useState<any>();

  /** useEffect hooks */
  useEffect(() => {
    const initializeJob = async () => {
      await fetchJob(location.href.split("/")[5]);
    };

    try {
      initializeJob();
    } catch (error: any) {
      enqueueSnackbar(error.toString(), { variant: "error" });
    }
  }, []);
  useEffect(() => {
    for (var i = 0; i < jobs.length; i++) {
      if (jobs[i].id === location.href.split("/")[5]) {
        setJob(jobs[i]);
        setIndex(i);
        setJobSkills(jobs[i].job_skills);
      }
    }
  }, [jobs]);

  // Convert number with commas
  const numberWithCommas = (x: string) => {
    return x.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",");
  };

  function convertValue(minValue: string, maxValue: string) {
    let value = "";
    if (Number(maxValue) === 100) {
      value = `${minValue}+`;
    } else {
      value = `${minValue} - ${maxValue}`;
    }
    return value;
  }

  return (
    <JobsContainer>
      <ViewJobsSection>
        <ViewJobsRequirementContainer>
          <Grid container>
            <Grid item xs={6} sm={3}>
              <CustomJobsDetailsWrapper>
                <Typography
                  component="p"
                  variant="body1"
                  paddingRight={isMobile ? `` : 4.1}
                  paddingLeft={isMobile ? `` : 4.1}
                >
                  {t("view_job_education_title")}
                </Typography>
                <Typography
                  component="p"
                  sx={{
                    fontSize: { sm: "16px", xs: "14px" },
                    fontWeight: "500",
                  }}
                >
                  {jobs[index]?.job_education}
                </Typography>
              </CustomJobsDetailsWrapper>
            </Grid>
            <Grid item xs={6} sm={3}>
              <CustomJobsDetailsWrapper>
                <Typography
                  component="p"
                  variant="body1"
                  paddingRight={isMobile ? `` : 4.1}
                  paddingLeft={isMobile ? `` : 4.1}
                >
                  {t("view_job_experiance_title")}
                </Typography>
                <Typography
                  component="p"
                  sx={{
                    fontSize: { sm: "16px", xs: "14px" },
                    fontWeight: "500",
                  }}
                >
                  {convertValue(
                    jobs[index]?.experience_min,
                    jobs[index]?.experience_max
                  )}
                </Typography>
              </CustomJobsDetailsWrapper>
            </Grid>
            <Grid item xs={6} sm={3}>
              <CustomJobsDetailsWrapper>
                <Typography
                  component="p"
                  variant="body1"
                  paddingRight={isMobile ? `` : 4.1}
                  paddingLeft={isMobile ? `` : 4.1}
                >
                  {t("view_job_salary_title")}
                </Typography>
                <Typography
                  component="p"
                  sx={{
                    fontSize: { sm: "16px", xs: "14px" },
                    fontWeight: "500",
                  }}
                >
                  {jobs[index]?.salary_max === 0 &&
                  jobs[index]?.salary_min === 0
                    ? "Salary No Bar"
                    : jobs[index]?.salary_max === 1 &&
                      jobs[index]?.salary_min === 1
                    ? "As per the market standards"
                    : (company && currency && company.currency) +
                      " " +
                      (company && currency && company.currency === "KRW"
                        ? " " +
                          numberWithCommas(
                            (
                              jobs[index]?.salary_min * currency.currency_krw
                            ).toFixed(2)
                          ) +
                          " - " +
                          numberWithCommas(
                            (
                              jobs[index]?.salary_max * currency.currency_krw
                            ).toFixed(2)
                          )
                        : company && currency && company.currency === "USD"
                        ? numberWithCommas(
                            (
                              (jobs[index]?.salary_min *
                                currency.currency_usd) /
                              1000
                            ).toFixed(2)
                          ) +
                          " - " +
                          numberWithCommas(
                            (
                              (jobs[index]?.salary_max *
                                currency.currency_usd) /
                              1000
                            ).toFixed(2)
                          )
                        : company && currency && company.currency === "EUR"
                        ? numberWithCommas(
                            (
                              (jobs[index]?.salary_min *
                                currency.currency_eur) /
                              1000
                            ).toFixed(2)
                          ) +
                          " - " +
                          numberWithCommas(
                            (
                              (jobs[index]?.salary_max *
                                currency.currency_eur) /
                              1000
                            ).toFixed(2)
                          )
                        : numberWithCommas(
                            (jobs[index]?.salary_min / 100000).toFixed(2)
                          ) +
                          " - " +
                          numberWithCommas(
                            (jobs[index]?.salary_max / 100000).toFixed(2)
                          )) +
                      (company && currency && company.currency === "KRW"
                        ? " "
                        : company && currency && company.currency === "USD"
                        ? " K"
                        : company && currency && company.currency === "EUR"
                        ? "K"
                        : " LPA") +
                      (company && currency && company.currency === "KRW"
                        ? "PA"
                        : company && currency && company.currency === "USD"
                        ? " PA"
                        : company && currency && company.currency === "EUR"
                        ? " PA"
                        : " ")}
                </Typography>
              </CustomJobsDetailsWrapper>
            </Grid>
            <Grid item xs={6} sm={3}>
              <CustomJobsDetailsWrapperLast>
                <Typography
                  component="p"
                  variant="body1"
                  paddingRight={isMobile ? `` : 4.1}
                  paddingLeft={isMobile ? `` : 4.1}
                >
                  {t("view_job_notice_period_title")}
                </Typography>
                <Typography
                  component="p"
                  sx={{
                    fontSize: { sm: "16px", xs: "14px" },
                    fontWeight: "500",
                  }}
                >
                  {jobs[index]?.job_notice_period}
                </Typography>
              </CustomJobsDetailsWrapperLast>
            </Grid>
          </Grid>
        </ViewJobsRequirementContainer>
        <SkillsWrapper>
          <Typography
            component="h5"
            variant="h5"
            color="primary.main"
            paddingTop={2}
          >
            {t("view_job_skills_title")}
          </Typography>
          <Typography
            component="span"
            paddingY={0.5}
            sx={{ textTransform: "capitalize" }}
          >
            {jobs[index]?.job_skills}
          </Typography>
        </SkillsWrapper>
        <JobsDescription>
          <Typography
            component="h5"
            variant="h5"
            color="primary.main"
            paddingY={1}
            marginTop="5px"
          >
            {t("view_job_description_title")}
          </Typography>
          <Typography component="p" variant="body1">
            <div
              dangerouslySetInnerHTML={{ __html: jobs[index]?.job_description }}
            />
          </Typography>
        </JobsDescription>
      </ViewJobsSection>
    </JobsContainer>
  );
}

const mapStateToProps = (state: RootState) => ({
  jobs: state.jobs.jobs,
});

const mapDispatchToProps = (dispatch: Dispatch) => {
  return {
    fetchJob: (id: string) => fetchJob(dispatch, id),
  };
};

export default connect(mapStateToProps, mapDispatchToProps)(ViewJobCard);
