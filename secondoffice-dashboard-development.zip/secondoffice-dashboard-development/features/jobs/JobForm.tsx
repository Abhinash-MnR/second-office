// React, Next packages
import React, { FC, useEffect, useState } from "react";
import { Form, FormProps, Field } from "react-final-form";
// Mui packages
import { Grid, Typography } from "@mui/material";
// Third party packages
import { useTranslation } from "react-i18next";
import "translation/i18n";
// Custom packages
import numberOfOpening from "data/numberOfOpening";
import salaryRange from "data/salaryRange";
import salaryRangeKRW from "data/salaryRangeKRW";
import salaryRangeUSD from "data/salaryRangeUSD";
import salaryRangeEUR from "data/salaryRangeEUR";
import experienceRange from "data/experienceRange";
import {
  ChipGroupField,
  LocationField,
  TagField,
  TextField,
  MonthField,
  PriorityField,
  EducationField,
  TextEditorField,
  TextEditorFieldEmpty,
} from "@common/FormField";
import {
  ArrayValidator,
  DateValidator,
  StringValidator,
} from "@lib/form-validations";
import { TagResponse } from "types/TagResponse";
import useCompany from "@lib/useCompany";
import { Box } from "@mui/material";

type IFormData = {
  /** Job description */
  job_description: string;
  /** Experience range  */
  experience_range: Array<number | string>;
  /** Job position location */
  job_location?: string;
  /** Count of people needed */
  job_openings?: number | string;
  /** Job position title */
  job_title: string;
  /** Job posted date */
  job_deadline: string;
  /** Job's salary range  */
  salary_range: Array<number | string>;
  /** Job's notice period  */
  job_notice_period: number | string;
  /** Tag data list to be displayed as chips  */
  job_skills: Array<TagResponse>;
  /** Job priority */
  priority: string;
};

export type JobFormProps = {} & FormProps;

const arrayValidator = new ArrayValidator();
const dateValidator = new DateValidator();
const stringValidator = new StringValidator();

export const JobForm: FC<JobFormProps> = (props) => {
  function humanize(str: string) {
    var i,
      frags = str?.split("_");
    for (i = 0; i < frags?.length; i++) {
      frags[i] = frags[i]?.charAt(0)?.toUpperCase() + frags[i]?.slice(1);
    }
    return frags?.join(" ");
  }
  /** props */
  const { onSubmit } = props;
  const { job } = props;

  // [Company Hooks]
  const { company } = useCompany();

  //**language translation hooks */
  const { t } = useTranslation();

  //no salary range
  const [salaryNoLimit, setSalaryNoLimit] = useState(false);
  const [salaryLimitCondition, setSalaryLimitCondition] = useState(false);

  useEffect(() => {
    if (job?.salary_min === 0 && job?.salary_max === 0) {
      setSalaryNoLimit(true);
    } else {
      setSalaryNoLimit(false);
    }
  }, [props]);

  useEffect(() => {
    salaryLimitCondition === true
      ? localStorage.setItem("salaryLimitStatus", "true")
      : localStorage.setItem("salaryLimitStatus", "false");
    setSalaryLimitCondition(salaryNoLimit);
  }, [salaryLimitCondition]);

  return (
    <Form
      onSubmit={onSubmit}
      initialValues={{
        job_title: job?.job_title,
        job_location: job?.job_location,
        job_notice_period:
          job?.job_notice_period === 0
            ? "Immediate Joiner"
            : job?.job_notice_period
            ? `${job?.job_notice_period} days`
            : "",
        job_skill_update: job?.job_skill_update,
        job_skills: job?.job_skills,
        job_education: job?.job_education,
        experience_range: job?.experience_max
          ? `${job?.experience_min}-${job?.experience_max}`
          : "",
        job_openings: job?.job_openings,
        // salary_range:
        //   job?.salary_max === 0 && job?.salary_min === 0
        //     ? "0-0"
        //     : job?.salary_max === 1 && job?.salary_min === 1
        //     ? "1-1"
        //     : job?.salary_max
        //     ? `${job?.salary_min}-${job?.salary_max}`
        //     : "",
        salary_min: job?.salary_min,
        salary_max: job?.salary_max,
        job_description: job?.job_description,
        priority: humanize(job?.priority),
        salaryNoLimit:
          job?.salary_max === 0 && job?.salary_min === 0 ? false : true,
        salaryLimitCondition:
          job?.salary_max === 0 && job?.salary_min === 0 ? false : true,
      }}
    >
      {({ handleSubmit, values }) => {
        const descriptionLength = values.job_description?.length;

        return (
          <form id="job_position_form" onSubmit={handleSubmit}>
            <Grid container spacing={2.75}>
              <Grid item xs={12} sm={4}>
                <Field
                  component={TextField}
                  fullWidth
                  name="job_title"
                  placeholder={`${t("job_position_name")}`}
                  size="small"
                  title={`${t("job_position_name")}`}
                  variant="outlined"
                  validate={stringValidator.validateRequiredMax128}
                  warning={`${t("recruit_this_field_empty_warning_title")}`}
                />
              </Grid>
              <Grid item xs={12} sm={2.5}>
                <Field
                  component={LocationField}
                  fullWidth
                  name="job_location"
                  required
                  placeholder={`${t("job_position_location_placeholder")}`}
                  title={`${t("job_position_location")}`}
                  variant="outlined"
                  validate={stringValidator.validateLocationNoNumber}
                  warning={`${t("recruit_this_field_empty_warning_title")}`}
                />
              </Grid>
              <Grid item xs={12} sm={2.5}>
                <Field
                  component={MonthField}
                  fullWidth
                  name="job_notice_period"
                  required
                  placeholder={`${t("notice_period")}`}
                  title={`${t("notice_period")}`}
                  variant="outlined"
                  validate={stringValidator.validateStringCount}
                  warning={`${t("recruit_this_field_empty_warning_title")}`}
                />
              </Grid>
              <Grid item xs={12} sm={4}>
                <Field
                  component={TextField}
                  fullWidth
                  name="job_skills"
                  placeholder={`${t("job_skills_placeholder")}`}
                  size="small"
                  title={`${t("job_skills")}`}
                  variant="outlined"
                  validate={stringValidator.validateTagCount}
                  warning={`${t("recruit_this_field_empty_warning_title")}`}
                />
                <Typography
                  color={"#8A8EBA"}
                  height={18}
                  marginTop={0.625}
                  marginBottom={0}
                  textAlign="left"
                  fontSize="12px"
                >
                  {t("job_skill_seprated_alert_text")}
                </Typography>
              </Grid>
              <Grid item xs={12} sm={2.5}>
                <Field
                  component={PriorityField}
                  fullWidth
                  name="priority"
                  required
                  placeholder={`${t("priority")}`}
                  title={`${t("priority")}`}
                  variant="outlined"
                  validate={stringValidator.onlyValidateNoNumber}
                  warning={`${t("recruit_this_field_empty_warning_title")}`}
                />
              </Grid>
              <Grid item xs={12} sm={2.5}>
                <Field
                  component={EducationField}
                  fullWidth
                  name="job_education"
                  required
                  size="small"
                  placeholder={`${t("education")}`}
                  title={`${t("education")}`}
                  variant="outlined"
                  validate={stringValidator.validateRequiredMax128}
                  warning={`${t("recruit_this_field_empty_warning_title")}`}
                />
              </Grid>
              <Grid item xs={12}>
                <Field
                  component={ChipGroupField}
                  name="experience_range"
                  options={experienceRange}
                  title={`${t("jobs_experiance")}`}
                  validate={stringValidator.validateRequired}
                  warning={`${t("recruit_this_field_empty_warning_title")}`}
                />
              </Grid>
              <Grid item xs={12}>
                <Field
                  component={ChipGroupField}
                  name="job_openings"
                  options={numberOfOpening}
                  title={`${t("number_of_openings")}`}
                  validate={stringValidator.validateRequired}
                  warning={`${t("recruit_this_field_empty_warning_title")}`}
                />
              </Grid>
              {/* <Grid item xs={12}>
                <Field
                  component={ChipGroupField}
                  name="salary_range"
                  options={
                    company && company.currency === "KRW"
                      ? salaryRangeKRW
                      : company && company.currency === "USD"
                        ? salaryRangeUSD
                        : company && company.currency === "EUR"
                          ? salaryRangeEUR
                          : salaryRange
                  }
                  title={
                    company && company.currency === "KRW"
                      ? "Salary Range KRW (In Lakhs Per Annum)"
                      : company && company.currency === "USD"
                        ? "Salary Range USD (In Lakhs Per Annum)"
                        : company && company.currency === "EUR"
                          ? "Salary Range EUR (In Lakhs Per Annum)"
                          : "Salary Range INR (In Lakhs Per Annum)"
                  }
                  validate={stringValidator.validateRequired}
                />
              </Grid> */}

              <Grid item xs={12} sm={12}>
                <Typography
                  sx={{
                    fontSize: "14px",
                    fontWeight: 400,
                    color: "#222222",
                    lineHeight: "150%",
                    marginBottom: "-15px",
                  }}
                >
                  {`${t("salary_per_annum")} (${
                    company && company.currency === "KRW"
                      ? `KRW`
                      : company && company.currency === "USD"
                      ? `USD`
                      : company && company.currency === "EUR"
                      ? `EUR`
                      : `INR`
                  })`}
                </Typography>
              </Grid>

              <Grid item xs={5} sm={2}>
                <Field
                  component={TextField}
                  fullWidth
                  name="salary_min"
                  placeholder={`${t("salary_min_range")}`}
                  size="small"
                  title={`${t("salary_min_range")}`}
                  variant="outlined"
                  validate={!salaryNoLimit && stringValidator.validateRequired}
                  type="number"
                  inputProps={{ min: 1 }}
                  disabled={salaryNoLimit}
                  warning={`${t("recruit_this_field_empty_warning_title")}`}
                />
              </Grid>

              <Grid item xs={5} sm={2}>
                <Field
                  component={TextField}
                  fullWidth
                  name="salary_max"
                  placeholder={`${t("salary_max_range")}`}
                  size="small"
                  title={`${t("salary_max_range")}`}
                  variant="outlined"
                  validate={!salaryNoLimit && stringValidator.validateRequired}
                  type="number"
                  inputProps={{ min: 1 }}
                  disabled={salaryNoLimit}
                  warning={`${t("recruit_this_field_empty_warning_title")}`}
                />
              </Grid>

              <Typography
                onClick={() => {
                  setSalaryNoLimit(!salaryNoLimit),
                    setSalaryLimitCondition(!salaryLimitCondition);
                }}
                sx={
                  salaryNoLimit
                    ? {
                        fontSize: "16px",
                        fontWeight: 400,
                        lineHeight: "150%",
                        color: "#ffffff",
                        width: "138px",
                        height: "30px",
                        display: "flex",
                        justifyContent: "center",
                        alignItems: "center",
                        backgroundColor: "#2C3058",
                        borderRadius: "18px",
                        cursor: "pointer",
                        marginTop: "50px",
                        marginLeft: "24px",
                      }
                    : {
                        fontSize: "16px",
                        fontWeight: 400,
                        lineHeight: "150%",
                        color: "#222222",
                        width: "138px",
                        height: "30px",
                        display: "flex",
                        justifyContent: "center",
                        alignItems: "center",
                        backgroundColor: "#ECEDF4",
                        borderRadius: "18px",
                        cursor: "pointer",
                        marginTop: "50px",
                        marginLeft: "24px",
                      }
                }
              >
                {t("salary_no_bar_text")}
              </Typography>

              {/* <Grid
                item
                xs={2}
                sx={{
                  marginTop: "28px",
                }}
              >
                <Field
                  component={ChipGroupField}
                  name="salary_range"
                  options={salaryRange}
                  validate={stringValidator.validateRequired}
                />
              </Grid> */}

              <Grid item xs={12}>
                <Field
                  component={
                    job?.job_description
                      ? TextEditorField
                      : TextEditorFieldEmpty
                  }
                  fullWidth
                  inputProps={{ maxLength: 10240 }}
                  multiline
                  name="job_description"
                  placeholder={`${t("view_job_description_title")}`}
                  minRows={4}
                  maxRows={4}
                  title={`${t("view_job_description_title")}`}
                  validate={stringValidator.validateRequiredMax10240}
                  variant="outlined"
                  warning={`${t("recruit_this_field_empty_warning_title")}`}
                />
                <Typography
                  color={descriptionLength > 10240 ? "error" : "grey.500"}
                  marginTop={0.625}
                  marginBottom={6}
                  textAlign="right"
                  variant="body2"
                >
                  {/* {descriptionLength ?? 0}/4,000 */}
                </Typography>
              </Grid>
            </Grid>
          </form>
        );
      }}
    </Form>
  );
};
