// React, Next packages
import React, { useEffect, useState } from "react";
import dynamic from "next/dynamic";
import Link from "next/link";
import { useRouter } from "next/router";
// import { useRouter } from "next/router";
import { connect } from "react-redux";
import { Dispatch } from "redux";
// Mui packages
import {
  Box,
  Grid,
  Button,
  Typography,
  styled,
  Stack,
  useMediaQuery,
} from "@mui/material";
// Third-party packages
import { useTranslation } from "react-i18next";
import "translation/i18n";
// import { useSnackbar } from "notistack";
// custom Hooks
import useCompany from "@lib/useCompany";
// Custom Packages
import { BackIcon } from "@common/Icon";
import { fetchJob } from "reducers/jobsSlice";
import { RootState } from "reducers";
import { renderRelativeDate } from "lib/formatter";

const ViewJobsContainer = styled("div")(({ theme }) => ({
  display: "flex",
  flexDirection: "column",
  width: "100%",
  paddingLeft: "8px",
  paddingTop: 8,
  [theme.breakpoints.down("sm")]: {
    display: "flex",
    flexDirection: "column",
    paddingLeft: "0px",
  },
}));

const ViewJobsTitleContainer = styled("div")(({ theme }) => ({
  display: "flex",
  flexDirection: "row",
  justifyContent: "space-between",
  alignItems: "center",
  marginBottom: 40,
  [theme.breakpoints.down("sm")]: {
    display: "flex",
    flexDirection: "column",
    alignItems: "flex-start",
  },
}));

const ViewJobsCustomCard = styled("div")(({ theme }) => ({
  display: "flex",
  flexDirection: "row",
  background: "#ECEDF4",
  justifyContent: "space-between",
  borderRadius: theme.shape.borderRadius,
  padding: "20px",
  [theme.breakpoints.down("sm")]: {
    padding: "15px",
    flexDirection: "column",
  },
}));

const ViewJobsTitle = styled("div")(({ theme }) => ({
  display: "flex",
  flexDirection: "row",

  alignItems: "center",
  [theme.breakpoints.down("sm")]: {
    display: "flex",
    flexDirection: "row",
  },
}));

function ViewJobCardSection(props: any) {
  /** props - states */
  const { jobs } = props;
  // const { index } = props;
  const router = useRouter();
  useEffect(() => {
    console.log(job, ":-index:-", jobs);
  }, [jobs]);

  //**language translation hooks */
  const { t } = useTranslation();

  /** useState hooks */
  const [isUpdating, setIsUpdating] = useState<boolean>(false);
  const [job, setJob] = useState();
  const [index, setIndex] = useState<any>();

  useEffect(() => {
    for (var i = 0; i < jobs.length; i++) {
      if (jobs[i].id === location.href.split("/")[5]) {
        setJob(jobs[i]);
        setIndex(i);
      }
    }
  }, [jobs]);
  // custom Hooks for company Name
  const { company } = useCompany();
  function humanize(str: string) {
    var i,
      frags = str?.split("_");
    for (i = 0; i < frags?.length; i++) {
      frags[i] = frags[i]?.charAt(0)?.toUpperCase() + frags[i]?.slice(1);
    }
    return frags?.join(" ");
  }

  /** Find Nature Of Job item Value matching by Job Type (or undefined if no match found) */

  return (
    <ViewJobsContainer>
      <ViewJobsTitleContainer>
        <Link href="/applications">
          <a>
            <ViewJobsTitle>
              <Typography component="span">
                <BackIcon
                  sx={{
                    fontSize: { xs: "11px", sm: "12px" },
                    marginRight: { xs: "5px", sm: "10px" },
                    marginTop: "0.5px",
                  }}
                />
              </Typography>
              <Typography component="h6" variant="h6">
                {jobs[index]?.job_title} {t("job_edit_history_table_head_job")}
              </Typography>
            </ViewJobsTitle>
          </a>
        </Link>
        <Box sx={{ width: { xs: "100%", sm: "156px" } }}>
          <Button
            component="a"
            variant="contained"
            rel="noopener noreferrer"
            target="_blank"
            size="medium"
            sx={{
              border: "1px solid #8A8EBA",
              background: "#fff",
              color: "#2c3058",
              cursor: "pointer",
              "&:hover": {
                background: "none",
              },
              width: { xs: "100%", sm: "156px" },
              marginTop: { xs: "30px", sm: "0px" },
            }}
            onClick={() =>
              router.push(
                "/applications/jobs/" +
                  jobs[index].id +
                  "/viewJobIndex/jobsHistory"
              )
            }
          >
            {t("job_edit_history_backIcon_title")}
          </Button>
        </Box>
      </ViewJobsTitleContainer>

      <ViewJobsCustomCard>
        <Stack direction="column">
          <Typography
            component="h3"
            variant="h3"
            sx={{ height: "25px", marginBottom: "15px" }}
          >
            {jobs[index]?.job_title}
          </Typography>
          <Typography component="p" variant="body1" paddingTop="5px">
            {company?.company_name} : {jobs[index]?.job_location}
          </Typography>
          <Typography component="p" variant="body1" paddingTop="5px">
            {jobs[index]?.job_openings}
            {t(`openings`)}
          </Typography>
          {jobs[index]?.priority ? (
            <Typography component="p" variant="body1" paddingTop="5px">
              <b style={{ fontWeight: "600" }}> {t("view_priority")}</b>:{" "}
              {humanize(jobs[index]?.priority)}
            </Typography>
          ) : (
            ""
          )}
        </Stack>
        <Box sx={{ display: "flex", flexDirection: "column" }}>
          <Box
            sx={{
              display: "flex",
              flexDirection: "row",
              marginTop: { xs: "15px", sm: "0px" },
            }}
          >
            <Button
              component="a"
              variant="contained"
              rel="noopener noreferrer"
              target="_blank"
              size="medium"
              sx={{
                border: "1px solid #2c3058",
                background: "primary.main",
                color: "#fff",
                width: "165px",
                marginRight: "20px",
                cursor: "pointer",
              }}
              onClick={() =>
                router.push("/applications/" + `${jobs[index]?.id}/`)
              }
            >
              {t("view_candidate_button_title")}
            </Button>

            <Button
              component="a"
              variant="contained"
              rel="noopener noreferrer"
              target="_blank"
              size="medium"
              sx={{
                border: "1px solid #8A8EBA",
                background: "none",
                color: "#2c3058",
                width: "156px",
                cursor: "pointer",
                "&:hover": {
                  background: "none",
                },
              }}
              onClick={() =>
                router.push(
                  "/applications/jobs/" + jobs[index]?.id + "/editJobIndex/"
                )
              }
            >
              {t("view_job_edit_button_title")}
            </Button>
          </Box>
          <Stack direction="column">
            <Typography
              component="p"
              variant="body1"
              textAlign="end"
              sx={{
                paddingRight: "1%",
                paddingTop: { xs: "10px", sm: "60px" },
              }}
            >
              {t("view_job_posted_title")} :{" "}
              {renderRelativeDate(jobs[index]?.created_at)}
            </Typography>
          </Stack>
        </Box>
      </ViewJobsCustomCard>
    </ViewJobsContainer>
  );
}

const mapStateToProps = (state: RootState) => ({
  jobs: state.jobs.jobs,
});

const mapDispatchToProps = (dispatch: Dispatch) => {
  return {
    fetchJob: (id: string) => fetchJob(dispatch, id),
  };
};

export default connect(mapStateToProps, mapDispatchToProps)(ViewJobCardSection);
