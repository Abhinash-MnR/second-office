// React, Next packages
import React, { useState } from "react";
// Mui packages
import {
  Button,
  DialogContent,
  DialogTitle,
  IconButton,
  ListItemButton,
  ListItemIcon,
  ListItemText,
  styled,
  Typography,
} from "@mui/material";

// Custom packages
import {
  ChartIcon,
  PaperIcon,
  AddUser,
  StoreWhite,
  SettingsWhite,
  OfficeManagementIcon,
  CloseIconColor,
} from "@common/Icon";
import { Box } from "@mui/material";

import { makeStyles, Dialog } from "@material-ui/core";
import { putSettingsDetail } from "@api/expenses";

// [Styles]
const CloseButton = styled("div")(({ theme }) => ({
  position: "absolute",
  right: 12,
  top: 20,
  [theme.breakpoints.down("sm")]: {
    right: theme.spacing(1.02),
    top: theme.spacing(2.75),
  },
}));

const useStyles = makeStyles({
  dialog: {
    position: "absolute",
    top: 0,
    left: 320,
    maxWidth: 465,
  },

  dialog2: {
    position: "absolute",
    top: 60,
    left: 320,
    maxWidth: 465,
  },

  dialog3: {
    position: "absolute",
    top: 120,
    left: 320,
    maxWidth: 465,
  },

  dialog4: {
    position: "absolute",
    top: 160,
    left: 320,
    maxWidth: 465,
  },

  dialog5: {
    position: "absolute",
    top: 220,
    left: 320,
    maxWidth: 465,
  },

  dialog6: {
    position: "absolute",
    top: 260,
    left: 320,
    maxWidth: 465,
  },
});

export const OnboardingCards = () => {
  //  [States]
  const [open, setOpen] = useState(true);
  const [cardVisible, setCardVisible] = useState(1);

  const handleClose = async () => {
    setOpen(false);
    await putSettingsDetail({ onboarding_complete: "True" });
    window.location.reload();
    console.log("Finish");
  };

  const classes = useStyles();

  return (
    <Dialog
      open={open}
      fullWidth
      classes={{
        paper:
          cardVisible === 1
            ? classes.dialog
            : cardVisible === 2
            ? classes.dialog2
            : cardVisible === 3
            ? classes.dialog3
            : cardVisible === 4
            ? classes.dialog4
            : cardVisible === 5
            ? classes.dialog5
            : classes.dialog6,
      }}
    >
      {/* [Menu Side Title] */}
      <div
        style={
          cardVisible === 1
            ? {
                position: "fixed",
                top: 120,
              }
            : cardVisible === 2
            ? {
                position: "fixed",
                top: 168,
              }
            : cardVisible === 3
            ? {
                position: "fixed",
                top: 222,
              }
            : cardVisible === 4
            ? {
                position: "fixed",
                top: 274,
              }
            : cardVisible === 5
            ? {
                position: "fixed",
                top: 328,
              }
            : {
                position: "fixed",
                top: 378,
              }
        }
      >
        <div
          style={{
            width: 325,
            height: 55,
            marginLeft: -352,
            display: "flex",
            alignItems: "center",
            padding: "0 0 0 28px",
            backgroundColor: "#DFA718",
            borderRight: "4px solid #2C3058",
          }}
        >
          <ListItemIcon>
            {cardVisible === 1 ? (
              <ChartIcon />
            ) : cardVisible === 2 ? (
              <AddUser />
            ) : cardVisible === 3 ? (
              <OfficeManagementIcon />
            ) : cardVisible === 4 ? (
              <StoreWhite />
            ) : cardVisible === 5 ? (
              <PaperIcon />
            ) : (
              <SettingsWhite />
            )}
          </ListItemIcon>
          <Typography
            component="p"
            variant="body2"
            sx={{ fontWeight: 700, color: "white" }}
          >
            {cardVisible === 1
              ? "Dashboard"
              : cardVisible === 2
              ? "Recruit"
              : cardVisible === 3
              ? "Office Management"
              : cardVisible === 4
              ? "Store"
              : cardVisible === 5
              ? "Office Expenses"
              : "Settings"}
          </Typography>
        </div>
      </div>

      {/* Triangle */}
      <div
        style={
          cardVisible === 1
            ? {
                position: "fixed",
                top: 128,
              }
            : cardVisible === 2
            ? {
                position: "fixed",
                top: 174,
              }
            : cardVisible === 3
            ? {
                position: "fixed",
                top: 230,
              }
            : cardVisible === 4
            ? {
                position: "fixed",
                top: 282,
              }
            : cardVisible === 5
            ? {
                position: "fixed",
                top: 336,
              }
            : {
                position: "fixed",
                top: 386,
              }
        }
      >
        <div
          style={{
            width: 0,
            height: 0,
            borderTop: "20px solid transparent",
            borderBottom: "20px solid transparent",
            borderRight: "20px solid #ffffff",
            marginLeft: -20,
          }}
        />
      </div>

      {/* [Dialog Title] */}
      <DialogTitle sx={{ padding: "20px 20px 0 20px" }}>
        <Typography component="h3" variant="h3">
          {cardVisible === 1
            ? "Dashboard"
            : cardVisible === 2
            ? "Recruit"
            : cardVisible === 3
            ? "Office Management"
            : cardVisible === 4
            ? "Store"
            : cardVisible === 5
            ? "Office Expenses"
            : "Settings"}
        </Typography>

        <CloseButton>
          <IconButton onClick={handleClose}>
            <CloseIconColor />
          </IconButton>
        </CloseButton>
      </DialogTitle>

      <DialogContent>
        <Typography
          sx={{
            fontSize: 16,
            fontWeight: 400,
            lineHeight: 1.5,
            marginTop: "24px",
          }}
        >
          {cardVisible === 1
            ? "Book a call with our SecondOffice experts or glance through our SecondOffice features from the Dashboard."
            : cardVisible === 2
            ? "Post a job and shortlist, select, or reject candidates to build your dream team."
            : cardVisible === 3
            ? "Keep a tab of your team’s attendance and performance, and maintain your management log here."
            : cardVisible === 4
            ? "Our store is under construction. We will notify you when it’s ready."
            : cardVisible === 5
            ? "Top up your wallet balance, keep track of your incurred expenses and applied funds here."
            : "Configure settings like interview modules, frequency of performance review, and currency as per your requirements."}
        </Typography>

        <Box
          sx={{
            marginTop: "24px",
            borderTop: "1px solid rgba(138, 142, 186, 0.32)",
          }}
        >
          <Box
            sx={{
              marginTop: "24px",
              display: "flex",
              alignItems: "center",
              justifyContent: "space-between",
            }}
          >
            <Typography
              sx={{
                fontSize: 16,
                fontWeight: 400,
                lineHeight: 1.5,
                color: "#4D4D4D",
              }}
            >
              {`Step ${cardVisible} of 6`}
            </Typography>

            <Button
              component="a"
              variant="contained"
              rel="noopener noreferrer"
              target="_blank"
              size="medium"
              sx={{
                border: "1px solid #2c3058",
                width: "158px",
                background: "#2C3058",
                color: "#FFFFFF",
                "&:hover": {
                  background: "#2C3058",
                },
              }}
              onClick={async () => {
                if (cardVisible !== 6) {
                  setCardVisible(cardVisible + 1);
                } else {
                  await putSettingsDetail({ onboarding_complete: "True" });
                  setOpen(false);
                  window.location.reload();
                  console.log("Finish");
                }
              }}
            >
              {cardVisible === 6 ? "Finish" : "Next"}
            </Button>
          </Box>
        </Box>
      </DialogContent>
    </Dialog>
  );
};
