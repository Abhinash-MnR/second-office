// React, Next packages
import React, { useState } from "react";
// Mui packages
import {
  Button,
  Dialog,
  DialogContent,
  DialogTitle,
  IconButton,
  styled,
  Typography,
} from "@mui/material";
// Custom packages
import { CloseIconColor, OnboardingDialogueArrow } from "@common/Icon";
import { Box } from "@mui/material";
import { OnboardingCards } from "features/onboarding/OnboardingCards";
import { putSettingsDetail } from "@api/expenses";

const CloseButton = styled("div")(({ theme }) => ({
  position: "absolute",
  right: 12,
  top: 20,
  [theme.breakpoints.down("sm")]: {
    right: theme.spacing(1.02),
    top: theme.spacing(2.75),
  },
}));

export const OnboardingDialogue = ({ companyName }) => {
  const [open, setOpen] = useState(true);
  const [onBoardingStart, setOnBoardingStart] = useState(false);

  /** custom handlers */
  const handleClose = async () => {
    setOpen(false);
    await putSettingsDetail({ onboarding_complete: "True" });
    window.location.reload();
    console.log("Finish");
  };

  return (
    <Box sx={{ position: "relative" }}>
      <Dialog open={open && !onBoardingStart} fullWidth>
        <DialogTitle sx={{ padding: "20px 20px 0 20px" }}>
          <Typography component="h3" variant="h3">
            {`Hey ${companyName}`}
          </Typography>

          <Typography
            sx={{
              fontSize: 20,
              fontWeight: 700,
              lineHeight: 1.5,
              marginTop: "10px",
            }}
          >
            Welcome to your SecondOffice Dashboard
          </Typography>

          <CloseButton>
            <IconButton onClick={handleClose}>
              <CloseIconColor />
            </IconButton>
          </CloseButton>
        </DialogTitle>

        <DialogContent>
          <Typography
            sx={{
              fontSize: 16,
              fontWeight: 400,
              lineHeight: 1.5,
              maxWidth: 423,
              marginTop: "24px",
            }}
          >
            Just getting started? Let’s take a quick look at all the features of
            this platform.
          </Typography>

          <Box
            sx={{
              marginTop: "24px",
              display: "flex",
              alignItems: "center",
            }}
          >
            <Button
              component="a"
              variant="contained"
              rel="noopener noreferrer"
              target="_blank"
              size="medium"
              sx={{
                border: "1px solid #2c3058",
                width: "158px",
                background: "#2C3058",
                color: "#FFFFFF",
                "&:hover": {
                  background: "#2C3058",
                },
              }}
              onClick={() => setOnBoardingStart(true)}
            >
              Let’s Get Started
            </Button>

            <div style={{ marginLeft: 16 }}>
              <OnboardingDialogueArrow />
            </div>
          </Box>
        </DialogContent>

        <img
          src="/svg/onboardingDialogue.svg"
          alt="onboardingDialogue"
          style={{ position: "absolute", right: 20, bottom: 0 }}
        />
      </Dialog>

      {onBoardingStart && <OnboardingCards />}
    </Box>
  );
};
