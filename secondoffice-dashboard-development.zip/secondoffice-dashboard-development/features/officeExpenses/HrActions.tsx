// React, Next packages
import React, { useState } from "react";
import dynamic from "next/dynamic";
// Mui packages
import {
  Box,
  Grid,
  LinearProgress,
  Typography,
  FormControl,
  MenuItem,
  Select,
  SelectChangeEvent,
  styled,
} from "@mui/material";
// Custom packages
import hrActionStatus from "data/hrActionStatus";
import { putTeamPerformanceHrAction } from "@api/teamPerformance";
// Third-party packages
import { useSnackbar } from "notistack";
import { useTranslation } from "react-i18next";
import "translation/i18n";

function HRActions(props) {
  /* HR Actions Status */
  const { status, id } = props;
  /* HR Actions  State */
  const [actions, setActions] = useState(status);
  //** Language translation hooks */
  const { t } = useTranslation();
  /** third-party hooks */
  const { enqueueSnackbar } = useSnackbar();
  /** useState hooks */
  const [isUpdating, setIsUpdating] = useState<boolean>(false);

  /* HR Actions Handle */
  const handleChangeActions = (e) => {
    setActions(e.target.value);
    handleSaveHrActionChange(e.target.value);
    console.log("open and close jobs");
  };
  /** custom handlers  */
  const handleSaveHrActionChange = async (data: any) => {
    try {
      setIsUpdating(true);
      // Create form payload
      const payload = {
        hR_actions: data,
      };
      const job = await putTeamPerformanceHrAction(id, payload);
      enqueueSnackbar(`${t("hr_action_updated")}`, {
        variant: "info",
      });
    } catch (error: any) {
      enqueueSnackbar(error.toString(), { variant: "error" });
      setIsUpdating(false);
    }
  };

  // console.log(status, "actions status");

  //** hr actions data */
  const hrActionsDataList = [
    {
      label: `${t("hr_actions_no_needed")}`,
      value: "No action needed",
    },
    {
      label: `${t("hr_actions_bonus")}`,
      value: "Bonus",
    },
    {
      label: `${t("hr_actions_termination")}`,
      value: "Termination",
    },
    {
      label: `${t("hr_actions_promotion")}`,
      value: "Promotion",
    },
  ];

  return (
    <Box>
      {/* </FormControl> */}
      <Select
        labelId="demo-simple-select-label"
        id="demo-simple-select"
        value={actions}
        onChange={handleChangeActions}
        sx={{ width: "200px", height: "44px" }}
      >
        {hrActionsDataList.map((item, index) => (
          <MenuItem value={item.value}>{item.label}</MenuItem>
        ))}
      </Select>
    </Box>
  );
}

export default HRActions;
