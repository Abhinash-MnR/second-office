// React, Next Packages
import React from "react";
import Image from "next/image";
// Mui packages
import { Grid, styled, Typography, useMediaQuery } from "@mui/material";
// Third-party packages
import Slider from "react-slick";
import "slick-carousel/slick/slick.css";
import "slick-carousel/slick/slick-theme.css";
import { useTranslation } from "react-i18next";
import "translation/i18n";
// Custom Packages
import {
  ExpenseSlider1,
  ExpenseSlider3,
  MobileExpenseCardSlider,
} from "./ExpenseSlider";

function ExpenseCardSlider() {
  //** Language translation hooks */
  const { t } = useTranslation();

  /* Mobile View Responsive   */
  const IsMobile = useMediaQuery("(max-width:600px)");

  const settings = {
    dots: true,
    infinite: true,
    speed: 500,
    slidesToShow: 1,
    slidesToScroll: 1,
    autoplay: true,
    arrows: false,
    dotsClass: "custom-slick-dots",
  };
  return (
    <div>
      <Slider {...settings}>
        <div>
          {IsMobile ? (
            <MobileExpenseCardSlider
              title={`${t("office_expense_banner1_title")}`}
              content={`${t("office_expense_banner1_desc")}`}
              img_url="/svg/1.svg"
            />
          ) : (
            <ExpenseSlider1
              title={`${t("office_expense_banner1_title")}`}
              content={`${t("office_expense_banner1_desc")}`}
              img_url="/svg/1.svg"
            />
          )}
        </div>
        <div>
          {IsMobile ? (
            <MobileExpenseCardSlider
              title={`${t("office_expense_banner2_title")}`}
              content={`${t("office_expense_banner2_desc")}`}
              img_url="/svg/2.svg"
            />
          ) : (
            <ExpenseSlider1
              title={`${t("office_expense_banner2_title")}`}
              content={`${t("office_expense_banner2_desc")}`}
              img_url="/svg/2.svg"
            />
          )}
        </div>
        <div>
          {IsMobile ? (
            <MobileExpenseCardSlider
              title="Stay informed about your wallet balance"
              content="Track your balance and keep yourself abreast of the latest exchange rate, all in one place!"
              img_url="/svg/2.svg"
            />
          ) : (
            <ExpenseSlider1
              title={`${t("office_expense_banner3_ttile")}`}
              content={`${t("office_expense_banner3_desc")}`}
              img_url="/svg/3.svg"
            />
          )}
        </div>
      </Slider>
    </div>
  );
}

export default ExpenseCardSlider;
