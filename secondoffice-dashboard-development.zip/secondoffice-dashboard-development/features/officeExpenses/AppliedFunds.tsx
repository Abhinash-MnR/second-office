// React, Next packages
import React, { useState, useEffect } from "react";
import { connect } from "react-redux";
import { Dispatch } from "redux";
import dynamic from "next/dynamic";
import Link from "next/link";
// Mui packages
import {
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  Paper,
  Typography,
  styled,
  Stack,
  FormControl,
  MenuItem,
  Select,
  SelectChangeEvent,
  Grid,
  Box,
  Pagination,
  Button,
  Tooltip,
  IconButton,
} from "@mui/material";
// 3Rd Party Component/Packages
import { useSnackbar } from "notistack";
import moment from "moment";
import { useTranslation } from "react-i18next";
import "translation/i18n";
// Custom packages
import { RootState } from "reducers";
import { expensesAppliedFundList } from "@reducers/appliedFundsSlice";
import NoOfficeData from "features/officeManagement/NoOfficeData";
import {
  EURIconColor,
  INRIconColor,
  KRWIconColor,
  USDIconColor,
  ToolTipIconColor,
} from "@common/Icon";
import useCompany from "@lib/useCompany";
import useCurrency from "@lib/useCurrency";

const CustomContainer = styled("div")(({ theme }) => ({
  display: "flex",
  flexDirection: "column",
  marginTop: 40,
}));
const CustomTableContainer = styled("div")(({ theme }) => ({
  display: "flex",
}));

const StyledTableRow = styled(TableRow)(({ theme }) => ({
  "&:nth-of-type(odd)": {
    // backgroundColor: theme.palette.action.hover,
  },
  // hide last border
  "&:last-child td, &:last-child th": {
    border: 0,
  },
}));

const StyledTableCell = styled(TableCell)(({ theme }) => ({
  fontSize: 14,
  padding: "18px",
}));

const CustomSelectContainer = styled("div")(({ theme }) => ({
  display: "flex",
  justifyContent: "space-between",
  paddingBottom: "20px",
  [theme.breakpoints.down("sm")]: {
    display: "flex",
    flexDirection: "column",
  },
}));

function appliedFunds(props: any) {
  /** third-party hooks */
  const { enqueueSnackbar } = useSnackbar();
  //** Language translation hooks */
  const { t } = useTranslation();

  /** props - actions */
  const { expensesAppliedFundList } = props;
  /** props - states */
  const { result, count } = props;
  const pageNumber = Math.ceil(count / 10);
  const [expensesListPage, setExpensesListPage] = useState(1);

  // Custom hooks
  const { company } = useCompany();
  const { currency } = useCurrency();

  // [Search filter]
  const appliedFundsFilterData = result?.filter((item: any) => {
    return (
      item.applied_fund_date.slice(0, 7) === `${props.year}-${props.month}`
    );
  });

  // Convert number with commas
  const numberWithCommas = (x: string) => {
    return x.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",");
  };

  /** useEffect hooks */
  useEffect(() => {
    const expenses = async () => {
      await expensesAppliedFundList({ page: expensesListPage, page_size: 10 });
    };

    try {
      expenses();
    } catch (error: any) {
      enqueueSnackbar(error.toString(), { variant: "error" });
    }
  }, [expensesListPage]);

  //** month list */
  const monthList = [
    `${t("january_title")}`,
    `${t("february_title")}`,
    `${t("march_title")}`,
    `${t("april_title")}`,
    `${t("may_title")}`,
    `${t("june_title")}`,
    `${t("july_title")}`,
    `${t("august_title")}`,
    `${t("september_title")}`,
    `${t("october_title")}`,
    `${t("november_title")}`,
    `${t("december_title")}`,
  ];

  return (
    <CustomContainer>
      <Box sx={{ marginBottom: "24px" }}>
        <Typography component="h3" variant="h3">
          {t("office_expense_applied_funds_title")}
          <Tooltip
            title={`${t("office_expense_applied_funds_tooltip")}`}
            arrow
            enterTouchDelay={0}
          >
            <IconButton aria-label="hr_actions">
              <ToolTipIconColor />
            </IconButton>
          </Tooltip>
        </Typography>
      </Box>

      {/* [Table data] */}
      {result.length > 0 && !props.searchClicked ? (
        <CustomTableContainer>
          <TableContainer component={Paper} sx={{ boxShadow: "none" }}>
            <Table sx={{ minWidth: 1050 }} aria-label="simple table">
              <TableHead sx={{ background: "#ECEDF4" }}>
                <StyledTableRow>
                  <StyledTableCell
                    sx={{
                      fontSize: 16,
                      lineHeight: 1.5,
                      fontWeight: 700,
                      width: "29%",
                    }}
                  >
                    {t("office_expense_applied_funds_table_head_date")}
                  </StyledTableCell>
                  <StyledTableCell
                    sx={{
                      fontSize: 16,
                      lineHeight: 1.5,
                      fontWeight: 700,
                    }}
                  >
                    {t("office_expense_applied_funds_table_head_amount")}
                  </StyledTableCell>
                </StyledTableRow>
              </TableHead>
              <TableBody>
                {result?.map((row, index) => {
                  //const date define
                  const multiLanguageDateFormat = moment(
                    row?.applied_fund_date
                  ).format("MMMM");
                  // day and year format
                  const dayYearFormat = moment(row?.applied_fund_date).format(
                    " DD, YYYY"
                  );
                  return (
                    <TableRow
                      key={index}
                      sx={{ "&:last-child td, &:last-child th": { border: 0 } }}
                    >
                      <StyledTableCell
                        component="th"
                        scope="row"
                        sx={{
                          fontSize: 14,
                          fontWeight: 400,
                          lineHeight: 1.5,
                          color: "#222222",
                        }}
                      >
                        {/* {moment(row?.applied_fund_date).format("MMMM DD, YYYY")} */}
                        {multiLanguageDateFormat === "January"
                          ? monthList[0].concat(" ", dayYearFormat)
                          : multiLanguageDateFormat === "February"
                          ? monthList[1].concat(" ", dayYearFormat)
                          : multiLanguageDateFormat === "March"
                          ? monthList[2].concat(" ", dayYearFormat)
                          : multiLanguageDateFormat === "April"
                          ? monthList[3].concat(" ", dayYearFormat)
                          : multiLanguageDateFormat === "May"
                          ? monthList[4].concat(" ", dayYearFormat)
                          : multiLanguageDateFormat === "June"
                          ? monthList[5].concat(" ", dayYearFormat)
                          : multiLanguageDateFormat === "July"
                          ? monthList[6].concat(" ", dayYearFormat)
                          : multiLanguageDateFormat === "August"
                          ? monthList[7].concat(" ", dayYearFormat)
                          : multiLanguageDateFormat === "September"
                          ? monthList[8].concat(" ", dayYearFormat)
                          : multiLanguageDateFormat === "October"
                          ? monthList[9].concat(" ", dayYearFormat)
                          : multiLanguageDateFormat === "November"
                          ? monthList[10].concat(" ", dayYearFormat)
                          : multiLanguageDateFormat === "December"
                          ? monthList[11].concat(" ", dayYearFormat)
                          : ""}
                      </StyledTableCell>
                      <StyledTableCell
                        sx={{ fontWeight: "700", color: "#2c3058" }}
                      >
                        {company && currency && company.currency === "KRW" ? (
                          <KRWIconColor sx={{ fontSize: "10px" }} />
                        ) : company &&
                          currency &&
                          company.currency === "USD" ? (
                          <USDIconColor sx={{ fontSize: "10px" }} />
                        ) : company &&
                          currency &&
                          company.currency === "EUR" ? (
                          <EURIconColor sx={{ fontSize: "10px" }} />
                        ) : (
                          <INRIconColor sx={{ fontSize: "10px" }} />
                        )}
                        {company && currency && company.currency === "KRW"
                          ? numberWithCommas(
                              (row?.amount * currency.currency_krw).toFixed(2)
                            )
                          : company && currency && company.currency === "USD"
                          ? numberWithCommas(
                              (row?.amount * currency.currency_usd).toFixed(2)
                            )
                          : company && currency && company.currency === "EUR"
                          ? numberWithCommas(
                              (row?.amount * currency.currency_eur).toFixed(2)
                            )
                          : numberWithCommas(row?.amount)}
                      </StyledTableCell>
                    </TableRow>
                  );
                })}
              </TableBody>
            </Table>
          </TableContainer>
        </CustomTableContainer>
      ) : appliedFundsFilterData.length > 0 && props.searchClicked ? (
        <CustomTableContainer>
          <TableContainer component={Paper} sx={{ boxShadow: "none" }}>
            <Table sx={{ minWidth: 1050 }} aria-label="simple table">
              <TableHead sx={{ background: "#ECEDF4" }}>
                <StyledTableRow>
                  <StyledTableCell
                    sx={{
                      fontSize: 16,
                      lineHeight: 1.5,
                      fontWeight: 700,
                      width: "29%",
                    }}
                  >
                    {t("office_expense_applied_funds_table_head_date")}
                  </StyledTableCell>
                  <StyledTableCell
                    sx={{
                      fontSize: 16,
                      lineHeight: 1.5,
                      fontWeight: 700,
                    }}
                  >
                    {t("office_expense_applied_funds_table_head_amount")}
                  </StyledTableCell>
                </StyledTableRow>
              </TableHead>
              <TableBody>
                {appliedFundsFilterData?.map((row, index) => {
                  //const date define
                  const multiLanguageDateFormat = moment(
                    row?.applied_fund_date
                  ).format("MMMM");
                  // day and year format
                  const dayYearFormat = moment(row?.applied_fund_date).format(
                    " DD, YYYY"
                  );
                  return (
                    <TableRow
                      key={index}
                      sx={{ "&:last-child td, &:last-child th": { border: 0 } }}
                    >
                      <StyledTableCell
                        component="th"
                        scope="row"
                        sx={{
                          fontSize: 14,
                          fontWeight: 400,
                          lineHeight: 1.5,
                          color: "#222222",
                        }}
                      >
                        {/* {moment(row?.applied_fund_date).format("MMMM DD, YYYY")} */}
                        {multiLanguageDateFormat === "January"
                          ? monthList[0].concat(" ", dayYearFormat)
                          : multiLanguageDateFormat === "February"
                          ? monthList[1].concat(" ", dayYearFormat)
                          : multiLanguageDateFormat === "March"
                          ? monthList[2].concat(" ", dayYearFormat)
                          : multiLanguageDateFormat === "April"
                          ? monthList[3].concat(" ", dayYearFormat)
                          : multiLanguageDateFormat === "May"
                          ? monthList[4].concat(" ", dayYearFormat)
                          : multiLanguageDateFormat === "June"
                          ? monthList[5].concat(" ", dayYearFormat)
                          : multiLanguageDateFormat === "July"
                          ? monthList[6].concat(" ", dayYearFormat)
                          : multiLanguageDateFormat === "August"
                          ? monthList[7].concat(" ", dayYearFormat)
                          : multiLanguageDateFormat === "September"
                          ? monthList[8].concat(" ", dayYearFormat)
                          : multiLanguageDateFormat === "October"
                          ? monthList[9].concat(" ", dayYearFormat)
                          : multiLanguageDateFormat === "November"
                          ? monthList[10].concat(" ", dayYearFormat)
                          : multiLanguageDateFormat === "December"
                          ? monthList[11].concat(" ", dayYearFormat)
                          : ""}
                      </StyledTableCell>
                      <StyledTableCell
                        sx={{ fontWeight: "700", color: "#2c3058" }}
                      >
                        {company && currency && company.currency === "KRW" ? (
                          <KRWIconColor sx={{ fontSize: "10px" }} />
                        ) : company &&
                          currency &&
                          company.currency === "USD" ? (
                          <USDIconColor sx={{ fontSize: "10px" }} />
                        ) : company &&
                          currency &&
                          company.currency === "EUR" ? (
                          <EURIconColor sx={{ fontSize: "10px" }} />
                        ) : (
                          <INRIconColor sx={{ fontSize: "10px" }} />
                        )}
                        {company && currency && company.currency === "KRW"
                          ? (row?.amount * currency.currency_krw).toFixed(2)
                          : company && currency && company.currency === "USD"
                          ? (row?.amount * currency.currency_usd).toFixed(2)
                          : company && currency && company.currency === "EUR"
                          ? (row?.amount * currency.currency_eur).toFixed(2)
                          : (row?.amount).toFixed(2)}
                      </StyledTableCell>
                    </TableRow>
                  );
                })}
              </TableBody>
            </Table>
          </TableContainer>
        </CustomTableContainer>
      ) : appliedFundsFilterData.length === 0 &&
        props.isMonthSelected !== "1" &&
        props.isYearSelected !== "1" &&
        props.searchClicked ? (
        <Box>
          <NoOfficeData
            title={`${t("office_expense_applied_funds_empty_title")}`}
            imgName="Illust-4"
          />
        </Box>
      ) : (
        <Box>
          <NoOfficeData
            title={`${t("office_expense_applied_funds_empty_title")}`}
            imgName="Illust-4"
          />
        </Box>
      )}

      {/* Pagination for Team Expenses List   */}
      {count > 10 ? (
        <Grid container spacing={1}>
          <Grid item xs={12}>
            <Box sx={{ display: "flex", justifyContent: "center" }}>
              <Stack
                direction="row"
                alignItems="center"
                justifyContent="center"
                paddingTop={5}
                paddingBottom={3}
              >
                <Pagination
                  count={pageNumber}
                  color="secondary"
                  onChange={(e, value) => setExpensesListPage(value)}
                  sx={{
                    background: "#ECEDF4",
                    borderRadius: "10px",
                    padding: { xs: "5px", sm: "10px" },
                  }}
                />
              </Stack>
            </Box>
          </Grid>
        </Grid>
      ) : (
        ""
      )}
    </CustomContainer>
  );
}

const mapStateToProps = (state: RootState) => ({
  result: state.appliedFunds.results,
  count: state.appliedFunds.count,
});

const mapDispatchToProps = (dispatch: Dispatch) => {
  return {
    expensesAppliedFundList: (params: any) =>
      expensesAppliedFundList(dispatch, params),
  };
};

export default connect(mapStateToProps, mapDispatchToProps)(appliedFunds);
