// React, Next packages
import React, { useState } from "react";

// Mui packages
import { MenuItem, Select, Box } from "@mui/material";
// Third-party packages
import { useSnackbar } from "notistack";
import { postTeamEmployeeHrAction } from "@api/teams";
import { useTranslation } from "react-i18next";
import "translation/i18n";

// Custom packages
import hrActionStatus from "data/hrActionStatus";

function TeamRoasterHrActions(props) {
  /* HR Actions Status */
  const { status, id, cardView } = props;
  //** Language translation hooks */
  const { t } = useTranslation();
  /* HR Actions  State */
  const [actions, setActions] = useState(status);

  /** third-party hooks */
  const { enqueueSnackbar } = useSnackbar();

  /** useState hooks */
  const [isUpdating, setIsUpdating] = useState<boolean>(false);

  /* HR Actions Handle */
  const handleChangeActions = (e) => {
    setActions(e.target.value);
    handleSaveHrActionChange(e.target.value);
    console.log("open and close jobs");
  };

  /** custom handlers  */
  const handleSaveHrActionChange = async (data: any) => {
    try {
      setIsUpdating(true);
      // Create form payload
      const payload = {
        hr_action: data,
      };
      const job = await postTeamEmployeeHrAction(id, payload);
      enqueueSnackbar("HR action has been updated.", {
        variant: "info",
      });
    } catch (error: any) {
      enqueueSnackbar(error.toString(), { variant: "error" });
      setIsUpdating(false);
    }
  };

  //** hr actions data */
  const hrActionsDataList = [
    {
      label: `${t("hr_actions_no_needed")}`,
      value: "No action needed",
    },
    {
      label: `${t("hr_actions_bonus")}`,
      value: "Bonus",
    },
    {
      label: `${t("hr_actions_termination")}`,
      value: "Termination",
    },
    {
      label: `${t("hr_actions_promotion")}`,
      value: "Promotion",
    },
  ];

  // console.log(status, "actions status");

  return (
    <Box display={`flex`} flexDirection={`column`} width={`100%`}>
      {/* </FormControl> */}

      <Select
        labelId="demo-simple-select-label"
        id="demo-simple-select"
        value={actions}
        onChange={handleChangeActions}
        sx={
          cardView == true
            ? { height: "44px", fontSize: "14px" }
            : { height: "44px" }
        }
      >
        {hrActionsDataList.map((item, index) => (
          <MenuItem key={index} value={item.value}>
            {item.label}
          </MenuItem>
        ))}
      </Select>
    </Box>
  );
}

export default TeamRoasterHrActions;
