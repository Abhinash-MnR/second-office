// React, Next Packages
import React from "react";
// Mui packages
import { Grid, Typography } from "@mui/material";
// Third party packages
import { useTranslation } from "react-i18next";
import "translation/i18n";

// Custom Packages
import { Box } from "@mui/material";
import { Button } from "@mui/material";

function PremiumBanner() {
  //** Language translation hooks */
  const { t } = useTranslation();

  const bannerData = [
    {
      id: 0,
      title: `${t("office_expense_standard_package_title")}`,
      subTitile: `${t("office_expense_standard_package_title")}`,
      price: "$ 500",
    },
    {
      id: 1,
      title: `${t("office_expense_inclusive_package_title")}`,
      subTitile: `${t("office_expense_inclusive_package_desc")}`,
      price: "$ 1500",
    },
    {
      id: 2,
      title: `${t("office_expense_enterprise_title")}`,
      subTitile: `${t("office_expense_enterprise_desc")}`,
      price: "-",
    },
  ];

  return (
    <Box
      sx={{
        marginBottom: {
          xs: "20px",
          sm: "30px",
        },
        padding: { xs: "20px 33px", sm: "9px 0" },
        backgroundColor: "#ffffff",
        borderRadius: "10px",
        position: "relative",
      }}
    >
      <Grid container>
        {/* [Yellow Box] */}
        {/* <Grid item xs={12} sm={1}>
          <Box
            sx={{
              backgroundColor: "#DFA718",
              height: 64,
              width: 54,
              borderRadius: "0 0 100px 100px",
              position: "absolute",
              left: { xs: "none", sm: 38 },
              right: { xs: 20, sm: "none" },
              top: 0,
              display: "block",
            }}
          />
        </Grid> */}

        {/* [Pricing Grids] */}
        {bannerData.map((data, index) => (
          <Grid
            key={index}
            item
            xs={12}
            sm={data.id !== 2 ? 4 : 3}
            sx={
              data.id !== 2
                ? {
                    display: "flex",
                    flexDirection: "column",
                    alignItems: { xs: "flex-start", sm: "center" },
                    borderRight: {
                      xs: "none",
                      sm: "1.5px solid rgba(140, 142, 186, 0.32)",
                    },
                    borderBottom: {
                      xs: "1.5px solid rgba(140, 142, 186, 0.32)",
                      sm: "none",
                    },
                    paddingBottom: { xs: "10px", sm: "0" },
                    marginBottom: { xs: "10px", sm: "0" },
                  }
                : {
                    display: "flex",
                    flexDirection: "column",
                    alignItems: { xs: "flex-start", sm: "center" },
                  }
            }
          >
            <Box>
              <Box
                sx={{
                  backgroundColor: "#DFA718",
                  height: 64,
                  width: 54,
                  borderRadius: "0 0 100px 100px",
                  position: "absolute",
                  left: { xs: "none", sm: 38 },
                  right: { xs: 20, sm: "none" },
                  top: 0,
                  display: "block",
                }}
              />

              <Typography
                sx={{
                  fontSize: "16px",
                  fontWeight: 700,
                  color: "#2C3058",
                  lineHeight: "150%",
                }}
              >
                {data.title}
              </Typography>

              <Typography
                sx={{
                  fontSize: { xs: "12px", sm: "14px" },
                  fontWeight: 400,
                  color: "#2C3058",
                  lineHeight: "150%",
                  marginTop: "4px",
                }}
              >
                {data.subTitile}
              </Typography>

              {data.id !== 2 ? (
                <Typography
                  sx={{
                    fontSize: { xs: "18px", sm: "24px" },
                    fontWeight: 700,
                    color: "#DFA718",
                    lineHeight: "150%",
                    marginTop: "4px",
                  }}
                >
                  {data.price}
                </Typography>
              ) : (
                <Button
                  component="a"
                  variant="contained"
                  rel="noopener noreferrer"
                  target="_blank"
                  size="medium"
                  sx={{
                    border: "1px solid #2c3058",
                    padding: "9px 36px",
                    background: "#2C3058",
                    color: "#FFFFFF",
                    marginTop: "8px",
                    "&:hover": {
                      background: "#2C3058",
                    },
                  }}
                  onClick={() =>
                    window.open("https://secondoffice.io/pricing", "_blank")
                  }
                >
                  {t("office_expense_button_title")}
                </Button>
              )}
            </Box>
          </Grid>
        ))}
      </Grid>
    </Box>
  );
}

export default PremiumBanner;
