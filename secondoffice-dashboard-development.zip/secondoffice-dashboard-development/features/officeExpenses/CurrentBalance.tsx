// React, Next Packages
import React from "react";
// Mui packages
import {
  Grid,
  styled,
  Typography,
  Tooltip,
  Button,
  IconButton,
  Box,
} from "@mui/material";
// Third party packages
import { useTranslation } from "react-i18next";
import "translation/i18n";
// Custom Packages
import {
  ExpenseBalanceIcon,
  INRIcon,
  ToolTipIcon,
  USDIcon,
  KRWIcon,
  EURIcon,
} from "@common/Icon";
import useCompany from "@lib/useCompany";
import useCurrency from "@lib/useCurrency";
import { String } from "lodash";

const ExpenseBalanceContainer = styled("div")(({ theme }) => ({
  display: "flex",
  flexDirection: "column",
  background: "#2C3058",
  height: "230px",
  borderRadius: 10,
  justifyContent: "center",
  alignItems: "center",
}));

const ExpenseInnerContainer = styled("div")(({ theme }) => ({
  display: "flex",
  flexDirection: "row",
  justifyContent: "center",
  marginTop: "24px",
}));

function CurrentBalance() {
  //** Custom hooks */
  const { company, isLoading, isError } = useCompany();
  const { currency } = useCurrency();
  //** Language translation hooks */
  const { t } = useTranslation();

  // Convert number with commas
  const numberWithCommas = (x: string) => {
    return x.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",");
  };

  return (
    <ExpenseBalanceContainer>
      <div
        style={{
          color: "whitesmoke",
          display: "flex",
          alignItems: "center",
          justifyContent: "center",
          fontSize: "18px",
          fontWeight: "bold",
          textAlign: "center",
        }}
      >
        {t("office_expense_current_balance_title")}
      </div>
      <ExpenseInnerContainer>
        <Box>
          <ExpenseBalanceIcon sx={{ fontSize: "42px" }} />
        </Box>
      </ExpenseInnerContainer>
      <ExpenseInnerContainer>
        <Typography
          component="span"
          sx={{ marginTop: { xs: "8px", sm: "15px" }, color: "#fff" }}
        >
          {company && currency && company.currency === "KRW" ? (
            <KRWIcon sx={{ fontSize: "20px" }} />
          ) : company && currency && company.currency === "USD" ? (
            <USDIcon sx={{ fontSize: "20px" }} />
          ) : company && currency && company.currency === "EUR" ? (
            <EURIcon sx={{ fontSize: "20px" }} />
          ) : (
            <INRIcon sx={{ fontSize: "20px" }} />
          )}
        </Typography>
        {company && currency && (
          <Typography
            component="h2"
            variant="h2"
            sx={{ color: "#fff", marginLeft: "2px" }}
          >
            {company.currency === "KRW"
              ? numberWithCommas(
                  (company.company_fund * currency.currency_krw).toFixed(2)
                )
              : company.currency === "USD"
              ? numberWithCommas(
                  (company.company_fund * currency.currency_usd).toFixed(2)
                )
              : company.currency === "EUR"
              ? numberWithCommas(
                  (company.company_fund * currency.currency_eur).toFixed(2)
                )
              : numberWithCommas(company.company_fund)}
          </Typography>
        )}

        <Typography
          component="span"
          sx={{ marginTop: { xs: "-2px", sm: "5px" } }}
        >
          <Tooltip
            title={
              company && company.currency === "KRW"
                ? `${t("exchange_rate")}: 0.00079`
                : company && company.currency === "USD"
                ? `${t("exchange_rate")}: 1`
                : company && company.currency === "EUR"
                ? `${t("exchange_rate")}: 1.06`
                : `${t("exchange_rate")}: 0.013`
            }
            arrow
            enterTouchDelay={0}
          >
            <IconButton aria-label="expense">
              <ToolTipIcon />
            </IconButton>
          </Tooltip>
        </Typography>
      </ExpenseInnerContainer>
    </ExpenseBalanceContainer>
  );
}

export default CurrentBalance;
