// React, Next packages
import React, { useState, useEffect } from "react";
import { connect } from "react-redux";
import { Dispatch } from "redux";
import dynamic from "next/dynamic";
import Link from "next/link";
// Mui packages
import {
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  Paper,
  Typography,
  styled,
  Stack,
  FormControl,
  MenuItem,
  Select,
  SelectChangeEvent,
  Grid,
  Box,
  Pagination,
  Button,
  Tooltip,
  IconButton,
} from "@mui/material";
// 3Rd Party Component/Packages
import { useSnackbar } from "notistack";
import moment from "moment";
import { useTranslation } from "react-i18next";
import "translation/i18n";
// Custom packages
import { RootState } from "reducers";
import { expensesList } from "@reducers/expensesSlice";
import NoOfficeData from "features/officeManagement/NoOfficeData";
import {
  EURIconColor,
  INRIconColor,
  KRWIconColor,
  USDIconColor,
  ToolTipIconColor,
} from "@common/Icon";
import useCompany from "@lib/useCompany";
import useCurrency from "@lib/useCurrency";
import AppliedFunds from "./AppliedFunds";

const CustomContainer = styled("div")(({ theme }) => ({
  display: "flex",
  flexDirection: "column",
}));
const CustomTableContainer = styled("div")(({ theme }) => ({
  display: "flex",
}));

const StyledTableRow = styled(TableRow)(({ theme }) => ({
  "&:nth-of-type(odd)": {
    // backgroundColor: theme.palette.action.hover,
  },
  // hide last border
  "&:last-child td, &:last-child th": {
    border: 0,
  },
}));

const StyledTableCell = styled(TableCell)(({ theme }) => ({
  fontSize: 14,
  padding: "18px",
}));

const CustomSelectContainer = styled("div")(({ theme }) => ({
  display: "flex",
  justifyContent: "space-between",
  paddingBottom: "24px",
  alignItems: "center",
  [theme.breakpoints.down("sm")]: {
    display: "flex",
    flexDirection: "column",
    alignItems: "start",
  },
}));

// Month Drodwon Menu Props

const ITEM_HEIGHT = 30;
const ITEM_PADDING_TOP = 8;
const MenuProps = {
  PaperProps: {
    style: {
      maxHeight: ITEM_HEIGHT * 4.5 + ITEM_PADDING_TOP,
      width: 126,
    },
  },
};

function officeExpenses(props: any) {
  /** third-party hooks */
  const { enqueueSnackbar } = useSnackbar();
  //** Language translation hooks */
  const { t } = useTranslation();
  /** props - actions */
  const { expensesList } = props;
  /** props - states */
  const { result, count } = props;
  const pageNumber = Math.ceil(count / 10);
  const [expensesListPage, setExpensesListPage] = useState(1);

  // Custom hooks
  const { company } = useCompany();
  const { currency } = useCurrency();

  // Search functionality
  const [isYearSelected, setIsYearSelected] = useState<any>("1");
  const [isMonthSelected, setIsMonthSelected] = useState<any>("1");
  const [searchClicked, setSearchClicked] = useState(false);

  const handleChangeYear = (event: SelectChangeEvent) => {
    setIsYearSelected(event.target.value);
  };
  const handleChangeMonth = (event: SelectChangeEvent) => {
    setIsMonthSelected(event.target.value);
  };

  const [filteredTable, seFilteredTable] = useState<any>([]);

  const filterResultFunc = (year: string, month: string) => {
    const filteredResult = result.filter((item: any) => {
      return item.invoice_date.slice(0, 7) === `${year}-${month}`;
    });

    seFilteredTable(filteredResult);

    return filteredResult;
  };

  // Convert number with commas
  const numberWithCommas = (x: string) => {
    return x.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",");
  };

  /** useEffect hooks */
  useEffect(() => {
    const expenses = async () => {
      await expensesList({ page: expensesListPage, page_size: 10 });
    };

    try {
      expenses();
    } catch (error: any) {
      enqueueSnackbar(error.toString(), { variant: "error" });
    }
  }, [expensesListPage]);

  const months = [
    {
      value: "01",
      label: `${t("january_title")}`,
    },
    {
      value: "02",
      label: `${t("february_title")}`,
    },
    {
      value: "03",
      label: `${t("march_title")}`,
    },
    {
      value: "04",
      label: `${t("april_title")}`,
    },
    {
      value: "05",
      label: `${t("may_title")}`,
    },
    {
      value: "06",
      label: `${t("june_title")}`,
    },
    {
      value: "07",
      label: `${t("july_title")}`,
    },
    {
      value: "08",
      label: `${t("august_title")}`,
    },
    {
      value: "09",
      label: `${t("september_title")}`,
    },
    {
      value: "10",
      label: `${t("october_title")}`,
    },
    {
      value: "11",
      label: `${t("november_title")}`,
    },
    {
      value: "12",
      label: `${t("december_title")}`,
    },
  ];

  //** month list */
  const monthList = [
    `${t("january_title")}`,
    `${t("february_title")}`,
    `${t("march_title")}`,
    `${t("april_title")}`,
    `${t("may_title")}`,
    `${t("june_title")}`,
    `${t("july_title")}`,
    `${t("august_title")}`,
    `${t("september_title")}`,
    `${t("october_title")}`,
    `${t("november_title")}`,
    `${t("december_title")}`,
  ];

  return (
    <CustomContainer>
      <CustomSelectContainer>
        <Box sx={{ marginBottom: { xs: "24px", sm: "0px" } }}>
          <Typography component="h3" variant="h3">
            {/* here title and menu text are same that'w why  use this  */}
            {t("office_expense_menu")}
            <Tooltip
              title={`${t("office_expense_tooltip")}`}
              arrow
              enterTouchDelay={0}
            >
              <IconButton aria-label="hr_actions">
                <ToolTipIconColor />
              </IconButton>
            </Tooltip>
          </Typography>
        </Box>
        <Box>
          <Select
            labelId="demo-simple-select-label"
            id="demo-simple-select"
            value={isYearSelected}
            onChange={handleChangeYear}
            sx={{
              width: "96px",
              height: "40px",
              marginRight: "10px",
            }}
          >
            <MenuItem value={1} disabled selected>
              {t("year")}
            </MenuItem>
            <MenuItem value={2023}>2023</MenuItem>
            <MenuItem value={2022}>2022</MenuItem>
            <MenuItem value={2021}>2021</MenuItem>
          </Select>
          {/* </FormControl> */}

          <Select
            labelId="demo-simple-select-label"
            id="demo-simple-select"
            value={isMonthSelected}
            onChange={handleChangeMonth}
            MenuProps={MenuProps}
            sx={{ width: "110px", height: "40px", marginRight: "20px" }}
          >
            <MenuItem value={1} disabled selected>
              {t("month")}
            </MenuItem>

            {months.map((month, index) => (
              <MenuItem value={month.value} key={index}>
                {month.label}
              </MenuItem>
            ))}
          </Select>

          <Button
            component="a"
            variant="contained"
            rel="noopener noreferrer"
            target="_blank"
            size="medium"
            sx={{ width: "87px", height: "40px" }}
            onClick={() => {
              if (isYearSelected !== "1" && isMonthSelected !== "1") {
                filterResultFunc(isYearSelected, isMonthSelected);
                setSearchClicked(true);
                console.log("isYearSelected: ", isYearSelected);
                console.log("isMonthSelected: ", isMonthSelected);
                console.log("result: ", result);
                console.log("filteredTable: ", filteredTable);
              }
            }}
          >
            {t("search")}
          </Button>
        </Box>
      </CustomSelectContainer>

      {/* [Table data] */}
      {result.length > 0 && !searchClicked ? (
        <CustomTableContainer>
          <TableContainer component={Paper} sx={{ boxShadow: "none" }}>
            <Table sx={{ minWidth: 1050 }} aria-label="simple table">
              <TableHead sx={{ background: "#ECEDF4" }}>
                <StyledTableRow>
                  <StyledTableCell
                    sx={{
                      fontSize: 16,
                      lineHeight: 1.5,
                      fontWeight: 700,
                      width: "29%",
                    }}
                  >
                    {t("office_expense_table_head_date")}
                  </StyledTableCell>
                  <StyledTableCell
                    sx={{ fontSize: 16, lineHeight: 1.5, fontWeight: 700 }}
                  >
                    {t("office_expense_table_head_total")}
                  </StyledTableCell>
                  <StyledTableCell
                    sx={{ fontSize: 16, lineHeight: 1.5, fontWeight: 700 }}
                  >
                    {t("office_expense_table_head_payment")}
                  </StyledTableCell>
                  <StyledTableCell
                    sx={{ fontSize: 16, lineHeight: 1.5, fontWeight: 700 }}
                  >
                    {t("office_expense_table_head_invoice")}
                  </StyledTableCell>
                </StyledTableRow>
              </TableHead>
              <TableBody>
                {result.map((row, index) => {
                  //const date define
                  const multiLanguageDateFormat = moment(
                    row?.invoice_date
                  ).format("MMMM");
                  // day and year format
                  const dayYearFormat = moment(row?.invoice_date).format(
                    "DD, YYYY"
                  );
                  return (
                    <TableRow
                      key={index}
                      sx={{ "&:last-child td, &:last-child th": { border: 0 } }}
                    >
                      <StyledTableCell
                        component="th"
                        scope="row"
                        sx={{
                          fontSize: 14,
                          fontWeight: 400,
                          lineHeight: 1.5,
                          color: "#222222",
                        }}
                      >
                        {/* {moment(row?.invoice_date).format("MMMM DD, YYYY")} */}
                        {multiLanguageDateFormat === "January"
                          ? monthList[0].concat(" ", dayYearFormat)
                          : multiLanguageDateFormat === "February"
                          ? monthList[1].concat(" ", dayYearFormat)
                          : multiLanguageDateFormat === "March"
                          ? monthList[2].concat(" ", dayYearFormat)
                          : multiLanguageDateFormat === "April"
                          ? monthList[3].concat(" ", dayYearFormat)
                          : multiLanguageDateFormat === "May"
                          ? monthList[4].concat(" ", dayYearFormat)
                          : multiLanguageDateFormat === "June"
                          ? monthList[5].concat(" ", dayYearFormat)
                          : multiLanguageDateFormat === "July"
                          ? monthList[6].concat(" ", dayYearFormat)
                          : multiLanguageDateFormat === "August"
                          ? monthList[7].concat(" ", dayYearFormat)
                          : multiLanguageDateFormat === "September"
                          ? monthList[8].concat(" ", dayYearFormat)
                          : multiLanguageDateFormat === "October"
                          ? monthList[9].concat(" ", dayYearFormat)
                          : multiLanguageDateFormat === "November"
                          ? monthList[10].concat(" ", dayYearFormat)
                          : multiLanguageDateFormat === "December"
                          ? monthList[11].concat(" ", dayYearFormat)
                          : ""}
                      </StyledTableCell>
                      <StyledTableCell
                        sx={{ fontWeight: "700", color: "#222222" }}
                      >
                        {company && currency && company.currency === "KRW" ? (
                          <KRWIconColor sx={{ fontSize: "10px" }} />
                        ) : company &&
                          currency &&
                          company.currency === "USD" ? (
                          <USDIconColor sx={{ fontSize: "10px" }} />
                        ) : company &&
                          currency &&
                          company.currency === "EUR" ? (
                          <EURIconColor sx={{ fontSize: "10px" }} />
                        ) : (
                          <INRIconColor sx={{ fontSize: "10px" }} />
                        )}
                        {company && currency && company.currency === "KRW"
                          ? numberWithCommas(
                              (
                                row?.invoice_total_expenses *
                                currency.currency_krw
                              ).toFixed(2)
                            )
                          : company && currency && company.currency === "USD"
                          ? numberWithCommas(
                              (
                                row?.invoice_total_expenses *
                                currency.currency_usd
                              ).toFixed(2)
                            )
                          : company && currency && company.currency === "EUR"
                          ? numberWithCommas(
                              (
                                row?.invoice_total_expenses *
                                currency.currency_eur
                              ).toFixed(2)
                            )
                          : numberWithCommas(row?.invoice_total_expenses)}
                      </StyledTableCell>
                      <StyledTableCell
                        sx={
                          row.invoice_payment_status === "Completed"
                            ? { color: "#009806" }
                            : { color: "#FFA500" }
                        }
                      >
                        {" "}
                        {row?.invoice_payment_status === "Pending"
                          ? `${t("payment_status_pending")}`
                          : row?.invoice_payment_status === "Completed"
                          ? `${t("payment_status_completed")}`
                          : ""}
                      </StyledTableCell>
                      <StyledTableCell>
                        <Stack
                          direction="row"
                          alignItems="center"
                          justifyContent="start"
                        >
                          <Typography
                            component="span"
                            sx={{
                              fontSize: 14,
                              fontWeight: 700,
                              lineHeight: 1.5,
                              color: "#2c3058",
                            }}
                          >
                            <Link
                              href={
                                row?.invoice_file_upload === null
                                  ? row?.invoice_file
                                  : row?.invoice_file_upload
                              }
                            >
                              <a target="_blank">
                                {t("office_expense_view_invoice")}
                              </a>
                            </Link>
                          </Typography>
                        </Stack>
                      </StyledTableCell>
                    </TableRow>
                  );
                })}
              </TableBody>
            </Table>
          </TableContainer>
        </CustomTableContainer>
      ) : filteredTable.length > 0 && searchClicked ? (
        <CustomTableContainer>
          <TableContainer component={Paper} sx={{ boxShadow: "none" }}>
            <Table sx={{ minWidth: 1050 }} aria-label="simple table">
              <TableHead sx={{ background: "#ECEDF4" }}>
                <StyledTableRow>
                  <StyledTableCell
                    sx={{
                      fontSize: 16,
                      lineHeight: 1.5,
                      fontWeight: 700,
                      width: "29%",
                    }}
                  >
                    {t("office_expense_table_head_date")}
                  </StyledTableCell>
                  <StyledTableCell
                    sx={{ fontSize: 16, lineHeight: 1.5, fontWeight: 700 }}
                  >
                    {t("office_expense_table_head_total")}
                  </StyledTableCell>
                  <StyledTableCell
                    sx={{ fontSize: 16, lineHeight: 1.5, fontWeight: 700 }}
                  >
                    {t("office_expense_table_head_payment")}
                  </StyledTableCell>
                  <StyledTableCell
                    sx={{ fontSize: 16, lineHeight: 1.5, fontWeight: 700 }}
                  >
                    {t("office_expense_table_head_invoice")}
                  </StyledTableCell>
                </StyledTableRow>
              </TableHead>
              <TableBody>
                {filteredTable.map((row, index) => {
                  //const date define
                  const multiLanguageDateFormat = moment(
                    row?.invoice_date
                  ).format("MMMM");
                  // day and year format
                  const dayYearFormat = moment(row?.invoice_date).format(
                    "DD, YYYY"
                  );
                  return (
                    <TableRow
                      key={index}
                      sx={{ "&:last-child td, &:last-child th": { border: 0 } }}
                    >
                      <StyledTableCell
                        component="th"
                        scope="row"
                        sx={{
                          fontSize: 14,
                          fontWeight: 400,
                          lineHeight: 1.5,
                          color: "#222222",
                        }}
                      >
                        {/* {moment(row?.invoice_date).format("MMMM DD, YYYY")} */}
                        {multiLanguageDateFormat === "January"
                          ? monthList[0].concat(" ", dayYearFormat)
                          : multiLanguageDateFormat === "February"
                          ? monthList[1].concat(" ", dayYearFormat)
                          : multiLanguageDateFormat === "March"
                          ? monthList[2].concat(" ", dayYearFormat)
                          : multiLanguageDateFormat === "April"
                          ? monthList[3].concat(" ", dayYearFormat)
                          : multiLanguageDateFormat === "May"
                          ? monthList[4].concat(" ", dayYearFormat)
                          : multiLanguageDateFormat === "June"
                          ? monthList[5].concat(" ", dayYearFormat)
                          : multiLanguageDateFormat === "July"
                          ? monthList[6].concat(" ", dayYearFormat)
                          : multiLanguageDateFormat === "August"
                          ? monthList[7].concat(" ", dayYearFormat)
                          : multiLanguageDateFormat === "September"
                          ? monthList[8].concat(" ", dayYearFormat)
                          : multiLanguageDateFormat === "October"
                          ? monthList[9].concat(" ", dayYearFormat)
                          : multiLanguageDateFormat === "November"
                          ? monthList[10].concat(" ", dayYearFormat)
                          : multiLanguageDateFormat === "December"
                          ? monthList[11].concat(" ", dayYearFormat)
                          : ""}
                      </StyledTableCell>
                      <StyledTableCell
                        sx={{ fontWeight: "700", color: "#222222" }}
                      >
                        {company && currency && company.currency === "KRW" ? (
                          <KRWIconColor sx={{ fontSize: "10px" }} />
                        ) : company &&
                          currency &&
                          company.currency === "USD" ? (
                          <USDIconColor sx={{ fontSize: "10px" }} />
                        ) : company &&
                          currency &&
                          company.currency === "EUR" ? (
                          <EURIconColor sx={{ fontSize: "10px" }} />
                        ) : (
                          <INRIconColor sx={{ fontSize: "10px" }} />
                        )}
                        {company && currency && company.currency === "KRW"
                          ? (
                              row?.invoice_total_expenses *
                              currency.currency_krw
                            ).toLocaleString()
                          : company && currency && company.currency === "USD"
                          ? (
                              row?.invoice_total_expenses *
                              currency.currency_usd
                            ).toLocaleString()
                          : company && currency && company.currency === "EUR"
                          ? (
                              row?.invoice_total_expenses *
                              currency.currency_eur
                            ).toLocaleString()
                          : (row?.invoice_total_expenses).toLocaleString()}
                      </StyledTableCell>
                      <StyledTableCell
                        sx={
                          row.invoice_payment_status === "Completed"
                            ? { color: "#009806" }
                            : { color: "#FFA500" }
                        }
                      >
                        {" "}
                        {row?.invoice_payment_status}
                      </StyledTableCell>
                      <StyledTableCell>
                        <Stack
                          direction="row"
                          alignItems="center"
                          justifyContent="start"
                        >
                          <Typography
                            component="span"
                            sx={{
                              fontSize: 14,
                              fontWeight: 700,
                              lineHeight: 1.5,
                              color: "#2c3058",
                            }}
                          >
                            <Link href={row?.invoice_file}>
                              <a target="_blank">
                                {t("office_expense_view_invoice")}
                              </a>
                            </Link>
                          </Typography>
                        </Stack>
                      </StyledTableCell>
                    </TableRow>
                  );
                })}
              </TableBody>
            </Table>
          </TableContainer>
        </CustomTableContainer>
      ) : filteredTable.length === 0 &&
        isMonthSelected !== "1" &&
        isYearSelected !== "1" &&
        searchClicked ? (
        <Box>
          <NoOfficeData
            title={`${t("office_expense_empty_title")}`}
            imgName="Illust-4"
          />
        </Box>
      ) : (
        <Box>
          <NoOfficeData
            title={`${t("office_expense_empty_title")}`}
            imgName="Illust-4"
          />
        </Box>
      )}

      {/* Pagination for Team Expenses List   */}
      {count > 10 ? (
        <Grid container spacing={1}>
          <Grid item xs={12}>
            <Box sx={{ display: "flex", justifyContent: "center" }}>
              <Stack
                direction="row"
                alignItems="center"
                justifyContent="center"
                paddingTop={5}
                paddingBottom={3}
              >
                <Pagination
                  count={pageNumber}
                  color="secondary"
                  onChange={(e, value) => setExpensesListPage(value)}
                  sx={{
                    background: "#ECEDF4",
                    borderRadius: "10px",
                    padding: { xs: "5px", sm: "10px" },
                  }}
                />
              </Stack>
            </Box>
          </Grid>
        </Grid>
      ) : (
        ""
      )}

      <AppliedFunds
        month={isMonthSelected}
        year={isYearSelected}
        searchClicked={searchClicked}
      />
    </CustomContainer>
  );
}

const mapStateToProps = (state: RootState) => ({
  result: state.expenses.results,
  count: state.expenses.count,
});

const mapDispatchToProps = (dispatch: Dispatch) => {
  return {
    expensesList: (params: any) => expensesList(dispatch, params),
  };
};

export default connect(mapStateToProps, mapDispatchToProps)(officeExpenses);
