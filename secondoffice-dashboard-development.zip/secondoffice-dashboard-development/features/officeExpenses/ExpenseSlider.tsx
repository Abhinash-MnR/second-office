// React, Next Packages
import React from "react";
// Mui packages
import { Grid, styled, Typography } from "@mui/material";

// Custom Packages

const ExpenseSliderContainer = styled("div")(({ theme }) => ({
  display: "flex",
  flexDirection: "column",
  background: "#ECEDF4",
  borderRadius: 10,
  height: "230px",
  padding: "unset",
  [theme.breakpoints.down("sm")]: {
    padding: "14px 24px",
    height: "293px",
  },
}));

const ExpenseInnerContainer = styled("div")(({ theme }) => ({
  display: "flex",
  flexDirection: "row",
  width: "100%",
  justifyContent: "space-between",
  alignItems: "start",
  height: "230px",
  position: "relative",
  [theme.breakpoints.down("sm")]: {
    flexDirection: "column",
    alignItems: "center",
    height: "293px",
  },
}));

const ContentContainer = styled("div")(({ theme }) => ({
  display: "flex",
  flexDirection: "column",
  padding: "20px",
  [theme.breakpoints.down("sm")]: {
    padding: "unset",
  },
}));
const ImagesContainer = styled("div")(({ theme }) => ({
  display: "flex",
  flexDirection: "column",
  width: "198px",
  height: "199px",
  paddingRight: "30px",
  position: "absolute",
  right: 0,
  bottom: "-26px",
  [theme.breakpoints.down("sm")]: {
    display: "flex",
    flexDirection: "column",
    paddingRight: "0px",
    position: "relative",
    width: "125px",
    height: "70px",
    bottom: "80px",
    right: "unset",
  },
}));

const ImagesContainer3 = styled("div")(({ theme }) => ({
  display: "flex",
  flexDirection: "column",
  width: "198px",
  height: "199px",
  paddingRight: "30px",
  position: "absolute",
  right: 0,
}));

export function ExpenseSlider1(props: any) {
  // Expense Slider Component Props Data
  const { title, content, img_url } = props;

  return (
    <ExpenseSliderContainer>
      <ExpenseInnerContainer>
        <ContentContainer>
          <Typography
            component="h4"
            variant="h4"
            sx={{
              width: "390px",
              color: "primary.main",
              paddingBottom: "12px",
            }}
          >
            {title}
          </Typography>
          <Typography component="p" variant="body1" sx={{ width: "390px" }}>
            {content}
          </Typography>
        </ContentContainer>
        <ImagesContainer>
          <img src={img_url} alt="expense-slider" />
        </ImagesContainer>
      </ExpenseInnerContainer>
    </ExpenseSliderContainer>
  );
}

export function ExpenseSlider3(props) {
  // Expense Slider Component Props Data
  const { title, content, img_url } = props;
  return (
    <ExpenseSliderContainer>
      <ExpenseInnerContainer>
        <ContentContainer>
          <Typography
            component="h4"
            variant="h4"
            sx={{
              width: "390px",
              color: "primary.main",
              paddingBottom: "12px",
            }}
          >
            {title}
          </Typography>
          <Typography component="p" variant="body1" sx={{ width: "390px" }}>
            {content}
          </Typography>
        </ContentContainer>
        <ImagesContainer3>
          <img src={img_url} alt="expense-slider" />
        </ImagesContainer3>
      </ExpenseInnerContainer>
    </ExpenseSliderContainer>
  );
}

/*  Mobile View Component Design */

export function MobileExpenseCardSlider(props) {
  // Expense Slider Component Props Data
  const { title, content, img_url } = props;

  return (
    <ExpenseSliderContainer>
      <ExpenseInnerContainer>
        <ContentContainer>
          <Typography component="h6" variant="h6" sx={{ textAlign: "center" }}>
            {title}
          </Typography>
          <Typography
            component="p"
            sx={{
              textAlign: "center",
              fontSize: "12px",
              lineHeght: "150%",
              marginTop: "10px",
            }}
          >
            {content}
          </Typography>
        </ContentContainer>
        <ImagesContainer>
          <img src={img_url} alt="expense-slider" />
        </ImagesContainer>
      </ExpenseInnerContainer>
    </ExpenseSliderContainer>
  );
}
