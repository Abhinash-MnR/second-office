// React, Next packages
import React, { FC, useEffect, useState } from "react";
// Mui packages
import {
  IconButton,
  LinearProgress,
  Pagination,
  Stack,
  Typography,
} from "@mui/material";
import {
  BookmarkBorderOutlined,
  ChatBubbleOutline,
  ZoomIn,
  ZoomOut,
} from "@mui/icons-material";
// Third-party packages
import { useSnackbar } from "notistack";
import { Document, Page, pdfjs } from "react-pdf";
import { SizeMe } from "react-sizeme";
// Custom packages
import { DialogForm, DialogFormProps } from "@common/DialogForm";
import { getUserDetail } from "api/user";
import { User } from "types/UserType";

pdfjs.GlobalWorkerOptions.workerSrc = `//cdnjs.cloudflare.com/ajax/libs/pdf.js/${pdfjs.version}/pdf.worker.js`;

export type ResumeDialogProps = {
  /** Callback triggered on click of the `Accept` button */
  onAccept?: (...params: any) => void;
  /** Callback triggered on click of the `Chat` button */
  onChat?: (...params: any) => void;
  /** Callback triggered on click of the `Reject` button */
  onReject?: (...params: any) => void;
  /** Callback triggered on click of the `Retrieve` button */
  onRetrieve?: (...params: any) => void;
  /** Callback triggered on click of the `Save` button */
  onSave?: (...params: any) => void;
  /** Unique id assigned to the application owner  */
  userId?: string;
} & DialogFormProps;

export const ResumeDialog: FC<ResumeDialogProps> = (
  props: ResumeDialogProps
) => {
  /** third-party hooks */
  const { enqueueSnackbar } = useSnackbar();

  /** props - states */
  const {
    onAccept,
    onChat,
    onClose,
    onReject,
    onRetrieve,
    onSave,
    userId,
    open,
  } = props;

  /** useState hooks */
  const [numPages, setNumPages] = useState(undefined);
  const [pageNumber, setPageNumber] = useState<number>(1);
  const [pageScale, setPageScale] = useState<number>(1);
  const [user, setUser] = useState<User | undefined>(undefined);

  function onResumeLoadSuccess({ numPages }: any) {
    setNumPages(numPages);
  }

  /** useEffect hooks */
  useEffect(() => {
    const initializeProfile = async () => {
      try {
        // Fetch applicant data with unique user profile link
        const response = await getUserDetail(userId as string);
        const _user = response.data;
        // Change profile variable states
        setUser(_user);
      } catch (error: any) {
        enqueueSnackbar(error.toString(), { variant: "warning" });
      }
    };
    userId && initializeProfile();
  }, [userId]);

  /** custom handlers */
  const handleChange = (event: React.ChangeEvent<unknown>, value: number) => {
    setPageNumber(value);
  };

  const handleZoomIn = () => {
    setPageScale((prev) => prev + 0.25);
  };

  const handleZoomOut = () => {
    setPageScale((prev) => prev - 0.25);
  };

  return (
    <DialogForm
      maxWidth="md"
      onClose={onClose}
      open={open}
      title={user ? `${user.first_name} ${user.last_name}` : "Loading..."}
      footer={
        <Stack
          alignItems="center"
          direction="row"
          justifyContent="center"
          width={1}
        >
          <IconButton
            size="small"
            disabled={pageScale >= 2}
            onClick={handleZoomIn}
          >
            <ZoomIn />
          </IconButton>
          <IconButton
            size="small"
            disabled={pageScale <= 0.5}
            onClick={handleZoomOut}
          >
            <ZoomOut />
          </IconButton>
          <Pagination
            count={numPages}
            color="primary"
            onChange={handleChange}
            siblingCount={0}
            size="small"
            shape="rounded"
          />
          <IconButton size="small" onClick={onChat}>
            <ChatBubbleOutline />
          </IconButton>
          <IconButton size="small" onClick={onSave}>
            <BookmarkBorderOutlined />
          </IconButton>
        </Stack>
      }
    >
      {/* Indicate loading state when profile not fetched yet */}
      {!user && <LinearProgress />}
      {/* Start loading pdf when resume exists  */}
      {user && user.resume && (
        <SizeMe>
          {/* https://github.com/wojtekmaj/react-pdf/issues/129#issuecomment-653710431 */}
          {({ size }) => (
            <Document
              options={{
                cMapUrl: `//cdn.jsdelivr.net/npm/pdfjs-dist@${pdfjs.version}/cmaps/`,
                cMapPacked: true,
              }}
              file={user.resume}
              onLoadSuccess={onResumeLoadSuccess}
            >
              <Page
                className="pdf-page"
                pageNumber={pageNumber}
                scale={pageScale}
              />
            </Document>
          )}
        </SizeMe>
      )}
      {/* Indicate no resume found when profile exists but no resume found */}
      {user && !user.resume && (
        <Typography>This user does not have a resume attached.</Typography>
      )}
    </DialogForm>
  );
};
