// React, Next packages
import React, { FC, ReactNode, useState } from "react";
import Link from "next/link";
import Head from "next/head";
import dynamic from "next/dynamic";
import { useRouter } from "next/router";
// Mui packages
import {
  AppBar,
  Drawer,
  Hidden,
  IconButton,
  Stack,
  styled,
  Toolbar,
  Typography,
  useMediaQuery,
} from "@mui/material";
// Custom packages
import { MenuIcon } from "@common/Icon";
import useCompany from "@lib/useCompany";
import SideBarMenu from "./SideBarMenu";

export type LayoutProps = {
  /** Background color */
  backgroundColor?: string;
  /** Main content of the layout */
  children: ReactNode;
  /** Callback triggered when the page CTA button is clicked  */
  ctaCallback?: (...pararms: any) => void;
  /** CTA button title */
  ctaTitle?: string;
  /** Callback triggered when chip is clicke */
  onChange?: (event: any, value: any) => void;
  /** Title of the page to be crawled via OG */
  ogTitle?: string;
  /** Description of the page to be craweld via OG */
  ogDescription?: string;
  /** Image of the page to be crawled via OG */
  ogImage?: string;
  /** Title of the page */
  pageTitle?: string | ReactNode;
  /** Current value of the chip group form */
  value?: string;
  /**Company Name of The Login User */
  companyName?: string | ReactNode;
};

// const drawerMenu = [
//   {
//     label: "Dashboard",
//     icon: <ChartIcon />,
//     iconColor: <ChartIconColor />,
//     value: "/dashboard",
//     path: "/dashboard",
//   },
//   {
//     label: "Recruit",
//     icon: <AddUser />,
//     iconColor: <AddUserColor />,
//     value: "/applications",
//     path: "/applications",
//   },
//   {
//     label: "Office Management",
//     icon: <AddMultiUser />,
//     iconColor: <AddMultiUserColor />,
//     value: "/officeManagement",
//     path: "/officeManagement",
//   },
//   {
//     label: "Store",
//     icon: <StoreWhite />,
//     iconColor: <Store />,
//     value: "/store",
//     path: "/store",
//   },
//   {
//     label: "Office Expenses",
//     icon: <PaperIcon />,
//     iconColor: <PaperIconColor />,
//     value: "/expenses",
//     path: "/expenses",
//   },
//   {
//     label: "Settings",
//     icon: <SettingsWhite />,
//     iconColor: <Settings />,
//     value: "/settings",
//     path: "/settings",
//   },
// ];

const drawerWidth = "16.8%";
const containerWidth = "83.2%";

const DrawerContainer = styled("nav")(({ theme }) => ({
  [theme.breakpoints.up("lg")]: {
    width: drawerWidth,
    // flexShrink: 0,
  },
}));

const DrawerPaper = styled(Drawer)(({ theme }) => ({
  ["& .MuiDrawer-paper"]: {
    background: "#FFFFFF",
    borderRight: "1px solid rgba(138, 142, 186, 0.32)",
    width: drawerWidth,
    [theme.breakpoints.down("lg")]: {
      width: "280px",
      // flexShrink: 0,
    },
  },
}));

const ImageContainer = styled("div")(({ theme }) => ({
  display: "flex",
  flexDirection: "column",
  border: "1px solid #D5D6DE",
  borderRadius: "50%",
  cursor: "pointer",
}));

export const Layout: FC<LayoutProps> = (props: LayoutProps) => {
  /** third-party hooks */
  const [mobileOpen, setMobileOpen] = useState(false);
  const { company, isLoading, isError } = useCompany();
  // const { user } = useUser();
  const router = useRouter();

  //  Media Quiery Hooks

  const isMobile = useMediaQuery("(max-width:600px)");
  const MediumScreen = useMediaQuery("(max-width:1200px)");

  /** props */
  const {
    backgroundColor,
    children,
    companyName,
    pageTitle,
    ogImage = "/images/banner.png",
    ogTitle = "SecondOffice | Your Personal Job Portal",
    ogDescription = "A Job for Everyone. SecondOffice is a job portal dedicated to be your personal recruiting team.",
  } = props;

  /** custom handlers */
  const handleDrawerToggle = () => {
    setMobileOpen(!mobileOpen);
  };

  const drawer = (
    <Stack direction="column" justifyContent="space-between" minHeight="100%">
      <div>
        <Toolbar sx={{ paddingLeft: "30px !important", marginBottom: 4.2 }}>
          {/* SecondOffice Logo */}
          <img
            height="35px"
            src="/svg/logo-blue.svg"
            style={{ marginLeft: -5, marginTop: 2 }}
          />
        </Toolbar>
        {/* Menu Component */}
        <SideBarMenu />
      </div>
    </Stack>
  );

  const WebNavigationBar = (
    <AppBar
      position="fixed"
      sx={{
        background: "#fff",
        boxShadow: "none",
        borderBottom: "1px solid rgba(138, 142, 186, 0.32)",
      }}
    >
      <Toolbar>
        <Stack
          alignItems={{ xs: "flex-start", sm: "center", md: "start" }}
          direction={{ xs: "row", sm: "column" }}
          justifyContent="flex-center"
          width={{ xs: "auto", sm: drawerWidth }}
        >
          {/* Drawer Toggle */}
          <IconButton
            color="primary"
            aria-label="open drawer"
            onClick={handleDrawerToggle}
            sx={{
              display: { lg: "none" },
            }}
          >
            <MenuIcon />
          </IconButton>
        </Stack>
        <Stack
          direction="row"
          alignItems={{ xs: "center", sm: "center" }}
          width={{ xs: "100%", sm: "83.5%" }}
          paddingTop={{ xs: "none", sm: "none" }}
          justifyContent="space-between"
        >
          <Typography
            component="h3"
            variant="h3"
            color="primary.main"
            paddingLeft={isMobile ? "27%" : "24px"}
          >
            {company?.company_name}
          </Typography>
          <Typography
            component="h2"
            variant="h2"
            color="primary.main"
            paddingRight={isMobile ? "0px" : "15px"}
          >
            <ImageContainer onClick={() => router.push("/profile")}>
              <img
                // src="/svg/defaltProfileIcon.svg"
                src={
                  company?.company_logo
                    ? company?.company_logo
                    : `/svg/DefaultLogo.svg`
                }
                alt="ProfileIcon_Image"
                style={{
                  width: "42px",
                  height: "42px",
                  borderRadius: 40,
                }}
              />
            </ImageContainer>
          </Typography>
        </Stack>
      </Toolbar>
    </AppBar>
  );
  const MobileNavigationBar = (
    <AppBar
      position="fixed"
      sx={{
        background: "#fff",
        boxShadow: "none",
        borderBottom: "1px solid rgba(138, 142, 186, 0.32)",
        // boxShadow:
        //   "0px 11.9687px 17.205px -2.99217px rgba(145, 158, 171, 0.24)",
      }}
    >
      <Toolbar sx={{ display: "flex", justifyContent: "space-between" }}>
        <Stack
          alignItems={{ xs: "flex-start", sm: "center", md: "start" }}
          direction={{ xs: "row", sm: "column" }}
          justifyContent="flex-center"
          width={{ xs: "auto", sm: drawerWidth }}
        >
          {/* Drawer Toggle */}
          <IconButton
            color="primary"
            aria-label="open drawer"
            onClick={handleDrawerToggle}
            sx={{
              display: { lg: "none" },
            }}
          >
            <MenuIcon />
          </IconButton>
        </Stack>

        <Typography component="h3" variant="h3" color="primary.main">
          {company?.company_name}
        </Typography>
        <Typography component="h2" variant="h2" color="primary.main">
          <ImageContainer onClick={() => router.push("/profile")}>
            <img
              // src="/svg/defaltProfileIcon.svg"
              src={
                company?.company_logo
                  ? company?.company_logo
                  : `/svg/DefaultLogo.svg`
              }
              alt="ProfileIcon_Image"
              style={{
                width: "42px",
                height: "42px",
                borderRadius: 40,
              }}
            />
          </ImageContainer>
        </Typography>
      </Toolbar>
    </AppBar>
  );

  return (
    <>
      <Head>
        <meta charSet="utf-8" />
        <meta httpEquiv="X-UA-Compatible" content="IE=edge" />
        <meta
          name="viewport"
          content="width=device-width,initial-scale=1,minimum-scale=1,maximum-scale=1,user-scalable=no"
        />
        <meta name="description" content={ogDescription} />
        <meta name="keywords" content="Jobs in India" />
        <title>{ogTitle}</title>
        <meta property="og:image" content={ogImage} />
        <meta property="og:title" content={ogTitle} />
        <meta property="og:description" content={ogDescription} />
        <meta name="twitter:title" content={ogTitle} />
        <meta name="twitter:description" content={ogDescription} />
        <meta name="twitter:image" content={ogImage} />
        <meta name="twitter:card" content="summary_large_image" />
        <link rel="manifest" href="/manifest.json" />
        <link
          href="/favicon-white-2.ico"
          rel="icon"
          type="image/svg"
          sizes="16x16"
        />
        <link
          href="/favicon-white-2.ico"
          rel="icon"
          type="image/svg"
          sizes="32x32"
        />
        {/* <link rel="apple-touch-icon" href="/faviconSO.ico"></link>
        <link rel="shortcut icon" href="/faviconSO.ico" /> */}
      </Head>
      <div>
        {/* Top navigation */}
        <div style={{ width: "100%" }}>
          {isMobile ? MobileNavigationBar : WebNavigationBar}
        </div>

        {/* Side navigation */}
        <div
          style={{
            display: "flex",
            width: "100%",
          }}
        >
          <div
            style={{
              width: `${isMobile || MediumScreen ? "0px" : "16.8%"}`,
              background: "#2c3058",
              minHeight: "100vh",
            }}
          >
            {/* Side navigation */}

            {/* Side navigation */}
            <DrawerContainer aria-label="job provider dashboard menus">
              <Hidden lgDown implementation="css">
                {/* Drawer in desktop */}
                <DrawerPaper
                  sx={{
                    width: {
                      lg: drawerWidth,
                    },
                    flexShrink: {
                      lg: 0,
                    },
                    // display: "none",
                  }}
                  variant="permanent"
                  anchor="left"
                >
                  {drawer}
                </DrawerPaper>
              </Hidden>
              <Hidden mdUp implementation="css">
                {/* Drawer in mobile */}
                <DrawerPaper
                  variant="temporary"
                  open={mobileOpen}
                  onClose={handleDrawerToggle}
                  ModalProps={{
                    keepMounted: true,
                  }}
                >
                  {drawer}
                </DrawerPaper>
              </Hidden>
            </DrawerContainer>
          </div>

          <div
            style={{
              width: `${isMobile || MediumScreen ? "100%" : containerWidth}`,
              padding: `${
                isMobile ? "100px 20px 20px 20px " : "120px 40px 30px 40px"
              }`,
              backgroundColor: backgroundColor,
            }}
          >
            {/* Main content children */}

            {children}
          </div>
        </div>
      </div>
    </>
  );
};

Layout.defaultProps = {
  backgroundColor: "#f8f8f8",
};
