import * as React from "react";
import Box from "@mui/material/Box";
import Tab from "@mui/material/Tab";
import TabContext from "@mui/lab/TabContext";
import TabList from "@mui/lab/TabList";
import TabPanel from "@mui/lab/TabPanel";
import { Typography } from "@mui/material";
import Iframe from "react-iframe";

export default function OfficeLocationTab() {
  const [value, setValue] = React.useState("1");

  const handleChange = (event: React.SyntheticEvent, newValue: string) => {
    setValue(newValue);
  };

  return (
    <Box sx={{ width: "100%" }}>
      <TabContext value={value}>
        <Box>
          <TabList
            onChange={handleChange}
            aria-label="lab API tabs example"
            variant="scrollable"
            scrollButtons={false}
          >
            <Tab
              label="New Delhi"
              value="1"
              disableRipple
              sx={{
                fontSize: 16,
                padding: "0 8px 0 0",
              }}
            />
            <Tab
              label="Pune"
              value="2"
              disableRipple
              sx={{
                fontSize: 16,
              }}
            />
            <Tab
              label="Ahmedabad"
              value="3"
              disableRipple
              sx={{
                fontSize: 16,
              }}
            />
            <Tab
              label="Hyderabad"
              value="4"
              disableRipple
              sx={{
                fontSize: 16,
              }}
            />
            <Tab
              label="Bengaluru"
              value="5"
              disableRipple
              sx={{
                fontSize: 16,
              }}
            />
          </TabList>
        </Box>
        <TabPanel
          value="1"
          sx={{ paddingLeft: 0, paddingRight: 0, paddingTop: "15px" }}
        >
          <Box>
            <Iframe
              url=""
              src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3502.583726683146!2d77.3641306150085!3d28.612262382425712!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x390ce566708014d5%3A0x6aca7dd0b914c54c!2sMcKinley%20Rice!5e0!3m2!1sen!2sin!4v1648552211997!5m2!1sen!2sin"
              width="100%"
              height="450"
              id="myId"
              className="myClassname"
              loading="lazy"
              referrerpolicy="no-referrer-when-downgrade"
            />
          </Box>
        </TabPanel>
        <TabPanel
          value="2"
          sx={{ paddingLeft: 0, paddingRight: 0, paddingTop: "15px" }}
        >
          <Iframe
            url=""
            src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3782.777416232715!2d73.88372941481353!3d18.53895798739826!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3bc2c142f92a74fd%3A0x35f27cd708204775!2sMcKinley%20Rice%20-%20Pune%20office!5e0!3m2!1sen!2sin!4v1648558833691!5m2!1sen!2sin"
            width="100%"
            height="450"
            id="myId"
            className="myClassname"
            loading="lazy"
            referrerpolicy="no-referrer-when-downgrade"
          />
        </TabPanel>
        <TabPanel
          value="3"
          sx={{ paddingLeft: 0, paddingRight: 0, paddingTop: "15px" }}
        >
          <Iframe
            url=""
            src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3671.8284641576!2d72.52666261489082!3d23.030069684949304!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x395e85f9bbdbdc41%3A0xc336c3544e4468ec!2sMcKinley%20Rice%20Ahmedabad!5e0!3m2!1sen!2sin!4v1648558922681!5m2!1sen!2sin"
            width="100%"
            height="450"
            id="myId"
            className="myClassname"
            loading="lazy"
            referrerpolicy="no-referrer-when-downgrade"
          />
        </TabPanel>
        <TabPanel
          value="4"
          sx={{ paddingLeft: 0, paddingRight: 0, paddingTop: "15px" }}
        >
          <Iframe
            url=""
            src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3805.8931668202717!2d78.34388811529001!3d17.464826705162952!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3bcb93acea404de3%3A0x2de1c0bc8d8aa3ad!2s4th%20Floor%2C%20192%2C%20Botanical%20Garden%20Rd%2C%20Masjid%20Banda%2C%20Camelot%20Layout%2C%20Kondapur%2C%20Telangana%20500084!5e0!3m2!1sen!2sin!4v1653220681628!5m2!1sen!2sin"
            width="100%"
            height="450"
            id="myId"
            className="myClassname"
            loading="lazy"
            referrerpolicy="no-referrer-when-downgrade"
          />
        </TabPanel>
        <TabPanel
          value="5"
          sx={{ paddingLeft: 0, paddingRight: 0, paddingTop: "15px" }}
        >
          <Iframe
            url=""
            src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3888.6929248297547!2d77.6102785152601!3d12.927447319342322!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3bae145411534d33%3A0xa1125cd7c858731f!2s5th%20Block%2C%2019%2C%204th%20C%20Cross%20Rd%2C%20KHB%20Colony%2C%20Koramangala%20Industrial%20Layout%2C%20S.G.%20Palya%2C%20Bengaluru%2C%20Karnataka%20560095!5e0!3m2!1sen!2sin!4v1653033192118!5m2!1sen!2sin"
            width="100%"
            height="450"
            id="myId"
            className="myClassname"
            loading="lazy"
            referrerpolicy="no-referrer-when-downgrade"
          />
        </TabPanel>
      </TabContext>
    </Box>
  );
}
