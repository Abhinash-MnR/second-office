// React, Next packages
import React from "react";
import { useRouter } from "next/router";
// Mui packages
import {
  Typography,
  Stack,
  Box,
  Grid,
  IconButton,
  Tooltip,
} from "@mui/material";
import { ToolTipIcon, ToolTipIconColor } from "./Icon";
// Third party packages
// Custom components

const SummaryCard = (props: any) => {
  //** props  */
  const { cardData, cardGridSize } = props;

  return (
    <Box>
      <Grid container spacing={2}>
        {cardData.map((data, index) => (
          <Grid item xs={12} sm={cardGridSize} key={index}>
            <Box
              bgcolor={`grey.100`}
              borderRadius={`10px`}
              sx={{ border: "1px solid rgba(140, 142, 186, 0.3)" }}
            >
              <Stack
                direction={`column`}
                p={2}
                justifyContent={`center`}
                alignItems={`center`}
              >
                {data.icon}
                <Typography variant="h3" sx={{ color: "#696E9C" }} mt={3}>
                  {data.count}
                </Typography>
                <Typography variant="h5" color={`text.secondary`}>
                  {data.title}
                  {data.tooltipStatus === true && (
                    <Tooltip
                      title="Brief details mentioned in below excel sheet."
                      arrow
                      enterTouchDelay={0}
                    >
                      <IconButton sx={{ p: 0, ml: 1 }}>
                        <ToolTipIconColor />
                      </IconButton>
                    </Tooltip>
                  )}
                </Typography>
                {/* tooltip  */}
              </Stack>
            </Box>
          </Grid>
        ))}
      </Grid>
    </Box>
  );
};

export default SummaryCard;
