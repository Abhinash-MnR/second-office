// React, Next packages
import React, { FC, ReactNode } from "react";

// Mui packages
import { styled } from "@mui/material/styles";
import { Divider, Stack, Typography } from "@mui/material";

type SectionProps = {
  /** Children component */
  children: ReactNode;
  /** Footer of the section */
  footer?: ReactNode;
  /** Form title */
  title: string;
};

export const SectionContainer = styled("div")(({ theme }) => ({
  borderRadius: Number(theme.shape.borderRadius) * 1,
  // boxShadow: " 4px 4px 16px rgba(181, 181, 181, 0.3)",
  marginBottom: theme.spacing(7),
  // padding: theme.spacing(3.75),
  padding: "24px",
  background: "#fff",
  [theme.breakpoints.down("sm")]: {
    boxShadow: "none",
    marginBottom: 0,
    padding: "10px 15px",
  },
}));

export const SectionHeader = styled("div")(({ theme }) => ({
  borderBottom: "1px solid #C9C9C9",
  paddingBottom: theme.spacing(2),
}));

export const SectionBody = styled("div")(({ theme }) => ({
  paddingTop: theme.spacing(2),
}));

export const SectionDivider = styled(Divider)(({ theme }) => ({
  marginBottom: theme.spacing(3.75),
}));

export const Section: FC<SectionProps> = (props: SectionProps) => {
  /** props */
  const { title, children, footer } = props;

  return (
    <SectionContainer>
      <SectionHeader>
        <Typography fontWeight="bold" variant="h4">
          {title}
        </Typography>
      </SectionHeader>
      <SectionBody>{children}</SectionBody>
      <Stack
        direction="row"
        justifyContent="flex-end"
        width={{ sm: "100%", md: "50%" }}
        marginLeft="auto"
        padding={(theme) => `${theme.spacing(2)} 0`}
      >
        {footer}
      </Stack>
    </SectionContainer>
  );
};
