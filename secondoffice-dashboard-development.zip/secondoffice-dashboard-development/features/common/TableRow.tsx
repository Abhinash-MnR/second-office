// React, Next packages
import React, { FC, MouseEvent, useState } from "react";
// Mui packages
import { Avatar, Button, Typography, Stack, styled } from "@mui/material";
import {
  Bookmark,
  BookmarkBorder,
  Cancel,
  CheckCircle,
  QuestionAnswer,
} from "@mui/icons-material";
// Custom packages
import { User } from "types/UserType";

type TableRowProps = {
  /** Unique identifier assigned to the row */
  id: string;
  /** If `true`, disables all actions */
  disabled?: boolean;
  /** TableRow data source */
  row?: User;
  /** Callback triggered on click of the `Accept` button */
  onAccept?: (...params: any) => void;
  /** Callback triggered on click of the `Chat` button */
  onChat?: (...params: any) => void;
  /** Callback triggered on click of the row */
  onClick?: (...params: any) => void;
  /** Callback triggered on click of the `Reject` button */
  onReject?: (...params: any) => void;
  /** Callback triggered on click of the `Retrieve` button */
  onRetrieve?: (...params: any) => void;
  /** Callback triggered on click of the `Save` button */
  onSave?: (...params: any) => void;
};

const TableRowContainer = styled("tr")({
  "&:hover": {
    backgroundColor: "#fafafa",
    cursor: "pointer",
  },
  "& > :nth-of-type(n + 1)": {
    textAlign: "center",
  },
});

const TableColumn = styled("td")({
  border: "1px solid #E5E5E5",
  borderCollapse: "collapse",
  padding: 10,
  minWidth: 130,
  maxWidth: 250,
  height: 57.5,
});

const TableAvatar = styled(Avatar)({
  marginRight: 10,
  width: 30,
  height: 30,
});

const TableActionContainer = styled("td")({
  border: "1px solid #E5E5E5",
  borderCollapse: "collapse",
  height: 57.5,
  padding: 10,
  minWidth: "370px !important",
  overflow: "hidden",
  flexWrap: "nowrap",
  display: "flex",
  "&>:nth-of-type(1)": {
    marginRight: 10,
  },
});

export const TableRow: FC<TableRowProps> = (props) => {
  /** third-party hooks */

  /** useState hooks */
  const [showActions, setShowActions] = useState(false);

  /** props */
  const {
    id,
    disabled,
    row,
    onAccept,
    onChat,
    onClick,
    onReject,
    onRetrieve,
    onSave,
  } = props;

  /** custom handlers */
  const handleAccept = (e: MouseEvent<HTMLElement>) => {
    e.preventDefault();
    e.stopPropagation();
    onAccept && onAccept(id, { application_status: "accepted" });
  };

  const handleChat = (e: MouseEvent<HTMLElement>) => {
    e.preventDefault();
    e.stopPropagation();
    onChat && onChat(id, { acceptance_status: "accepted" });
  };

  const handleClick = (e: MouseEvent<HTMLElement>) => {
    e.preventDefault();
    e.stopPropagation();
    onClick && onClick(row.id);
  };

  const handleMouseOver = (e: MouseEvent<HTMLElement>) => {
    e.preventDefault();
    setShowActions(true);
  };

  const handleMouseLeave = (e: MouseEvent<HTMLElement>) => {
    e.preventDefault();
    setShowActions(false);
  };

  const handleReject = (e: MouseEvent<HTMLElement>) => {
    e.preventDefault();
    e.stopPropagation();
    onReject && onReject(id, { application_status: "rejected" });
  };

  const handleRetrieve = (e: MouseEvent<HTMLElement>) => {
    e.preventDefault();
    e.stopPropagation();
    onRetrieve && onRetrieve(id, { application_status: "applied" });
  };

  const handleSave = (e: MouseEvent<HTMLElement>) => {
    e.preventDefault();
    e.stopPropagation();
    onSave && onSave(id, row.is_bookmarked);
  };

  return (
    <TableRowContainer
      onClick={handleClick}
      onMouseOver={handleMouseOver}
      onMouseLeave={handleMouseLeave}
    >
      <TableColumn>
        <Stack alignItems="center" direction="row">
          <TableAvatar src={row.avatar} />
          <Typography variant="body2" noWrap>
            {`${row.first_name} ${row.last_name}`}
          </Typography>
        </Stack>
      </TableColumn>
      <TableColumn>
        <Typography variant="body2" noWrap>
          {row.designation}
        </Typography>
      </TableColumn>
      <TableColumn>
        <Typography variant="body2" noWrap>
          {row.location}
        </Typography>
      </TableColumn>
      <TableColumn>
        <Typography variant="body2">{row.experience} Years</Typography>
      </TableColumn>
      <TableActionContainer>
        {/* Note: redundantly compare showActions for readability */}
        {onAccept && (
          <Button
            color="primary"
            disabled={disabled}
            fullWidth
            onClick={handleAccept}
            size="small"
            startIcon={<CheckCircle />}
            variant="contained"
          >
            Accept
          </Button>
        )}

        {onReject && (
          <Button
            disabled={disabled}
            fullWidth
            onClick={handleReject}
            size="small"
            startIcon={<Cancel />}
            variant="outlined"
          >
            Reject
          </Button>
        )}

        {onRetrieve && (
          <Button
            disabled={disabled}
            color="primary"
            fullWidth
            onClick={handleRetrieve}
            size="small"
            startIcon={<QuestionAnswer />}
            variant="contained"
          >
            Retrive row
          </Button>
        )}

        {onChat && (
          <Button
            disabled={disabled}
            color="primary"
            fullWidth
            onClick={handleChat}
            size="small"
            startIcon={<QuestionAnswer />}
            variant="contained"
          >
            Chat
          </Button>
        )}

        {onSave && (
          <Button
            disabled={disabled}
            fullWidth
            onClick={handleSave}
            size="small"
            startIcon={row?.is_bookmarked ? <BookmarkBorder /> : <Bookmark />}
            variant="outlined"
          >
            {row?.is_bookmarked ? "Unsave" : "Save"}
          </Button>
        )}
      </TableActionContainer>
    </TableRowContainer>
  );
};
