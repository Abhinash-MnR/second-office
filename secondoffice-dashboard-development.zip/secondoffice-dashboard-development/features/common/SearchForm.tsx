// React, Next packages
import React, { FC } from "react";
import { Form, Field } from "react-final-form";
// Mui packages
import { Button, Stack } from "@mui/material";
// Custom packages
import { CloseIcon } from "@common/Icon";
import { SearchTextField } from "@common/FormField";

export type SearchFormProps = {
  /** Callback triggered when data is submitted */
  onSubmit: (...params: any) => void;
  /** Label in the input to provide hints for users */
  placeholder?: string;
};

export const SearchForm: FC<SearchFormProps> = (props: SearchFormProps) => {
  /** props */
  const { placeholder, onSubmit } = props;

  return (
    <Form onSubmit={onSubmit}>
      {({ handleSubmit }) => (
        <form onSubmit={handleSubmit}>
          <Stack
            direction="row"
            spacing={2}
            width="100%"
            sx={{
              "& div:first-of-type": {
                flex: 8.5,
              },
              "& button:last-child": {
                flex: 1.4,
              },
            }}
          >
            <Field
              component={SearchTextField}
              InputProps={{
                endAdornment: <CloseIcon sx={{ color: "#878787" }} />,
              }}
              placeholder={placeholder}
              fullWidth
              name="search"
              size="small"
            />
            {/* <Button color="primary" size="large" variant="contained">
              Search
            </Button> */}
          </Stack>
        </form>
      )}
    </Form>
  );
};
