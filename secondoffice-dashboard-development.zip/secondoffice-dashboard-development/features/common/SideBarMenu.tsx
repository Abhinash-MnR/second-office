// React, Next packages
import React from "react";
// Mui packages
import { List } from "@mui/material";
// Third party packages
import { useTranslation } from "react-i18next";
import "translation/i18n";
// Custom packages
import {
  AddUser,
  AddMultiUser,
  ChartIcon,
  PaperIcon,
  ChartIconColor,
  AddUserColor,
  AddMultiUserColor,
  PaperIconColor,
  Store,
  StoreWhite,
  Settings,
  SettingsWhite,
  HelpCenter,
  HelpCenterColor,
  AttendanceColor,
} from "@common/Icon";
import SideMenuList from "./SideMenuList";
import SideBarDropdownMenu from "./SideBarDropdownMenu";
import useCompany from "@lib/useCompany";

const drawerMenu = [
  {
    label: "Dashboard",
    icon: <ChartIcon />,
    iconColor: <ChartIconColor />,
    value: "/dashboard",
    path: "/dashboard",
  },
  {
    label: "Recruit",
    icon: <AddUser />,
    iconColor: <AddUserColor />,
    value: "/applications",
    path: "/applications",
  },
  {
    label: "Office Management",
    icon: <AddMultiUser />,
    iconColor: <AddMultiUserColor />,
    value: "/officeManagement",
    path: "/officeManagement",
  },
  {
    label: "Store",
    icon: <StoreWhite />,
    iconColor: <Store />,
    value: "/store",
    path: "/store",
  },
  {
    label: "Office Expenses",
    icon: <PaperIcon />,
    iconColor: <PaperIconColor />,
    value: "/expenses",
    path: "/expenses",
  },
  {
    label: "Settings",
    icon: <SettingsWhite />,
    iconColor: <Settings />,
    value: "/settings",
    path: "/settings",
  },
];

function SideBarMenu() {
  const { company } = useCompany();
  //** Language translation hooks */
  const { t } = useTranslation();

  return (
    <List>
      <SideMenuList
        menuLable={t("dashboard_menu_title")}
        path={
          company && company.onboarding_complete === "true"
            ? "/disabled"
            : "/dashboard"
        }
        iconColor={<ChartIconColor />}
        icon={<ChartIcon />}
      />
      <SideMenuList
        menuLable={t("recruit_menu_title")}
        path="/applications"
        iconColor={<AddUserColor />}
        icon={<AddUser />}
      />
      {/* DropDown Menu */}
      <SideBarDropdownMenu />

      {/* TODO - delete after tech audit */}
      <SideMenuList
        menuLable={t("task_management_menu")}
        path="https://meta.secondoffice.co"
        iconColor={<AttendanceColor />}
        icon={<AttendanceColor />}
        newTab
      />

      <SideMenuList
        menuLable={t("store")}
        path="/store"
        iconColor={<Store />}
        icon={<StoreWhite />}
      />
      <SideMenuList
        menuLable={t("office_expense_menu")}
        path="/expenses"
        iconColor={<PaperIconColor />}
        icon={<PaperIcon />}
      />
      <SideMenuList
        menuLable={t("settings")}
        path="/settings"
        iconColor={<Settings />}
        icon={<SettingsWhite />}
      />
      <SideMenuList
        menuLable={t("help_center")}
        path="/help_center"
        iconColor={<HelpCenterColor />}
        icon={<HelpCenter />}
      />
    </List>
  );
}

export default SideBarMenu;
