// React, Next packages
import React, { FC } from "react";
// Mui packages
import { styled } from "@mui/material";
// Custom packages
import { User } from "types/UserType";
import { TableRow } from "@common/TableRow";

type TableProps = {
  /** If exists, it indicates the application status of the rows */
  applicationStatus?: string;
  /** Callback triggered on click of the `Accept` button */
  onAccept?: (...params: any) => void;
  /** Callback triggered on click of the `Chat` button */
  onChat?: (...params: any) => void;
  /** Callback triggered on click of the `Reject` button */
  onReject?: (...params: any) => void;
  /** Callback triggered on click of the `Retrieve` button */
  onRetrieve?: (...params: any) => void;
  /** Callback triggered on click of the `Save` button */
  onSave?: (...params: any) => void;
  /** Callback triggered on click of the row */
  onClick?: (...params: any) => void;
  /** Table data source */
  rows?: Array<User>;
};

const TableContainer = styled("table")({
  borderCollapse: "collapse",
  width: "100%",
});

const TableHead = styled("thead")(({ theme }) => ({
  color: theme.palette.grey[500],
  borderBottom: "3px solid #DDDDDD",
  "& tr th": {
    padding: 10,
    textAlign: "center",
    ...theme.typography.subtitle1,
  },
}));

const TableBody = styled("tbody")({
  "& tr:nth-of-type(even)": {
    backgroundColor: "#F3F5F9",
  },
});

export const Table: FC<TableProps> = (props) => {
  /** third-party hooks */

  /** props */
  const {
    applicationStatus,
    onAccept,
    onChat,
    onClick,
    onReject,
    onRetrieve,
    onSave,
    rows,
  } = props;

  /** custom handlers */
  const renderRow = (row: any) => {
    return (
      <TableRow
        key={row.id}
        id={row.id}
        // Applications are mapped with owner key
        disabled={
          applicationStatus &&
          row.owner &&
          applicationStatus !== row.application_status
        }
        // Applications are mapped with owner key
        row={row.owner ? row.owner : row}
        onAccept={onAccept}
        onChat={onChat}
        onClick={onClick}
        onReject={onReject}
        onRetrieve={onRetrieve}
        onSave={onSave}
      />
    );
  };

  return (
    <TableContainer>
      <TableHead>
        <tr>
          <th>Candidate</th>
          <th>Domain of Expertise</th>
          <th>Location</th>
          <th>Experience</th>
        </tr>
      </TableHead>
      <TableBody>{rows && rows.map(renderRow)}</TableBody>
    </TableContainer>
  );
};
