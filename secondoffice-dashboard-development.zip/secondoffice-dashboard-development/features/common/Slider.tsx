// React, Next packages
import React, { FC, ReactNode } from "react";
import Image from "next/image";

// Mui packages
import { styled } from "@mui/material/styles";
import { Grid, Box } from "@mui/material";
// Third-party packages
import Slider from "react-slick";
import "slick-carousel/slick/slick.css";
import "slick-carousel/slick/slick-theme.css";
import sliderData from "../../data/sliderData";

type SliderProps = {
  /** Form title */
  title: string;
};

const SectionContainer = styled("div")(({ theme }) => ({
  display: "flex",
  justifyContent: "center",
  alignItems: "center",
  minHeight: "88vh",
  [theme.breakpoints.down("sm")]: {
    width: "100%",
    display: "none",
  },
}));

const SliderWrapper = styled("div")(({ theme }) => ({
  width: "100%",
  // height: 584,
  background: "#fff",
  padding: "0px 36px 36px ",
  borderRadius: 10,
  [theme.breakpoints.down("sm")]: {
    display: "flex",
    flexDiraction: "column",
    maxWidth: "600px",
    padding: 20,
  },
}));

const SliderContainer = styled("div")(({ theme }) => ({
  display: "flex",
  justifyContent: "center",
  alignItems: "center",
  // padding: "0px 36px",
  [theme.breakpoints.down("sm")]: {
    display: "flex",
    flexDirection: "column",
    alignItem: "center",
    justifyContent: "center",
  },
}));

export const SliderSection: FC<SliderProps> = (props: SliderProps) => {
  /** props */
  const { title } = props;

  const settings = {
    dots: true,
    arrows: false,
    infinite: true,
    speed: 1000,
    slidesToShow: 1,
    slidesToScroll: 1,
    autoplay: true,
    dotsClass: "slick-dots",
  };

  return (
    <SectionContainer>
      <SliderWrapper>
        <Slider {...settings}>
          {sliderData.map((sliderItem, index) => (
            <div key={index}>
              <SliderContainer>
                <Image
                  src={sliderItem.img_url}
                  alt="sliderImage"
                  width="422px"
                  height="550px"
                />
              </SliderContainer>
            </div>
          ))}
        </Slider>
      </SliderWrapper>
    </SectionContainer>
  );
};
