// React, Next packages
import React, { FC, MouseEvent, useState } from "react";
import { useRouter } from "next/router";
// Mui packages
import {
  Badge,
  IconButton,
  LinearProgress,
  Popover,
  Stack,
  styled,
  Typography,
} from "@mui/material";
// Third-party packages
import InfiniteScroll from "react-infinite-scroll-component";
import useSWRInfinite from "swr/infinite";

// Custom packages
import { ApiHandler } from "@lib/api-handler";
// import useUser from "@lib/useUser";
import { NotificationIcon } from "@common/Icon";
import { Notification } from "features/notifications/Notification";

const PopoverPaper = styled(Popover)(({ theme }) => ({
  ["& .MuiPopover-paper"]: {
    background: theme.palette.background.paper,
    borderRadius: theme.shape.borderRadius,
    boxShadow: "4px 4px 16px rgba(181, 181, 181, 0.3)",
    display: "flex",
    flexDirection: "column",
    minWidth: 300,
    maxWidth: 320,
    maxHeight: "calc(90vh - 100px)",
    top: `calc(${theme.mixins.toolbar.minHeight}px + 5px) !important`,

    [theme.breakpoints.up("sm")]: {
      top: `calc(${theme.mixins.toolbar.minHeight}px + 15px) !important`,
      maxWidth: 600,
    },
  },
}));

const handler = new ApiHandler({
  context: undefined,
});

const getKey = (pageIndex, previousPageData) => {
  // reached the end
  if (previousPageData && !previousPageData.results) return null;

  // first page, we don't have `previousPageData`
  if (pageIndex === 0) return `/companies/company/notifications/?page=1`;

  // add the cursor to the API endpoint
  return `/companies/company/notifications/?page=${previousPageData.next}`;
};

const getThumbnail = (notification) => {
  if (notification.sender_company) {
    return notification.sender_company.profile_image;
  } else if (notification.sender) {
    return notification.sender.user_profile.profile_image;
  } else if (notification.image) {
    return notification.image;
  } else {
    return "/svgs/warning.svg";
  }
};

const getCount = (data) => {
  let count = 0;

  if (!data) return count;

  for (let i = 0; i < data.length; i++) {
    count += data[i].results.length;
  }

  return count;
};

async function fetcher(url: string) {
  const response = await handler.get(url);
  return response.data;
}

const PAGE_SIZE = 16;

export const NotificationMenu: FC = () => {
  /** custom hooks */
  const router = useRouter();
  // const { user, mutateUser } = useUser();
  const { data, error, isValidating, mutate, size, setSize } = useSWRInfinite(
    getKey,
    fetcher
  );

  /** component variables */
  const notificationCount = getCount(data);
  const notifications = data ? [].concat(...data) : [];
  const isEmpty = data?.[0]?.length === 0;
  const isReachingEnd =
    isEmpty || (data && data[data.length - 1]?.results?.length < PAGE_SIZE);

  /** useState hooks */
  const [anchorEl, setAnchorEl] = useState<HTMLButtonElement | null>(null);

  /** custom handlers */

  const handleClick = (event: MouseEvent<HTMLButtonElement>) => {
    setAnchorEl(event.currentTarget);
  };

  const handleClose = () => {
    setAnchorEl(null);
  };

  const handlePaginate = () => {
    console.log("set next");
  };

  console.log(notificationCount);

  const open = Boolean(anchorEl);

  return (
    <>
      <IconButton onClick={handleClick}>
        <Badge>
          <NotificationIcon />
        </Badge>
      </IconButton>
      <PopoverPaper
        anchorEl={anchorEl}
        anchorOrigin={{
          vertical: "bottom",
          horizontal: "center",
        }}
        open={open}
        onClose={handleClose}
        transformOrigin={{
          vertical: "top",
          horizontal: "center",
        }}
      >
        {!data && !error && <LinearProgress />}
        {isEmpty && (
          <Stack padding={2} textAlign="center">
            <Typography variant="subtitle1">No Notifications</Typography>
            <Typography variant="body2">
              You have no notifications from the last 30 days.
            </Typography>
          </Stack>
        )}
        <InfiniteScroll
          dataLength={notificationCount}
          style={{ overflow: "hidden" }}
          next={handlePaginate}
          hasMore={!isReachingEnd}
          loader={<LinearProgress sx={{ width: "100%", marginY: 2 }} />}
        >
          {data &&
            data.map((notifications, index) => {
              // `data` is an array of each page's API response.
              return notifications.results.map((notification) => (
                <Notification
                  key={notification.id}
                  createdAt={notification.created_at}
                  isRead={notification.is_read}
                  message={notification.description}
                  notificationId={notification.id}
                  // onClick={handleClickNotification}
                  thumbnail={getThumbnail(notification)}
                />
              ));
            })}
        </InfiniteScroll>
      </PopoverPaper>
    </>
  );
};
