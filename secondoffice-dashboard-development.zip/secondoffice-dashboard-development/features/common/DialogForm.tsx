// React, Next packages
import React, { FC, ReactNode } from "react";
// Mui packages
import {
  Dialog,
  DialogActions,
  DialogContent,
  DialogTitle,
  IconButton,
  Stack,
  styled,
  Typography,
  useMediaQuery,
} from "@mui/material";
// Custom packages
import { CloseIcon } from "@common/Icon";

export type DialogFormProps = {
  /** Content of the DialogForm */
  children?: ReactNode;
  /** Footer content of the DialogForm */
  footer?: ReactNode;
  /** Should the form go fullscreen */
  fullScreen?: boolean;
  /** Max width of the dialog in desktop view */
  maxWidth?: "sm" | "md" | "lg";
  /** Callback fired when the component requests to be closed. */
  onClose: (data?: any) => void;
  /** If `true`, the Dialog is open. */
  open?: boolean;
  /** Subtitle placed below the title */
  subtitle?: string;
  /** Title of the DialogForm */
  title?: ReactNode;
  /** Team Employee Data of the DialogForm */
  teamResultData?:any;
};

const CloseButton = styled("div")(({ theme }) => ({
  position: "absolute",
  right: 12,
  top: 20,
  [theme.breakpoints.down("sm")]: {
    right: theme.spacing(1.02),
    top: theme.spacing(2.75),
  },
}));

export const DialogForm: FC<DialogFormProps> = (props: DialogFormProps) => {
  /** third-party hooks */
  const isMobile = useMediaQuery("(max-width:600px)");

  /** props */
  const {
    children,
    footer,
    fullScreen,
    maxWidth,
    onClose,
    open,
    subtitle,
    title,
  } = props;

  /** custom handlers */
  const handleClose = () => onClose();

  return (
    <Dialog
      // fullScreen={fullScreen && isMobile}
      open={!!open}
      onClose={handleClose}
      fullWidth
      maxWidth={maxWidth}
      sx={{ padding: "20px 0px" }}
    >
      <DialogTitle sx={{ padding: { xs: "20px 16px", sm: "20px" } }}>
        <Typography component="h3" variant="h3">
          {title}
        </Typography>
        <Typography component="p" variant="body1">
          {subtitle}
        </Typography>
        <CloseButton>
          <IconButton onClick={handleClose}>
            <CloseIcon />
          </IconButton>
        </CloseButton>
      </DialogTitle>
      <DialogContent sx={{ padding: { xs: "20px 20px" } }}>
        {/* {subtitle && (
          <Typography
            sx={{ marginBottom: 5 }}
            color="textSecondary"
            variant="h6"
          >
            {subtitle}
          </Typography>
        )} */}
        {children}
      </DialogContent>
      {footer && <DialogActions>{footer}</DialogActions>}
    </Dialog>
  );
};

DialogForm.defaultProps = {
  fullScreen: true,
  maxWidth: "sm",
};
