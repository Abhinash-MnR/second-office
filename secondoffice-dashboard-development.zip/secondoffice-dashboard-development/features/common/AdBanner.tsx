// React, Next packages
import React, { FC } from "react";
import Link from "next/link";
import { UrlObject } from "url";
// Mui packages
import { Avatar, styled } from "@mui/material";

type AdBannerProps = {
  /** Image of the banner */
  image?: string;
  /** Link redirected to when clicked */
  href: string | UrlObject;
};

const BannerImage = styled(Avatar)({
  width: "100%",
  height: "auto",
  maxHeight: 115,
  border: "1px solid #e5e5e5",
  marginBottom: "16px",
});

export const AdBanner: FC<AdBannerProps> = ({ image, href }: AdBannerProps) => {
  return (
    <Link href={href} passHref>
      {/* @ts-ignore - currently a typescript bug */}
      <BannerImage component="a" src={image} variant="square" />
    </Link>
  );
};
