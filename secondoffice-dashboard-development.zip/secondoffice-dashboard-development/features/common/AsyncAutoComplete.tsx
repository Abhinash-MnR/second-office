// React, Next packages
import React, { ChangeEvent, FC, Fragment, useEffect, useState } from "react";
// Mui packages
import {
  Autocomplete,
  CircularProgress,
  createFilterOptions,
  TextField,
  styled,
  Grid,
  Typography,
} from "@mui/material";
import { grey } from "@mui/material/colors";

// Third-party packages
import match from "autosuggest-highlight/match";
import parse from "autosuggest-highlight/parse";
import { ChevronDown } from "react-feather";
import debounce from "lodash/debounce";

type AsncAutoCompleteProps = {
  /** If `true`, indicate error on the form */
  error?: boolean;
  /** API function to fetch options */
  getOptions: (...params: any) => Promise<any>;
  /** Callback triggered when value changes */
  onChange: (event: ChangeEvent<{}>, value: any) => void;
  /** Callback triggered when menu closes */
  onClose?: (...params: any) => void;
  /** Callback triggered when menu opens */
  onOpen?: (...params: any) => void;
  /** What key should be used to map the options */
  optionsKey: string;
  /** Placeholder text displayed when no selection made */
  placeholder: string;
  /** If the form is required */
  required?: boolean;
  /** Currently selected item */
  value?: any;
  /** Select type variant to `outlied` or `default` */
  variant?: "standard" | "outlined";
};

const AutoCompleteTextField = styled(TextField)({
  color: grey[700],
});

export const AsyncAutoComplete: FC<AsncAutoCompleteProps> = (
  props: AsncAutoCompleteProps
) => {
  /** props */
  const {
    error,
    placeholder,
    getOptions,
    onClose,
    onChange,
    onOpen,
    optionsKey,
    required,
    value,
    variant,
    ...rest
  } = props;

  /** class variables */
  const optionKey = optionsKey;

  /** useState hooks */
  const [open, setOpen] = useState(false);
  const [loading, setLoading] = useState(false);
  const [options, setOptions] = useState([]);
  const [searchKeyword, setsearchKeyword] = useState("");

  /** useEffect hooks */

  useEffect(() => {
    (async () => {
      setLoading(true);
      let isValid = searchKeyword && searchKeyword.length > 1;
      const response = isValid && (await getOptions(searchKeyword));
      const responseData = response
        ? response.data.results
          ? response.data.results
          : response.data
        : [];
      setOptions(responseData);
      setLoading(false);
      return function cleanup() {};
    })();

    return;
  }, [searchKeyword]);

  /** custom handlers */
  const handleKeywordChange = debounce((e) => {
    e && e.target && setsearchKeyword(e.target.value);
  }, 300);

  const filterOptions = createFilterOptions({
    matchFrom: "start",
  });

  return (
    <Autocomplete
      {...rest}
      clearOnBlur
      filterOptions={filterOptions}
      isOptionEqualToValue={(option, value) => {
        return optionKey === "owner.email"
          ? option.owner.email === value.owner.email
          : option[optionKey] === value[optionKey];
      }}
      getOptionLabel={(option) => {
        return optionKey === "owner.email"
          ? option.owner.email
          : option[optionKey] || null || "";
      }}
      loading={loading}
      noOptionsText={
        <Typography
          sx={{ "& > b": { color: (theme) => theme.palette.primary.main } }}
        >
          <b>No Results.</b> Please try something else.
        </Typography>
      }
      open={open}
      onOpen={() => {
        setOpen(true);
        onOpen && onOpen();
      }}
      onClose={() => {
        setOpen(false);
        onClose && onClose();
      }}
      onChange={onChange}
      options={options}
      onInputChange={handleKeywordChange}
      popupIcon={<ChevronDown strokeWidth={1} />}
      renderInput={(params) => (
        <AutoCompleteTextField
          {...params}
          InputLabelProps={{
            sx: { color: grey[700] },
          }}
          InputProps={{
            ...params.InputProps,
            sx: {
              fontVariant: "outlined",
              color: grey[700],
              padding: "6.5px 4px",
            },

            endAdornment: (
              <Fragment>
                {loading ? (
                  <CircularProgress color="inherit" size={20} />
                ) : null}
                {params.InputProps.endAdornment}
              </Fragment>
            ),
          }}
          error={error}
          placeholder={placeholder}
          required={required}
          variant={variant}
        />
      )}
      size="small"
      renderOption={(props, option, { inputValue }) => {
        const matches = match(option.tag, inputValue);
        const parts = parse(option.tag, matches);
        return (
          <li {...props}>
            <div>
              {parts.map((part, index) => {
                return (
                  <Typography
                    key={index}
                    component="span"
                    color={part.highlight ? "primary" : "inherit"}
                    fontWeight={part.highlight ? "bold" : "normal"}
                  >
                    {part.text}
                  </Typography>
                );
              })}
            </div>
          </li>
        );
      }}
      value={value}
    />
  );
};

AsyncAutoComplete.defaultProps = {
  variant: "standard",
};
