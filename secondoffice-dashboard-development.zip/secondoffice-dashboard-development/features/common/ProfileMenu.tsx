// React, Next packages
import React, { FC, MouseEvent, useState } from "react";
import Link from "next/link";
import { useRouter } from "next/router";
// Mui packages
import {
  Avatar,
  ButtonBase,
  Divider,
  Popover,
  Skeleton,
  Stack,
  styled,
  Typography,
} from "@mui/material";
// Custom packages
// import useUser from "@lib/useUser";
import { ChevronDownIcon } from "@common/Icon";

const PopoverPaper = styled(Popover)(({ theme }) => ({
  ["& .MuiPopover-paper"]: {
    background: theme.palette.background.paper,
    borderRadius: theme.shape.borderRadius,
    boxShadow: "4px 4px 16px rgba(181, 181, 181, 0.3)",
    display: "flex",
    flexDirection: "column",
    minWidth: 225,
    top: `calc(${theme.mixins.toolbar.minHeight}px + 5px) !important`,

    [theme.breakpoints.up("sm")]: {
      top: `calc(${theme.mixins.toolbar.minHeight}px + 15px) !important`,
    },
  },
}));

const subdomain = process.env.ENVIRONMENT === "production" ? "" : "dev.";

export const ProfileMenu: FC = () => {
  /** custom hooks */
  const router = useRouter();
  // const { user, mutateUser } = useUser();

  /** useState hooks */
  const [anchorEl, setAnchorEl] = useState<HTMLButtonElement | null>(null);

  const handleClick = (event: MouseEvent<HTMLButtonElement>) => {
    setAnchorEl(event.currentTarget);
  };

  const handleClose = () => {
    setAnchorEl(null);
  };

  const open = Boolean(anchorEl);

  return (
    <>
      <ButtonBase onClick={handleClick} sx={{ padding: 0.625 }}>
        <Stack alignItems="center" direction="row" spacing={1.25}>
          <Avatar
            // src={user?.avatar}
            sx={{ width: 32, height: 32, marginRight: 0.625 }}
          />
          <Typography
            color="primary"
            display={{ xs: "none", lg: "inherit" }}
            fontWeight="500"
            variant="body2"
          >
            {/* Welcome, {user ? user.first_name : "..."} */}
          </Typography>
          <ChevronDownIcon
            color="primary"
            fontSize="small"
            sx={{ display: { xs: "none", lg: "inherit" } }}
          />
        </Stack>
      </ButtonBase>
      <PopoverPaper
        anchorEl={anchorEl}
        anchorOrigin={{
          vertical: "bottom",
          horizontal: "center",
        }}
        open={open}
        onClose={handleClose}
        transformOrigin={{
          vertical: "top",
          horizontal: "center",
        }}
      >
        <Link
          href={`https://${subdomain}accounts.careerchat.me/profile?section=personal`}
          passHref
        >
          <ButtonBase
            component="a"
            sx={{ justifyContent: "flex-start", padding: 2, textAlign: "left" }}
          >
            <Avatar
              // src={user?.avatar}
              sx={{ width: 45, height: 45, marginRight: 2 }}
            />
            <div>
              <Typography color="grey.600" variant="subtitle2">
                {/* {user ? `${user?.first_name} ${user.last_name}` : <Skeleton />} */}
              </Typography>
              <Typography color="grey.500" variant="body2">
                Go to Account
              </Typography>
            </div>
          </ButtonBase>
        </Link>
        <Divider />
        <Link
          href="https://www.notion.so/Privacy-Policy-bda5612676794b24866f3ced0bae937b"
          passHref
        >
          <Typography
            component="a"
            color="inherit"
            rel="noopener noreferrer"
            target="_blank"
            variant="body2"
            paddingX={2}
            marginTop={2}
          >
            Privacy Policy
          </Typography>
        </Link>
        <Link href="https://forms.gle/tCNzfZyFmWFq1aWf9" passHref>
          <Typography
            component="a"
            color="inherit"
            rel="noopener noreferrer"
            target="_blank"
            variant="body2"
            paddingX={2}
            marginTop={2}
          >
            Help Center
          </Typography>
        </Link>
        <Link href="/logout" passHref>
          <Typography
            component="a"
            color="inherit"
            variant="body2"
            paddingX={2}
            marginY={2}
          >
            Log Out
          </Typography>
        </Link>
      </PopoverPaper>
    </>
  );
};
