// React, Next packages
import React, { useState } from "react";
import Link from "next/link";

import { useRouter } from "next/router";
// Mui packages
import {
  List,
  ListItemButton,
  ListItemIcon,
  ListItemText,
  Typography,
} from "@mui/material";

function SideMenuList(props: any) {
  //  Router Hooks
  const router = useRouter();

  /** props desctructring */
  const { menuLable, path, icon, iconColor, newTab } = props;

  return (
    <Link href={path} passHref>
      <ListItemButton
        component="a"
        disableRipple
        target={newTab ? "_blank" : "_self"}
        selected={router.pathname.includes(path)}
      >
        {router.pathname.includes(path) ? (
          <ListItemIcon>{icon}</ListItemIcon>
        ) : (
          <ListItemIcon>{iconColor}</ListItemIcon>
        )}
        <ListItemText>
          <Typography
            component="p"
            variant="body2"
            sx={
              router.pathname.includes(path)
                ? { fontWeight: 700, color: "white" }
                : { fontWeight: 400, color: "#4d4d4d" }
            }
          >
            {menuLable}
          </Typography>
        </ListItemText>
      </ListItemButton>
    </Link>
  );
}

export default SideMenuList;
