// React packages
import React, { FC, ReactNode } from "react";
// Mui packages
import { Button, Typography } from "@mui/material";
// Third-party packages
import parse from "html-react-parser";
// Custom packages
import { DialogForm, DialogFormProps } from "@common/DialogForm";

export type AlertDialogProps = {
  /** Dialog content */
  description: string;
  /** Confirm button icon */
  buttonIcon?: ReactNode;
  /** Primary confirm button label */
  buttonLabel?: string;
  /** Callback trigerred when primary confirm button is clicked */
  onConfirm?: () => void;
} & DialogFormProps;

const AlertDialog: FC<AlertDialogProps> = (props: AlertDialogProps) => {
  /** third-party hooks */

  /** props */
  const {
    open,
    title,
    description,
    onClose,
    onConfirm,
    buttonLabel,
    buttonIcon,
  } = props;

  return (
    <DialogForm open={open} onClose={onClose} title={title}>
      <Typography style={{ fontSize: 18 }} color="textSecondary">
        {parse(description as string)}
      </Typography>

      <Button
        color="primary"
        data-cy="alert-dialog-primary"
        style={{ marginTop: 30 }}
        fullWidth
        onClick={onConfirm}
        variant="contained"
        startIcon={buttonIcon}
      >
        {buttonLabel}
      </Button>
    </DialogForm>
  );
};

AlertDialog.defaultProps = {
  buttonLabel: "Confirm",
};

export default AlertDialog;
