// React, Next packages
import React, { FC, useEffect, useState } from "react";
// Mui packages
import {
  Button,
  ButtonProps,
  InputBase,
  styled,
  Typography,
} from "@mui/material";
// Third-party packages
import { useSnackbar } from "notistack";
import { CheckSquare, Copy, Link2 } from "react-feather";
// Custom packages
import { DialogForm, DialogFormProps } from "@common/DialogForm";

export type ShareDialogProps = {
  /** Label of the input */
  label: string;
  /** Link to be copied */
  link: string;
} & DialogFormProps;

const DialogContentContainer = styled("div")(({ theme }) => ({
  alignItems: "center",
  display: "flex",
  border: "1px solid #E5E5E5",
  borderRadius: 8,
  paddingLeft: theme.spacing(2),
  marginTop: theme.spacing(2),
  marginBottom: theme.spacing(2),
}));

const ShareFormInput = styled(InputBase)(({ theme }) => ({
  marginLeft: theme.spacing(1),
  marginRight: theme.spacing(1),
  flex: 1,
}));

interface ShareButtonProps extends ButtonProps {
  copied?: boolean;
}

const ShareButton = styled(Button, {
  shouldForwardProp: (prop) => prop !== "copied",
})<ShareButtonProps>(({ copied, theme }) => ({
  borderRadius: 0,
  borderTopRightRadius: 8,
  borderBottomRightRadius: 8,
  ...(copied && {
    backgroundColor: "#2ECE34",
    "&:hover": {
      backgroundColor: "#238e27",
    },
  }),
}));

export const ShareDialog: FC<ShareDialogProps> = (props: ShareDialogProps) => {
  /** third-party hooks */
  const { enqueueSnackbar } = useSnackbar();

  /** props */
  const { open, onClose, title, label, link } = props;

  /** useState hooks */
  const [copied, setCopied] = useState(false);

  useEffect(() => {
    setCopied(false);
  }, [open]);

  const onCopyLink = () => {
    let copyText = document.getElementById("clipboardArea");
    // @ts-ignore
    copyText.value = encodeURI(copyText.value);
    // @ts-ignore
    copyText.select();
    // @ts-ignore
    copyText.setSelectionRange(0, 99999);
    document.execCommand("copy");

    enqueueSnackbar("URL Copied!", { variant: "success" });

    setCopied(true);
  };

  return (
    <DialogForm fullScreen={false} open={open} onClose={onClose} title={title}>
      <Typography variant="h5">{label}</Typography>
      <DialogContentContainer>
        <Link2 />
        <ShareFormInput id="clipboardArea" value={link} readOnly />
        <ShareButton
          color="primary"
          variant="contained"
          onClick={onCopyLink}
          startIcon={copied ? <CheckSquare /> : <Copy />}
        >
          {copied ? "Copied" : "Copy"}
        </ShareButton>
      </DialogContentContainer>
    </DialogForm>
  );
};
