// React, Next packages
import React, { FC } from "react";
import Link from "next/link";
// Mui packages
import { Box, Container, Grid, Stack, Typography } from "@mui/material";
// Custom packages
import {
  FacebookIcon,
  InstagramIcon,
  TwitterIcon,
  YoutubeIcon,
} from "@common/Icon";

type FooterProps = {};

const subdomain = process.env.ENVIRONMENT === "production" ? "" : "dev.";

const services = [
  {
    path: `https://${subdomain}accounts.careerchat.me`,
    name: "Accounts",
  },
  {
    path: `https://${subdomain}jobs.careerchat.me`,
    name: "Jobs",
  },
  {
    path: `https://${subdomain}recruiters.careerchat.me`,
    name: "Recruiters",
  },
  {
    path: `https://${subdomain}forum.careerchat.me`,
    name: "Forum",
  },
  {
    path: `https://${subdomain}rexpert.careerchat.me`,
    name: "Rexpert",
  },
  {
    path: `https://${subdomain}connect.careerchat.me`,
    name: "Connect",
  },
  {
    path: "https://dev.uplift.careerchat.me",
    name: "Uplift",
  },
];

export const Footer: FC<FooterProps> = ({}: FooterProps) => {
  /** custom handlers */
  const renderService = (service) => (
    <Link href={service.path} key={service.name}>
      <a rel="noreferrer noopener" target="_blank">
        <Typography color="grey.600" marginBottom={2} variant="body2">
          {service.name}
        </Typography>
      </a>
    </Link>
  );

  return (
    <Box bottom={0} paddingTop={12.5} paddingBottom={7.5} component="footer">
      <Container>
        <Grid container spacing={2}>
          {/* Footer 1st column */}
          <Grid item xs={12} sm={6} lg={3}>
            <img style={{ marginLeft: -8 }} src="/svg/logo.svg" />
            <Typography marginTop={3}>CareerChat | Recruiters</Typography>
          </Grid>

          {/* Footer 2nd column */}
          <Grid item xs={12} sm={6} lg={2}>
            <Typography
              component="div"
              variant="button"
              marginTop={1.25}
              marginBottom={2}
            >
              Services
            </Typography>
            {services.map(renderService)}
          </Grid>

          {/* Footer 2nd column */}
          <Grid item xs={12} sm={6} lg={2}>
            <Typography
              component="div"
              variant="button"
              marginTop={1.25}
              marginBottom={2}
            >
              Company
            </Typography>
            <Typography color="grey.600" variant="body2" marginBottom={2}>
              McKinley &amp; Rice
            </Typography>
            <Typography color="grey.600" variant="body2" marginBottom={2}>
              SecondOffice
            </Typography>
            <Typography color="grey.600" variant="body2" marginBottom={2}>
              Blog
            </Typography>
            <Typography color="grey.600" variant="body2" marginBottom={2}>
              Careers
            </Typography>
          </Grid>

          {/* Footer 3rd column */}
          <Grid item xs={12} sm={6} lg={2}>
            <Typography
              component="div"
              variant="button"
              marginTop={1.25}
              marginBottom={2}
            >
              Support
            </Typography>
            <Typography color="grey.600" variant="body2" marginBottom={2}>
              Privacy Policy
            </Typography>
            <Typography color="grey.600" variant="body2" marginBottom={2}>
              Terms &amp; Conditions
            </Typography>
            <Typography color="grey.600" variant="body2" marginBottom={2}>
              Help Center
            </Typography>
          </Grid>

          {/* Footer 4th column */}
          <Grid item xs={6} lg={2}>
            <Typography
              component="div"
              variant="button"
              marginTop={1.25}
              marginBottom={2}
            >
              Social Media
            </Typography>
            <Stack
              alignItems="center"
              direction="row"
              justifyContent="space-between"
            >
              <Link href="https://www.facebook.com/CareerChat.2020/">
                <a rel="noreferrer noopener" target="_blank">
                  <FacebookIcon htmlColor="black" />
                </a>
              </Link>
              <Link href="https://www.instagram.com/career_chat/">
                <a>
                  <InstagramIcon htmlColor="black" />
                </a>
              </Link>
              <Link href="https://www.youtube.com/channel/UCybgiy9tNNDlIWgBECgawKQ">
                <a rel="noreferrer noopener" target="_blank">
                  <YoutubeIcon fill="white" />
                </a>
              </Link>
              <Link href="https://twitter.com/mckinleyandrice">
                <a rel="noreferrer noopener" target="_blank">
                  <TwitterIcon fill="white" />
                </a>
              </Link>
            </Stack>
          </Grid>
        </Grid>
      </Container>
    </Box>
  );
};

Footer.defaultProps = {};
