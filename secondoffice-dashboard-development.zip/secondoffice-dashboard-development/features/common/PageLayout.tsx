// React, Next packages
import React from "react";
import Head from "next/head";
// Mui packages
import { Grid, Hidden, Box, useMediaQuery } from "@mui/material";
import { SliderSection } from "@common/Slider";

function PageLayout(props: any) {
  // props destructing
  const {
    LoginComponent,
    SignUpComponent,
    ForgotPassComponent,
    ResetPassComponent,
  } = props;
  const isMobile = useMediaQuery("(max-width:600px)");
  return (
    <Grid container spacing={isMobile ? 0 : 2}>
      <Grid
        item
        sm={4}
        xs={12}
        sx={{
          display: { xs: "block", sm: "block" },
          minHeight: { xs: "10vh", sm: "100vh" },
        }}
      >
        <Box
          style={{
            background: "#fff",
            // height: `${isMobile ? "80px" : "100vh"}`,
            minHeight: `${isMobile ? "10vh" : "100vh"}`,
            // padding: `${isMobile ? "30px 20px" : "30px 41px"}`,
            width: "100%",
          }}
        >
          <Box
            sx={{
              display: "flex",
              flexDirection: "column",
              padding: `${isMobile ? "30px 20px" : "36px 36px 0px"}`,
            }}
          >
            <img
              src="/svg/logo.svg"
              style={{ width: "167px", height: "auto" }}
            />
          </Box>
          <SliderSection title="Login" />
        </Box>
      </Grid>

      <Grid
        item
        sm={8}
        xs={12}
        sx={{
          alignItems: "center",
          justifyContent: "center",
          display: "flex",
        }}
      >
        {LoginComponent}
        {SignUpComponent}
        {ForgotPassComponent}
        {ResetPassComponent}
      </Grid>
    </Grid>
  );
}

export default PageLayout;
