// React, Next packages
import React, { FC } from "react";
import Link from "next/link";
// Mui packages
import { styled, Typography } from "@mui/material";
// Third-party packages
import { ParsedUrlQueryInput } from "querystring";

type Tab = {
  /** Label of the tab */
  label: string;
  /** Shallow URL to be redirected on click */
  path: string;
  /** Query for path */
  query?: string | ParsedUrlQueryInput;
  /** Unique value of the tab */
  value: string;
};

type TabsProps = {
  /** Array of tabs */
  tabs: Array<Tab>;
  /** Currently selected tab value */
  value: string;
};

const TabContainer = styled("div")({
  display: "inline-flex",
  marginBottom: 30,
  width: "100%",
});

export const Tabs: FC<TabsProps> = (props) => {
  const { tabs, value } = props;

  return (
    <TabContainer>
      {tabs &&
        tabs.map((tab) => (
          <Link
            href={{ pathname: tab.path, query: tab.query }}
            passHref
            shallow
            key={tab.value}
          >
            <Typography
              color={tab.value === value ? "primary" : "grey.500"}
              component="a"
              fontWeight={tab.value === value ? "700" : "400"}
              marginRight={3.75}
              variant="subtitle1"
            >
              {tab.label}
            </Typography>
          </Link>
        ))}
    </TabContainer>
  );
};
