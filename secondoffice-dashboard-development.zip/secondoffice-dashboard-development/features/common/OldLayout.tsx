// React, Next packages
import React, { FC, ReactNode, useState } from "react";
import Link from "next/link";
import Head from "next/head";
import dynamic from "next/dynamic";
import { useRouter } from "next/router";
// Mui packages
import {
  AppBar,
  Avatar,
  Container,
  Drawer,
  Hidden,
  IconButton,
  List,
  ListItemButton,
  ListItemIcon,
  ListItemText,
  Stack,
  styled,
  Toolbar,
  Typography,
  useMediaQuery,
} from "@mui/material";
// Custom packages
import {
  AddUser,
  AddMultiUser,
  ChartIcon,
  MenuIcon,
  PaperIcon,
} from "@common/Icon";
import useCompany from "@lib/useCompany";

export type LayoutProps = {
  /** Main content of the layout */
  children: ReactNode;
  /** Callback triggered when the page CTA button is clicked  */
  ctaCallback?: (...pararms: any) => void;
  /** CTA button title */
  ctaTitle?: string;
  /** Callback triggered when chip is clicke */
  onChange?: (event: any, value: any) => void;
  /** Title of the page to be crawled via OG */
  ogTitle?: string;
  /** Description of the page to be craweld via OG */
  ogDescription?: string;
  /** Image of the page to be crawled via OG */
  ogImage?: string;
  /** Title of the page */
  pageTitle?: string | ReactNode;
  /** Current value of the chip group form */
  value?: string;
  /**Company Name of The Login User */
  companyName?: string | ReactNode;
};

const drawerMenu = [
  {
    label: "Dashboard",
    icon: <ChartIcon />,
    value: "/dashboard",
    path: "/dashboard",
  },
  {
    label: "Recruit",
    icon: <AddUser />,
    value: "/applications",
    path: "/applications",
  },
  {
    label: "Office Management",
    icon: <AddMultiUser />,
    value: "/officeManagement",
    path: "/officeManagement",
  },
  {
    label: "Office Expenses",
    icon: <PaperIcon />,
    value: "/expenses",
    path: "/expenses",
  },
];

const drawerWidth = 280;

const DrawerContainer = styled("nav")(({ theme }) => ({
  [theme.breakpoints.up("lg")]: {
    width: drawerWidth,
    flexShrink: 0,
  },
}));

const DrawerPaper = styled(Drawer)(({ theme }) => ({
  ["& .MuiDrawer-paper"]: {
    background: "#2c3058",
    borderRight: "none",
    width: drawerWidth,
  },
}));

const ImageContainer = styled("div")(({ theme }) => ({
  display: "flex",
  flexDirection: "column",
  border: "1px solid #D5D6DE",
  borderRadius: "50%",
  cursor: "pointer",
}));

export const OldLayout: FC<LayoutProps> = (props: LayoutProps) => {
  /** third-party hooks */
  const [mobileOpen, setMobileOpen] = useState(false);
  const { company, isLoading, isError } = useCompany();
  // const { user } = useUser();
  const router = useRouter();

  /** props */
  const {
    children,
    companyName,
    pageTitle,
    ogImage = "/images/banner.png",
    ogTitle = "SecondOffice | Your Personal Job Portal",
    ogDescription = "A Job for Everyone. SecondOffice is a job portal dedicated to be your personal recruiting team.",
  } = props;

  /** custom handlers */
  const handleDrawerToggle = () => {
    setMobileOpen(!mobileOpen);
  };

  const drawer = (
    <Stack direction="column" justifyContent="space-between" minHeight="100%">
      <div>
        <Toolbar sx={{ paddingLeft: "30px !important", marginBottom: 4 }}>
          {/* SecondOffice Logo */}
          <img
            height="35px"
            src="/svg/logoWhite.svg"
            style={{ marginLeft: -5, marginTop: 10 }}
          />
        </Toolbar>
        <List sx={{ marginTop: "-25px" }}>
          {drawerMenu.map((menu, index) => (
            <Link key={menu.label} href={menu.path} passHref>
              <ListItemButton
                disableRipple
                component="a"
                // selected={window.location.pathname.includes(menu.value)}
                // selected={router.pathname.includes(menu.value)}
                selected={router.pathname.includes(menu.path)}
              >
                <ListItemIcon>{menu.icon}</ListItemIcon>
                <ListItemText>
                  <Typography
                    key={index}
                    component="p"
                    sx={
                      router.pathname.includes(menu.path)
                        ? { fontWeight: 700, color: "white" }
                        : { fontWeight: 400, color: "white" }
                    }
                  >
                    {menu.label}
                  </Typography>
                </ListItemText>
              </ListItemButton>
            </Link>
          ))}
        </List>
      </div>
    </Stack>
  );

  const isMobile = useMediaQuery("(max-width:600px)");
  return (
    <div style={{ display: "flex" }}>
      <Head>
        <meta charSet="utf-8" />
        <meta httpEquiv="X-UA-Compatible" content="IE=edge" />
        <meta
          name="viewport"
          content="width=device-width,initial-scale=1,minimum-scale=1,maximum-scale=1,user-scalable=no"
        />
        <meta name="description" content={ogDescription} />
        <meta name="keywords" content="Jobs in India" />
        <title>{ogTitle}</title>
        <meta property="og:image" content={ogImage} />
        <meta property="og:title" content={ogTitle} />
        <meta property="og:description" content={ogDescription} />
        <meta name="twitter:title" content={ogTitle} />
        <meta name="twitter:description" content={ogDescription} />
        <meta name="twitter:image" content={ogImage} />
        <meta name="twitter:card" content="summary_large_image" />
        <link rel="manifest" href="/manifest.json" />
        <link href="/faviconSO.ico" rel="icon" type="image/svg" sizes="16x16" />
        <link href="/faviconSO.ico" rel="icon" type="image/svg" sizes="32x32" />
        <link rel="apple-touch-icon" href="/faviconSO.ico"></link>
        <link rel="shortcut icon" href="/faviconSO.ico" />
      </Head>
      {/* Top navigation */}
      <AppBar
        position="fixed"
        sx={{
          background: "#ffffff",
          boxShadow: "none",
        }}
      >
        <Toolbar>
          <Stack
            alignItems={{ xs: "flex-start", sm: "center", md: "start" }}
            direction={{ xs: "row", sm: "column" }}
            justifyContent="flex-center"
            width={{ xs: "auto", sm: "300px" }}
          >
            {/* Drawer Toggle */}
            <IconButton
              color="primary"
              aria-label="open drawer"
              onClick={handleDrawerToggle}
              sx={{
                display: { lg: "none" },
              }}
            >
              <MenuIcon />
            </IconButton>
          </Stack>
          <Stack
            direction="row"
            alignItems={{ xs: "center", sm: "center" }}
            width={{ xs: "100%", sm: "87%" }}
            paddingTop={{ xs: "none", sm: "13px" }}
            paddingX={{ xs: "none", sm: "20px" }}
            justifyContent="space-between"
            // marginRight={2.5}
            // marginLeft={4.9}
          >
            <Typography
              component="h2"
              variant="h2"
              color="primary.main"
              sx={{ marginLeft: { xs: "25%", sm: "0%" } }}
            >
              {company?.company_name}
            </Typography>
            <Typography component="h2" variant="h2" color="primary.main">
              <ImageContainer onClick={() => router.push("/profile")}>
                <img
                  // src="/svg/defaltProfileIcon.svg"
                  src={
                    company?.company_logo
                      ? company?.company_logo
                      : `/svg/DefaultLogo.svg`
                  }
                  alt="ProfileIcon_Image"
                  style={{ width: "42px", height: "42px", borderRadius: 40 }}
                />
              </ImageContainer>
            </Typography>
          </Stack>
        </Toolbar>
      </AppBar>

      {/* Side navigation */}
      <DrawerContainer aria-label="job provider dashboard menus">
        <Hidden lgDown implementation="css">
          {/* Drawer in desktop */}
          <DrawerPaper
            sx={{
              width: {
                lg: drawerWidth,
              },
              flexShrink: {
                lg: 0,
              },
            }}
            variant="permanent"
            anchor="left"
          >
            {drawer}
          </DrawerPaper>
        </Hidden>
        <Hidden mdUp implementation="css">
          {/* Drawer in mobile */}
          <DrawerPaper
            variant="temporary"
            open={mobileOpen}
            onClose={handleDrawerToggle}
            ModalProps={{
              keepMounted: true,
            }}
          >
            {drawer}
          </DrawerPaper>
        </Hidden>
      </DrawerContainer>
      <Container
        // maxWidth="xl"
        // disableGutters={isMobile ? false : true}
        sx={{ paddingY: 8, background: "#f8f8f8", minHeight: "100vh" }}
      >
        {/* Page Header  */}
        <Typography
          variant="h3"
          color="primary.main"
          display={{ xs: "block" }}
          marginTop={4.5}
        >
          {pageTitle}
        </Typography>

        {/* Main content children */}

        {children}
      </Container>
    </div>
  );
};
