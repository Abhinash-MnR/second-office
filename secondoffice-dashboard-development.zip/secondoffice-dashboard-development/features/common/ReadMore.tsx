// React, Next packages
import React, { useState } from "react";

// Mui packages
import { styled, Typography } from "@mui/material";
// Third party packages
import { useTranslation } from "react-i18next";
import "translation/i18n";

const CommentsContainer = styled("div")(({ theme }) => ({
  display: "inline",
  width: "100%",
  fontSize: 14,
  lineHeight: "150%",
}));

function ReadMore({ children, sliceTextLength }) {
  //** Language translation hooks */
  const { t } = useTranslation();
  // Children
  const text = children;
  // Text Changes State Define
  const [isReadMore, setIsReadMore] = useState(true);
  // Toggle Read More and Read Less
  const toggleReadMore = () => {
    setIsReadMore(!isReadMore);
  };

  const sliceText = sliceTextLength;
  return (
    <CommentsContainer>
      {isReadMore ? text.slice(0, sliceText) : text}
      <Typography
        component="span"
        onClick={toggleReadMore}
        sx={{ cursor: "pointer" }}
      >
        {isReadMore ? (
          <Typography
            component="span"
            sx={{
              fontWeight: 700,
              fontSize: 14,
              color: "#2c3058",
            }}
          >
            {" "}
            {t("read_more_title")}
          </Typography>
        ) : (
          <Typography
            component="span"
            sx={{
              fontWeight: 700,
              fontSize: 14,
              color: "#2c3058",
            }}
          >
            {" "}
            {t("show_less_title")}
          </Typography>
        )}
      </Typography>
    </CommentsContainer>
  );
}

export default ReadMore;
