// React, Next packages
import React, { useEffect, useState } from "react";
import { useRouter } from "next/router";
import { connect } from "react-redux";
import { Dispatch } from "redux";
// Mui packages
import { Box } from "@mui/material";
import Tab from "@mui/material/Tab";
import TabContext from "@mui/lab/TabContext";
import TabList from "@mui/lab/TabList";
import TabPanel from "@mui/lab/TabPanel";
// 3Rd Party Component/Packages
import { useSnackbar } from "notistack";
// Custom Component
import { RootState } from "reducers";
import {
  clearApplications,
  editApplication,
  listApplication,
} from "reducers/applicationsSlice";
import AllApplicants from "features/applications/AllApplicants";
import AcceptedApplicants from "features/applications/AcceptedApplicants";
import RejectedApplicants from "features/applications/RejectedApplicants";

function LabTabs(props: any) {
  /** third-party hooks */
  const { enqueueSnackbar } = useSnackbar();
  const router = useRouter();

  /** props - actions */
  const { clearApplications, editApplication, listApplication } = props;
  /** props - states */
  const { applications, applicationsNext } = props;

  /** useEffect hooks */
  useEffect(() => {
    const initializeApplicationList = async () => {
      clearApplications();
      await listApplication({
        ...router.query,
        page_size: 9,
        page: 1,
        applicant_status: "pending",
        job_post: location.href.split("/")[4],
      });
    };
    try {
      initializeApplicationList();
    } catch (error) {
      console.log(error);
    }
  }, []);

  const [value, setValue] = React.useState("1");

  const handleChange = (event: React.SyntheticEvent, newValue: string) => {
    setValue(newValue);
  };

  return (
    <Box sx={{ width: "100%", marginTop: { xs: "5px", sm: "12px" } }}>
      <TabContext value={value}>
        <Box>
          <TabList
            onChange={handleChange}
            aria-label="Second Office Jobs Applicant "
            variant="scrollable"
            scrollButtons={false}
          >
            <Tab
              label={
                applications[0]?.applicant_status === "pending"
                  ? `All Applicants(${applications.length})`
                  : "All Applicants"
              }
              value="1"
              disableRipple={true}
              sx={{ fontSize: 16, paddingLeft: 0 }}
            />
            <Tab
              label={
                applications[0]?.applicant_status === "accepted"
                  ? `Accepted Applicants(${applications.length})`
                  : "Accepted Applicants"
              }
              value="2"
              disableRipple={true}
              sx={{ fontSize: 16 }}
            />
            <Tab
              label={
                applications[0]?.applicant_status === "rejected"
                  ? `Rejected Applicants(${applications.length})`
                  : "Rejected Applicants"
              }
              value="3"
              disableRipple={true}
              sx={{ fontSize: 16 }}
            />
          </TabList>
        </Box>
        {/* All Aplicants List */}
        <TabPanel value="1" sx={{ padding: "24px 0px" }}>
          <AllApplicants />
        </TabPanel>
        {/* Accepted Aplicants List */}
        <TabPanel value="2" sx={{ padding: "24px 0px" }}>
          <AcceptedApplicants />{" "}
        </TabPanel>
        {/* Rejected Aplicants List */}
        <TabPanel value="3" sx={{ padding: "24px 0px" }}>
          <RejectedApplicants />
        </TabPanel>
      </TabContext>
    </Box>
  );
}

const mapStateToProps = (state: RootState) => ({
  applications: state.applications.applications,
  applicationsLength: state.applications.applicationsLength,
  applicationsNext: state.applications.applicationsNext,
});

const mapDispatchToProps = (dispatch: Dispatch) => {
  return {
    clearApplications: () => dispatch(clearApplications()),
    editApplication: (id: string, payload: any) =>
      editApplication(dispatch, id, payload),
    listApplication: (params: any) => listApplication(dispatch, params),
  };
};

export default connect(mapStateToProps, mapDispatchToProps)(LabTabs);
