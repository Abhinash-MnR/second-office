// React, Next packages
import React, { useEffect, useState } from "react";
import Link from "next/link";
import { useRouter } from "next/router";
// Mui packages
import {
  Collapse,
  List,
  ListItemButton,
  ListItemIcon,
  ListItemText,
  Typography,
  useMediaQuery,
} from "@mui/material";
// Third party packages
import { useTranslation } from "react-i18next";
import "translation/i18n";
// Custom packages
import {
  AddMultiUser,
  OfficeManagementIcon,
  OfficeManagementIconColor,
  AddMultiUserColor,
  AttendanceColor,
  PerformanceColor,
  ManagementLogColor,
} from "@common/Icon";
import ExpandLess from "@mui/icons-material/ExpandLess";
import ExpandMore from "@mui/icons-material/ExpandMore";

function SideBarDropdownMenu() {
  //** router hooks */
  const router = useRouter();

  /** third-party hooks */
  const [open, setOpen] = useState(false);

  //** Language translation hooks */
  const { t } = useTranslation();

  /** Dropdown menu handle */
  const handleClick = () => {
    setOpen(!open);
  };

  useEffect(() => {
    if (router.pathname.includes("/officeManagement")) {
      setOpen(true);
    } else {
      setOpen(false);
    }
  }, []);

  const drawerDropDownMenu = [
    {
      label: `${t("office_management_submenu_team")}`,
      icon: <AddMultiUser />,
      iconColor: <AddMultiUserColor />,
      path: "/officeManagement/team",
    },
    // {
    //   label: `${t("office_management_submenu_attendance")}`,
    //   icon: <AttendanceColor />,
    //   iconColor: <AttendanceColor />,
    //   path: "/officeManagement/attendance",
    // },
    {
      label: `${t("office_management_submenu_performance")}`,
      icon: <PerformanceColor />,
      iconColor: <PerformanceColor />,
      path: "/officeManagement/performance",
    },
    {
      label: `${t("office_management_submenu_log")}`,
      icon: <ManagementLogColor />,
      iconColor: <ManagementLogColor />,
      path: "/officeManagement/managementLog",
    },
  ];

  return (
    <div>
      <ListItemButton
        onClick={handleClick}
        disableRipple
        selected={router.pathname.includes("/officeManagement")}
      >
        {router.pathname.includes("/officeManagement") ? (
          <ListItemIcon>
            <OfficeManagementIcon />
          </ListItemIcon>
        ) : (
          <ListItemIcon>
            <OfficeManagementIconColor />
          </ListItemIcon>
        )}
        <ListItemText>
          <Typography
            component="p"
            variant="body2"
            sx={
              router.pathname.includes("/officeManagement")
                ? { fontWeight: 700, color: "white" }
                : { fontWeight: 400, color: "#4d4d4d" }
            }
          >
            {t("office_management_menu")}
          </Typography>
        </ListItemText>
        {open ? <ExpandLess /> : <ExpandMore />}
      </ListItemButton>

      <Collapse in={open} timeout="auto" unmountOnExit>
        <List component="div" disablePadding sx={{ background: "#ECEDF4" }}>
          {/* code Sample */}
          {drawerDropDownMenu.map((menu, index) => (
            <Link href={menu.path} key={index}>
              <ListItemButton
                disableRipple
                sx={
                  router.pathname.includes(menu.path)
                    ? { background: "#FFFFFF", pl: 6 }
                    : { background: "none", pl: 6 }
                }
              >
                <ListItemIcon>{menu.iconColor}</ListItemIcon>
                <ListItemText>
                  <Typography
                    component="p"
                    variant="body2"
                    sx={
                      router.pathname.includes(menu.path)
                        ? { fontWeight: 700, color: "#4D4D4D" }
                        : { fontWeight: 400, color: "#4d4d4d" }
                    }
                  >
                    {menu.label}
                  </Typography>
                </ListItemText>
              </ListItemButton>
            </Link>
          ))}
        </List>
      </Collapse>
    </div>
  );
}

export default SideBarDropdownMenu;
