// React , Next js packages
import React, { useState } from "react";
// Mui packages
import {
  Dialog,
  DialogActions,
  DialogContent,
  DialogTitle,
  Box,
  IconButton,
  styled,
  Typography,
} from "@mui/material";
import { CloseIcon } from "./Icon";
// Third party packages
import { useTranslation } from "react-i18next";
import "translation/i18n";
// Custom packages

const CloseButton = styled("div")(({ theme }) => ({
  position: "absolute",
  right: 12,
  top: 20,
  [theme.breakpoints.down("sm")]: {
    right: theme.spacing(1.02),
    top: theme.spacing(2.75),
  },
}));

function DialogBox({ description }) {
  //** Language translation hooks */
  const { t } = useTranslation();
  //** useState hooks */
  const [open, setOpen] = useState(false);

  const handleClickOpen = () => {
    setOpen(true);
  };

  const handleClose = () => {
    setOpen(false);
  };

  return (
    <Box>
      <Typography
        onClick={handleClickOpen}
        sx={{ cursor: "pointer" }}
        color="primary.main"
        variant="button"
      >
        {t("read_more_title")}
      </Typography>
      <Dialog
        open={open}
        onClose={handleClose}
        aria-labelledby="alert-dialog-title"
        aria-describedby="alert-dialog-description"
        fullWidth
        maxWidth={"sm"}
      >
        <DialogTitle id="alert-dialog-title">{t("description")}</DialogTitle>
        <CloseButton>
          <IconButton onClick={handleClose}>
            <CloseIcon />
          </IconButton>
        </CloseButton>
        <DialogContent sx={{ paddingTop: "0px", paddingBottom: 0 }}>
          {description}
        </DialogContent>
        <DialogActions sx={{ visibility: "hidden" }}>dummy text</DialogActions>
      </Dialog>
    </Box>
  );
}

export default DialogBox;
