// React packages
import React, { FC, HTMLAttributes } from "react";
// Mui packages
import {
  Backdrop as MuiBackdrop,
  BackdropProps,
  CircularProgress,
  styled,
} from "@mui/material";

interface MuiBackdropProps extends HTMLAttributes<HTMLDivElement> {
  isInvisible?: boolean;
  open: boolean;
}

const StyledBackdrop = styled(MuiBackdrop, {
  shouldForwardProp: (prop) => prop !== "isInvisible",
})<MuiBackdropProps>(({ isInvisible, theme }) => ({
  root: {
    zIndex: theme.zIndex.modal + 1,
  },

  ...(isInvisible
    ? {
        backgroundColor: "rgba(0, 0, 0, 0)",
        color: theme.palette.primary.main,
      }
    : {
        color: "#fff",
      }),
}));

export const Backdrop: FC<BackdropProps> = (props: BackdropProps) => {
  /** props */
  const { invisible, open } = props;

  return (
    <StyledBackdrop isInvisible={invisible} open={open}>
      <CircularProgress color="inherit" />
    </StyledBackdrop>
  );
};
