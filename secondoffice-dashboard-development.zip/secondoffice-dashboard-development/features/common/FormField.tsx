// @ts-nocheck - TODO
/**
 * A collection of hoisted Field components
 */
// React, Next packages
import React, { useEffect, useState } from "react";
import dynamic from "next/dynamic";
// Mui packages
import {
  Autocomplete,
  Avatar,
  Box,
  Chip,
  Select,
  styled,
  TextField as MuiTextField,
  Typography,
} from "@mui/material";
// Third-party packages
import { ChevronDown, Share } from "react-feather";
// Custom packages
import { AsyncAutoComplete } from "@common/AsyncAutoComplete";
import { ChipGroup } from "@common/ChipGroup";
import india_cities from "data/india_cities";
import monthRange from "data/monthRange";
import jobPriority from "data/jobPriority";
import { listTag } from "api/tag";
import education from "data/education";
// Draft.js packages
import { convertToRaw } from "draft-js";
import draftToHtml from "draftjs-to-html";
import { EditorState, ContentState, convertFromHTML } from "draft-js";
const Editor = dynamic(
  () => import("react-draft-wysiwyg").then((mod) => mod.Editor),
  { ssr: false }
);
import "react-draft-wysiwyg/dist/react-draft-wysiwyg.css";

const DraftField = React.forwardRef((props, ref) => {
  const { component: Component, editorRef, handleOnChange, ...rest } = props;

  React.useImperativeHandle(ref, () => ({
    focus: () => {
      editorRef?.current?.focus();
    },
  }));

  return <Component {...rest} ref={editorRef} onChange={handleOnChange} />;
});

export const TextEditorField = (props: FieldProps & MuiTextFieldProps) => {
  const {
    input,
    meta: { touched, error },
    title,
    warning,
    ...rest
  } = props;

  const [counter, setCounter] = useState(0);

  useEffect(() => {
    const newCounter = counter + 1;
    setCounter(newCounter);
    if (input.value !== "" && counter <= 1) {
      setEditorState(
        EditorState.createWithContent(
          ContentState.createFromBlockArray(convertFromHTML(input.value))
        )
      );
    }
  }, [input.value]);

  const onEditorStateChange = (editorState) => {
    if (editorState.getCurrentContent().hasText()) {
      props.input.onChange(
        draftToHtml(convertToRaw(editorState.getCurrentContent()))
      );
    } else {
      props.input.onChange("");
    }
    onChange(editorState);
  };
  const initialState = () => EditorState.createEmpty();
  // EditorState.createWithContent(ContentState.createFromBlockArray(convertFromHTML(input.value)));

  const [editorState, setEditorState] = useState(initialState);

  const onChange = async (value) => {
    await setEditorState(value);
  };

  return (
    <div>
      {title && (
        <Typography
          color={touched && error ? "error" : "inherit"}
          component="div"
          variant="caption"
          marginBottom={0.625}
        >
          {title}
        </Typography>
      )}
      <MuiTextField
        {...input}
        {...rest}
        error={touched && error ? true : false}
        InputProps={{
          inputProps: {
            component: Editor,
            onEditorStateChange,
            // defaultEditorState: editorState,
            editorState,
          },
          inputComponent: DraftField,
          style: {
            padding: 10,
          },
        }}
      />

      {touched && error && (
        <Typography color="error" variant="caption">
          {error ? warning : null}
        </Typography>
      )}
    </div>
  );
};

export const TextEditorFieldEmpty = (props: FieldProps & MuiTextFieldProps) => {
  const {
    input,
    meta: { touched, error },
    title,
    warning,
    ...rest
  } = props;

  const onEditorStateChange = (editorState) => {
    if (editorState.getCurrentContent().hasText()) {
      props.input.onChange(
        draftToHtml(convertToRaw(editorState.getCurrentContent()))
      );
    } else {
      props.input.onChange("");
    }
  };

  return (
    <div>
      {title && (
        <Typography
          color={touched && error ? "error" : "inherit"}
          component="div"
          variant="caption"
          marginBottom={0.625}
        >
          {title}
        </Typography>
      )}
      <MuiTextField
        {...input}
        {...rest}
        error={touched && error ? true : false}
        InputProps={{
          inputProps: {
            component: Editor,
            onEditorStateChange,
          },
          inputComponent: DraftField,
          style: {
            padding: 10,
          },
        }}
      />

      {touched && error && (
        <Typography color="error" variant="caption">
          {error ? warning : null}
        </Typography>
      )}
    </div>
  );
};

const ImageFieldLabel = styled("label")({
  alignItems: "center",
  background: "#F6F6F633",
  border: "1px dashed #E5E5E5",
  borderRadius: 8,
  display: "flex",
  justifyContent: "center",
  width: "100%",
  height: 200,
  "&:hover": {
    cursor: "pointer",
    background: "#ebebeb",
  },
});

export const ChipGroupField = (props) => {
  /** props */
  const {
    input,
    meta: { touched, error },
    options,
    round,
    warning,
    title,
  } = props;

  /** custom handlers */
  const handleChange = (event, value) => input.onChange(value);

  return (
    <>
      {title && (
        <Typography
          color={touched && error ? "error" : "inherit"}
          component="div"
          variant="caption"
          marginBottom={0.925}
        >
          {title}
        </Typography>
      )}
      <ChipGroup
        onChange={handleChange}
        options={options}
        value={input.value}
        round={round}
      />
      {touched && error && (
        <Typography color="error" variant="caption">
          {error ? warning : null}
        </Typography>
      )}
    </>
  );
};

export const ImageField = ({ input, meta: { touched, error }, title }) => {
  const handleChange = (e) => {
    const file = e.target.files[0];
    const reader = new FileReader();
    file && reader.readAsDataURL(file);
    reader.onloadend = () => {
      input.onChange({
        file,
        thumbnail: reader.result,
      });
      input.onBlur();
    };
  };

  return (
    <>
      {title && (
        <Typography
          color={touched && error ? "error" : "inherit"}
          component="div"
          variant="caption"
          marginBottom={0.625}
        >
          {title}
        </Typography>
      )}
      <ImageFieldLabel>
        {input.value?.thumbnail ? (
          <Avatar
            style={{ height: 200, width: 200 }}
            src={input.value.thumbnail}
            variant="square"
          />
        ) : (
          <div
            style={{
              alignItems: "center",
              display: "flex",
              flexDirection: "column",
            }}
          >
            <Box
              bgcolor="#5360E7"
              border="1px solid #5360E7"
              borderRadius={1}
              color="white"
              py={1.5}
              px={5}
              textAlign="center"
            >
              <Typography color="inherit" variant="body1" fontWeight="600">
                <Share
                  style={{
                    marginRight: 10,
                    opacity: 0.5,
                    verticalAlign: "bottom",
                  }}
                  size={20}
                />
                Upload Image
              </Typography>
            </Box>
            <Typography
              align="center"
              style={{ width: 100, fontSize: 10, marginTop: 10 }}
            >
              Image should not be more than <b>1MB</b>
            </Typography>
          </div>
        )}
        <input
          accept="image/*"
          type="file"
          onChange={handleChange}
          style={{ display: "none" }}
        />
      </ImageFieldLabel>
      {touched && error && (
        <Typography color="error" variant="caption">
          {error}
        </Typography>
      )}
    </>
  );
};

export const MonthField = ({
  input,
  meta: { touched, error },
  title,
  warning,
  placeholder,
}) => {
  const handleSelected = (event, value) => {
    input.onChange(value);
  };

  return (
    <>
      {title && (
        <Typography
          color={touched && error ? "error" : "inherit"}
          component="div"
          variant="caption"
          marginBottom={0.625}
        >
          {title}
        </Typography>
      )}
      <Autocomplete
        {...input}
        onChange={handleSelected}
        fullWidth
        freeSolo
        size="small"
        options={monthRange.map((option) => option)}
        renderInput={(params) => {
          const { inputProps, InputProps } = params;
          return (
            <MuiTextField
              {...input}
              fullWidth
              placeholder={placeholder}
              variant="outlined"
              size="small"
              InputProps={{ ...InputProps }}
              inputProps={{
                ...inputProps,
              }}
              error={touched && error ? true : false}
            />
          );
        }}
      />
      {touched && error && (
        <Typography color="error" variant="caption">
          {error ? warning : null}
        </Typography>
      )}
    </>
  );
};

export const LocationField = ({
  input,
  meta: { touched, error },
  title,
  warning,
  placeholder,
}) => {
  const handleSelected = (event, value) => {
    input.onChange(value);
  };

  return (
    <>
      {title && (
        <Typography
          color={touched && error ? "error" : "inherit"}
          component="div"
          variant="caption"
          marginBottom={0.625}
        >
          {title}
        </Typography>
      )}
      <Autocomplete
        {...input}
        onChange={handleSelected}
        fullWidth
        freeSolo
        size="small"
        options={india_cities.map((option) => option)}
        renderInput={(params) => {
          const { inputProps, InputProps } = params;
          return (
            <MuiTextField
              {...input}
              fullWidth
              placeholder={placeholder}
              variant="outlined"
              size="small"
              InputProps={{ ...InputProps }}
              inputProps={{
                ...inputProps,
              }}
              error={touched && error ? true : false}
            />
          );
        }}
      />
      {touched && error && (
        <Typography color="error" variant="caption">
          {error ? warning : null}
        </Typography>
      )}
    </>
  );
};
export const PriorityField = ({
  input,
  meta: { touched, error },
  title,
  warning,
  placeholder,
}) => {
  const handleSelected = (event, value) => {
    input.onChange(value);
  };

  return (
    <>
      {title && (
        <Typography
          color={touched && error ? "error" : "inherit"}
          component="div"
          variant="caption"
          marginBottom={0.625}
        >
          {title}
        </Typography>
      )}
      <Autocomplete
        {...input}
        onChange={handleSelected}
        fullWidth
        freeSolo
        size="small"
        options={jobPriority.map((option) => option)}
        renderInput={(params) => {
          const { inputProps, InputProps } = params;
          return (
            <MuiTextField
              {...input}
              fullWidth
              placeholder={placeholder}
              variant="outlined"
              size="small"
              InputProps={{ ...InputProps }}
              inputProps={{
                ...inputProps,
              }}
              error={touched && error ? true : false}
            />
          );
        }}
      />
      {touched && error && (
        <Typography color="error" variant="caption">
          {error ? warning : null}
        </Typography>
      )}
    </>
  );
};
export const EducationField = ({
  input,
  meta: { touched, error },
  title,
  warning,
  placeholder,
}) => {
  const handleSelected = (event, selectedRow) => {
    input.onChange(selectedRow.value);
  };

  return (
    <>
      {title && (
        <Typography
          color={touched && error ? "error" : "inherit"}
          component="div"
          variant="caption"
          marginBottom={0.625}
        >
          {title}
        </Typography>
      )}
      <Autocomplete
        {...input}
        onChange={handleSelected}
        fullWidth
        freeSolo
        size="small"
        options={education.map((option) => option)}
        renderInput={(params) => {
          const { inputProps, InputProps } = params;
          return (
            <MuiTextField
              {...input}
              fullWidth
              placeholder={placeholder}
              variant="outlined"
              size="small"
              InputProps={{ ...InputProps }}
              inputProps={{
                ...inputProps,
              }}
              error={touched && error ? true : false}
            />
          );
        }}
      />
      {touched && error && (
        <Typography color="error" variant="caption">
          {error ? warning : null}
        </Typography>
      )}
    </>
  );
};

export const SelectField = ({
  input,
  children,
  meta: { touched, error },
  title,
  options,
  ...rest
}) => {
  return (
    <>
      {title && (
        <Typography
          color={touched && error ? "error" : "inherit"}
          component="div"
          variant="caption"
          marginBottom={0.625}
        >
          {title}
        </Typography>
      )}
      <Select
        {...input}
        {...rest}
        fullWidth
        IconComponent={ChevronDown}
        native
        variant="outlined"
      >
        {options?.map((option, key) => {
          return (
            <option key={key} value={option.value}>
              {option.label}
            </option>
          );
        })}
      </Select>
      {touched && error && (
        <Typography color="error" variant="caption">
          {error}
        </Typography>
      )}
    </>
  );
};

export const TagField = ({
  input,
  meta: { touched, error },
  title,
  placeholder,
}) => {
  /** props */
  const { value, onBlur, onChange, onFocus } = input;

  /** constants */
  const initialized = value && value.length > 0;

  /** custom handlers */
  const handleTagsChange = (event, newTag) => {
    if (newTag && !initialized) {
      onChange([newTag]);
    } else if (newTag && initialized) {
      const newTagList = value.filter((tag) => tag.id !== newTag.id);
      newTagList.push(newTag);
      onChange(newTagList);
    }
  };

  const handleRemoveTag = (tagId: string) => {
    const newTagList = value.filter((tag: TagResponse) => {
      return tag.id !== tagId;
    });
    onChange(newTagList);
  };

  return (
    <>
      {title && (
        <Typography
          color={touched && error ? "error" : "inherit"}
          component="div"
          variant="caption"
          marginBottom={0.625}
        >
          {title}
        </Typography>
      )}
      <AsyncAutoComplete
        error={!!(touched && error)}
        getOptions={listTag}
        onChange={handleTagsChange}
        onClose={onBlur}
        onOpen={onFocus}
        optionsKey="tag"
        placeholder={placeholder ? placeholder : "Add skill by tags"}
        variant="outlined"
        value={value}
      />
      {touched && error && (
        <Typography color="error" variant="caption">
          {error}
        </Typography>
      )}
      {value &&
        value.map((jobTag: TagResponse) => {
          return (
            <Chip
              key={jobTag.id}
              label={jobTag.tag}
              onDelete={() => handleRemoveTag(jobTag.id)}
              sx={{
                backgroundColor: "#F3F5F9",
                marginTop: 2,
                marginRight: 1.25,
              }}
            />
          );
        })}
    </>
  );
};

export const TextField = (props: FieldProps & MuiTextFieldProps) => {
  const {
    input,
    meta: { touched, error },
    title,
    warning,
    ...rest
  } = props;

  return (
    <div>
      {title && (
        <Typography
          color={touched && error ? "error" : "inherit"}
          component="div"
          variant="caption"
          marginBottom={0.625}
        >
          {title}
        </Typography>
      )}
      <MuiTextField
        {...input}
        {...rest}
        error={touched && error ? true : false}
      />
      {touched && error && (
        <Typography color="error" variant="caption">
          {error ? warning : null}
        </Typography>
      )}
    </div>
  );
};

export const SelectDropdownField = ({
  input,
  meta: { touched, error },
  title,
  placeholder,
  warning,
  domain,
}) => {
  const handleSelected = (event, value) => {
    input.onChange(value);
  };

  return (
    <>
      {title && (
        <Typography
          color={touched && error ? "error" : "inherit"}
          component="div"
          variant="caption"
          marginBottom={0.625}
        >
          {title}
        </Typography>
      )}
      <Autocomplete
        {...input}
        onChange={handleSelected}
        fullWidth
        size="small"
        options={domain.map((option) => option)}
        renderInput={(params) => {
          const { inputProps, InputProps } = params;
          return (
            <MuiTextField
              {...input}
              fullWidth
              placeholder={placeholder}
              variant="outlined"
              size="small"
              InputProps={{ ...InputProps }}
              inputProps={{
                ...inputProps,
              }}
              error={touched && error ? true : false}
            />
          );
        }}
      />
      {touched && error && (
        <Typography color="error" variant="caption">
          {error ? warning : null}
        </Typography>
      )}
    </>
  );
};

export const SearchTextField = (props: FieldProps & MuiTextFieldProps) => {
  const {
    input,
    meta: { touched, error },
    title,

    ...rest
  } = props;

  return (
    <div>
      {title && (
        <Typography
          color={touched && error ? "error" : "inherit"}
          component="div"
          variant="caption"
          marginBottom={0.625}
        >
          {title}
        </Typography>
      )}
      <MuiTextField
        {...input}
        {...rest}
        error={touched && error ? true : false}
        sx={{ width: "400px" }}
      />
      {touched && error && (
        <Typography color="error" variant="caption">
          {error}
        </Typography>
      )}
    </div>
  );
};
