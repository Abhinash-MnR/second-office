// React, Next packages
import React, { FC } from "react";
import Link from "next/link";
import { UrlObject } from "url";
// Mui packages
import { Box, Typography } from "@mui/material";

type AlertBannerProps = {
  /** Background color of the banner */
  backgroundColorHex?: string;
  /** CTA message to display */
  cta: string;
  /** Link redirected to when clicked */
  href: string | UrlObject;
  /** Color of the CTA text */
  textColorHex?: string;
};

export const AlertBanner: FC<AlertBannerProps> = ({
  backgroundColorHex,
  cta,
  href,
  textColorHex,
}: AlertBannerProps) => {
  return (
    <Box
      alignItems="center"
      bgcolor={backgroundColorHex}
      component="aside"
      display="flex"
      justifyContent="center"
      p={2.5}
      textAlign="center"
      width={1}
    >
      <Link href={href} passHref>
        <Typography
          component="a"
          style={{ color: textColorHex, textDecoration: "underline" }}
          variant="body2"
        >
          {cta}
        </Typography>
      </Link>
    </Box>
  );
};

AlertBanner.defaultProps = {
  backgroundColorHex: "#222222",
  textColorHex: "#FFFFFF",
};
