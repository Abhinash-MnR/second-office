// React packages
import React, { FC } from "react";
// Mui packages
import { Chip, Stack } from "@mui/material";

type ChipGroupItem = {
  /** Label of an option */
  label: string;
  /** Value of the option */
  value: string;
};

type ChipGroupProps = {
  /** Callback triggered when chip is clicke */
  onChange?: (...params: any) => void;
  /** Option array of the chip group */
  options: Array<ChipGroupItem>;
  /** Current value of the chip group form */
  value?: string;
};

export const ChipGroup: FC<ChipGroupProps> = (props: ChipGroupProps) => {
  /** third-party hooks */

  /** props */
  const { onChange, options, value } = props;

  return (
    <Stack display="flex" direction="row" flexWrap="wrap">
      {options &&
        options.map((option) => {
          return (
            <Chip
              key={option.label}
              color={option.value == value ? "primary" : "default"}
              label={option.label}
              variant="filled"
              onClick={(e) => onChange && onChange(e, option.value)}
              sx={{
                marginRight: 2,
                marginBottom: 1.25,
                ...(option.value !== value && {
                  backgroundColor: "#F3F5F9",
                  color: "#222222",
                }),
              }}
            />
          );
        })}
    </Stack>
  );
};
