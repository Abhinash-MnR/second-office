// React, Next packages
import React, { FC, useState, useEffect } from "react";

// Mui packages
import { styled, Typography, Skeleton, Stack, Grid } from "@mui/material";

// Third-party packages
import { GoogleSpreadsheet } from "google-spreadsheet";
// Custom Component
import { BlogCard } from "./BlogCard";

export type BlogSectionProps = {
  /** Blog Section Title Props */
  blogTitle: string;
};

const BlogSectionWrapper = styled("div")(({ theme }) => ({
  marginTop: 40,
  marginBottom: 30,
}));
const BlogSectionTitle = styled("div")(({ theme }) => ({
  display: "flex",
  flexDirection: "row",
  paddingBottom: "30px",
}));

export const BlogSection: FC<BlogSectionProps> = (props: BlogSectionProps) => {
  const { blogTitle } = props;

  // ------------Google sheet API--------------
  const [blogData, setBlogData] = useState([]);
  const [loading, setLoading] = useState(true);
  // client id and client email for google spreadSheet

  const blogSheetSetup = async () => {
    const doc = new GoogleSpreadsheet(
      "1naOPBrUoEJteZsaFr3BeFArWyjQsc3iyGpAOXW9exmg"
    );
    await doc.useServiceAccountAuth({
      client_email: "mnr-website@websites-332414.iam.gserviceaccount.com",
      private_key:
        "-----BEGIN PRIVATE KEY-----\nMIIEvgIBADANBgkqhkiG9w0BAQEFAASCBKgwggSkAgEAAoIBAQDGiOzB6xFm5/aC\nUsMQvRG3xEHQQ2lWM8kR1xvWxFY2qzqvaJ51zlJpLcOpshnSbB/JEgUqBYPfcQo4\nJM/NnIBMf+6IHolssfII2LozjiHNUqRos53UhOxhMYkHJmluuMkYG/ofb2VZzlXp\nIX+Q0o1M9QP4K8XphEHzFmTNCNFcJAxdqSzWewxnIENHuEGlLxmxoVsvhDW/Fwni\nJ3CeKpN+9Z6b1Mvb6urpqTS/XIHABzSog5VeYLh/zs988x4MO72sE6fFGQXIEgIL\n5hNrSJcbKBQAuZ9q7JMqvMRCuX8hshUHhWqtz2dMZXV0zuIfUzbsv5Z4kCtnv8bI\npiV9SZPJAgMBAAECggEACJD2ZDycDNxj4MYo6AM8bTkw3MdX13IXEie9qgPhM20q\ndFCXi746BJNGrr8CSbfEHFUkd2ZzBPRX7Em8VKMUzxgzBtkIdXHtH1AYoqpWj4kq\nEmFzpSySFXSBdNdFs9MRzDJC1dHk5d3XC57YJfvLwH8O64mZ+cQs40v7T/R6MhdB\ngk6vdzuwF9NEfwtL1CZ3sbMPU5/ICvUwevKbL0ddFGAMb53oIlz7VYtyaVy41/59\nC5W8AL+PsRa4cFPJNG9awuZDBGUCRXjz+6pgkiLGMpf9wx631s8kzK+k7rH13gtR\n5KDiI5kNoK5BdenLRMOKi8KZCUVmcY75kObfcacUgQKBgQD9LsDV/zfJ/4MSkty3\nohCwKWnKSoGuV0bjtwfMXBdfQ2zzIQ8bIcR7rZEOLBWxCNcbtrMIWKRnbSAfdmSM\nODSM+CckYrZaLDSxzZhbRg+xODIv5DMMPOmb85H6IXiOZmChLsRdEhoy12V1s3JZ\n//Lp2wazGNt1H/VTUybSNdKcCQKBgQDIvn7M2xiuHPvJ/jq4wPtBQM9iewh9J2EH\nCTBsV8C+KHclgDflQZMTrroR5/qus5TyH2T93wzfVFNWx69oL7sgSy1RjieslXBo\nhIX2kMma003a9StBUHXXEdP7XvAXGAzy2B41VJ+R9GkpOdu2OGzhJrZk9W2I81rn\ntl5c/ICpwQKBgQC0ZGaDUwgGBeb3Cer3cCKh0bANsU560Layswt8YTVJ6/mptalU\ntJeRY5aR2XlPHTRfC6q+TKI/CvKzWCDGA5n1wy3ob+jrkMmu0gU3K1Es/RRNKTPy\nCUiNlFszNDv4ghthXLgOdEJ0bSJeXZAhbgs+8o7wdsqOxkl+qCVl63F3OQKBgQC8\nhDB93u8ha3SFL6sjn48Uq3FV8WZ6acWznsyLoikOKuAhJnTXZapiHH7+m9SNxXWF\nnzfvNU1YWU9eOm4eMFzRqeeoJBBcAYarkHBhqXy6Wd9OVVjGoHHZhBOHh5N+jIZ0\nc8KCoLKtlVJAdeZADGMrWXiF/PldV/OxkFCzkCifwQKBgFnp18ARWA2lx5/upOG/\nuvJR5UYU+DrGUtmHT3NJUpxL+pTrO0he0JZqTham4icyOmoPLDnIhf6j7oP2RqfJ\njFeob07e9v6zkQF6nnwn705ZHb2O7NqIrliHGvhU0Y1uYSL3G9byluh1jojELz8+\nKgyqf7vXLsSLgBx0TJl84Cu7\n-----END PRIVATE KEY-----\n".replace(
          /\\n/g,
          "\n"
        ),
    });

    await doc.loadInfo(); // loads document properties and worksheets

    const blogSheet = doc.sheetsById[1918350053]; // or use doc.sheetsById[id]
    const blogRows = await blogSheet.getRows();
    setBlogData(blogRows);
    setLoading(false);
  };

  useEffect(() => {
    blogSheetSetup();
  }, [1]);
  console.log("blofatdaaa", blogData);
  return (
    <>
      <BlogSectionWrapper>
        <BlogSectionTitle>
          <Typography component="h3" variant="h3">
            {blogTitle}
          </Typography>
        </BlogSectionTitle>

        {/* loading screen added before blog data fetch */}
        {loading ? (
          <Grid container spacing={2}>
            <Grid item xs={12} sm={12}>
              <Stack spacing={1}>
                <Skeleton
                  variant="rectangular"
                  width="100%"
                  height={350}
                  animation="pulse"
                />
              </Stack>
            </Grid>
          </Grid>
        ) : (
          <BlogCard blogdata={blogData} />
        )}
      </BlogSectionWrapper>
    </>
  );
};
