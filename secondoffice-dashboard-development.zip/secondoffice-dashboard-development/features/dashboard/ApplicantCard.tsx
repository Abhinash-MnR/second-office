// React, Next packages
import React, { FC } from "react";
// Mui packages
import { Avatar, Stack, Typography } from "@mui/material";
// Custom packages
import {renderRelativeDate} from "lib/formatter";

type ApplicantCardProps = {
  /** Image to be inserted into the avatar component */
  avatarImage?: string;
  /** applicantName */
  title?: string;
  /** position of applicant */
  subTitle?: string;
  /** date createdAt */
  createdAt?: string;
};

export const ApplicantCard: FC<ApplicantCardProps> = (
  props: ApplicantCardProps
) => {
  /** props */
  const { subTitle, avatarImage, title, createdAt } = props;

  return (
    <Stack direction="row" spacing={2} marginBottom={2}>
      <Avatar src={avatarImage}></Avatar>
      <Stack width={1}>
        <Typography variant="subtitle2" color="primary.main">{title}</Typography>
        <Stack direction="row" justifyContent="space-between">
          <Typography
            component="div"
            color="text.secondary"
            variant="caption"
            sx={{
              "& > span": { color: (theme) => theme.palette.text.primary },
            }}
          >
            Applied for <span>{subTitle}</span>
          </Typography>
          <Typography align="right"  variant="caption" color="text.secondary">
            {renderRelativeDate(createdAt)}
          </Typography>
        </Stack>
      </Stack>
    </Stack>
  );
};
