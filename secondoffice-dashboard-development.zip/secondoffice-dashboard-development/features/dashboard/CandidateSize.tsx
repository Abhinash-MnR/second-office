// React, Next packages
import React, { FC } from "react";

// Mui packages
import { styled, Typography, useMediaQuery } from "@mui/material";

type CandidateSizeProps = {
  /** Count */
  count: string;
};

const Container = styled("div")(({ theme }) => ({
  backgroundColor: "#f8f8f8",
  borderRadius: theme.shape.borderRadius,
  color: theme.palette.background.default,
  height: "100%",
  padding: theme.spacing(2.5),
  position: "relative",
}));

const BoxContainer = styled("div")(({ theme }) => ({
  backgroundImage: `url(${"/svg/Desktop.svg"})`,
  height: "255px",
  backgroundSize: "contain",
  backgroundRepeat: "no-repeat",
  backgroundPosition: "top center",
  // margin: "0px 15px",
  padding: "0px 10px",
  display: "flex",
  textAlign: "center",
  justifyContent: "center",

  [theme.breakpoints.down("sm")]: {
    // height: "280px",
  },
}));

export const CandidateSize: FC<CandidateSizeProps> = (
  props: CandidateSizeProps
) => {
  /** props */
  const { count } = props;
  const MobileView = useMediaQuery("(max-width:600px)");
  return (
    <Container>
      <BoxContainer>
        <Typography
          variant="body1"
          paddingTop={3}
          maxWidth={306}
          overflow="hidden"
        >
          You don’t need a consulting firm to set up an overseas office. Nor do
          you need freelancers or outsourcing agencies for global talent.
          Instantly deploy a <b> SecondOffice</b>. and directly hire your own
          global talent.
        </Typography>
      </BoxContainer>
    </Container>
  );
};
