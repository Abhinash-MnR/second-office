// React, Next packages
import React, { useEffect, useState } from "react";
import useCompany from "@lib/useCompany";
import { Typography, Box, Button } from "@mui/material";
import { putSettingsDetail } from "@api/expenses";
import { useRouter } from "next/router";

const steps = [
  {
    id: 1,
    title: "Book a Call",
    subTitle: "Instantly Deploy Your SecondOffice",
    button: "Book a Call",
    link: "https://calendly.com/secondoffice/booking?month=2022-06&back=1",
  },
  {
    id: 2,
    title: "Setup Profile",
    subTitle: "Setup Your Company Profile",
    button: "Setup Profile",
    link: "/profile/editProfile",
  },
  {
    id: 3,
    title: "Recruit Team",
    subTitle: "Recruit a new Team Member",
    button: "Post a Job",
    link: "/applications/jobs/add",
  },
];

function OnboardProgress() {
  const router = useRouter();

  // [Company Hooks]
  const { company } = useCompany();

  const [stepClicked, setStepClicked] = useState(0);

  useEffect(() => {
    if (
      company &&
      company.book_call_complete === "True" &&
      company &&
      company.create_profile_complete === "False"
    ) {
      setStepClicked(1);
    } else if (
      company &&
      company.book_call_complete === "True" &&
      company &&
      company.create_profile_complete === "True" &&
      company &&
      company.job_post_complete === "False"
    ) {
      setStepClicked(2);
    } else {
      setStepClicked(0);
    }
  }, [company]);

  return (
    <div>
      <Typography
        sx={{
          fontSize: { xs: "18px", sm: "24px" },
          fontWeight: 700,
          lineHeight: "150%",
          color: "#2C3058",
        }}
      >
        Complete these 3 steps to deploy your SecondOffice
      </Typography>

      {/* Box */}
      <Box
        sx={{
          backgroundColor: "#ffffff",
          border: "1.5px solid rgba(138, 142, 186, 0.32)",
          padding: { xs: "25px", sm: "35px 80px" },
          borderRadius: "10px",
          marginTop: { xs: "20px", sm: "30px" },
          display: "flex",
          justifyContent: "space-between",
          alignItems: "center",
        }}
      >
        <Box>
          {steps.map((step, index) => (
            <Box
              sx={index !== 0 ? { display: "flex" } : { display: "flex" }}
              key={index}
            >
              <Box
                sx={{
                  display: "flex",
                  flexDirection: "column",
                  alignItems: "center",
                }}
              >
                <Typography
                  sx={
                    (company &&
                      company.book_call_complete === "False" &&
                      step.id === 1) ||
                    (company &&
                      company.create_profile_complete === "False" &&
                      step.id === 2) ||
                    (company &&
                      company.job_post_complete === "False" &&
                      step.id === 3)
                      ? {
                          height: "24px",
                          width: "24px",
                          borderRadius: "50%",
                          backgroundColor: "#8A8EBA",
                          fontSize: "12px",
                          color: "#2C3058",
                          display: "flex",
                          justifyContent: "center",
                          alignItems: "center",
                        }
                      : {
                          height: "24px",
                          width: "24px",
                          borderRadius: "50%",
                          backgroundColor: "#2C3058",
                          fontSize: "12px",
                          color: "#FFFFFF",
                          display: "flex",
                          justifyContent: "center",
                          alignItems: "center",
                        }
                  }
                >
                  {step.id}
                </Typography>

                {step.id !== 3 && (
                  <div
                    style={
                      stepClicked === index
                        ? {
                            height: "110px",
                            width: 2,
                            backgroundColor: "#8A8EBA",
                            margin: "5px 0",
                            borderRadius: "10px",
                          }
                        : {
                            height: "18px",
                            width: 2,
                            backgroundColor: "#2C3058",
                            margin: "5px 0",
                            borderRadius: "10px",
                          }
                    }
                  />
                )}
              </Box>
              <Box sx={{ marginLeft: { xs: "16px", sm: "35px" } }}>
                <Typography
                  sx={
                    (company &&
                      company.book_call_complete === "False" &&
                      step.id === 1) ||
                    (company &&
                      company.create_profile_complete === "False" &&
                      step.id === 2) ||
                    (company &&
                      company.job_post_complete === "False" &&
                      step.id === 3)
                      ? {
                          fontSize: "16px",
                          color: "#2C3058",
                          lineHeight: "150%",
                          fontWeight: 500,
                          cursor: "pointer",
                        }
                      : {
                          fontSize: "16px",
                          color: "#2C3058",
                          lineHeight: "150%",
                          fontWeight: 500,
                          cursor: "pointer",
                        }
                  }
                  onClick={() => {
                    if (
                      ((company &&
                        company.book_call_complete === "False" &&
                        step.id === 1) ||
                        (company &&
                          company.create_profile_complete === "False" &&
                          step.id === 2) ||
                        (company &&
                          company.job_post_complete === "False" &&
                          step.id === 3)) &&
                      stepClicked !== index
                    ) {
                      setStepClicked(index);
                    } else {
                      setStepClicked(null);
                    }
                  }}
                >
                  {step.title}
                </Typography>
                {stepClicked === index && (
                  <Box>
                    <Typography
                      sx={{
                        fontSize: "14px",
                        color: "#4D4D4D",
                        lineHeight: "150%",
                        marginTop: "16px",
                        fontWeight: 400,
                      }}
                    >
                      {step.subTitle}
                    </Typography>
                    <Button
                      component="a"
                      variant="contained"
                      rel="noopener noreferrer"
                      target="_blank"
                      size="medium"
                      sx={{
                        border: "1px solid #2c3058",
                        padding: "9px 18px",
                        background: "#2C3058",
                        color: "#FFFFFF",
                        marginTop: "8px",
                        "&:hover": {
                          background: "#2C3058",
                        },
                      }}
                      onClick={async () => {
                        if (step.id === 1) {
                          window.open(step.link, "_blank");
                          await putSettingsDetail({
                            book_call_complete: "True",
                          });
                        } else {
                          router.push(step.link);
                        }
                      }}
                    >
                      {step.button}
                    </Button>
                  </Box>
                )}
              </Box>
            </Box>
          ))}
        </Box>

        <Box sx={{ display: { xs: "none", sm: "block" } }}>
          <img
            src={
              stepClicked === 0
                ? "/svg/stepsProgress1.svg"
                : stepClicked === 1
                ? "/svg/stepsProgress2.svg"
                : "/svg/stepsProgress3.svg"
            }
            alt="stepsProgress"
          />
        </Box>
      </Box>
    </div>
  );
}

export default OnboardProgress;
