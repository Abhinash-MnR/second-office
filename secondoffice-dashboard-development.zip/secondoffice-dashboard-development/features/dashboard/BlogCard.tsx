// React, Next packages
import React, { FC } from "react";
import Link from "next/link";
// Mui packages
import { styled, Grid } from "@mui/material";
// Common packages
// Third-party packages
import Slider from "react-slick";
import "slick-carousel/slick/slick.css";
import "slick-carousel/slick/slick-theme.css";

export type BlogCardProps = {
  /** Blog Section Title Props */
  title: string;
  thumbnail: string;
  author: string;
  slug: string;
};

const SectionContainer = styled("div")(({ theme }) => ({
  display: "flex",
  flexDirection: "column",
  background: "#f8f8f8",
}));
const BlogContainer = styled("div")(({ theme }) => ({
  borderRadius: theme.shape.borderRadius,
  // width: "364px",
  height: 350,
  display: "block",
  // flexDirection: "column",
  overflow: "hidden",
  background: "white",
  // boxShadow: "0px 16px 50px -4px rgba(145, 158, 171, 0.24)",

  border: "1px solid rgba(138, 142, 186, 0.3)",
  "&:hover": {
    boxShodow: "none",
    background: "#ECEDF4",
  },
  [theme.breakpoints.down("sm")]: {
    height: 335,
  },
}));

const CustomCardTitle = styled("div")(({ theme }) => ({
  display: "flex",
  flexDirection: "row",
  padding: "12px 16px",
  height: "80px",
  fontSize: 16,
  lineHeight: 1.5,
  color: "#222222",
  fontWeight: 500,
  [theme.breakpoints.down("sm")]: {
    padding: 10,
    fontSize: 14,
    lineHeight: 1.5,
    color: "#222222",
    fontWeight: 500,
  },
}));
const CardImageContainer = styled("div")(({ theme }) => ({
  display: "flex",
  flexDirection: "row",
  width: "100%",
  height: "260px",
  [theme.breakpoints.down("sm")]: {
    height: "252px",
    flexDirection: "column",
  },
}));

export const BlogCard = ({ blogdata }) => {
  // Blog Display
  const settings = {
    dots: true,
    infinite: true,
    arrows: false,
    speed: 1000,
    slidesToShow: 3,
    slidesToScroll: 3,
    autoplay: true,
    dotsClass: "slick-dots",
    responsive: [
      {
        breakpoint: 1024,
        settings: {
          slidesToShow: 3,
          slidesToScroll: 3,
          infinite: true,
          dots: true,
        },
      },
      {
        breakpoint: 600,
        settings: {
          slidesToShow: 2,
          slidesToScroll: 2,
          initialSlide: 2,
        },
      },
      {
        breakpoint: 480,
        settings: {
          slidesToShow: 1,
          slidesToScroll: 1,
        },
      },
    ],
  };

  return (
    <SectionContainer>
      <Slider {...settings}>
        {blogdata.map((blogItem: any, index: any) => (
          <Grid key={index} container columnSpacing={2}>
            <Grid item sm={12} >
              <Link href={`https://mckinleyrice.com/blog/${blogItem.slug}`}>
                <a target="_blank">
                  <BlogContainer>
                    <CardImageContainer>
                      <img
                        src={blogItem.thumbnail}
                        alt="Blog_Image"
                        width="100%"
                        style={{ objectFit: "cover", height: "inherit" }}
                      />
                    </CardImageContainer>
                    <CustomCardTitle>{blogItem.title}</CustomCardTitle>
                  </BlogContainer>
                </a>
              </Link>
            </Grid>
          </Grid>
        ))}
      </Slider>
    </SectionContainer>
  );
};
