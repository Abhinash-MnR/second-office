// React, Next packages
import React, { useState, useEffect } from "react";
import Link from "next/link";
import { useRouter } from "next/router";
// Mui packages
import {
  Button,
  Stack,
  styled,
  Typography,
  useMediaQuery,
  Box,
} from "@mui/material";
// Common packages

const CustomContainer = styled(Box)(({ theme }) => ({
  background: "#ECEDF4",
  borderRadius: theme.shape.borderRadius,
  width: "100%",
  height: 230,
  display: "flex",
  flexDirection: "column",
  padding: "20px 24px 10px 24px",
  alignItems: "center",
}));

const QuickActionContainer = styled("div")(() => ({
  display: "flex",
  flexDirection: "column",
}));

export const QuickActionCard = (props) => {
  // Component Data extracting from Props
  const { title, icon, buttonTitle, button_link, iconColor } = props;
  //** useState hooks */
  const [bgChangeOnHover, setBgChangeOnHover] = useState(false);
  //**useRoute hooks */
  const router = useRouter();
  //**useMediaQuery hooks */

  //** book a call*/
  const url = "https://calendly.com/secondoffice/booking?month=2022-03&back=1";
  //**new tab */
  const NewTab = () => {
    window.open(url, "_blank");
  };

  //**page redirect link */
  const PageRedirect = () => {
    router.push(button_link);
  };

  return (
    <Box
      bgcolor={bgChangeOnHover ? "#2c3058" : "#ECEDF4"}
      sx={{
        borderRadius: "10px",
        width: "100%",
        height: 230,
        display: "flex",
        flexDirection: "column",
        padding: "20px 24px 10px 24px",
        alignItems: "center",
      }}
      onMouseOver={() => setBgChangeOnHover(true)}
      onMouseLeave={() => setBgChangeOnHover(false)}
    >
      <QuickActionContainer>
        <Typography
          component="h4"
          variant="h4"
          textAlign="center"
          paddingX={2}
          color={bgChangeOnHover ? "#fff" : "primary.main"}
          sx={{
            fontSize: "18px",
            lineHeight: "150%",
            height: "60px",
          }}
        >
          {title}
        </Typography>
      </QuickActionContainer>
      <Stack direction="row" sx={{ marginTop: "20px", marginBottom: "20px" }}>
        <Typography>{bgChangeOnHover ? iconColor : icon}</Typography>
      </Stack>
      <Stack direction="column">
        <Button
          component="a"
          variant="contained"
          rel="noopener noreferrer"
          target="_blank"
          size="medium"
          sx={
            bgChangeOnHover
              ? {
                  border: "1px solid #fff",
                  width: "158px",
                  background: "#fff",
                  color: "#2c3058",
                  "&:hover": {
                    background: "#fff",
                  },
                }
              : {
                  border: "1px solid #2c3058",
                  width: "158px",
                  background: "#2c3058",
                  color: "#fff",
                }
          }
          onClick={url === button_link ? NewTab : PageRedirect}
        >
          {buttonTitle}
        </Button>
      </Stack>
    </Box>
  );
};
