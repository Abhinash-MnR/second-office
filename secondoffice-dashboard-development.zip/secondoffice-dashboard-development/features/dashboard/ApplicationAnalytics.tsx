// React, Next packages
import React, { FC } from "react";
// Mui packages
import { Chip, Stack, Typography } from "@mui/material";
// Third-party packages
import { ArrowIcon } from "@common/Icon";

type ApplicationAnalyticsProps = {
  /** title of graph */
  title: string;
  /** Count */
  count: number;
  /** Percentage count for applications */
  percentage: number;
};

export const ApplicationAnalytics: FC<ApplicationAnalyticsProps> = (
  props: ApplicationAnalyticsProps
) => {
  /** props */
  const { title, count, percentage } = props;

  /** custom handlers */
  const getLabels = () => {
    if (percentage > 0) {
      return {
        percentageChip: (
          <Chip
            color="secondary"
            size="small"
            label={
              <>
                {percentage}% <ArrowIcon sx={{ fontSize: 10 }} />
              </>
            }
          />
        ),
        description: "Increase since last week",
      };
    } else if (percentage < 0) {
      return {
        percentageChip: (
          <Chip
            color="error"
            size="small"
            label={
              <>
                {Math.abs(percentage)}%
                <ArrowIcon sx={{ fontSize: 10, transform: "rotate(90deg)" }} />
              </>
            }
          />
        ),
        description: "Decrease since last week",
      };
    } else {
      return {
        percentageChip: <Chip size="small" label="--%" />,
        description: "No change since last week",
      };
    }
  };

  const { percentageChip, description } = getLabels();

  return (
    <Stack width={1} minWidth="200px">
      <Typography variant="subtitle1" marginBottom={0.625}>
        {title}
      </Typography>
      <Stack alignItems="center" direction="row" marginBottom={0.625}>
        <Typography
          color="primary"
          fontWeight="bold"
          variant="h4"
          marginRight={1.25}
        >
          {count}
        </Typography>
        {percentageChip}
      </Stack>
      <Typography component="div" variant="caption">
        {description}
      </Typography>
    </Stack>
  );
};
