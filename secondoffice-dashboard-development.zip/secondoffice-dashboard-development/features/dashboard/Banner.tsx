// React, Next packages
import React from "react";
import Link from "next/link";
// Mui packages
import {
  Button,
  styled,
  Typography,
  useMediaQuery,
  Stack,
} from "@mui/material";
// Common packages

const BannerContainer = styled("div")(({ theme }) => ({
  background: "#ECEDF4",
  borderRadius: theme.shape.borderRadius,
  width: "100%",
  height: 230,
  display: "flex",
  justifyContent: "space-between",
  overflow: "hidden",
  [theme.breakpoints.down("sm")]: {
    width: "100%",
    height: "auto",
  },
}));
const ContentContainer = styled("div")(({ theme }) => ({
  padding: 30,
  display: "flex",
  flexDirection: "column",
  overflow: "hidden",
  [theme.breakpoints.down("sm")]: {
    display: "flex",
    alignItems: "center",
    textAlign: "center",
    padding: 20,
  },
}));
const ImageContainer = styled("div")(({ theme }) => ({
  display: "flex",
  flexDirection: "column",
  padding: "20px 30px 0px 30px",
  overflow: "hidden",
  [theme.breakpoints.down("sm")]: {
    display: "none",
    overflow: "hidden",
  },
}));

export const DashboardBanner = () => {
  const isMobile = useMediaQuery("(max-width:600px)");
  return (
    <BannerContainer>
      <ContentContainer>
        <Typography component="h3" variant="h3">
          Instantly Deploy Your SecondOffice
        </Typography>
        <Typography
          component="p"
          variant="body1"
          paddingY={{ xs: 1, sm: 1 }}
          width={{ xs: "auto", sm: "410px" }}
        >
          We set up the office, so you don’t have to establish yourself abroad.
        </Typography>
        <Stack
          alignSelf="start"
          marginBottom={isMobile ? 0.5 : 0}
          marginTop={{ xs: 3.77, sm: 3.77 }}
          alignItems={{ xs: "center", sm: "flex-start" }}
          width={{ xs: "100%", sm: "100%" }}
        >
          <Link
            href="https://calendly.com/secondoffice/booking?month=2022-02&back=1"
            passHref
          >
            <Button
              component="a"
              variant="contained"
              rel="noopener noreferrer"
              target="_blank"
              size="medium"
              sx={{ border: "1px solid white" }}
            >
              Book Now
            </Button>
          </Link>
        </Stack>
      </ContentContainer>
      <ImageContainer>
        <img src="/Images/banner_SO.svg" alt="Banner_Image" />
      </ImageContainer>
    </BannerContainer>
  );
};
