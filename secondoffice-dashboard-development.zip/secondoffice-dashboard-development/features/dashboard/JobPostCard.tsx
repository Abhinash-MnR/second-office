// React, Next packages
import React, { FC } from "react";
// Mui packages
import { Box, Grid, Stack, styled, Typography } from "@mui/material";
// Common packages
import { ClockIcon, LocationIcon, PeopleIcon, RupeeIcon } from "@common/Icon";
import { formatDeadline, formatUnderscore } from "@lib/formatter";

type JobPostCardProps = {
  /** Number of applicants */
  applicants: string | number;
  /** Job closing date */
  deadline: string;
  /** Employment type of the job */
  employmentType: string;
  /** Job position location */
  location?: string;
  /** Job position title */
  position: string;
  /** Starting value of job's salary range  */
  salaryStart: number | string;
  /** Ending value of job's salary range  */
  salaryEnd: number | string;
};

const JobPostContainer = styled("div")(({ theme }) => ({
  borderRadius: theme.shape.borderRadius,
  background: "#ffffff",
  padding: theme.spacing(1.25),
  marginBottom: theme.spacing(1.25),
  MozUserSelect: "-moz-none",
  WebkitUserSelect: "none",
  userSelect: "none",
  msUserSelect: "none",
  "&:hover": {
    background: "#efefef",
  },
}));

const StackItem = styled("div")(({ theme }) => ({
  alignItems: "center",
  color: theme.palette.grey[500],
  display: "flex",
  marginBottom: 5,
  marginRight: 20,

  "& :first-of-type": {
    fontSize: 14,
    marginRight: 5,
  },
}));

export const JobPostCard: FC<JobPostCardProps> = (props: JobPostCardProps) => {
  /** props */
  const {
    applicants,
    deadline,
    employmentType,
    location,
    position,
    salaryStart,
    salaryEnd,
  } = props;

  return (
    <JobPostContainer>
      <Typography variant="subtitle1" color="primary.main" marginBottom={1.25}>
        {position}
      </Typography>
      <Stack
        alignItems="center"
        direction="row"
        flexWrap="wrap"
        marginBottom={0.625}
      >
        <StackItem>
          <RupeeIcon />
          <Typography component="div" variant="caption" color="text.secondary">
            {`${salaryStart}-${salaryEnd} LPA`}
          </Typography>
        </StackItem>
        <StackItem>
          <ClockIcon />
          <Typography component="div" variant="caption" color="text.secondary">
            {formatUnderscore(employmentType)}
          </Typography>
        </StackItem>
        <StackItem>
          <LocationIcon />
          <Typography component="div" variant="caption" color="text.secondary">
            {location}
          </Typography>
        </StackItem>
      </Stack>
      <Stack direction="row" justifyContent="space-between">
        <Typography fontWeight="600" component="div" variant="caption" color="primary.main">
          <PeopleIcon
            fontSize="small"
            sx={{ verticalAlign: "text-top", marginRight: 0.625 }}
          />
          {applicants} Applicants
        </Typography>
        <Typography
          component="div"
          color="error"
          fontWeight="600"
          variant="caption"
        >
          {formatDeadline(deadline)} days left
        </Typography>
      </Stack>
    </JobPostContainer>
  );
};
