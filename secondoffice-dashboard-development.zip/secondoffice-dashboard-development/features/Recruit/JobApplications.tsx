import React from "react";

function JobApplications() {
  return <div>Welcome on Job Application Componnent</div>;
}

export default JobApplications;
