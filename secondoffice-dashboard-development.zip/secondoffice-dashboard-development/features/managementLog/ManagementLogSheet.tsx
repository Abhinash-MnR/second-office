// React, Next packages
import React from "react";
import dynamic from "next/dynamic";
import useCompany from "@lib/useCompany";
// Mui packages
import { Typography, Box } from "@mui/material";
// Third party packages
import { useTranslation } from "react-i18next";
import "translation/i18n";
import Iframe from "react-iframe";
// Custom packages
import NoOfficeData from "features/officeManagement/NoOfficeData";

function ManagementLogSheet() {
  //** Custom hooks */
  const { company } = useCompany();
  //** Language translation hooks */
  const { t } = useTranslation();

  return (
    <Box>
      <Typography component="h3" variant="h3">
        {t("office_management_log_title")}
      </Typography>

      {company && company.management_log_link ? (
        <Box sx={{ height: "calc(100vh - 240px)", marginTop: "40px" }}>
          <Iframe
            url=""
            src={company.management_log_link}
            width="100%"
            height="100%"
            id="myId"
            className="myClassname"
            loading="lazy"
            referrerpolicy="no-referrer-when-downgrade"
          />
        </Box>
      ) : (
        <NoOfficeData
          title={`${t("management_logs_empty_screen_title")}`}
          imgName="managementLog"
        />
      )}
    </Box>
  );
}

export default ManagementLogSheet;
