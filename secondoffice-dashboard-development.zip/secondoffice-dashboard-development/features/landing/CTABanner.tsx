// React, Next packages
import React, { FC } from "react";
import Link from "next/link";
// Mui packages
import { Box, Button, Container, Grid, Typography } from "@mui/material";

type CTABannerProps = {};

export const CTABanner: FC<CTABannerProps> = (props: CTABannerProps) => {
  /** props */
  const {} = props;

  return (
    <Box component="section" bgcolor="#111F3A" marginTop={15}>
      <Container>
        <Grid
          alignItems="flex-end"
          justifyContent="space-between"
          container
          spacing={2}
        >
          <Grid item xs={12} sm={6}>
            <Typography
              color="background.default"
              marginTop={12}
              variant="h3"
              sx={{
                "&::after": {
                  content: "''",
                  background: (theme) => theme.palette.background.default,
                  display: "block",
                  height: 2,
                  marginBottom: 3,
                  marginTop: 2,
                  width: 40,
                },
              }}
            >
              Numbers don&apos;t lie
            </Typography>
            <Typography
              color="background.default"
              fontWeight="normal"
              marginBottom={5}
              variant="body1"
              sx={{
                "& b": {
                  color: (theme) => theme.palette.secondary.main,
                },
              }}
            >
              <b>30,000+</b> users, <b>2,000</b> applications in just a few
              months!
              <br />- CareerChat is growing at an ever-increasing rate.
            </Typography>
            <Link
              href="https://careerchat.medium.com/the-first-tool-job-portal-a579d981da8f"
              passHref
            >
              <Button
                component="a"
                color="primary"
                size="large"
                sx={{ marginBottom: 15 }}
                variant="contained"
              >
                Learn the Analytics
              </Button>
            </Link>
          </Grid>
          <Grid item xs={12} sm={5}>
            <img
              src="https://cdn.careerchat.me/careerchat/landing/company/rocket.svg"
              width="100%"
              style={{ verticalAlign: "bottom" }}
            />
          </Grid>
        </Grid>
      </Container>
    </Box>
  );
};
