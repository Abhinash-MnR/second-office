// React, Next packages
import React, { FC } from "react";
import Link from "next/link";
import { UrlObject } from "url";
// Mui packages
import { Avatar, styled, Typography } from "@mui/material";

type ImageCardProps = {
  href: string | UrlObject;
  picture?: string;
  subtitle: string;
  title: string;
  tall?: boolean;
};

const CardContainer = styled("a")({
  cursor: "pointer",
  display: "flex",
  flexDirection: "column",
  alignItems: "center",
});

export const ImageCard: FC<ImageCardProps> = ({
  href,
  picture,
  subtitle,
  title,
  tall,
}: ImageCardProps) => {
  return (
    <Link href={href} passHref>
      <CardContainer>
        <Avatar
          sx={{ width: "auto", height: 175, marginBottom: 5 }}
          src={picture}
          variant="square"
        />
        <Typography variant="h5" marginBottom={2}>
          {title}
        </Typography>
        <Typography color="grey.600" textAlign="center" variant="body1">
          {subtitle}
        </Typography>
      </CardContainer>
    </Link>
  );
};
