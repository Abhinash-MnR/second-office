// React, Next packages
import React, { FC } from "react";
// Mui packages
import { Avatar, Box, Typography, styled } from "@mui/material";

type TestimonialProps = {
  picture?: string;
  name: string;
  position: string;
  body: string;
};

const CardAvatar = styled(Avatar)(({ theme }) => ({
  root: {
    width: 42,
    height: 42,
  },
}));

export const Testimonial: FC<TestimonialProps> = ({
  picture,
  name,
  position,
  body,
}: TestimonialProps) => {
  return (
    <Box alignItems="center" display="flex" flexDirection="column" p={7}>
      <Box mb={4} display="flex">
        <CardAvatar src={picture} />
        <Box
          display="flex"
          flexDirection="column"
          justifyContent="space-between"
          ml={2.25}
        >
          <Typography color="textPrimary" variant="h5">
            {name}
          </Typography>
          <Typography color="textSecondary" variant="body2">
            {position}
          </Typography>
        </Box>
      </Box>
      <Typography variant="h3" align="center">
        {body}
      </Typography>
    </Box>
  );
};
