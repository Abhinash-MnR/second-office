// React, Next packages
import React, { FC } from "react";
import Link from "next/link";
// Mui packages
import { Button, Grid, Typography } from "@mui/material";

type HeroProps = {
  /** Link redirected on click of the CTA */
  href?: string;
};

export const Hero: FC<HeroProps> = (props: HeroProps) => {
  /** props */
  const { href } = props;

  return (
    <Grid alignItems="center" container justifyContent="space-between" my={12}>
      <Grid item md={5}>
        <Typography
          color="primary"
          marginTop={5}
          marginBottom={3.75}
          sx={{
            "&::after": {
              content: "''",
              background: (theme) => theme.palette.text.primary,
              display: "block",
              height: 2,
              marginTop: 1.25,
              width: 40,
            },
          }}
          variant="h6"
        >
          CareerChat | Recruiters
        </Typography>
        <Typography
          variant="h3"
          marginBottom={3.75}
          sx={{
            "& b": {
              color: (theme) => theme.palette.primary.main,
            },
          }}
        >
          Looking for
          <br />
          <b>Personalized</b>
          <br />
          Recruitment?
        </Typography>
        <Typography
          color="grey.600"
          fontWeight="normal"
          marginBottom={5}
          variant="h6"
        >
          CareerChat lets you hire what you require! Directly approach top
          candidates with the required skillset through our dashboard.
        </Typography>
        <Link href={href} passHref>
          <Button
            component="a"
            color="primary"
            size="large"
            variant="contained"
            sx={{ marginBottom: 5 }}
          >
            Get Started
          </Button>
        </Link>
      </Grid>
      <Grid item md={7}>
        <img
          width="100%"
          src="https://cdn.careerchat.me/careerchat/landing/company/jp_landing.png"
        />
      </Grid>
    </Grid>
  );
};
