// React, Next packages
import React from "react";
import dynamic from "next/dynamic";
import Link from "next/link";
import { useRouter } from "next/router";
// Mui packages
import {
  styled,
  Typography,
  Stack,
  Button,
  useMediaQuery,
} from "@mui/material";
// Third party packages
import { useTranslation } from "react-i18next";
import "translation/i18n";

const BannerContainer = styled("div")(({ theme }) => ({
  background: "#ECEDF4",
  borderRadius: theme.shape.borderRadius,
  width: "100%",
  height: 230,
  display: "flex",
  justifyContent: "space-between",
  overflow: "hidden",
  [theme.breakpoints.down("sm")]: {
    width: "100%",
    height: "210px",
  },
}));
const ContentContainer = styled("div")(({ theme }) => ({
  padding: 30,
  display: "flex",
  flexDirection: "column",
  overflow: "hidden",
  [theme.breakpoints.down("sm")]: {
    display: "flex",
    alignItems: "center",
    textAlign: "center",
    padding: 20,
  },
}));
const ImageContainer = styled("div")(({ theme }) => ({
  display: "flex",
  flexDirection: "column",
  padding: "0px 30px 0px 30px",
  overflow: "hidden",
  [theme.breakpoints.down("sm")]: {
    display: "none",
    overflow: "hidden",
  },
}));

function RecruitBanner() {
  const isMobile = useMediaQuery("(max-width:600px)");
  const router = useRouter();
  //**language translation hooks */
  const { t } = useTranslation();

  return (
    <BannerContainer>
      <ContentContainer>
        <Typography component="h3" variant="h3">
          {t("recruit_banner_title")}
        </Typography>
        <Typography
          component="p"
          variant="body1"
          paddingY={{ xs: 1, sm: 1 }}
          width={{ xs: "auto", sm: "410px" }}
        >
          {t("recruit_banner_desc")}
        </Typography>
        <Stack
          alignSelf="start"
          marginBottom={isMobile ? 0.5 : 0}
          marginTop={{ xs: 3.77, sm: 3.77 }}
          alignItems={{ xs: "center", sm: "flex-start" }}
          width={{ xs: "100%", sm: "100%" }}
        >
          <Button
            component="a"
            variant="contained"
            rel="noopener noreferrer"
            target="_blank"
            size="medium"
            onClick={() => router.push("/applications/jobs/add")}
          >
            {t("recruit_button_title")}
          </Button>
        </Stack>
      </ContentContainer>
      <ImageContainer>
        <img src="/Images/Post_illustration.svg" alt="Banner_Image" />
      </ImageContainer>
    </BannerContainer>
  );
}

export default RecruitBanner;
