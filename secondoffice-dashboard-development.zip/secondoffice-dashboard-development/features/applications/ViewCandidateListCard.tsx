// React , Next js packages
import React, { useState, useEffect } from "react";
import { useRouter } from "next/router";
// MUI Packages
import {
  Box,
  Avatar,
  Stack,
  Typography,
  Divider,
  useMediaQuery,
} from "@mui/material";
import Link from "next/link";
// Third party packages
import { useTranslation } from "react-i18next";
import "translation/i18n";
import moment from "moment";
// Custom components
import useCompany from "@lib/useCompany";
import useCurrency from "@lib/useCurrency";
import {
  EURIconColor,
  INRIconColor,
  KRWIconColor,
  USDIconColor,
} from "@common/Icon";
import { ChevronRightIcon } from "@common/Icon";
import JobsApplicantActions from "./JobsApplicantActions";

function ViewCandidateListCard(props) {
  /** third-party hooks */
  const { company } = useCompany();
  const router = useRouter();

  //** Language translation hooks */
  const { t } = useTranslation();

  //** useCurrency hooks */
  const { currency } = useCurrency();
  //** props - components */
  const { activeTab, application, applicationCount, candidateList } = props;
  //** useMedia Query hooks */
  const isMobile = useMediaQuery("(man-width:600px)");
  //** useState hooks */
  const [actions, setActions] = useState("shortlisted");
  const [rightColumnFix, setRightColumnFix] = useState(false);

  //** handleChangeActions */
  const handleChangeActions = (e) => {
    setActions(e.target.value);
  };
  //** fixed right side column */
  const fixedColumn = () => {
    if (window.scrollY >= 280) {
      setRightColumnFix(true);
    } else {
      setRightColumnFix(false);
    }
  };

  useEffect(() => {
    window.addEventListener("scroll", fixedColumn);
  }, [rightColumnFix]);

  // console.log(rightColumnFix, "check scroll");

  // console.log(activeTab, "findount my active tab");

  //** month list */
  const monthList = [
    `${t("january_title")}`,
    `${t("february_title")}`,
    `${t("march_title")}`,
    `${t("april_title")}`,
    `${t("may_title")}`,
    `${t("june_title")}`,
    `${t("july_title")}`,
    `${t("august_title")}`,
    `${t("september_title")}`,
    `${t("october_title")}`,
    `${t("november_title")}`,
    `${t("december_title")}`,
  ];

  return (
    <Box
      sx={
        rightColumnFix === true
          ? {
              position: { xs: "relative", sm: "sticky" },
              top: { xs: "unset", sm: 90 },
              overflow: "hidden",
              width: { xs: "100%", sm: "580px" },
            }
          : {
              position: "relative",
            }
      }
    >
      {application.map((data, index) => {
        //const date define
        const multiLanguageDateFormat = moment(data?.offer_date).format("MMMM");
        // day and year format
        const dayYearFormat = moment(data?.offer_date).format(
          "DD,YYYY hh:mm A"
        );
        {
          return (
            activeTab === index && (
              <Box
                bgcolor={`grey.100`}
                border="1px solid rgba(140, 142, 186, 0.3)"
                borderTop={
                  data.applicant_status === "hired" ||
                  data.applicant_status === "Hired"
                    ? "10px solid #E4FCCA"
                    : data.applicant_status === "rejected" ||
                      data.applicant_status === "Rejected" ||
                      data.applicant_status === "Reconsideration" ||
                      data.applicant_status === "reconsideration" ||
                      data.applicant_status === "Withdrew Application" ||
                      data.applicant_status === "withdrew_application"
                    ? "10px solid #FFE7D9"
                    : data.applicant_status === "client_round" ||
                      data.applicant_status === "Client Round" ||
                      data.applicant_status === "Client Review" ||
                      data.applicant_status === "client_review" ||
                      data.applicant_status === "Technical Round" ||
                      data.applicant_status === "technical_round" ||
                      data.applicant_status === "Cultural Round" ||
                      data.applicant_status === "cultural_round" ||
                      data.applicant_status === "Shortlisted" ||
                      data.applicant_status === "Shortlisted" ||
                      data.applicant_status === "online_technical_assessment" ||
                      data.applicant_status === "Online Technical Assessment"
                    ? "10px solid #FFF7CD"
                    : data.applicant_status === "offer_made" ||
                      data.applicant_status === "Offer Made"
                    ? "10px solid  #D0F2FF"
                    : "10px solid #ECEDF4"
                }
                borderRadius={1.25}
                py={3.75}
                px={3.75}
                position={`relative`}
              >
                <Box
                  display={`flex`}
                  alignItems={`start`}
                  flexWrap={{ xs: "wrap", sm: "unset" }}
                  justifyContent={{ xs: "center", sm: "unset" }}
                >
                  <Stack direction={`row`}>
                    {/* candidate name first letter will be profile icon */}

                    <Avatar
                      sx={{
                        bgcolor: `#DFA718`,
                        width: { xs: "34px", sm: `66px` },
                        height: { xs: "34px", sm: `66px` },
                      }}
                    >
                      <Typography variant="h3" color={`grey.100`}>
                        {data.applicant_name.charAt(0).toUpperCase()}
                      </Typography>
                    </Avatar>
                    {/* <img
                      src={"/svg/candidateProfileImg.svg"}
                      alt="profile"
                      width={82}
                      height={82}
                    /> */}
                  </Stack>
                  <Stack direction={`row`} flexGrow={`1`}>
                    {/* candidate details column */}
                    <Box
                      display={`flex`}
                      flexDirection={`column`}
                      ml={3.75}
                      flexGrow={1}
                    >
                      <Typography variant="h4" color={`primary.main`}>
                        {data.applicant_name}
                      </Typography>
                      <Stack direction="row" mt={0.5}>
                        <Typography variant="subtitle2">
                          {t("view_candidates_table_head_exp")} :{" "}
                        </Typography>
                        <Typography variant="body2" ml={`4px`}>
                          {" "}
                          {data.year_of_experience} {t("candidate_exp")}
                        </Typography>
                      </Stack>
                      <Stack direction={`row`} mt={1}>
                        <Typography variant="button" color={`primary.main`}>
                          {t("view_candidates_table_head_cultural")} :
                        </Typography>
                        <Typography
                          variant="button"
                          ml={1.5}
                          textTransform="capitalize"
                          px={2.5}
                          py={0.1}
                          borderRadius={`20px`}
                          color={
                            data.cvr_status === "pass"
                              ? `#54D62C`
                              : data.cvr_status === "priority_2"
                              ? "#2c3058"
                              : "error"
                          }
                          border={
                            data.cvr_status === "pass"
                              ? `1px solid #54D62C`
                              : data.cvr_status === "priority_2"
                              ? "1px solid #2c3058"
                              : "1px solid #D20000"
                          }
                          bgcolor={
                            data.cvr_status === "pass"
                              ? `#EDFDDB`
                              : data.cvr_status === "priority_2"
                              ? "#fff"
                              : "rgb(255 239 229)"
                          }
                        >
                          {data.cvr_status === "priority_2" ||
                          data.cvr_status === "na"
                            ? `${t("candidate_status_pending")}`
                            : data.cvr_status === "pass"
                            ? `${t("candidate_cvr_status_pass")}`
                            : data.cvr_status === "fail"
                            ? `${t("candidate_cvr_status_fail")}`
                            : null}
                        </Typography>
                      </Stack>
                    </Box>
                  </Stack>
                  <Stack direction={`row`}>
                    <Link href={data.applicant_resume}>
                      <a target={`_blank`}>
                        <Typography
                          variant="body2"
                          mt={1}
                          color={`primary.main`}
                          sx={{
                            fontWeight: 600,
                            display: "flex",
                            alignItems: "center",
                          }}
                        >
                          {t("view_candidate_view_resume_title")}
                          <ChevronRightIcon sx={{ fontSize: "14px" }} />
                        </Typography>
                      </a>
                    </Link>
                  </Stack>
                </Box>
                <Stack direction={`column`} mt={2.5}>
                  <Divider />
                </Stack>
                <Box
                  display={`flex`}
                  flexDirection={{ xs: "column", sm: "row" }}
                  marginY={{ xs: 2, sm: "unset" }}
                >
                  <Stack
                    direction={`row`}
                    justifyContent={`space-between`}
                    width={{ xs: "100%", sm: "50%" }}
                    alignItems={`center`}
                  >
                    <Typography variant="subtitle2" color={`#696E9C`}>
                      {t("view_candidates_table_head_ctc")}
                    </Typography>
                    {/* <Typography>{data.cTC}</Typography> */}
                    <Typography
                      variant="body2"
                      mt={0.5}
                      sx={{
                        fontWeight: 400,
                        color: "#222222",
                        display: "flex",
                        alignItems: "center",
                      }}
                    >
                      {company && currency && company.currency === "KRW" ? (
                        <KRWIconColor sx={{ fontSize: "14px" }} />
                      ) : company && currency && company.currency === "USD" ? (
                        <USDIconColor sx={{ fontSize: "14px" }} />
                      ) : company && currency && company.currency === "EUR" ? (
                        <EURIconColor sx={{ fontSize: "14px" }} />
                      ) : (
                        <INRIconColor sx={{ fontSize: "14px" }} />
                      )}

                      {company && currency && company.currency === "KRW"
                        ? Math.round(
                            data?.cTC * currency.currency_krw
                          ).toLocaleString()
                        : company && currency && company.currency === "USD"
                        ? Math.round(
                            (data?.cTC * currency.currency_usd) / 1000
                          ).toLocaleString()
                        : company && currency && company.currency === "EUR"
                        ? Math.round(
                            (data?.cTC * currency.currency_eur) / 1000
                          ).toLocaleString()
                        : (data?.cTC / 100000).toFixed(2)}

                      {company && currency && company.currency === "KRW"
                        ? ""
                        : company && currency && company.currency === "USD"
                        ? " K"
                        : company && currency && company.currency === "EUR"
                        ? "K"
                        : " LPA"}
                    </Typography>
                  </Stack>

                  {isMobile ? (
                    <Divider
                      sx={{
                        borderColor: "#8C8EBA",
                        opacity: 0.3,
                      }}
                    />
                  ) : (
                    <Divider
                      flexItem={true}
                      orientation={"vertical"}
                      sx={{
                        borderColor: "#8C8EBA",
                        opacity: 0.3,
                        mx: { sm: "20px" },
                        height: { sm: "60px" },
                      }}
                    />
                  )}
                  <Stack
                    direction={`row`}
                    width={{ xs: "100%", sm: "50%" }}
                    justifyContent={`space-between`}
                    alignItems={`center`}
                  >
                    <Typography variant="subtitle2" color={`#696E9C`}>
                      {t("view_candidates_table_head_ectc")}
                    </Typography>
                    {/* <Typography>{data.eCTC}</Typography> */}
                    <Typography
                      variant="body2"
                      mt={0.5}
                      sx={{
                        fontWeight: 400,
                        color: "#222222",
                        display: "flex",
                        alignItems: "center",
                      }}
                    >
                      {company && currency && company.currency === "KRW" ? (
                        <KRWIconColor sx={{ fontSize: "14px" }} />
                      ) : company && currency && company.currency === "USD" ? (
                        <USDIconColor sx={{ fontSize: "14px" }} />
                      ) : company && currency && company.currency === "EUR" ? (
                        <EURIconColor sx={{ fontSize: "14px" }} />
                      ) : (
                        <INRIconColor sx={{ fontSize: "14px" }} />
                      )}

                      {company && currency && company.currency === "KRW"
                        ? Math.round(
                            data?.eCTC * currency.currency_krw
                          ).toLocaleString()
                        : company && currency && company.currency === "USD"
                        ? Math.round(
                            (data?.eCTC * currency.currency_usd) / 1000
                          ).toLocaleString()
                        : company && currency && company.currency === "EUR"
                        ? Math.round(
                            (data?.eCTC * currency.currency_eur) / 1000
                          ).toLocaleString()
                        : (data?.eCTC / 100000).toFixed(2)}

                      {company && currency && company.currency === "KRW"
                        ? ""
                        : company && currency && company.currency === "USD"
                        ? " K"
                        : company && currency && company.currency === "EUR"
                        ? "K"
                        : " LPA"}
                    </Typography>
                  </Stack>
                </Box>
                {/* Notice period */}
                <Stack direction={`column`}>
                  <Divider />
                </Stack>
                <Stack direction={`row`} py={2.5}>
                  <Typography
                    variant="subtitle2"
                    color={`#696E9C`}
                    width={`40%`}
                  >
                    {t("view_candidates_table_head_notice")}
                  </Typography>
                  <Typography variant="body2">
                    {data.applicant_notice_period}
                  </Typography>
                </Stack>
                {/* offered date and time */}
                <Stack direction={`column`}>
                  <Divider />
                </Stack>
                <Stack
                  direction={`row`}
                  justifyContent={`space-between`}
                  py={2.5}
                  width={data.offer_date === null ? "53%" : "66%"}
                >
                  <Typography variant="subtitle2" color={`#696E9C`}>
                    {t("view_candidates_table_head_offer")}
                  </Typography>
                  <Typography variant="body2">
                    {/* {data.offer_date === null ? "-" : data.offer_date} */}
                    {multiLanguageDateFormat === "January"
                      ? monthList[0].concat(" ", dayYearFormat)
                      : multiLanguageDateFormat === "February"
                      ? monthList[1].concat(" ", dayYearFormat)
                      : multiLanguageDateFormat === "March"
                      ? monthList[2].concat(" ", dayYearFormat)
                      : multiLanguageDateFormat === "April"
                      ? monthList[3].concat(" ", dayYearFormat)
                      : multiLanguageDateFormat === "May"
                      ? monthList[4].concat(" ", dayYearFormat)
                      : multiLanguageDateFormat === "June"
                      ? monthList[5].concat(" ", dayYearFormat)
                      : multiLanguageDateFormat === "July"
                      ? monthList[6].concat(" ", dayYearFormat)
                      : multiLanguageDateFormat === "August"
                      ? monthList[7].concat(" ", dayYearFormat)
                      : multiLanguageDateFormat === "September"
                      ? monthList[8].concat(" ", dayYearFormat)
                      : multiLanguageDateFormat === "October"
                      ? monthList[9].concat(" ", dayYearFormat)
                      : multiLanguageDateFormat === "November"
                      ? monthList[10].concat(" ", dayYearFormat)
                      : multiLanguageDateFormat === "December"
                      ? monthList[11].concat(" ", dayYearFormat)
                      : "-"}
                  </Typography>
                </Stack>
                {/* Second office comments */}
                <Stack direction={`column`} pb={2.5}>
                  <Divider />
                </Stack>
                <Stack direction={`column`}>
                  <Typography
                    variant="body2"
                    color={`#696E9C`}
                    fontWeight={600}
                  >
                    {t("view_candidates_table_head_comments")}
                  </Typography>
                  <Typography variant="body2" mt={1}>
                    {data.additional_comments === ""
                      ? "No Comments"
                      : data.additional_comments}
                  </Typography>
                </Stack>
                <Stack direction={`column`} mt={2.5} mb={2.5}>
                  <Divider />
                </Stack>
                <Stack direction={`column`} mt={1}>
                  <Typography variant="button" color={`primary.main`} mb={1}>
                    {t("view_candidates_table_head_action")}
                  </Typography>
                  <JobsApplicantActions
                    cvrStatus={data.cvr_status}
                    status={data.applicant_actions}
                    applicationId={data.id}
                  />
                </Stack>
              </Box>
            )
          );
        }
      })}
    </Box>
  );
}

export default ViewCandidateListCard;
