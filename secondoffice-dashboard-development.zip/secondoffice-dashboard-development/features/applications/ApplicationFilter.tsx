// React, Next packages
import React, { FC } from "react";
import { Form, Field } from "react-final-form";
// Mui packages
import { ButtonBase, InputBase, styled, Typography } from "@mui/material";
import { ArrowForward, Search } from "@mui/icons-material";

export type ApplicationFilterProps = {
  /** Callback triggered when data is submitted */
  onSubmit: (...params: any) => void;
  /** Label in the input to provide hints for users */
  placeholder?: string;
};

const SearchField = ({ input, ...rest }) => (
  <InputBase
    {...rest}
    inputProps={{ ...input }}
    startAdornment={<Search sx={{ marginRight: "10px" }} htmlColor="#5E6167" />}
    fullWidth
    endAdornment={
      <ButtonBase type="submit">
        <ArrowForward
          htmlColor="white"
          style={{
            borderRadius: 5,
            background: "#5664F1",
            fontSize: "1.875rem",
            padding: 3,
          }}
        />
      </ButtonBase>
    }
  />
);

const FormContainer = styled("form")({
  alignItems: "center",
  display: "inline-flex",
  marginBottom: 40,
  width: "100%",
});

const StyledField = styled(Field)({
  marginLeft: 20,
  background: "#FFFFFF",
  border: "2px solid #E5E5E5",
  borderRadius: 15,
  padding: "6px 20px",

  ["& .MuiInputBase-input"]: {
    "&::placeholder": {
      color: "rgba(40, 44, 52, 0.25)",
      fontWeight: 600,
      opacity: 1,
    },
  },
});

export const ApplicationFilter: FC<ApplicationFilterProps> = (
  props: ApplicationFilterProps
) => {
  /** props */
  const { placeholder, onSubmit } = props;

  return (
    <Form onSubmit={onSubmit}>
      {({ handleSubmit }) => (
        <FormContainer onSubmit={handleSubmit}>
          <Typography
            sx={{ color: "#282C3480", flexShrink: 0 }}
            component="label"
            variant="body1"
          >
            Search by
          </Typography>
          <StyledField
            component={SearchField}
            placeholder={placeholder}
            name="search"
          />
        </FormContainer>
      )}
    </Form>
  );
};
