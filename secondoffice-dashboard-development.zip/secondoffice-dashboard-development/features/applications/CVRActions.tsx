// React, Next packages
import React, { useState } from "react";
import { connect } from "react-redux";
import { Dispatch } from "redux";
import { RootState } from "reducers";

// Mui packages
import { MenuItem, Select, styled } from "@mui/material";

// Custom Component
import {
  clearApplications,
  editApplication,
  listApplication,
} from "reducers/applicationsSlice";
import cvrActionsData from "data/cvrActionsData";

// 3Rd Party Component/Packages
import { useSnackbar } from "notistack";

const SectionContainer = styled("div")(({ theme }) => ({
  display: "flex",
  flexDirection: "column",
}));

function CVRActions(props) {
  /* Jobs Applicants Status */
  const { status, applicationId } = props;

  /* Closed Jobs State */
  const [cvrAction, setCvrAction] = useState(humanize(status));

  /** third-party hooks */
  const { enqueueSnackbar } = useSnackbar();

  /** useState hooks */
  const [isUpdating, setIsUpdating] = useState(false);
  const [isActionSelected, setIsActionSelected] = useState("");

  /** props - actions */
  const { editApplication } = props;

  /* Jobs open and Close Handle */
  const handleChangeJobs = (e) => {
    setCvrAction(e.target.value);
    handleApplicantAction(applicationId, e.target.value);
    console.log("open and close jobs");
  };

  function humanize(str: string) {
    var i,
      frags = str?.split("_");
    for (i = 0; i < frags?.length; i++) {
      frags[i] = frags[i]?.charAt(0)?.toUpperCase() + frags[i]?.slice(1);
    }
    return frags?.join(" ");
  }

  function postStringCreate(str: string) {
    var i,
      frags = str?.split(" ");
    for (i = 0; i < frags?.length; i++) {
      frags[i] = frags[i]?.charAt(0)?.toLowerCase() + frags[i]?.slice(1);
    }
    return frags?.join("_");
  }

  /** custom handlers */
  const handleApplicantAction = async (id: any, applicantStatus: string) => {
    setIsUpdating(true);
    try {
      await editApplication(id, {
        cvr_status: postStringCreate(applicantStatus),
      });

      enqueueSnackbar("Cultural Round updated successfully.", {
        variant: "info",
      });
      setIsActionSelected(id);
      setIsUpdating(false);
    } catch (error: any) {
      enqueueSnackbar(`Error: ${error.toString()}`, {
        variant: "error",
      });
    } finally {
      setIsUpdating(false);
    }
  };

  return (
    <SectionContainer>
      <Select
        labelId="demo-simple-select-label"
        id="demo-simple-select"
        value={cvrAction}
        onChange={handleChangeJobs}
        sx={{ width: "200px", height: "44px" }}
      >
        {cvrActionsData.map((item, index) => (
          <MenuItem key={index} value={item.value} disabled={item.value == "Pending"}>
            {item.label}
          </MenuItem>
        ))}
      </Select>
    </SectionContainer>
  );
}

const mapStateToProps = (state: RootState) => ({
  applications: state.applications.applications,
  applicationsLength: state.applications.applicationsLength,
  applicationsNext: state.applications.applicationsNext,
});

const mapDispatchToProps = (dispatch: Dispatch) => {
  return {
    clearApplications: () => dispatch(clearApplications()),
    editApplication: (id: string, payload: any) =>
      editApplication(dispatch, id, payload),
    listApplication: (params: any) => listApplication(dispatch, params),
  };
};

export default connect(mapStateToProps, mapDispatchToProps)(CVRActions);
