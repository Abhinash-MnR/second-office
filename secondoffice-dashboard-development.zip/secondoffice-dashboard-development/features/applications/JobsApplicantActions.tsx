// React, Next packages
import React, { useState } from "react";
import dynamic from "next/dynamic";
import { connect } from "react-redux";
import { Dispatch } from "redux";
import { useRouter } from "next/router";
import { RootState } from "reducers";
// Mui packages
import { Box, MenuItem, Select } from "@mui/material";
// Custom Component
import {
  clearApplications,
  editApplication,
  listApplication,
} from "reducers/applicationsSlice";
import applicantStatusData from "data/applicantStatusData";
// 3Rd Party Component/Packages
import { useSnackbar } from "notistack";
import { useTranslation } from "react-i18next";
import "translation/i18n";

function JobsApplicantActions(props) {
  /* Jobs Applicants Status */
  const { status, applicationId, cvrStatus } = props;
  /* Closed Jobs State */
  const [applicantsAction, setApplicantsAction] = useState(humanize(status));
  /** third-party hooks */
  const { enqueueSnackbar } = useSnackbar();

  //** Language translation hooks */
  const { t } = useTranslation();

  /** useState hooks */
  const [isUpdating, setIsUpdating] = useState(false);
  const [isActionSelected, setIsActionSelected] = useState("");
  /** props - actions */
  const { clearApplications, editApplication, listApplication } = props;

  /* Jobs open and Close Handle */
  const handleChangeJobs = (e) => {
    setApplicantsAction(e.target.value);
    handleApplicantAction(applicationId, e.target.value);
    // console.log("open and close jobs");
  };
  function humanize(str: string) {
    var i,
      frags = str?.split("_");
    for (i = 0; i < frags?.length; i++) {
      frags[i] = frags[i]?.charAt(0)?.toUpperCase() + frags[i]?.slice(1);
    }
    return frags?.join(" ");
  }
  function postStringCreate(str: string) {
    var i,
      frags = str?.split(" ");
    for (i = 0; i < frags?.length; i++) {
      frags[i] = frags[i]?.charAt(0)?.toLowerCase() + frags[i]?.slice(1);
    }
    return frags?.join("_");
  }

  /** custom handlers */
  const handleApplicantAction = async (id: any, applicantStatus: string) => {
    setIsUpdating(true);
    try {
      await editApplication(id, {
        applicant_actions: postStringCreate(applicantStatus),
      });
      // if (applicantStatus === "accepted") {
      //   enqueueSnackbar("Applicant Accepted successfully.", {
      //     variant: "info",
      //   });
      // } else if (applicantStatus === "rejected") {
      //   enqueueSnackbar("Applicant Rejected Successfully.", {
      //     variant: "info",
      //   });
      // }
      enqueueSnackbar("Applicant status updated successfully.", {
        variant: "info",
      });
      setIsActionSelected(id);
      setIsUpdating(false);
    } catch (error: any) {
      enqueueSnackbar(`Error: ${error.toString()}`, {
        variant: "error",
      });
    } finally {
      setIsUpdating(false);
    }
  };

  //** applicant actions */
  const applicantActionData = [
    {
      label: `${t("candidate_status_pending")}`,
      value: "Pending",
    },
    {
      label: `${t("candidate_status_shortlisted")}`,
      value: "Shortlisted",
    },
    {
      label: `${t("candidate_status_rejected")}`,
      value: "Rejected",
    },
  ];

  // console.log(status, "actions status");

  return (
    <Box>
      {/* </FormControl> */}
      <Select
        labelId="demo-simple-select-label"
        id="demo-simple-select"
        value={applicantsAction}
        onChange={handleChangeJobs}
        disabled={cvrStatus === "fail"}
        sx={{ width: { xs: "200px", sm: "170px" }, height: "44px" }}
      >
        {applicantActionData.map((item, index) => (
          <MenuItem
            key={index}
            disabled={
              item.value === "Pending"

              // applicantsAction === "Pending"
              //   ? item.value === "Cultural Round" ||
              //     item.value === "Technical Round" ||
              //     item.value === "Client Review" ||
              //     item.value === "Client Round" ||
              //     item.value === "Offer Made" ||
              //     item.value === "Hired" ||
              //     item.value === "Online Technical Assessment" ||
              //     item.value === "Reconsideration"
              //   : applicantsAction === "Shortlisted"
              //   ? item.value === "Pending" ||
              //     item.value === "Cultural Round" ||
              //     item.value === "Technical Round" ||
              //     item.value === "Client Review" ||
              //     item.value === "Client Round" ||
              //     item.value === "Offer Made" ||
              //     item.value === "Hired" ||
              //     item.value === "Online Technical Assessment" ||
              //     item.value === "Reconsideration"
              //   : applicantsAction === "Cultural Round"
              //   ? item.value === "Pending" ||
              //     item.value === "Technical Round" ||
              //     item.value === "Client Review" ||
              //     item.value === "Client Round" ||
              //     item.value === "Offer Made" ||
              //     item.value === "Hired" ||
              //     item.value === "Shortlisted" ||
              //     item.value === "Online Technical Assessment" ||
              //     item.value === "Reconsideration"
              //   : applicantsAction === "Technical Round"
              //   ? item.value === "Pending" ||
              //     item.value === "Cultural Round" ||
              //     item.value === "Client Round" ||
              //     item.value === "Offer Made" ||
              //     item.value === "Hired" ||
              //     item.value === "Shortlisted" ||
              //     item.value === "Online Technical Assessment" ||
              //     item.value === "Reconsideration"
              //   : applicantsAction === "Client Round"
              //   ? item.value === "Pending" ||
              //     item.value === "Cultural Round" ||
              //     item.value === "Technical Round" ||
              //     item.value === "Client Review" ||
              //     item.value === "Offer Made" ||
              //     item.value === "Hired" ||
              //     item.value === "Shortlisted" ||
              //     item.value === "Online Technical Assessment" ||
              //     item.value === "Reconsideration"
              //   : item.value === "Pending" ||
              //     item.value === "Cultural Round" ||
              //     item.value === "Client Round" ||
              //     item.value === "Technical Round" ||
              //     item.value === "Client Review" ||
              //     item.value === "Offer Made" ||
              //     item.value === "Hired" ||
              //     item.value === "Shortlisted" ||
              //     item.value === "Rejected" ||
              //     item.value === "Online Technical Assessment" ||
              //     item.value === "Reconsideration"
            }
            value={item.value}
          >
            {item.label}
          </MenuItem>
        ))}
      </Select>
    </Box>
  );
}

const mapStateToProps = (state: RootState) => ({
  applications: state.applications.applications,
  applicationsLength: state.applications.applicationsLength,
  applicationsNext: state.applications.applicationsNext,
});

const mapDispatchToProps = (dispatch: Dispatch) => {
  return {
    clearApplications: () => dispatch(clearApplications()),
    editApplication: (id: string, payload: any) =>
      editApplication(dispatch, id, payload),
    listApplication: (params: any) => listApplication(dispatch, params),
  };
};

export default connect(
  mapStateToProps,
  mapDispatchToProps
)(JobsApplicantActions);
