// React, Next packages
import React, { useEffect, useState } from "react";
import dynamic from "next/dynamic";
import { connect } from "react-redux";
import { Dispatch } from "redux";
import { useRouter } from "next/router";
import Link from "next/link";
// Mui packages
import {
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  Paper,
  Typography,
  styled,
  Stack,
  Button,
  MenuItem,
  Select,
  SelectChangeEvent,
  Grid,
  useMediaQuery,
  Box,
} from "@mui/material";
// 3Rd Party Component/Packages
import { useSnackbar } from "notistack";
import { AcceptIcon } from "@common/Icon";
// Custom Component
import { RootState } from "reducers";
import useCompany from "@lib/useCompany";
import {
  clearApplications,
  editApplication,
  listApplication,
} from "reducers/applicationsSlice";
import NoOfficeData from "features/officeManagement/NoOfficeData";

const CustomContainer = styled("div")(({ theme }) => ({
  display: "flex",
  flexDirection: "column",
}));
const CustomTableContainer = styled("div")(({ theme }) => ({
  display: "flex",
}));

const StyledTableRow = styled(TableRow)(({ theme }) => ({
  "&:nth-of-type(odd)": {
    // backgroundColor: theme.palette.action.hover,
  },
  // hide last border
  "&:last-child td, &:last-child th": {
    border: 0,
  },
}));

const StyledTableCell = styled(TableCell)(({ theme }) => ({
  fontSize: 16,
  width: "25%",
}));

const CustomSelectContainer = styled("div")(({ theme }) => ({
  padding: "30px 0px",
  display: "flex",
  justifyContent: "flex-end",
}));

function AcceptedApplicants(props: any) {
  const isMobile = useMediaQuery("(max-width:600px)");
  /** third-party hooks */
  useCompany({ redirectTo: "/" });
  const { enqueueSnackbar } = useSnackbar();
  const router = useRouter();
  const { job_title, is_open } = router.query;

  /** props - states */
  const { jobs } = props;

  const [value, setValue] = React.useState("1");

  const handleChange = (event: React.SyntheticEvent, newValue: string) => {
    setValue(newValue);
  };

  /** third-party hooks */
  const { company } = useCompany({
    redirectTo: "/",
  });

  /** class variables */
  const { job_post, jobTitle, application_status, userId } = router.query;

  /** props - actions */
  const { clearApplications, editApplication, listApplication } = props;
  /** props - states */
  const { applications, applicationsNext } = props;

  /** useState hooks */
  const [isUpdating, setIsUpdating] = useState(false);

  /** useEffect hooks */
  useEffect(() => {
    const initializeApplicationList = async () => {
      clearApplications();
      await listApplication({
        ...router.query,
        page_size: 9,
        page: 1,
        applicant_status: "accepted",
        job_post: location.href.split("/")[4],
      });
    };

    try {
      initializeApplicationList();
    } catch (error) {
      console.log(error);
    }
  }, []);

  useEffect(() => {
    console.log("applications:-", applications);
    console.log("location:-", location.href.split("/")[4]);
  }, [applications]);

  const handleClick = async (userId: string) => {
    router.push(
      {
        pathname: location.pathname,
        query: {
          ...router.query,
          userId: userId,
        },
      },
      undefined,
      { shallow: true }
    );
  };

  const handleClose = () => {
    const newQuery = { ...router.query };
    delete newQuery.userId;

    router.push(
      {
        pathname: location.pathname,
        query: newQuery,
      },
      undefined,
      { shallow: true }
    );
  };

  const handleLoadApplications = async () => {
    await listApplication({ ...router.query, page: applicationsNext });
  };
  return (
    <CustomContainer>
      <CustomTableContainer>
        <TableContainer component={Paper} sx={{ boxShadow: "none" }}>
          <Table sx={{ minWidth: 1050 }} aria-label="simple table">
            <TableHead sx={{ background: "#ECEDF4" }}>
              <StyledTableRow>
                <StyledTableCell
                  sx={{ fontSize: 14, lineHeight: 1.5, fontWeight: 700 }}
                >
                  Candidate
                </StyledTableCell>
                <StyledTableCell
                  sx={{ fontSize: 14, lineHeight: 1.5, fontWeight: 700 }}
                >
                  Notice Period
                </StyledTableCell>
                <StyledTableCell
                  sx={{ fontSize: 14, lineHeight: 1.5, fontWeight: 700 }}
                >
                  Experience
                </StyledTableCell>
                <StyledTableCell
                  sx={{ fontSize: 14, lineHeight: 1.5, fontWeight: 700 }}
                >
                  Resume
                </StyledTableCell>
              </StyledTableRow>
            </TableHead>
            <TableBody>
              {applications.map((row, index) => (
                <TableRow
                  key={row.candidate}
                  sx={{ "&:last-child td, &:last-child th": { border: 0 } }}
                >
                  <StyledTableCell
                    component="th"
                    scope="row"
                    sx={{
                      fontSize: 14,
                      fontWeight: 600,
                      lineHeight: 1.5,
                      color: "#222222",
                    }}
                  >
                    {row.applicant_name}
                  </StyledTableCell>
                  <StyledTableCell>
                    {row?.applicant_notice_period
                      ? `${row?.applicant_notice_period}`
                      : ""}
                  </StyledTableCell>
                  <StyledTableCell>
                    {row?.applicant_experience_min
                      ? `${row?.applicant_experience_min}-${row?.applicant_experience_max} Years`
                      : ""}
                  </StyledTableCell>
                  <StyledTableCell>
                    <Link href={row?.applicant_resume}>
                      <a target="_blank">
                        <Typography
                          sx={{
                            fontSize: 14,
                            lineHeight: 1.5,
                            fontWeight: 600,
                            color: "#2c3058",
                          }}
                        >
                          {"View Resume"}
                        </Typography>
                      </a>
                    </Link>
                  </StyledTableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </TableContainer>
      </CustomTableContainer>
      {/* Empty State when data not available  */}
      <Box>
        {applications.length > 0 ? null : (
          <NoOfficeData
            title="Keep an eye on all job applications here!"
            imgName="Illust-5"
          />
        )}
      </Box>
    </CustomContainer>
  );
}

const mapStateToProps = (state: RootState) => ({
  applications: state.applications.applications,
  applicationsLength: state.applications.applicationsLength,
  applicationsNext: state.applications.applicationsNext,
});

const mapDispatchToProps = (dispatch: Dispatch) => {
  return {
    clearApplications: () => dispatch(clearApplications()),
    editApplication: (id: string, payload: any) =>
      editApplication(dispatch, id, payload),
    listApplication: (params: any) => listApplication(dispatch, params),
  };
};

export default connect(mapStateToProps, mapDispatchToProps)(AcceptedApplicants);
