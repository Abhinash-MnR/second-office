// React , Next js packages
import React, { useState, useEffect } from "react";
import { Dispatch } from "redux";
import { connect } from "react-redux";
import { RootState } from "reducers";
import Link from "next/link";
import { useRouter } from "next/router";
// MUI Packages
import {
  Box,
  Grid,
  Stack,
  Typography,
  Avatar,
  Pagination,
} from "@mui/material";
// Third party packages
import { useTranslation } from "react-i18next";
import "translation/i18n";
// Custom components
import {
  listApplication,
  listSearchApplication,
} from "reducers/applicationsSlice";

import JobsApplicantActions from "./JobsApplicantActions";
import NoOfficeData from "features/officeManagement/NoOfficeData";

function CandidateListCard(props) {
  //** useRouter hooks */
  const { query } = useRouter();
  //** Language translation hooks */
  const { t } = useTranslation();
  //** props - components */
  const {
    candidateList,
    key,
    handleCandidates,
    searchTerm,
    candidateListCount,
    checkBoxFilter,
    handlePagination,
  } = props;
  /** props - actions */
  const { listApplication, searchCandidateApplication } = props;

  /** props - states */
  const {
    jobs,
    applications,
    applicationsCount,
    listJobs,
    searchResult,
    searchResultCount,
  } = props;
  //** useState hooks */

  const [activeState, setActiveState] = useState(0);

  //**total page number */
  const pageNumber = Math.ceil(candidateListCount / 9);

  console.log(candidateList, "check candidate");

  return (
    <Box>
      <Grid container rowSpacing={2}>
        {candidateList
          // .filter((val) => {
          //   if (searchTerm == "") {
          //     return val;
          //   } else if (
          //     val.applicant_status
          //       .toLowerCase()
          //       .includes(searchTerm.toLowerCase())
          //   ) {
          //     return val;
          //   } else if (
          //     val.applicant_name
          //       .toLowerCase()
          //       .includes(searchTerm.toLowerCase())
          //   ) {
          //     return val;
          //   } else if (
          //     val.year_of_experience
          //       .toLowerCase()
          //       .includes(searchTerm.toLowerCase())
          //   ) {
          //     return val;
          //   }
          // })

          .map((data: any, index) => (
            <Grid item xs={12} key={index}>
              <Box
                bgcolor={`grey.100`}
                borderRadius={1.25}
                border="1px solid rgba(140, 142, 186, 0.3)"
                py={2.5}
                px={2}
                position={`relative`}
                onClick={() => {
                  handleCandidates(index);
                  setActiveState(index);
                }}
              >
                {/* active card show */}
                <Box
                  bgcolor={
                    activeState === index
                      ? data.applicant_status === "hired" ||
                        data.applicant_status === "Hired"
                        ? "#E4FCCA"
                        : data.applicant_status === "rejected" ||
                          data.applicant_status === "Rejected" ||
                          data.applicant_status === "Reconsideration" ||
                          data.applicant_status === "reconsideration" ||
                          data.applicant_status === "Withdrew Application" ||
                          data.applicant_status === "withdrew_application"
                        ? "#FFE7D9"
                        : data.applicant_status === "client_round" ||
                          data.applicant_status === "Client Round" ||
                          data.applicant_status === "Client Review" ||
                          data.applicant_status === "client_review" ||
                          data.applicant_status === "Technical Round" ||
                          data.applicant_status === "technical_round" ||
                          data.applicant_status === "Cultural Round" ||
                          data.applicant_status === "cultural_round" ||
                          data.applicant_status === "Shortlisted" ||
                          data.applicant_status === "Shortlisted" ||
                          data.applicant_status ===
                            "online_technical_assessment" ||
                          data.applicant_status ===
                            "Online Technical Assessment"
                        ? "#FFF7CD"
                        : data.applicant_status === "offer_made" ||
                          data.applicant_status === "Offer Made"
                        ? "#D0F2FF"
                        : "#ECEDF4"
                      : ""
                  }
                  position={`absolute`}
                  width={6}
                  height={{ xs: "214px", sm: `124px` }}
                  marginLeft={-2}
                  marginTop={-2.5}
                  sx={{ borderRadius: "12.5px 0px 0px 12.5px" }}
                ></Box>
                <Stack
                  direction={`row`}
                  alignItems={{ xs: "start", sm: "unset" }}
                  flexWrap={{ xs: "wrap", sm: "unset" }}
                  justifyContent={{ xs: "center", sm: "unset" }}
                >
                  {/* candidate name first letter will be profile icon */}
                  <Avatar
                    sx={{
                      bgcolor: `#DFA718`,
                      width: { xs: "34px", sm: `66px` },
                      height: { xs: "34px", sm: `66px` },
                    }}
                  >
                    <Typography variant="h3" color={`grey.100`}>
                      {data.applicant_name.charAt(0).toUpperCase()}
                    </Typography>
                  </Avatar>
                  {/* <img
                  src={"/svg/candidateProfileImg.svg"}
                  alt="profile"
                  width={82}
                  height={82}
                /> */}
                  {/* candidate details column */}
                  <Box
                    display={`flex`}
                    flexDirection={`column`}
                    ml={{ xs: 3, sm: 2.5 }}
                    flexGrow={`1`}
                  >
                    <Typography variant="h4" color={`primary.main`}>
                      {data.applicant_name}
                    </Typography>
                    <Stack direction="row" mt={0.5}>
                      <Typography variant="subtitle2">
                        {t("view_candidates_table_head_exp")} :
                      </Typography>
                      <Typography variant="body2" ml={`4px`}>
                        {" "}
                        {data.year_of_experience} {t("candidate_exp")}
                      </Typography>
                    </Stack>
                    <Stack width={{ xs: "unset", sm: "50%" }}>
                      <Link href={data.applicant_resume}>
                        <a target={`_blank`}>
                          <Typography
                            variant="body2"
                            mt={1}
                            color={`primary.main`}
                            sx={{
                              fontWeight: 600,
                              display: "flex",
                              alignItems: "center",
                            }}
                          >
                            {t("view_candidate_view_resume_title")}
                          </Typography>
                        </a>
                      </Link>
                    </Stack>
                  </Box>
                  {/* cultural fit column */}
                  <Box
                    display={`flex`}
                    flexDirection={`column`}
                    mt={{ xs: 1, sm: "unset" }}
                  >
                    <Typography
                      variant="body2"
                      mt={0.5}
                      bgcolor={
                        data.applicant_status === "hired" ||
                        data.applicant_status === "Hired"
                          ? "#E4FCCA"
                          : data.applicant_status === "rejected" ||
                            data.applicant_status === "Rejected" ||
                            data.applicant_status === "Reconsideration" ||
                            data.applicant_status === "reconsideration" ||
                            data.applicant_status === "Withdrew Application" ||
                            data.applicant_status === "withdrew_application"
                          ? "#FFE7D9"
                          : data.applicant_status === "client_round" ||
                            data.applicant_status === "Client Round" ||
                            data.applicant_status === "Client Review" ||
                            data.applicant_status === "client_review" ||
                            data.applicant_status === "Technical Round" ||
                            data.applicant_status === "technical_round" ||
                            data.applicant_status === "Cultural Round" ||
                            data.applicant_status === "cultural_round" ||
                            data.applicant_status === "Shortlisted" ||
                            data.applicant_status === "Shortlisted" ||
                            data.applicant_status ===
                              "online_technical_assessment" ||
                            data.applicant_status ===
                              "Online Technical Assessment"
                          ? "#FFF7CD"
                          : data.applicant_status === "offer_made" ||
                            data.applicant_status === "Offer Made"
                          ? "#D0F2FF"
                          : "#ECEDF4"
                      }
                      color={`text.primary`}
                      py={0.5}
                      borderRadius={1.25}
                      mb={1}
                      textAlign={`center`}
                      textTransform={"capitalize"}
                    >
                      {data.applicant_status === "offer_made" ||
                      data.applicant_status === "Offer Made"
                        ? `${t("candidate_status_offer_made")}`
                        : data.applicant_status ===
                            "online_technical_assessment" ||
                          data.applicant_status ===
                            "Online Technical Assessment"
                        ? "Online Technical Asses..."
                        : data.applicant_status === "cultural_round" ||
                          data.applicant_status === "Cultural Round"
                        ? "Cultural Fit"
                        : data.applicant_status === "withdrew_application" ||
                          data.applicant_status === "Withdrew Application"
                        ? "Withdrew Application"
                        : data.applicant_status === "technical_round" ||
                          data.applicant_status === "Technical Round"
                        ? `${t("candidate_status_tech_round")}`
                        : data.applicant_status === "client_review" ||
                          data.applicant_status === "Client Review"
                        ? `${t("candidate_status_client_review")}`
                        : data.applicant_status === "client_round" ||
                          data.applicant_status === "Client Round"
                        ? `${t("candidate_status_client_round")}`
                        : data.applicant_status === "rejected"
                        ? `${t("candidate_status_rejected")}`
                        : data.applicant_status === "hired"
                        ? `${t("candidate_status_hired")}`
                        : data.applicant_status === "pending" ||
                          data.applicant_status === "Pending"
                        ? `${t("candidate_status_pending")}`
                        : data.applicant_status === "shortlisted"
                        ? `${t("candidate_status_shortlisted")}`
                        : null}
                    </Typography>

                    <JobsApplicantActions
                      cvrStatus={data.cvr_status}
                      status={data.applicant_actions}
                      applicationId={data.id}
                    />
                  </Box>
                </Stack>
              </Box>
            </Grid>
          ))}
      </Grid>

      {candidateListCount >= 9 ? (
        <Stack
          direction="row"
          alignItems="center"
          justifyContent="center"
          paddingTop={5}
          paddingBottom={3}
        >
          {checkBoxFilter === true ? (
            ""
          ) : (
            <Pagination
              count={pageNumber}
              color="secondary"
              onChange={(e, value) => handlePagination(value)}
              sx={{
                background: "#ECEDF4",
                borderRadius: "10px",
                padding: { xs: "5px", sm: "10px" },
              }}
            />
          )}
        </Stack>
      ) : (
        ""
      )}
    </Box>
  );
}

const mapStateToProps = (state: RootState) => ({
  jobs: state.jobs.jobs,
  applications: state.applications.applications,
  listJobs: state.applications.applications,
  applicationsCount: state.applications.applicationsLength,
  //** search data */
  searchResult: state.applications.searchResult,
  searchResultCount: state.applications.searchCount,
});

const mapDispatchToProps = (dispatch: Dispatch) => {
  return {
    listApplication: (params: any) => listApplication(dispatch, params),
    searchCandidateApplication: (params: any) =>
      listSearchApplication(dispatch, params),
  };
};
export default connect(mapStateToProps, mapDispatchToProps)(CandidateListCard);
