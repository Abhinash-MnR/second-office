// React, Next packages
import React, { useEffect, useState } from "react";
import dynamic from "next/dynamic";
import { connect } from "react-redux";
import { Dispatch } from "redux";
import { useRouter } from "next/router";
import Link from "next/link";
import { RootState } from "reducers";
// Mui packages
import {
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  Paper,
  Typography,
  styled,
  Stack,
  Button,
  MenuItem,
  Select,
  SelectChangeEvent,
  Grid,
  useMediaQuery,
  Box,
  Tooltip,
  IconButton,
  Pagination,
  Chip,
} from "@mui/material";
// 3Rd Party Component/Packages
import { useSnackbar } from "notistack";
import { AcceptIcon } from "@common/Icon";
// Custom Component
import useCompany from "@lib/useCompany";
import {
  clearApplications,
  editApplication,
  listApplication,
} from "reducers/applicationsSlice";
import NoOfficeData from "features/officeManagement/NoOfficeData";
import JobsApplicantActions from "./JobsApplicantActions";
import ReadMore from "@common/ReadMore";
import useCurrency from "@lib/useCurrency";
import {
  EURIconColor,
  INRIconColor,
  KRWIconColor,
  USDIconColor,
  ToolTipIconColor,
} from "@common/Icon";
import CVRActions from "./CVRActions";
import { capitalize } from "lodash";

const CustomContainer = styled("div")(({ theme }) => ({
  display: "flex",
  flexDirection: "column",
}));
const CustomTableContainer = styled("div")(({ theme }) => ({
  display: "flex",
}));

const StyledTableRow = styled(TableRow)(({ theme }) => ({
  borderLeft: "4px solid #ECEDF4",
  "&:nth-of-type(odd)": {
    // backgroundColor: theme.palette.action.hover,
  },
  // hide last border
  "&:last-child td, &:last-child th": {
    border: 0,
  },
}));

const StyledTableCell = styled(TableCell)(({ theme }) => ({
  fontSize: 14,
}));

const CustomSelectContainer = styled("div")(({ theme }) => ({
  padding: "30px 0px",
  display: "flex",
  justifyContent: "flex-end",
}));

function AllApplicants(props: any) {
  const isMobile = useMediaQuery("(max-width:600px)");
  /** third-party hooks */
  useCompany({ redirectTo: "/" });
  const { enqueueSnackbar } = useSnackbar();
  const router = useRouter();
  const { job_title, is_open } = router.query;

  /** props - states */
  const { jobs } = props;

  const [value, setValue] = React.useState("1");

  const handleChange = (event: React.SyntheticEvent, newValue: string) => {
    setValue(newValue);
  };

  // Convert number with commas
  const numberWithCommas = (x:string) => {
    return x.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ',');
  }

  /** third-party hooks */
  const { company } = useCompany({
    redirectTo: "/",
  });

  const { currency } = useCurrency();

  /** class variables */
  const { job_post, jobTitle, application_status, userId } = router.query;

  /** props - actions */
  const { clearApplications, editApplication, listApplication } = props;
  /** props - states */
  const { applications, applicationsNext, applicationsLength } = props;

  /** useState hooks */
  const [isUpdating, setIsUpdating] = useState(false);

  // Total page number
  const pageNumber = Math.ceil(applicationsLength / 9);

  const [jobApplicantPage, setJobApplicantPage] = useState(1);

  const [isActionSelected, setIsActionSelected] = useState("");

  /** useEffect hooks */
  useEffect(() => {
    const initializeApplicationList = async () => {
      clearApplications();
      await listApplication({
        ...router.query,
        page: jobApplicantPage,
        page_size: 9,
        // applicant_status: "pending",
        job_post: location.href.split("/")[4],
      });
    };
    try {
      initializeApplicationList();
    } catch (error) {
      console.log(error);
    }
  }, [jobApplicantPage]);

  /** custom handlers */
  const handleApplicantAction = async (id: any, applicantStatus: String) => {
    setIsUpdating(true);
    try {
      await editApplication(id, { applicant_status: applicantStatus });
      if (applicantStatus === "accepted") {
        enqueueSnackbar("Applicant Accepted successfully.", {
          variant: "info",
        });
      } else if (applicantStatus === "rejected") {
        enqueueSnackbar("Applicant Rejected Successfully.", {
          variant: "info",
        });
      }
      setIsActionSelected(id);
      setIsUpdating(false);
    } catch (error: any) {
      enqueueSnackbar(`Error: ${error.toString()}`, {
        variant: "error",
      });
    } finally {
      setIsUpdating(false);
    }
  };

  useEffect(() => {
    console.log("applications:-", applications);
  }, [applications]);

  useEffect(() => {
    const initializeApplicationList = async () => {
      clearApplications();
      await listApplication({
        ...router.query,
        page: 1,
        page_size: 9,
        // applicant_status: "pending",
        job_post: location.href.split("/")[4],
      });
    };
    try {
      setTimeout(() => {
        initializeApplicationList();
      }, 30);
    } catch (error) {
      console.log(error);
    }
  }, [isActionSelected]);

  const handleClick = async (userId: string) => {
    router.push(
      {
        pathname: location.pathname,
        query: {
          ...router.query,
          userId: userId,
        },
      },
      undefined,
      { shallow: true }
    );
  };

  const handleClose = () => {
    const newQuery = { ...router.query };
    delete newQuery.userId;

    router.push(
      {
        pathname: location.pathname,
        query: newQuery,
      },
      undefined,
      { shallow: true }
    );
  };

  function humanize(str: string) {
    var i,
      frags = str?.split("_");
    for (i = 0; i < frags?.length; i++) {
      frags[i] = frags[i]?.charAt(0)?.toUpperCase() + frags[i]?.slice(1);
    }
    return frags?.join(" ");
  }

  const handleLoadApplications = async () => {
    await listApplication({ ...router.query, page: applicationsNext });
  };

  // const handleChange = (event: SelectChangeEvent) => {
  //   console.log("menu slected");
  // };

  console.log("applications: ", applications);

  return (
    <CustomContainer>
      {/* [FAQ Button] */}
      <Box
        sx={{
          position: "fixed",
          right: 48,
          bottom: 48,
          cursor: "pointer",
          zIndex: 9999,
        }}
        onClick={() => router.push("/help_center/view-candidate-page")}
      >
        <img
          src="/svg/helpCenterFloatingButton.svg"
          alt="helpCenterFloatingButton"
          style={{ height: 56, width: 56 }}
        />
      </Box>

      <CustomTableContainer>
        <TableContainer component={Paper} sx={{ boxShadow: "none" }}>
          <Table sx={{ minWidth: 1050 }} aria-label="simple table">
            <TableHead sx={{ background: "#ECEDF4" }}>
              <StyledTableRow>
                <StyledTableCell
                  sx={{ fontSize: 14, lineHeight: 1.5, fontWeight: 700 }}
                >
                  Candidate
                </StyledTableCell>
                <StyledTableCell
                  sx={{
                    fontSize: 14,
                    lineHeight: 1.5,
                    fontWeight: 700,
                    minWidth: 180,
                  }}
                >
                  Notice Period
                  <Tooltip
                    title="It is the period between receiving the letter of dismissal and the end of the last working day."
                    arrow
                    enterTouchDelay={0}
                  >
                    <IconButton aria-label="hr_actions">
                      <ToolTipIconColor />
                    </IconButton>
                  </Tooltip>
                </StyledTableCell>
                <StyledTableCell
                  sx={{ fontSize: 14, lineHeight: 1.5, fontWeight: 700 }}
                >
                  Experience
                </StyledTableCell>
                <StyledTableCell
                  sx={{
                    fontSize: 14,
                    lineHeight: 1.5,
                    fontWeight: 700,
                    minWidth: 110,
                  }}
                >
                  CTC
                  <Tooltip
                    title="It is the cost a company incurs when hiring an employee, and includes all monthly components such as basic pay, reimbursements, various allowances, etc."
                    arrow
                    enterTouchDelay={0}
                  >
                    <IconButton aria-label="hr_actions">
                      <ToolTipIconColor />
                    </IconButton>
                  </Tooltip>
                </StyledTableCell>
                <StyledTableCell
                  sx={{
                    fontSize: 14,
                    lineHeight: 1.5,
                    fontWeight: 700,
                    minWidth: 110,
                  }}
                >
                  ECTC
                  <Tooltip
                    title="It is a term used to understand
                    what a candidate is expecting
                    from the organization in terms of
                    their all-inclusive CTC."
                    arrow
                    enterTouchDelay={0}
                  >
                    <IconButton aria-label="hr_actions">
                      <ToolTipIconColor />
                    </IconButton>
                  </Tooltip>
                </StyledTableCell>
                <StyledTableCell
                  sx={{ fontSize: 14, lineHeight: 1.5, fontWeight: 700 }}
                >
                  Resume/Portfolio
                </StyledTableCell>
                <StyledTableCell
                  sx={{
                    fontSize: 14,
                    lineHeight: 1.5,
                    fontWeight: 700,
                    minWidth: 180,
                  }}
                >
                  Cultural Round
                  <Tooltip
                    title="The operations team can either shortlist or reject a candidate, post which, you can check the Cultural Round here. No further action will be possible."
                    arrow
                    enterTouchDelay={0}
                  >
                    <IconButton aria-label="hr_actions">
                      <ToolTipIconColor />
                    </IconButton>
                  </Tooltip>
                </StyledTableCell>
                <StyledTableCell
                  sx={{ fontSize: 14, lineHeight: 1.5, fontWeight: 700 ,minWidth: 230}}
                >
                  Additional Comments
                </StyledTableCell>
                <StyledTableCell
                  sx={{ fontSize: 14, lineHeight: 1.5, fontWeight: 700 ,minWidth: 180}}
                >
                  Technical Rounds
                </StyledTableCell>
                <StyledTableCell
                  sx={{ fontSize: 14, lineHeight: 1.5, fontWeight: 700, minWidth: 145}}
                >
                  Action
                  <Tooltip
                    title="You can shortlist or reject a candidate from the dropdown list in the column. Note: If the Cultural Round shows that the candidate has been rejected, no further action can be taken here."
                    arrow
                    enterTouchDelay={0}
                  >
                    <IconButton aria-label="hr_actions">
                      <ToolTipIconColor />
                    </IconButton>
                  </Tooltip>
                </StyledTableCell>
                <StyledTableCell
                  sx={{ fontSize: 14, lineHeight: 1.5, fontWeight: 700, minWidth: 145 }}
                >
                  Status
                  <Tooltip
                    title="The status of the candidate will be visible here after recruiter chooses the appropriate action such as ‘shortlist’, ‘pending’, ‘client review’, ‘offer made’, ‘withdrew application’, and more."
                    arrow
                    enterTouchDelay={0}
                  >
                    <IconButton aria-label="hr_actions">
                      <ToolTipIconColor />
                    </IconButton>
                  </Tooltip>
                </StyledTableCell>
              </StyledTableRow>
            </TableHead>
            <TableBody>
              {applications.map((row, index) => (
                <TableRow
                  key={index}
                  sx={
                    row?.applicant_status === "online_technical_assessment" ||
                      row?.applicant_status === "cultural_round" ||
                      row?.applicant_status === "client_review" ||
                      row?.applicant_status === "client_round" ||
                      row?.applicant_status === "shortlisted" ||
                      row?.applicant_status === "technical_round"
                      ? {
                        "&:last-child td, &:last-child th": { border: 0 },
                        backgroundColor: "#FFF7CD",
                        borderLeft: "4px solid #DFA718",
                      }
                      : row?.applicant_status === "rejected" || row?.cvr_status === "fail"
                        ? {
                          "&:last-child td, &:last-child th": { border: 0 },
                          backgroundColor: "#FFE7D9",
                          borderLeft: "4px solid #EC0C0C",
                        }
                        : row?.applicant_status === "withdrew_application"
                        ? {
                          "&:last-child td, &:last-child th": { border: 0 },
                          backgroundColor: "#FFE7D9",
                          borderLeft: "4px solid #EC0C0C",
                        }
                        : row?.applicant_status === "reconsideration"
                        ? {
                          "&:last-child td, &:last-child th": { border: 0 },
                          backgroundColor: "#FFE7D9",
                          borderLeft: "4px solid #EC0C0C",
                        }
                        : row?.applicant_status === "offer_made"
                          ? {
                            "&:last-child td, &:last-child th": { border: 0 },
                            backgroundColor: "#D6F4FF",
                            borderLeft: "4px solid #00B8FF",
                          }
                          : row?.applicant_status === "hired"
                            ? {
                              "&:last-child td, &:last-child th": { border: 0 },
                              backgroundColor: "#E4FCCA",
                              borderLeft: "4px solid #54D62C",
                            }
                            : {
                              "&:last-child td, &:last-child th": { border: 0 },
                              backgroundColor: "#FFFFFF",
                            }
                  }
                >
                  <StyledTableCell
                    component="th"
                    scope="row"
                    sx={{
                      fontSize: 14,
                      fontWeight: 600,
                      lineHeight: 1.5,
                      color: "#222222",
                    }}
                  >
                    {row.applicant_name}
                  </StyledTableCell>
                  <StyledTableCell
                    sx={{ maxWidth: 120, wordWrap: "break-word" }}
                  >
                    {row?.applicant_notice_period
                      ? `${row?.applicant_notice_period}`
                      : ""}
                  </StyledTableCell>
                  <StyledTableCell>
                    {/* {row?.applicant_experience_min
                      ? `${row?.applicant_experience_min}-${row?.applicant_experience_max} Years`
                      : ""} */}
                    {row?.year_of_experience
                      ? `${row?.year_of_experience} Years`
                      : ""}
                  </StyledTableCell>
                  <StyledTableCell>
                    {company && currency && company.currency === "KRW" ? (
                      <KRWIconColor sx={{ fontSize: "10px" }} />
                    ) : company && currency && company.currency === "USD" ? (
                      <USDIconColor sx={{ fontSize: "10px" }} />
                    ) : company && currency && company.currency === "EUR" ? (
                      <EURIconColor sx={{ fontSize: "10px" }} />
                    ) : (
                      <INRIconColor sx={{ fontSize: "10px" }} />
                    )}

                    {company && currency && company.currency === "KRW"
                      ? numberWithCommas((row?.cTC * currency.currency_krw
                      ).toFixed(2))
                      : company && currency && company.currency === "USD"
                        ? numberWithCommas((
                          row?.cTC * currency.currency_usd / 1000
                        ).toFixed(2))
                        : company && currency && company.currency === "EUR"
                          ? numberWithCommas((
                            row?.cTC * currency.currency_eur / 1000
                          ).toFixed(2))
                          : numberWithCommas((row?.cTC / 100000).toFixed(2))}

                    {company && currency && company.currency === "KRW"
                      ? ""
                      : company && currency && company.currency === "USD"
                        ? " K"
                        : company && currency && company.currency === "EUR"
                          ? "K"
                          : " LPA"}
                  </StyledTableCell>

                  <StyledTableCell>
                    {company && currency && company.currency === "KRW" ? (
                      <KRWIconColor sx={{ fontSize: "10px" }} />
                    ) : company && currency && company.currency === "USD" ? (
                      <USDIconColor sx={{ fontSize: "10px" }} />
                    ) : company && currency && company.currency === "EUR" ? (
                      <EURIconColor sx={{ fontSize: "10px" }} />
                    ) : (
                      <INRIconColor sx={{ fontSize: "10px" }} />
                    )}

                    {company && currency && company.currency === "KRW"
                      ? numberWithCommas((
                        row?.eCTC * currency.currency_krw
                      ).toFixed(2))
                      : company && currency && company.currency === "USD"
                        ? numberWithCommas((
                          row?.eCTC * currency.currency_usd / 1000
                        ).toFixed(2))
                        : company && currency && company.currency === "EUR"
                          ? numberWithCommas((
                            row?.eCTC * currency.currency_eur / 1000
                          ).toFixed(2))
                          : numberWithCommas((row?.eCTC / 100000).toFixed(2))}

                    {company && currency && company.currency === "KRW"
                      ? ""
                      : company && currency && company.currency === "USD"
                        ? " K"
                        : company && currency && company.currency === "EUR"
                          ? "K"
                          : " LPA"}
                  </StyledTableCell>

                  <StyledTableCell>
                    <Link href={row?.applicant_resume}>
                      <a target="_blank">
                        <Typography
                          sx={{
                            fontSize: 14,
                            lineHeight: 1.5,
                            fontWeight: 600,
                            color: "#2c3058",
                          }}
                        >
                          {"View Resume"}
                        </Typography>
                      </a>
                    </Link>
                    {row?.applicant_portfolio !== "" ? (
                      <Link href={row?.applicant_portfolio}>
                        <a target="_blank">
                          <Typography
                            sx={{
                              fontSize: 14,
                              lineHeight: 1.5,
                              fontWeight: 600,
                              color: "#2c3058",
                            }}
                          >
                            {"View Portfolio"}
                          </Typography>
                        </a>
                      </Link>
                    ) : (
                      <Typography
                        sx={{
                          fontSize: 14,
                          lineHeight: 1.5,
                          fontWeight: 600,
                          color: "#2c3058",
                          opacity: 0.8,
                        }}
                      >
                        {"View Portfolio"}
                      </Typography>
                    )}
                  </StyledTableCell>

                  <StyledTableCell>
                    <Chip label={capitalize(row?.cvr_status === "priority_2" ? "Pending" : row?.cvr_status === "na" ? "Pending" : row?.cvr_status)} sx={{
                      padding: "5px 10px", border: row?.cvr_status === "pass" ? "1px solid #54D62C" :
                        row?.cvr_status === "fail" ? "1px solid #EC0C0C" : "1px solid #2C3058", borderRadius: "18px", background: row?.cvr_status === "pass" ? "#EDFDDB" :
                          row?.cvr_status === "fail" ? "#FFEFE5" : "#FFFFFF", color: row?.cvr_status === "pass" ? "#54D62C" :
                            row?.cvr_status === "fail" ? "#EC0C0C" : "#2C3058", fontWeight: 700
                    }} />
                  </StyledTableCell>

                  <StyledTableCell
                    sx={{ maxWidth: 240, wordWrap: "break-word" }}
                  >
                    <Box>
                      {row?.additional_comments.length > 30 ? (
                        <ReadMore sliceTextLength="30">
                          {row?.additional_comments}
                        </ReadMore>
                      ) : (
                        <Typography component="p" variant="body2">
                          {row?.additional_comments}
                        </Typography>
                      )}
                    </Box>
                  </StyledTableCell>

                  <StyledTableCell
                    sx={{ maxWidth: 240, wordWrap: "break-word" }}
                  >
                    <Box>
                      {row?.technical_round.length > 30 ? (
                        <ReadMore sliceTextLength="30">
                          {row?.technical_round}
                        </ReadMore>
                      ) : (
                        <Typography component="p" variant="body2">
                          {row?.technical_round}
                        </Typography>
                      )}
                    </Box>
                  </StyledTableCell>
                  <StyledTableCell>
                    <JobsApplicantActions
                    cvrStatus={row?.cvr_status}
                      status={row?.applicant_actions}
                      applicationId={row?.id}
                    />
                  </StyledTableCell>
                  <StyledTableCell
                    sx={{ maxWidth: 320 }}
                  >
                    {row?.applicant_status
                      ? row?.applicant_status === "pending" ? "Resume Review" :`${humanize(row?.applicant_status)}`
                      : ""}
                  </StyledTableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </TableContainer>
      </CustomTableContainer>
      {/* Empty State when data not available  */}
      {applications.length > 0 ?
        <Grid container spacing={1}>
          <Grid item xs={12}>
            <Box sx={{ display: "flex", justifyContent: "center" }}>
              <Stack
                direction="row"
                alignItems="center"
                justifyContent="center"
                paddingTop={5}
                paddingBottom={3}
              >
                <Pagination
                  count={pageNumber}
                  page={jobApplicantPage}
                  color="secondary"
                  onChange={(e, value) => setJobApplicantPage(value)}
                  sx={{
                    background: "#ECEDF4",
                    borderRadius: "10px",
                    padding: { xs: "5px", sm: "10px" },
                  }}
                />
              </Stack>
            </Box>
          </Grid>
        </Grid> : null}
      <Box>
        {applications.length > 0 ? null : (
          <NoOfficeData
            title="Keep an eye on all job applications here!"
            imgName="Illust-5"
          />
        )}
      </Box>
    </CustomContainer>
  );
}

const mapStateToProps = (state: RootState) => ({
  applications: state.applications.applications,
  applicationsLength: state.applications.applicationsLength,
  applicationsNext: state.applications.applicationsNext,
});

const mapDispatchToProps = (dispatch: Dispatch) => {
  return {
    clearApplications: () => dispatch(clearApplications()),
    editApplication: (id: string, payload: any) =>
      editApplication(dispatch, id, payload),
    listApplication: (params: any) => listApplication(dispatch, params),
  };
};

export default connect(mapStateToProps, mapDispatchToProps)(AllApplicants);
