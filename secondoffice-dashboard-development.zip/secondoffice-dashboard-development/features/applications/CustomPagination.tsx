// React, Next packages
import React from "react";
// Mui packages
import { styled, Box, Stack, Grid, Pagination } from "@mui/material";

function CustomPagination() {
  return (
    <Grid container spacing={1}>
      <Grid item xs={12}>
        <Box sx={{ display: "flex", justifyContent: "center" }}>
          <Stack
            direction="row"
            alignItems="center"
            justifyContent="center"
            paddingTop={5}
            paddingBottom={3}
          >
            <Pagination
              count={6}
              color="secondary"
              sx={{
                background: "#ECEDF4",
                borderRadius: "10px",
                padding: { xs: "5px", sm: "10px" },
              }}
            />
          </Stack>
        </Box>
      </Grid>
    </Grid>
  );
}

export default CustomPagination;
