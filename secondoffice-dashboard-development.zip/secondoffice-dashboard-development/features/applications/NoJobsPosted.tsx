// React, Next packages
import React from "react";
import { useRouter } from "next/router";
// Mui packages
import { styled, Box, Button, Grid, Typography } from "@mui/material";
// Third party packages
import { useTranslation } from "react-i18next";
import "translation/i18n";

const SectionContainer = styled("div")(({ theme }) => ({
  display: "flex",
  flexDirection: "column",
}));

const ImageContainer = styled("div")(({ theme }) => ({
  display: "flex",
  flexDirection: "column",
}));

function NoJobsPosted() {
  //**Router use for Page Redirect */
  const router = useRouter();
  //**language translation hooks */
  const { t } = useTranslation();
  return (
    <Grid container spacing={1}>
      <Grid item xs={12}>
        <Box
          sx={{
            display: "flex",
            justifyContent: "center",
            alignItems: "center",
            flexDirection: "column",
            width: "100%",
            height: "500px",
            background: "#fff",
            borderRadius: "10px",
          }}
        >
          <ImageContainer>
            <img src="/svg/Illust-1.svg" />
          </ImageContainer>
          <Typography
            component="h4"
            variant="h4"
            justifyContent="center"
            alignItems="center"
            marginTop={3}
            color="primary.main"
          >
            {t("recruit_empty_screen_title")}
          </Typography>
          <Typography
            component="p"
            variant="body1"
            justifyContent="center"
            alignItems="center"
            marginTop={2}
          >
            {t("recruit_empty_screen_subtitle")}
          </Typography>
          <Button
            component="a"
            variant="contained"
            rel="noopener noreferrer"
            target="_blank"
            size="medium"
            sx={{ marginTop: 2.5, px: 3.5 }}
            onClick={() => router.push("/applications/jobs/add")}
          >
            {t("recruit_jobs_post_button_title")}
          </Button>
        </Box>
      </Grid>
    </Grid>
  );
}

export default NoJobsPosted;
