// React, Next packages
import React, { useEffect, useState } from "react";
import { useRouter } from "next/router";
import Link from "next/link";
import { connect, useDispatch } from "react-redux";
import { Dispatch } from "redux";
// Mui packages
import {
  styled,
  Typography,
  Stack,
  Button,
  useMediaQuery,
  Chip,
  Box,
  Grid,
  Pagination,
  List,
  ListItem,
  Divider,
} from "@mui/material";
// 3Rd Party Component/Packages
import { useSnackbar } from "notistack";
import { useTranslation } from "react-i18next";
import "translation/i18n";
// Custom packages
import { EditIcon, ListIcon } from "@common/Icon";
import useCompany from "@lib/useCompany";
import { listJob, openJobsList } from "reducers/jobsSlice";
import { renderRelativeDate } from "lib/formatter";
import { RootState } from "reducers";
import NoJobsPosted from "./NoJobsPosted";
import useCurrency from "@lib/useCurrency";

function JobApplicationCard(props: any) {
  const isMobile = useMediaQuery("(max-width:600px)");
  /** third-party hooks */
  useCompany({ redirectTo: "/" });
  const { enqueueSnackbar } = useSnackbar();
  const router = useRouter();

  /** props - actions */
  const { listJob, openJobsList } = props;

  /** props - states */
  const { jobs, count, openJobs, openJobsCount } = props;
  // Total page number
  const pageNumber = Math.ceil(openJobsCount / 9);

  const [jobListPage, setJobListPage] = useState(1);

  /** third-party hooks */
  const { company } = useCompany({
    redirectTo: "/",
  });

  const { currency } = useCurrency();

  /** Find Nature Of Job item Value matching by Job Type (or undefined if no match found) */
  function convertValue(minValue: string, maxValue: string, ext: string) {
    let value = "";
    if (Number(maxValue) === 100) {
      value = `${minValue}+ ${ext}`;
    } else {
      value = `${minValue} - ${maxValue} ${ext}`;
    }
    return value;
  }

  // Convert number with commas
  const numberWithCommas = (x: string) => {
    return x.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",");
  };

  /** useEffect hooks */
  useEffect(() => {
    const initializeJobList = async () => {
      await openJobsList({ page: jobListPage, page_size: 9 });
    };

    try {
      initializeJobList();
    } catch (error: any) {
      enqueueSnackbar(error.toString(), { variant: "error" });
    }
  }, [jobListPage]);

  //**language translation hooks */
  const { t } = useTranslation();

  console.log(openJobs, "checl list of jobs");

  return (
    <Box flexDirection={`column`} overflow={`hidden`}>
      {openJobs.length > 0 ? (
        <Grid container spacing={2}>
          {openJobs.map((Jobs: any, index: any) => {
            return (
              <Grid item sm={4} xs={12} key={index}>
                <Box
                  flexDirection={`column`}
                  overflow={`hidden`}
                  borderRadius={1.25}
                  border={`1px solid rgba(140, 142, 186, 0.3)`}
                >
                  <Box bgcolor={"grey.100"} padding={{ xs: 2, sm: 2.5 }}>
                    {/* Jobs Posted   */}
                    <Box
                      sx={{
                        display: "flex",
                        justifyContent: "space-between",
                      }}
                    >
                      <Typography variant="h6" color="primary.main">
                        {Jobs.job_title}
                      </Typography>
                      <Typography
                        component="span"
                        sx={{
                          display: "flex",
                          alignItems: "center",
                          cursor: "pointer",
                        }}
                        onClick={() =>
                          router.push(
                            "/applications/jobs/" + Jobs.id + "/editJobIndex/"
                          )
                        }
                      >
                        <EditIcon sx={{ fontSize: 16 }} />
                      </Typography>
                    </Box>
                    {/* Jobs salary range   */}
                    <Box pt={1.5} display={`flex`}>
                      {/* job salary range  */}
                      <Typography
                        variant="body2"
                        sx={{
                          fontWeight: 600,
                          whiteSpace: "nowrap",
                          overflow: "hidden",
                        }}
                      >
                        {Jobs?.salary_max === 0 && Jobs?.salary_min === 0
                          ? "Salary No Bar"
                          : Jobs?.salary_max === 1 && Jobs?.salary_min === 1
                          ? "As per the market standards"
                          : (company && currency && company.currency) +
                            " " +
                            (company && currency && company.currency === "KRW"
                              ? " " +
                                numberWithCommas(
                                  (
                                    Jobs.salary_min * currency.currency_krw
                                  ).toFixed(2)
                                ) +
                                " - " +
                                numberWithCommas(
                                  (
                                    Jobs.salary_max * currency.currency_krw
                                  ).toFixed(2)
                                )
                              : company &&
                                currency &&
                                company.currency === "USD"
                              ? numberWithCommas(
                                  (
                                    (Jobs.salary_min * currency.currency_usd) /
                                    1000
                                  ).toFixed(2)
                                ) +
                                " - " +
                                numberWithCommas(
                                  (
                                    (Jobs.salary_max * currency.currency_usd) /
                                    1000
                                  ).toFixed(2)
                                )
                              : company &&
                                currency &&
                                company.currency === "EUR"
                              ? numberWithCommas(
                                  (
                                    (Jobs.salary_min * currency.currency_eur) /
                                    1000
                                  ).toFixed(2)
                                ) +
                                " - " +
                                numberWithCommas(
                                  (
                                    (Jobs.salary_max * currency.currency_eur) /
                                    1000
                                  ).toFixed(2)
                                )
                              : numberWithCommas(
                                  (Jobs.salary_min / 100000).toFixed(2)
                                ) +
                                " - " +
                                numberWithCommas(
                                  (Jobs.salary_max / 100000).toFixed(2)
                                )) +
                            (company && currency && company.currency === "KRW"
                              ? " "
                              : company &&
                                currency &&
                                company.currency === "USD"
                              ? " K"
                              : company &&
                                currency &&
                                company.currency === "EUR"
                              ? "K"
                              : " LPA") +
                            (company && currency && company.currency === "KRW"
                              ? "PA"
                              : company &&
                                currency &&
                                company.currency === "USD"
                              ? " PA"
                              : company &&
                                currency &&
                                company.currency === "EUR"
                              ? " PA"
                              : " ")}
                      </Typography>
                    </Box>
                    {/* Jobs Year of Experience   */}
                    <Box display={`flex`} pt={1.5}>
                      {/* job Year of Experience */}
                      <Typography
                        variant="body2"
                        sx={{
                          whiteSpace: "nowrap",
                          overflow: "hidden",
                        }}
                      >
                        {convertValue(
                          Jobs.experience_min,
                          Jobs.experience_max,
                          "Year of Experience"
                        )}
                      </Typography>
                    </Box>

                    {/* skills related to jobs  */}
                    <Box
                      style={{
                        paddingTop: "12px",
                        whiteSpace: "nowrap",
                        overflow: "hidden",
                      }}
                      paddingRight={isMobile ? "0px" : "0px"}
                    >
                      <List sx={{ display: "flex", p: 0 }}>
                        {Jobs.job_skills.map((skills, index) =>
                          skills?.split(",", 3).map((entry: string) => {
                            return (
                              <ListItem
                                sx={{
                                  padding: 0,
                                  width: "auto",
                                  marginRight: 2.5,
                                }}
                                key={index}
                              >
                                <ListIcon sx={{ fontSize: "8px" }} />
                                <Typography
                                  variant="body2"
                                  sx={{
                                    fontWeight: 600,
                                    whiteSpace: "nowrap",
                                    ml: 0.8,
                                    textTransform: "capitalize",
                                  }}
                                >
                                  {entry.split(",")[index]}
                                </Typography>
                              </ListItem>
                            );
                          })
                        )}
                      </List>
                      {/* {Jobs.job_skills.map((data, index) =>
                        data?.split(",")?.map((entry) => (
                          <Chip
                            key={index}
                            label={entry.split(",")[index]}
                            sx={{
                              background: "#ECEDF4",
                              color: "#222222",
                              marginRight: { xs: "7px", sm: "6px" },
                            }}
                          />
                        ))
                      )} */}
                    </Box>
                  </Box>
                  <Divider sx={{ borderColor: "#8C8EBA", opacity: 0.3 }} />

                  {/* View candidate buttons  */}
                  <Stack
                    alignSelf="start"
                    marginBottom={isMobile ? 0.1 : 0}
                    marginTop={{ xs: 0.5, sm: "0px" }}
                    alignItems={{ xs: "center", sm: "flex-start" }}
                    width={{ xs: "100%", sm: "100%" }}
                    direction="row"
                    justifyContent="space-between"
                    bgcolor={`grey.100`}
                  >
                    {/* View jobs post buttons  */}
                    <Button
                      component="a"
                      variant="contained"
                      rel="noopener noreferrer"
                      target="_blank"
                      size="medium"
                      sx={{
                        border: "none",
                        color: "primary.main",
                        borderRadius: "0",
                        background: "transparent",
                        "&:hover": {
                          background: "primary.main",
                          borderRadius: 0,
                          color: "grey.100",
                        },
                        minWidth: "47%",
                      }}
                      onClick={() =>
                        router.push(
                          "/applications/jobs/" + Jobs.id + "/viewJobIndex/"
                        )
                      }
                    >
                      {t("view_job_post_button_title")}
                    </Button>
                    <Divider
                      flexItem={true}
                      orientation={`vertical`}
                      sx={{ borderColor: "#8C8EBA", opacity: 0.3 }}
                    />
                    {/* View candidates  */}
                    <Button
                      component="a"
                      variant="contained"
                      rel="noopener noreferrer"
                      target="_blank"
                      size="medium"
                      sx={{
                        border: "none",
                        borderRadius: "0",
                        color: "primary.main",
                        background: "transparent",
                        "&:hover": {
                          background: "primary.main",
                          borderRadius: 0,
                          color: "grey.100",
                        },
                        minWidth: "50%",
                      }}
                      onClick={() =>
                        router.push("/applications/" + `${Jobs?.id}/`)
                      }
                    >
                      {t("view_candidate_button_title")}
                    </Button>
                  </Stack>
                </Box>
              </Grid>
            );
          })}
          {/* Posted jobs time   */}
          {/* Pagination for Job List   */}
          {openJobsCount >= 9 ? (
            <Grid container spacing={1}>
              <Grid item xs={12}>
                <Box sx={{ display: "flex", justifyContent: "center" }}>
                  <Stack
                    direction="row"
                    alignItems="center"
                    justifyContent="center"
                    paddingTop={5}
                    paddingBottom={3}
                  >
                    <Pagination
                      count={pageNumber}
                      color="secondary"
                      onChange={(e, value) => setJobListPage(value)}
                      sx={{
                        background: "#ECEDF4",
                        borderRadius: "10px",
                        padding: { xs: "5px", sm: "10px" },
                      }}
                    />
                  </Stack>
                </Box>
              </Grid>
            </Grid>
          ) : (
            ""
          )}
        </Grid>
      ) : (
        <NoJobsPosted />
      )}
    </Box>
  );
}

const mapStateToProps = (state: RootState) => ({
  //** all jobs */
  jobs: state.jobs.jobs.slice(0).sort(),
  count: state.jobs.jobsCount,
  //** open jobs */
  openJobs: state.jobs.openJobs.slice(0).sort(),
  openJobsCount: state.jobs.openJobsCount,
});

const mapDispatchToProps = (dispatch: Dispatch) => {
  return {
    listJob: (params: any) => listJob(dispatch, params),
    openJobsList: (params: any) => openJobsList(dispatch, params),
  };
};

export default connect(mapStateToProps, mapDispatchToProps)(JobApplicationCard);
