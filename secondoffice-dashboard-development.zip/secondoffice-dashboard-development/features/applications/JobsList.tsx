// React, Next packages
import React, { useEffect, useState } from "react";
import dynamic from "next/dynamic";
import { useRouter } from "next/router";
import { connect } from "react-redux";
import { Dispatch } from "redux";
// Mui packages
import { Box, Grid, Typography, MenuItem, Select, Button } from "@mui/material";
// 3Rd Party Component/Packages
import { useSnackbar } from "notistack";
import { useTranslation } from "react-i18next";
import "translation/i18n";
// Custom packages
import { ChevronDownIcon, EditIcon, JobSKillIcon } from "@common/Icon";
import {
  CloseJobsPostIcon,
  OpenJobsPostIcon,
  TotalCandidateIcon,
  TotalJobsIcon,
} from "@common/Icon";

import useCompany from "@lib/useCompany";
import {
  ClosedJobsList,
  listJob,
  openJobsList,
  totalCandidateList,
} from "reducers/jobsSlice";
import { renderRelativeDate } from "lib/formatter";
import { RootState } from "reducers";
import JobApplicationCard from "features/applications/JobApplicationCard";
import ClosedJobs from "features/applications/ClosedJobs";
import SummaryCard from "@common/SummaryCard";
import { ExpandLess } from "@mui/icons-material";

// Dynamic import packages
const Layout = dynamic(() =>
  import("@common/Layout").then((mod) => mod.Layout)
);

/* Parent Component */
function JobsList(props: any) {
  //** router */
  const router = useRouter();
  const { enqueueSnackbar } = useSnackbar();
  /* Closed Jobs State */
  const [closedJobs, setClosedJobs] = useState("open");
  const [jobListPage, setJobListPage] = useState(1);
  /** props - actions */
  const { listJob, openJobsList, closedJobsList, totalCandidate } = props;

  /** props - states */
  const {
    jobs,
    count,
    openJobs,
    openJobsCount,
    closedJobsData,
    closedJobsCount,
    candidateCount,
  } = props;

  /** useEffect hooks */
  useEffect(() => {
    const initializeJobList = async () => {
      await listJob({ page: jobListPage, page_size: 100 });
    };

    const openListJobs = async () => {
      await openJobsList({ page: jobListPage, page_size: 9 });
    };
    const closedListJobs = async () => {
      await closedJobsList({ page: jobListPage, page_size: 9 });
    };
    const allCandidate = async () => {
      await totalCandidate();
    };
    try {
      initializeJobList();
      openListJobs();
      closedListJobs();
      allCandidate();
    } catch (error: any) {
      enqueueSnackbar(error.toString(), { variant: "error" });
    }
  }, [jobListPage]);

  /* Jobs open and Close Handle */
  const handleChangeJobs = (e) => {
    setClosedJobs(e.target.value);
    console.log("open and close jobs");
  };

  //**language translation hooks */
  const { t } = useTranslation();

  console.log(count, "check filter value");

  //** Recruit details card data */
  const recruitData = [
    {
      icon: <TotalJobsIcon sx={{ fontSize: "30px" }} />,
      title: `${t("recruit_summary_card_title1")}`,
      count: count,
    },
    {
      icon: <OpenJobsPostIcon sx={{ fontSize: "30px" }} />,
      title: `${t("recruit_summary_card_title2")}`,
      count: openJobsCount,
    },
    {
      icon: <CloseJobsPostIcon sx={{ fontSize: "30px" }} />,
      title: `${t("recruit_summary_card_title3")}`,
      count: closedJobsCount,
    },
    {
      icon: <TotalCandidateIcon sx={{ fontSize: "30px" }} />,
      title: `${t("recruit_summary_card_title4")}`,
      count: candidateCount,
    },
  ];

  // console.log(openJobs, "ye jobs count hhhh");
  return (
    <Box>
      {/* Recruit Summary Card */}
      <SummaryCard cardData={recruitData} cardGridSize={3} />
      {/* jobs filter and post jobs */}
      <Grid container spacing={2}>
        <Grid item xs={12} sm={12}>
          <Box
            paddingTop={5}
            paddingBottom={3}
            sx={{
              display: "flex",
              justifyContent: "space-between",
              alignItems: { xs: "flex-start", sm: "center" },
              flexDirection: { xs: "column", sm: "row" },
            }}
          >
            {/* </FormControl> */}
            <Select
              labelId="demo-simple-select-label"
              id="demo-simple-select"
              value={closedJobs}
              onChange={handleChangeJobs}
              sx={{
                width: { sm: "auto", xs: "100%" },
                height: "44px",
                background: "#f8f8f8",
                "&:hover": {
                  border: "none",
                },
                "& .MuiOutlinedInput-notchedOutline": {
                  border: "none",
                },
              }}
            >
              <MenuItem value={`open`}>
                <Typography
                  variant={closedJobs === "open" ? "h4" : "body2"}
                  sx={{
                    marginBottom: { xs: "20px", sm: "0px", color: "#2c3058" },
                  }}
                >
                  {t("recruit_open_jobs_title")} ({openJobsCount})
                </Typography>
              </MenuItem>
              <MenuItem value={`closed`}>
                <Typography
                  variant={closedJobs === "closed" ? "h4" : "body2"}
                  sx={{ marginBottom: { xs: "20px", sm: "0px" } }}
                >
                  {t("recruit_closed_jobs_title")} ({closedJobsCount})
                </Typography>
              </MenuItem>
            </Select>
            <Button
              variant="contained"
              sx={{ px: 3.5 }}
              onClick={() => router.push("/applications/jobs/add")}
            >
              {t("recruit_jobs_post_button_title")}
            </Button>
          </Box>
        </Grid>
      </Grid>
      <Grid container spacing={2}>
        <Grid item xs={12} md={12} sm={12}>
          {closedJobs === "open" && <JobApplicationCard />}
          {closedJobs === "closed" && <ClosedJobs />}
        </Grid>
      </Grid>
    </Box>
  );
}

const mapStateToProps = (state: RootState) => ({
  jobs: state.jobs.jobs.slice(0).sort(),
  jobsClose: state.jobs.jobsClosedCount,
  count: state.jobs.jobsCount,
  //** open jobs */
  openJobs: state.jobs.openJobs,
  openJobsCount: state.jobs.openJobsCount,
  //** closed jobs */
  closedJobsData: state.jobs.closedJobs,
  closedJobsCount: state.jobs.closedJobsCount,
  //** jobs applied total candidate  */
  candidateCount: state.jobs.totalCandidateCount,
});

const mapDispatchToProps = (dispatch: Dispatch) => {
  return {
    listJob: (params: any) => listJob(dispatch, params),
    openJobsList: (params: any) => openJobsList(dispatch, params),
    closedJobsList: (params: any) => ClosedJobsList(dispatch, params),
    totalCandidate: (params: any) => totalCandidateList(dispatch, params),
  };
};

export default connect(mapStateToProps, mapDispatchToProps)(JobsList);
