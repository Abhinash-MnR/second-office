// React , Next js packages
import React, { useState, useEffect } from "react";
// MUI Packages
import {
  Box,
  Popover,
  Stack,
  FormControlLabel,
  Checkbox,
  FormGroup,
} from "@mui/material";
// Third party packages
// Custom components
import { FilterIcon } from "@common/Icon";

function CardViewJobsFilter(props) {
  //** props - components */
  const { handleFilters, cusines, changeChecked } = props;

  const [anchorEl, setAnchorEl] = React.useState<HTMLButtonElement | null>(
    null
  );

  const handleClick = (event) => {
    setAnchorEl(event.currentTarget);
  };

  const handleClose = () => {
    setAnchorEl(null);
  };

  const open = Boolean(anchorEl);
  const id = open ? "simple-popover" : undefined;

  return (
    <Stack direction={`column`} ml={2.5}>
      <FilterIcon
        aria-describedby={id}
        sx={{ cursor: "pointer" }}
        onClick={handleClick}
      />
      <Popover
        id={id}
        open={open}
        anchorEl={anchorEl}
        onClose={handleClose}
        anchorOrigin={{
          vertical: "bottom",
          horizontal: "left",
        }}
      >
        <Box px={2.5} py={2.5}>
          <FormGroup>
            {cusines.map((item, index) => (
              <FormControlLabel
                key={index}
                control={
                  <Checkbox
                    checked={item.checked}
                    onChange={() => changeChecked(item.id)}
                  />
                }
                label={`${item.label}`}
              />
            ))}
          </FormGroup>
        </Box>
      </Popover>
    </Stack>
  );
}

export default CardViewJobsFilter;
