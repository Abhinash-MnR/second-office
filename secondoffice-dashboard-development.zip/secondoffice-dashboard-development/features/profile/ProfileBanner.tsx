// React, Next packages
import React, { FC, ReactNode } from "react";
import Link from "next/link";
// Mui packages
import { Avatar, Divider, styled, Typography, Stack } from "@mui/material";
// Third-party packages

type ProfileBannerProps = {
  /** Component rendered at the top of the banner */
  header?: ReactNode;
  /** Image for the avatar */
  image?: string;
  /** Biggest text on the 1st line: ex) Name of the user, company, job */
  companyName: string;
  /** Text below the companyName: ex) User's current position  */
  location?: string;
  /** facebook link */
  facebookLink?: string;
  /** twitter link */
  twitterLink?: string;
  /** instagram link */
  instagramLink?: string;
  /** youtube link */
  youtubeLink?: string;
};

/** Styles the first grid with profile images */
const ProfileAvatar = styled(Avatar)(({ theme }) => ({
  borderRadius: 4,
  border: "1px solid rgba(196, 196, 196, 0.5)",
  width: 100,
  height: 100,
  [theme.breakpoints.down("xs")]: {
    margin: "0 auto 10px",
  },
}));

export const ProfileBanner: FC<ProfileBannerProps> = (
  props: ProfileBannerProps
) => {
  /** props */
  const {
    header,
    image,
    companyName,
    location,
    facebookLink,
    twitterLink,
    instagramLink,
    youtubeLink,
  } = props;

  return (
    <div>
      <Stack
        alignItems={{ xs: "center", sm: "flex-start" }}
        direction={{ xs: "column", sm: "row" }}
        flexWrap="wrap"
        justifyContent={{ xs: "center", sm: "flex-start" }}
        spacing={3.75}
        textAlign={{ xs: "center", sm: "left" }}
      >
        <ProfileAvatar src={image} />
        <div>
          <Typography
            sx={{ color: "#282C34", marginBottom: 1 }}
            variant="h4"
            fontWeight="bold"
          >
            {companyName}
          </Typography>
          <Typography
            sx={{ color: "#282C34", fontWeight: "normal", marginBottom: 1 }}
            variant="h6"
          >
            {location}
          </Typography>
        </div>
      </Stack>
      <Divider sx={{ marginY: 3.5 }} />
    </div>
  );
};
