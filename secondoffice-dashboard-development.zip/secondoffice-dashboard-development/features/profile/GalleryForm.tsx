// React, Next packages
import React, { FC } from "react";
import { Form, FormProps, Field } from "react-final-form";
// Mui packages
import { Button, Grid } from "@mui/material";
// Custom packages
import { FileValidator, StringValidator } from "@lib/form-validations";
import { DialogForm, DialogFormProps } from "@common/DialogForm";
import { ImageField, TextField } from "@common/FormField";

type IFormData = {
  /** Gallery image in binary file or string  */
  image?: any;
  /** Gallery image title  */
  title?: string;
  /** Gallery image caption placed below the image  */
  caption?: string;
  /** Gallery image description  */
  description?: string;
};

export type GalleryFormProps = {} & FormProps & DialogFormProps;

const fileValidator = new FileValidator();
const stringValidator = new StringValidator();

export const GalleryForm: FC<GalleryFormProps> = (props: GalleryFormProps) => {
  /** props */
  const { open, onClose, onSubmit } = props;

  return (
    <DialogForm
      open={open}
      onClose={onClose}
      subtitle="Add images of your choice below"
      title="Add Gallery"
    >
      <Form onSubmit={onSubmit}>
        {({ handleSubmit }) => (
          <form onSubmit={handleSubmit}>
            <Grid container spacing={2}>
              <Grid item xs={12}>
                <Field
                  component={ImageField}
                  name="image"
                  title="Please upload your image below*"
                  validate={fileValidator.validateImageRequiredMax1MB}
                />
              </Grid>
              <Grid item xs={12}>
                <Field
                  component={TextField}
                  fullWidth
                  inputProps={{ maxLength: 128 }}
                  name="title"
                  placeholder="Image Title"
                  size="small"
                  title="What is the title of the image?*"
                  validate={stringValidator.validateRequiredMax128}
                  variant="outlined"
                />
              </Grid>
              <Grid item xs={12}>
                <Field
                  component={TextField}
                  fullWidth
                  inputProps={{ maxLength: 128 }}
                  name="caption"
                  placeholder="Caption of the image"
                  size="small"
                  title="Would you like to give a caption to this photo?*"
                  validate={stringValidator.validateRequiredMax128}
                  variant="outlined"
                />
              </Grid>
              <Grid item xs={12}>
                <Field
                  component={TextField}
                  fullWidth
                  inputProps={{ maxLength: 2024 }}
                  multiline
                  name="description"
                  placeholder="Enter your Specific Details..."
                  minRows={4}
                  maxRows={4}
                  title="Any specific details that you wish to enter?"
                  validate={stringValidator.validateMax2024}
                  variant="outlined"
                />
              </Grid>
              <Grid item xs={12}>
                <Button
                  color="primary"
                  fullWidth
                  type="submit"
                  variant="contained"
                >
                  Save
                </Button>
              </Grid>
            </Grid>
          </form>
        )}
      </Form>
    </DialogForm>
  );
};
