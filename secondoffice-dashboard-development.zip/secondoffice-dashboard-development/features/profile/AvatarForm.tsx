// React, Next packages
import React, { ChangeEvent, FC } from "react";

// Mui packages
import { Avatar, ButtonBase, IconButton } from "@mui/material";
import { styled } from "@mui/material";

const IMAGE_HEIGHT = "111px";
const IMAGE_WIDTH = "111px";

type AvatarFormProps = {
  /** Profile image source URL */
  src?: string;
  /** Callback triggered when image changes */
  // onChange: (event: ChangeEvent) => void;
};

type AvatarFormCameraProps = {
  /** Profile image source URL */
  src?: string;
  /** Callback triggered when image changes */
  onChange: (event: ChangeEvent) => void;
};
const ProfileImageContainer = styled("div")(({ theme }) => ({
  overflow: "hidden",
  position: "relative",
  display: "flex",
}));

// TODO - convert hard-coded pixels to relative measures
const AvatarFormContainer = styled("div")(({ theme }) => ({
  border: "1px solid #e7e7e7",
  borderRadius: "50%",
  height: IMAGE_HEIGHT,
  marginBottom: theme.spacing(5),
  overflow: "hidden",
  position: "relative",
  width: IMAGE_WIDTH,
}));
// TODO - convert hard-coded pixels to relative measures
const ProfileAvatarFormContainer = styled("div")(({ theme }) => ({
  marginBottom: theme.spacing(5),
  overflow: "hidden",
  position: "relative",
  width: IMAGE_WIDTH,
  height: IMAGE_HEIGHT,
  marginLeft: "-70px",
}));

// TODO - convert hard-coded pixels to relative measures
const UploadButton = styled(ButtonBase)(({ theme }) => ({
  background: "unset",
  bottom: 0,
  position: "absolute",
  width: "100%",
  height: "46px",
  right: 0,
  zIndex: "99",
}));

// TODO - convert hard-coded pixels to relative measures
const UploadIcon = styled("img")(({ theme }) => ({
  marginTop: "5px",
  marginLeft: "2px",
}));

// Display Profile Image
export const AvatarForm: FC<AvatarFormProps> = (props: AvatarFormProps) => {
  /** props */
  const { src } = props;

  return (
    <AvatarFormContainer>
      <Avatar sx={{ width: IMAGE_WIDTH, height: IMAGE_HEIGHT }} src={src} />
      {/* @ts-ignore */}
      <UploadButton component="label" disabled>
        <input accept="image/*" type="file" style={{ display: "none" }} />
        {/* <UploadIcon src="/svg/ImageUploadIcon.svg" /> */}
      </UploadButton>
    </AvatarFormContainer>
  );
};
// Upload Profile Image
export const AvatarFormCamera: FC<AvatarFormCameraProps> = (
  props: AvatarFormCameraProps
) => {
  /** props */
  const { src, onChange } = props;

  return (
    <ProfileImageContainer>
      <AvatarFormContainer>
        <Avatar sx={{ width: IMAGE_WIDTH, height: IMAGE_HEIGHT }} src={src} />
      </AvatarFormContainer>

      <ProfileAvatarFormContainer>
        {/* @ts-ignore */}
        <UploadButton component="label">
          <input
            accept="image/*"
            id="icon-button-file"
            type="file"
            style={{ display: "none" }}
            onChange={onChange}
          />
          <UploadIcon src="/svg/ImageUploadIcon.svg" />
        </UploadButton>
      </ProfileAvatarFormContainer>
    </ProfileImageContainer>
  );
};
