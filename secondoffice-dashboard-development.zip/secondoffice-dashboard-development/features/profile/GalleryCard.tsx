// React, Next packages
import React, { FC } from "react";
// Mui packages
import { Avatar, styled, Typography } from "@mui/material";

type GalleryCardProps = {
  /** Gallery card image  */
  image?: string;
  /** Gallery card title on first line */
  title?: string;
  /** Gallery card specifics on third line */
  specifics?: string;
};

const GalleryCardRoot = styled("div")(({ theme }) => ({
  display: "flex",
  flexDirection: "column",
  "&:hover": {
    cursor: "pointer",
    background: "rgb(0 0 0 / 10%)",
    borderRadius: 8,
  },
}));

const GalleryCardThumbanilContainer = styled("div")(({ theme }) => ({
  position: "relative",
  paddingTop: "100%" /** keep 1:1 ratio of the child image */,
  overflow: "hidden",
  marginBottom: 10,
}));

const GalleryCardThumbanil = styled(Avatar)(({ theme }) => ({
  position: "absolute",
  top: 0,
  left: 0,
  bottom: 0,
  right: 0,
  width: "100%",
  height: "auto",
  borderRadius: 8,
  border: "1px solid rgba(196, 196, 196, 0.5)",
}));

export const GalleryCard: FC<GalleryCardProps> = ({
  image,
  title,
  specifics,
}: GalleryCardProps) => {
  return (
    <GalleryCardRoot>
      <GalleryCardThumbanilContainer>
        <GalleryCardThumbanil alt={title} src={image} variant="rounded" />
      </GalleryCardThumbanilContainer>
      <Typography align="left" variant="h5" noWrap>
        {title}
      </Typography>
      {specifics && (
        <Typography
          color="textSecondary"
          variant="body2"
          noWrap
          mt={0.5}
          mb={1}
        >
          {specifics}
        </Typography>
      )}
    </GalleryCardRoot>
  );
};
