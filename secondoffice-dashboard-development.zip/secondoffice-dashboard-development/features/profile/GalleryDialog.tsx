// React, Next packages
import React, { FC } from "react";
// Mui packages
import { Avatar, Button, styled, Skeleton, Typography } from "@mui/material";
import { DeleteForever } from "@mui/icons-material";
// Third-party packages
import { Edit2 } from "react-feather";
// Custom packages
import { DialogForm, DialogFormProps } from "@common/DialogForm";
import { GalleryResponse } from "types/GalleryResponse";

export type GalleryDialogProps = {
  /** Callback triggered when close job button is clicked */
  onDelete?: (...params: any) => void;
  /** Callback triggered when edit button is clicked  */
  onEdit?: (...params: any) => void;
  /** Job data from API */
  galleryData: GalleryResponse;
} & DialogFormProps;

const ThumbnailContainer = styled("div")({
  position: "relative",
  paddingTop: "100%" /** keep 1:1 ratio of the child image */,
  overflow: "hidden",
  marginBottom: 10,
});

const Thumbnail = styled(Avatar)({
  position: "absolute",
  top: 0,
  left: 0,
  bottom: 0,
  right: 0,
  width: "100%",
  height: "auto",
  borderRadius: 8,
  border: "1px solid rgba(196, 196, 196, 0.5)",
});

const Caption = styled(Typography)(({ theme }) => ({
  fontSize: theme.typography.h4.fontSize,
  fontWeight: "normal",
  marginBottom: 20,
}));

const Description = styled(Typography)({
  fontSize: 18,
  marginBottom: 20,
});

const buttonIconStyle = {
  fontSize: 20,
  marginRight: 10,
};

export const GalleryDialog: FC<GalleryDialogProps> = (props) => {
  /** third-party hooks */

  /** props */
  const { galleryData, open, onClose, onDelete, onEdit } = props;

  return (
    <DialogForm
      open={open}
      onClose={onClose}
      title={
        galleryData ? galleryData.title : <Skeleton width={300} height={50} />
      }
    >
      {galleryData && (
        <ThumbnailContainer>
          <Thumbnail
            alt={galleryData.title}
            src={galleryData.image}
            variant="rounded"
          />
        </ThumbnailContainer>
      )}
      {galleryData ? (
        <Caption variant="h4">{galleryData.caption}</Caption>
      ) : (
        <Skeleton width={300} height={50} />
      )}

      {galleryData ? (
        <Description variant="body2">{galleryData.description}</Description>
      ) : (
        <Skeleton width={300} height={50} />
      )}

      {onEdit && (
        <Button
          disabled={!galleryData}
          color="primary"
          fullWidth
          variant="contained"
          onClick={onEdit}
        >
          <Edit2 style={buttonIconStyle} color="#ffffff" size={14} />
          Edit
        </Button>
      )}
      {onDelete && (
        <Button disabled={!galleryData} fullWidth onClick={onDelete}>
          <DeleteForever sx={buttonIconStyle} htmlColor="#616161" />
          Delete
        </Button>
      )}
    </DialogForm>
  );
};
