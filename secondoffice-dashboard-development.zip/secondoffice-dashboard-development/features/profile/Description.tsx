// React, Next packages
import React, { FC } from "react";
// Mui packages
import { Typography } from "@mui/material";

type DescriptionProps = {
  // Company Additional decription link
  additionalLink?: string;
  /** Text content */
  description?: string;
  title?: string;
};

export const Description: FC<DescriptionProps> = ({
  description,
  additionalLink,
  title,
}: DescriptionProps) => {
  return (
    <>
      <Typography
        component="div"
        fontWeight="bold"
        variant="caption"
        marginBottom={2}
      >
        {title}
      </Typography>
      <Typography
        color="grey.600"
        marginBottom={3.75}
        variant="body1"
        whiteSpace="pre-line"
      >
        {description ? description : "No update yet."}
      </Typography>
      {additionalLink && (
        <Typography variant="body1" noWrap>
          Additional Description:&nbsp;
          <b>
            <a href={additionalLink} rel="noreferrer noopener" target="_blank">
              {additionalLink}
            </a>
          </b>
        </Typography>
      )}
    </>
  );
};
