// React, Next packages
import React, { FC, ReactNode } from "react";
// Mui packages
import { Divider, Typography, Grid, Stack, styled } from "@mui/material";
// Third-party packages
import { Plus } from "react-feather";
// Custom packages
import { JobCard } from "features/jobs/JobCard";
import { GalleryCard } from "features/profile/GalleryCard";

type ProfileSectionProps = {
  /** Number of cards in the section */
  dataLength?: any;
  /** If `false`, see more button will be hidden  */
  hasMore?: boolean | number;
  /** Callback triggered for the add action the list page */
  onAdd?: (...data: any) => void;
  /** Callback triggered when an item is clicked */
  onRead?: (...data: any) => void;
  /** Callback triggered when an the primary action button is clicked */
  onPrimaryAction?: (...data: any) => void;
  /** Callback triggered when an see more button is clicked */
  onSeeMore?: () => void;
  /** Content within the page */
  sectionData?: Array<any>;
  /** Section title */
  sectionTitle?: string | ReactNode;
};

const EditButton = styled("button")(({ theme }) => ({
  alignItems: "center",
  background: "white",
  border: "none",
  borderRadius: 4,
  color: theme.palette.primary.main,
  display: "flex",
  "&:hover": {
    background: "#e5e5e5",
    color: theme.palette.primary.dark,
    cursor: "pointer",
    fontWeight: "bold",
  },
}));

const EditButtonIcon = styled(Plus)({
  marginRight: 10,
});

export const ProfileSection: FC<ProfileSectionProps> = ({
  dataLength,
  hasMore,
  onAdd,
  onRead,
  onSeeMore,
  onPrimaryAction,
  sectionData,
  sectionTitle,
}: ProfileSectionProps) => {
  const renderCard = (cardData: any) => {
    switch (sectionTitle) {
      case "Job Positions":
        return (
          <Grid
            item
            xs={12}
            sm={4}
            key={cardData.id}
            onClick={() => onRead && onRead(cardData)}
          >
            <JobCard
              data={cardData}
              hasPermission={onAdd ? true : false}
              onViewApplicants={onPrimaryAction}
            />
          </Grid>
        );
      case "Gallery":
        return (
          <Grid
            item
            xs={6}
            sm={4}
            lg={3}
            key={cardData.id}
            onClick={() => onRead && onRead(cardData)}
          >
            <GalleryCard
              image={cardData?.image}
              title={cardData?.title}
              specifics={cardData?.caption}
            />
          </Grid>
        );
      default:
        break;
    }
  };

  return (
    <>
      <Stack direction="row" justifyContent="space-between" mb={1.75}>
        <Typography color="textPrimary" variant="h6" fontWeight="600">
          {sectionTitle}&nbsp;·&nbsp;
          <Typography
            component="span"
            color="primary"
            variant="h6"
            fontWeight="500"
          >
            {dataLength}
          </Typography>
        </Typography>
        {onAdd && (
          <EditButton onClick={onAdd}>
            <EditButtonIcon size={20} />
            <Typography
              style={{ textDecoration: "underline" }}
              color="inherit"
              fontWeight="600"
              variant="h6"
            >
              Add
            </Typography>
          </EditButton>
        )}
      </Stack>
      {sectionData && dataLength ? (
        <Grid container spacing={2}>
          {sectionData.map(renderCard)}
        </Grid>
      ) : (
        <Typography variant="body1">No update yet</Typography>
      )}
      {hasMore && (
        <Typography
          color="textPrimary"
          mt={3.75}
          fontWeight="bold"
          onClick={onSeeMore}
          style={{ cursor: "pointer", textDecorationLine: "underline" }}
          variant="body1"
        >
          See More
        </Typography>
      )}
      <Divider sx={{ paddingTop: 3.75, marginBottom: 3.75 }} />
    </>
  );
};
