// React, Next packages
import React, { FC } from "react";
import { Form, FormProps, Field } from "react-final-form";
import { useRouter } from "next/router";
// Mui packages
import { Button, Grid, Typography } from "@mui/material";
// Third-party packages
// Custom packages
import { Section } from "@common/Section";
import { LocationField, TextField } from "@common/FormField";
import { StringValidator } from "@lib/form-validations";

type IFormData = {
  /** Company's profile image avatar  */
  profile_image?: any;
  /** Company descrption  */
  company_description?: string;
  /** Company's full name  */
  company_name?: string;
  /** Company's location  */
  company_location?: string;
};

export type ProfileFormProps = {} & FormProps;

const stringValidator = new StringValidator();

export const ProfileForm: FC<ProfileFormProps> = (props: ProfileFormProps) => {
  /** custom hooks */
  const router = useRouter();

  /** props */
  const { onSubmit, initialValues } = props;

  /** custom handlers */
  const handleBack = () => router.back();

  return (
    <Form onSubmit={onSubmit} initialValues={initialValues}>
      {({ handleSubmit, valid, values }) => {
        const contentLength = values.company_description?.length;
        return (
          <Section
            title="Edit Company Information"
            footer={
              <>
                <Button onClick={handleBack} fullWidth>
                  Discard Changes
                </Button>
                <Button
                  color="primary"
                  disabled={!valid}
                  form="company_form"
                  fullWidth
                  type="submit"
                  variant="contained"
                >
                  Save
                </Button>
              </>
            }
          >
            <form id="company_form" onSubmit={handleSubmit}>
              <Grid container spacing={2.5}>
                <Grid item xs={12} md={6}>
                  <Field
                    component={TextField}
                    fullWidth
                    name="company_name"
                    placeholder="Company Name"
                    size="small"
                    title="Name of the Company"
                    validate={stringValidator.validateRequiredMax128}
                    variant="outlined"
                  />
                </Grid>
                <Grid item xs={12} md={6}>
                  <Field
                    component={LocationField}
                    fullWidth
                    name="company_location"
                    placeholder="Delhi/NCR"
                    title="Company Location"
                    validate={stringValidator.validateRequiredMax128}
                  />
                </Grid>
                <Grid item xs={12}>
                  <Field
                    component={TextField}
                    fullWidth
                    maxRows={16}
                    minRows={16}
                    multiline
                    name="company_description"
                    placeholder="Introduce the company here."
                    title="Description"
                    variant="outlined"
                    validate={stringValidator.validateMax4000}
                  />
                  <Typography
                    color={contentLength > 4000 ? "error" : "grey.500"}
                    marginTop={0.625}
                    marginBottom={6}
                    textAlign="right"
                    variant="body2"
                  >
                    {/* {contentLength ?? 0}/4,000 */}
                  </Typography>
                </Grid>
              </Grid>
            </form>
          </Section>
        );
      }}
    </Form>
  );
};
