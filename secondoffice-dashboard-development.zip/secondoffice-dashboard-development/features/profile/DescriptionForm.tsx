// React, Next packages
import React, { FC } from "react";
import { Form, FormProps, Field } from "react-final-form";
// Mui packages
import { Button, Grid } from "@mui/material";
// Custom packages
import { StringValidator, URLValidator } from "@lib/form-validations";
import { DialogForm, DialogFormProps } from "@common/DialogForm";
import { TextField } from "@common/FormField";

type IFormData = {
  /** Company description submitted through textarea  */
  company_description?: string;
  /** Company introduction link or any external link  */
  video_link?: string;
};

export type DescriptionFormProps = {} & FormProps & DialogFormProps;

const stringValidator = new StringValidator();
const urlValidator = new URLValidator();

export const DescriptionForm: FC<DescriptionFormProps> = (
  props: DescriptionFormProps
) => {
  /** props */
  const { onSubmit, open, onClose } = props;

  return (
    <DialogForm
      open={open}
      onClose={onClose}
      subtitle="You can describe your company in different ways."
      title="Company Description"
    >
      <Form onSubmit={onSubmit}>
        {({ handleSubmit, valid }) => (
          <form onSubmit={handleSubmit}>
            <Grid container spacing={2}>
              <Grid item xs={12}>
                <Field
                  component={TextField}
                  fullWidth
                  inputProps={{ maxLength: 2024 }}
                  multiline
                  name="company_description"
                  placeholder="Company Description..."
                  minRows={4}
                  maxRows={20}
                  title="Describe your company below"
                  validate={stringValidator.validateMax2024}
                  variant="outlined"
                />
              </Grid>
              <Grid item xs={12}>
                <Field
                  component={TextField}
                  fullWidth
                  name="video_link"
                  placeholder="Link (Google Drive Link Also Accepted)"
                  size="small"
                  title="You can add additional details in form of a link"
                  validate={urlValidator.validateURL}
                  helperText="You can add the company presentation, company video or the link to your website"
                  variant="outlined"
                />
              </Grid>
              <Grid item xs={12}>
                <Button
                  color="primary"
                  disabled={!valid}
                  fullWidth
                  type="submit"
                  variant="contained"
                >
                  Save
                </Button>
              </Grid>
            </Grid>
          </form>
        )}
      </Form>
    </DialogForm>
  );
};
