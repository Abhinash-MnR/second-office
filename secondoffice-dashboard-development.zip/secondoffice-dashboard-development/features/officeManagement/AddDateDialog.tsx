// React, Next packages
import React, { useState, useEffect, FC } from "react";
// Mui packages
import {
  Box,
  Button,
  Chip,
  Skeleton,
  Stack,
  styled,
  Grid,
  TextField,
} from "@mui/material";
// Custom packages
import { DialogForm, DialogFormProps } from "@common/DialogForm";
import { AddCommentDialog } from "./Dialog";
// import { formatUnderscore } from "@lib/formatter";
import { JobListResponse } from "types/JobResponse";
// 3Rd Party Component/Packages
import { useSnackbar } from "notistack";
import moment from "moment";
import { useTranslation } from "react-i18next";
import "translation/i18n";

export type AddDateDialogProps = {
  /** Callback triggered when close job button is clicked */
  // onDelete?: (...params: any) => void;
  /** Callback triggered when edit button is clicked  */
  onSubmit?: (...params: any) => void;
  /** Job data from API */
  teamRoaster()
} & DialogFormProps;

const StackItem = styled("div")(({ theme }) => ({
  alignItems: "center",
  color: theme.palette.grey[500],
  display: "flex",
  marginBottom: 15,
  marginRight: 30,

  "& :first-of-type": {
    color: theme.palette.grey[600],
    fontSize: 14,
    marginRight: 10,
  },
}));
const onSubmitRating = () => {
  console.log("submit tapped");
};

export const AddDateDialog: FC<AddDateDialogProps> = (props) => {
  /** props */
  const { open, onClose, onSubmit , teamRoaster } = props;
  const [isName, setIsName] = useState("");
  const [date, setDate] = useState("");
  const [score, setScore] = useState("");
  const [feedback, setFeedback] = useState("");
  const [openAddComment, setOpenAddComment] = React.useState(false);
  const { enqueueSnackbar } = useSnackbar();

  //** Language translation hooks */
  const { t } = useTranslation();

  useEffect(() => {
    console.log("isName:-", isName);
  }, [isName]);

  const handleSubmitComment = async (
    isName: any,
    score: any,
    date: any,
    feedback: any
  ) => {};

  return (
    <DialogForm
      open={open}
      onClose={onClose}
      title={`${t("offie_management_eveluation_button_title")}`}
      subtitle={`${t("office_management_evaluation_popup_desc")}`}
      footer={
        <Stack
          alignItems="center"
          direction="row"
          justifyContent="center"
          width={{ xs: "100%", md: "100%" }}
          // sx={{ padding: { xs: "20px 0px", sm: "1px 45px 30px 45px" } }}
        >
          <Button
            //   disabled={!jobData}
            color="primary"
            fullWidth
            variant="contained"
            onClick={() => {
              if (date) {
                onSubmit("-", date, "0", "-");
              } else {
                enqueueSnackbar("Employee feedback date required", {
                  variant: "error",
                });
              }
            }}
          >
            {t("office_management_evaluation_popup_button_title_title")}
          </Button>
          <AddCommentDialog
            // jobData={selectedJob}
            onSubmit={(isName, date, score, feedback) =>
              handleSubmitComment(isName, date, score, feedback)
            }
            teamRoaster={teamRoaster}
            open={openAddComment}
            onClose={() => setOpenAddComment(false)}
          />
        </Stack>
      }
    >
      <Stack direction="row" flexWrap="wrap" sx={{ paddingTop: "5px" }}>
        {/* Employee Performance Date TextField */}
        <Grid container spacing={2}>
          {/* Date TextField */}
          <Grid item xs={12}>
            <TextField
              label="Date"
              type="Date"
              name="Date"
              onChange={(e) => {
                setDate(e.target.value);
              }}
              InputLabelProps={{
                shrink: true,
              }}
              value={date}
              variant="outlined"
              fullWidth
            />
          </Grid>
        </Grid>
      </Stack>
    </DialogForm>
  );
};
