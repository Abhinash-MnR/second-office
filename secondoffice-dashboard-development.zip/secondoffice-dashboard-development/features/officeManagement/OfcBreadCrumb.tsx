// React, Next packages
import React from "react";
import dynamic from "next/dynamic";
// Mui packages
import {
  Box,
  styled,
  Breadcrumbs,
  Typography,
  Stack,
  Link,
} from "@mui/material";

import NavigateNextIcon from "@mui/icons-material/NavigateNext";
// custom Component

const CustomContainer = styled("div")(({ theme }) => ({
  display: "flex",
  flexDirection: "column",
}));

function OfcBreadCrumb(props) {
  /** Breadcrumb Data Destructure from props */
  /** BeradCrumb Data */
  /** Material Ui Link used for BreadCrumb  */
  const breadcrumbs = [
    <Link key="1" href="/officeManagement" sx={{ textDecoration: "none" }}>
      Office Management
    </Link>,
    <Typography key="2" color="text.primary">
      Management Log
    </Typography>,
  ];

  return (
    <CustomContainer>
      <Box>
        <Breadcrumbs
          separator={<NavigateNextIcon fontSize="small" />}
          aria-label="breadcrumb"
        >
          {breadcrumbs}
        </Breadcrumbs>
      </Box>
    </CustomContainer>
  );
}

export default OfcBreadCrumb;
