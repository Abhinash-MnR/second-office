// React, Next Js packages
import React, { useState, useEffect } from "react";
import Link from "next/link";
// MUI Packages
import { Box, Stack, Typography, Grid, Pagination } from "@mui/material";
// 3Rd Party Component/Packages
import { useSnackbar } from "notistack";
import moment from "moment";
import { useTranslation } from "react-i18next";
// Custom components
import { CalendarIcon } from "@common/Icon";

function AttendanceInCardView(props) {
  //** props - components */
  const { attendanceData, pageNumber, count, handlePagination } = props;
  //** Language translation hooks */
  const { t } = useTranslation();
  //** month list */
  const monthList = [
    `${t("january_title")}`,
    `${t("february_title")}`,
    `${t("march_title")}`,
    `${t("april_title")}`,
    `${t("may_title")}`,
    `${t("june_title")}`,
    `${t("july_title")}`,
    `${t("august_title")}`,
    `${t("september_title")}`,
    `${t("october_title")}`,
    `${t("november_title")}`,
    `${t("december_title")}`,
  ];

  return (
    <Box>
      <Grid container spacing={3}>
        {attendanceData.map((data: any, index) => {
          //const date define
          const multiLanguageDateFormat = moment(
            data?.attendance_log_date
          ).format("MMMM");
          // day and year format
          const dayYearFormat = moment(data?.attendance_log_date).format(
            "DD,YYYY"
          );
          return (
            <Grid item xs={12} sm={3} key={index}>
              <Box
                bgcolor={`grey.100`}
                py={2.5}
                px={2.5}
                borderRadius={1.25}
                border="1px solid rgba(140, 142, 186, 0.3)"
              >
                <Stack direction={`column`}>
                  <CalendarIcon />
                  <Typography variant="body1" mt={1}>
                    {/* {data.attendance_log_date} */}
                    {multiLanguageDateFormat === "January"
                      ? monthList[0].concat(" ", dayYearFormat)
                      : multiLanguageDateFormat === "February"
                      ? monthList[1].concat(" ", dayYearFormat)
                      : multiLanguageDateFormat === "March"
                      ? monthList[2].concat(" ", dayYearFormat)
                      : multiLanguageDateFormat === "April"
                      ? monthList[3].concat(" ", dayYearFormat)
                      : multiLanguageDateFormat === "May"
                      ? monthList[4].concat(" ", dayYearFormat)
                      : multiLanguageDateFormat === "June"
                      ? monthList[5].concat(" ", dayYearFormat)
                      : multiLanguageDateFormat === "July"
                      ? monthList[6].concat(" ", dayYearFormat)
                      : multiLanguageDateFormat === "August"
                      ? monthList[7].concat(" ", dayYearFormat)
                      : multiLanguageDateFormat === "September"
                      ? monthList[8].concat(" ", dayYearFormat)
                      : multiLanguageDateFormat === "October"
                      ? monthList[9].concat(" ", dayYearFormat)
                      : multiLanguageDateFormat === "November"
                      ? monthList[10].concat(" ", dayYearFormat)
                      : multiLanguageDateFormat === "December"
                      ? monthList[11].concat(" ", dayYearFormat)
                      : ""}
                  </Typography>
                </Stack>
                <Stack direction={`column`} mt={1.5}>
                  <Link href={data.attendance_log}>
                    <a target={`_blank`}>
                      <Typography
                        variant="body2"
                        mt={1}
                        color={`primary.main`}
                        sx={{ fontWeight: 600 }}
                      >
                        {t("office_management_attendance_table_data_view_log")}
                      </Typography>
                    </a>
                  </Link>
                </Stack>
              </Box>
            </Grid>
          );
        })}
      </Grid>
      {/* pagination  */}
      {count > 12 ? (
        <Stack
          direction="row"
          alignItems="center"
          justifyContent="center"
          paddingTop={5}
          paddingBottom={3}
        >
          <Pagination
            count={pageNumber}
            color="secondary"
            // onChange={(e, value) => handlePagination(value)}
            sx={{
              background: "#ECEDF4",
              borderRadius: "10px",
              padding: { xs: "5px", sm: "10px" },
            }}
          />
        </Stack>
      ) : (
        ""
      )}
    </Box>
  );
}

export default AttendanceInCardView;
