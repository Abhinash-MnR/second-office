// React, Next packages
import React, { useState, useEffect } from "react";
import dynamic from "next/dynamic";
import Link from "next/link";
import { connect } from "react-redux";
import { Dispatch } from "redux";
// Mui packages
import {
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  Paper,
  Typography,
  styled,
  Stack,
  Grid,
  Box,
  Pagination,
} from "@mui/material";

//  packages
import { RootState } from "reducers";
import { teamExpectedNewJoinersList } from "@reducers/teamExpectedNewJoinersSlice";
import {
  EURIconColor,
  INRIconColor,
  KRWIconColor,
  USDIconColor,
} from "@common/Icon";
// 3Rd Party Component/Packages
import { useSnackbar } from "notistack";
import NoOfficeData from "./NoOfficeData";
import moment from "moment";
import { useTranslation } from "react-i18next";
import "translation/i18n";
// Custom Component
import useCompany from "@lib/useCompany";
import useCurrency from "@lib/useCurrency";

const CustomContainer = styled("div")(({ theme }) => ({
  display: "flex",
  flexDirection: "column",
}));
const CustomTableContainer = styled("div")(({ theme }) => ({
  display: "flex",
}));

const StyledTableRow = styled(TableRow)(({ theme }) => ({
  "&:nth-of-type(odd)": {
    // backgroundColor: theme.palette.action.hover,
  },
  // hide last border
  "&:last-child td, &:last-child th": {
    border: 0,
  },
}));

const StyledTableCell = styled(TableCell)(({ theme }) => ({
  fontSize: 14,
  width: "17%",
}));

function ExpectedNewJoiners(props: any) {
  //SnackBar
  const { enqueueSnackbar } = useSnackbar();
  /** props - actions */
  const { teamExpectedNewJoinersList } = props;
  /** props - states */
  const { result, count } = props;
  const pageNumber = Math.ceil(count / 10);
  const [jobListPage, setJobListPage] = useState(1);

  /** third-party hooks */
  const { company } = useCompany();

  //** Language translation hooks */
  const { t } = useTranslation();

  const { currency } = useCurrency();

  // Convert number with commas
  const numberWithCommas = (x: string) => {
    return x.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",");
  };

  /** useEffect hooks */
  useEffect(() => {
    const roaster = async () => {
      await teamExpectedNewJoinersList({ page: jobListPage, page_size: 10 });
    };

    try {
      roaster();
    } catch (error: any) {
      enqueueSnackbar(error.toString(), { variant: "error" });
    }
  }, [jobListPage]);

  // console.log("check team Roaster", result);
  //** month list */
  const monthList = [
    `${t("january_title")}`,
    `${t("february_title")}`,
    `${t("march_title")}`,
    `${t("april_title")}`,
    `${t("may_title")}`,
    `${t("june_title")}`,
    `${t("july_title")}`,
    `${t("august_title")}`,
    `${t("september_title")}`,
    `${t("october_title")}`,
    `${t("november_title")}`,
    `${t("december_title")}`,
  ];

  return (
    <CustomContainer>
      <CustomTableContainer>
        <TableContainer component={Paper} sx={{ boxShadow: "none" }}>
          <Table sx={{ minWidth: 1050 }} aria-label="simple table">
            <TableHead sx={{ background: "#ECEDF4", opacity: "1" }}>
              <StyledTableRow>
                <StyledTableCell
                  sx={{ fontSize: 16, lineHeight: 1.5, fontWeight: 700 }}
                >
                  {t("office_management_expected_newjoiners_table_head_emp")}
                </StyledTableCell>
                <StyledTableCell
                  sx={{ fontSize: 16, lineHeight: 1.5, fontWeight: 700 }}
                >
                  {t(
                    "office_management_expected_newjoiners_table_head_position"
                  )}
                </StyledTableCell>
                <StyledTableCell
                  sx={{ fontSize: 16, lineHeight: 1.5, fontWeight: 700 }}
                >
                  {t("office_management_expected_newjoiners_table_head_ctc")}
                </StyledTableCell>
                <StyledTableCell
                  sx={{ fontSize: 16, lineHeight: 1.5, fontWeight: 700 }}
                >
                  {t(
                    "office_management_expected_newjoiners_table_head_joining"
                  )}
                </StyledTableCell>
                <StyledTableCell
                  sx={{ fontSize: 16, lineHeight: 1.5, fontWeight: 700 }}
                >
                  {t(
                    "office_management_expected_newjoiners_table_head_emp_status"
                  )}
                </StyledTableCell>
                <StyledTableCell
                  sx={{ fontSize: 16, lineHeight: 1.5, fontWeight: 700 }}
                >
                  {t("office_management_expected_newjoiners_table_head_resume")}
                </StyledTableCell>
              </StyledTableRow>
            </TableHead>

            <TableBody>
              {result.map((row: any) => {
                //const date define
                const multiLanguageDateFormat = moment(
                  row?.new_joiner_join_date
                ).format("MMMM");
                // day and year format
                const dayYearFormat = moment(row?.new_joiner_join_date).format(
                  "DD, YYYY"
                );
                return (
                  <TableRow
                    key={row.id}
                    sx={{
                      "&:last-child td, &:last-child th": { border: 0 },
                    }}
                  >
                    <StyledTableCell
                      component="th"
                      scope="row"
                      sx={{
                        fontSize: 14,
                        fontWeight: 600,
                        lineHeight: 1.5,
                        color: "#222222",
                      }}
                    >
                      {row.new_joiner_name}
                    </StyledTableCell>
                    <StyledTableCell>
                      {row?.new_joiner_position}
                    </StyledTableCell>
                    <StyledTableCell>
                      {company && currency && company.currency === "KRW" ? (
                        <KRWIconColor sx={{ fontSize: "10px" }} />
                      ) : company && currency && company.currency === "USD" ? (
                        <USDIconColor sx={{ fontSize: "10px" }} />
                      ) : company && currency && company.currency === "EUR" ? (
                        <EURIconColor sx={{ fontSize: "10px" }} />
                      ) : (
                        <INRIconColor sx={{ fontSize: "10px" }} />
                      )}

                      {company && currency && company.currency === "KRW"
                        ? numberWithCommas(
                            (
                              row?.new_joiner_CTC * currency.currency_krw
                            ).toFixed(2)
                          )
                        : company && currency && company.currency === "USD"
                        ? numberWithCommas(
                            (
                              (row?.new_joiner_CTC * currency.currency_usd) /
                              1000
                            ).toFixed(2)
                          )
                        : company && currency && company.currency === "EUR"
                        ? numberWithCommas(
                            (
                              (row?.new_joiner_CTC * currency.currency_eur) /
                              1000
                            ).toFixed(2)
                          )
                        : numberWithCommas(
                            (row?.new_joiner_CTC / 100000).toFixed(2)
                          )}

                      {company && currency && company.currency === "KRW"
                        ? ""
                        : company && currency && company.currency === "USD"
                        ? " K"
                        : company && currency && company.currency === "EUR"
                        ? "K"
                        : " LPA"}
                    </StyledTableCell>
                    <StyledTableCell>
                      {/* {row?.employee_join_date} */}
                      {/* 
                      {moment(row?.new_joiner_join_date).format(
                        "MMMM DD, YYYY"
                      )} */}
                      {multiLanguageDateFormat === "January"
                        ? monthList[0].concat(" ", dayYearFormat)
                        : multiLanguageDateFormat === "February"
                        ? monthList[1].concat(" ", dayYearFormat)
                        : multiLanguageDateFormat === "March"
                        ? monthList[2].concat(" ", dayYearFormat)
                        : multiLanguageDateFormat === "April"
                        ? monthList[3].concat(" ", dayYearFormat)
                        : multiLanguageDateFormat === "May"
                        ? monthList[4].concat(" ", dayYearFormat)
                        : multiLanguageDateFormat === "June"
                        ? monthList[5].concat(" ", dayYearFormat)
                        : multiLanguageDateFormat === "July"
                        ? monthList[6].concat(" ", dayYearFormat)
                        : multiLanguageDateFormat === "August"
                        ? monthList[7].concat(" ", dayYearFormat)
                        : multiLanguageDateFormat === "September"
                        ? monthList[8].concat(" ", dayYearFormat)
                        : multiLanguageDateFormat === "October"
                        ? monthList[9].concat(" ", dayYearFormat)
                        : multiLanguageDateFormat === "November"
                        ? monthList[10].concat(" ", dayYearFormat)
                        : multiLanguageDateFormat === "December"
                        ? monthList[11].concat(" ", dayYearFormat)
                        : ""}
                    </StyledTableCell>
                    <StyledTableCell>{row?.new_joiner_status}</StyledTableCell>
                    <StyledTableCell>
                      <Stack
                        direction="row"
                        alignItems="center"
                        justifyContent="start"
                      >
                        <Typography
                          component="span"
                          sx={{
                            fontSize: 14,
                            fontWeight: 700,
                            lineHeight: 1.5,
                            color: "#2c3058",
                          }}
                        >
                          <Link href={row.new_joiner_resume}>
                            <a target="_blank">
                              {t("view_candidate_view_resume_title")}
                            </a>
                          </Link>
                        </Typography>
                      </Stack>
                    </StyledTableCell>
                  </TableRow>
                );
              })}
            </TableBody>
          </Table>
        </TableContainer>
      </CustomTableContainer>
      {/* Empty State when data not available  */}
      <Box>
        {result.length > 0 ? null : (
          <NoOfficeData
            title={`${t("expectedJoiners_empty_screen_title")}`}
            imgName="Illust-2"
          />
        )}
      </Box>
      {/* Pagination for Team Roaster List   */}
      {count > 10 ? (
        <Grid container spacing={1}>
          <Grid item xs={12}>
            <Box sx={{ display: "flex", justifyContent: "center" }}>
              <Stack
                direction="row"
                alignItems="center"
                justifyContent="center"
                paddingTop={5}
                paddingBottom={3}
              >
                <Pagination
                  count={pageNumber}
                  color="secondary"
                  onChange={(e, value) => setJobListPage(value)}
                  sx={{
                    background: "#ECEDF4",
                    borderRadius: "10px",
                    padding: { xs: "5px", sm: "10px" },
                  }}
                />
              </Stack>
            </Box>
          </Grid>
        </Grid>
      ) : (
        ""
      )}
    </CustomContainer>
  );
}

const mapStateToProps = (state: RootState) => ({
  result: state.newJoiners.results,
  count: state.newJoiners.count,
});

const mapDispatchToProps = (dispatch: Dispatch) => {
  return {
    teamExpectedNewJoinersList: (params: any) =>
      teamExpectedNewJoinersList(dispatch, params),
  };
};

export default connect(mapStateToProps, mapDispatchToProps)(ExpectedNewJoiners);
