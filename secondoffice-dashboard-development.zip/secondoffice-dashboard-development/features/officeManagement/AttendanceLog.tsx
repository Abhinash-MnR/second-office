// React, Next packages
import React, { useState, useEffect } from "react";
import { connect } from "react-redux";
import { Dispatch } from "redux";
import dynamic from "next/dynamic";
import Link from "next/link";
// Mui packages
import {
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  Paper,
  Typography,
  styled,
  Box,
  Pagination,
  Grid,
  Stack,
} from "@mui/material";
// 3Rd Party Component/Packages
import { useSnackbar } from "notistack";
import moment from "moment";
import { useTranslation } from "react-i18next";
import "translation/i18n";
// Custom packages
import { RootState } from "reducers";
import { teamAttendanceLogList } from "@reducers/teamAttendanceLogSlice";
import NoOfficeData from "features/officeManagement/NoOfficeData";

const StyledTableRow = styled(TableRow)(({ theme }) => ({
  "&:nth-of-type(odd)": {
    // backgroundColor: theme.palette.action.hover,
  },
  // hide last border
  "&:last-child td, &:last-child th": {
    border: 0,
  },
}));

const StyledTableCell = styled(TableCell)(({ theme }) => ({
  fontSize: 14,
  padding: "18px",
}));

function AttendanceLog(props: any) {
  //SnackBar
  const { enqueueSnackbar } = useSnackbar();
  /** props - actions */
  const { teamAttendanceLogList } = props;
  /** props - states */
  const { result, count } = props;
  const pageNumber = Math.ceil(count / 10);
  const [attendanceLogListPage, setAttendanceLogListPage] = useState(1);

  //** Language translation hooks */
  const { t } = useTranslation();

  /** useEffect hooks */
  useEffect(() => {
    const roaster = async () => {
      await teamAttendanceLogList({
        page: attendanceLogListPage,
        page_size: 10,
      });
    };

    try {
      roaster();
    } catch (error: any) {
      enqueueSnackbar(error.toString(), { variant: "error" });
    }
  }, [attendanceLogListPage]);

  // console.log(
  //   result[0]?.attendance_log_date.split("-"),
  //   "check attendance result"
  // );
  //** month list */
  const monthList = [
    `${t("january_title")}`,
    `${t("february_title")}`,
    `${t("march_title")}`,
    `${t("april_title")}`,
    `${t("may_title")}`,
    `${t("june_title")}`,
    `${t("july_title")}`,
    `${t("august_title")}`,
    `${t("september_title")}`,
    `${t("october_title")}`,
    `${t("november_title")}`,
    `${t("december_title")}`,
  ];

  return (
    <Box display={`flex`} flexDirection={`column`}>
      <Box display={`flex`}>
        <TableContainer component={Paper} sx={{ boxShadow: "none" }}>
          <Table sx={{ minWidth: 1050 }} aria-label="simple table">
            <TableHead sx={{ background: "#ECEDF4" }}>
              <StyledTableRow>
                <StyledTableCell
                  sx={{
                    fontSize: 16,
                    lineHeight: 1.5,
                    fontWeight: 700,
                    width: "90%",
                  }}
                >
                  {t("office_management_attendance_table_head_date")}
                </StyledTableCell>
                <StyledTableCell
                  sx={{
                    fontSize: 16,
                    lineHeight: 1.5,
                    fontWeight: 700,
                    width: "10%",
                  }}
                >
                  {t("office_management_attendance_table_head_log")}
                </StyledTableCell>
              </StyledTableRow>
            </TableHead>
            <TableBody>
              {result?.map((row, index) => {
                //const date define
                const multiLanguageDateFormat = moment(
                  row?.attendance_log_date
                ).format("MMMM");
                // day and year format
                const dayYearFormat = moment(row?.attendance_log_date).format(
                  "DD,YYYY"
                );
                return (
                  <TableRow
                    key={row?.id}
                    sx={{ "&:last-child td, &:last-child th": { border: 0 } }}
                  >
                    <StyledTableCell
                      component="th"
                      scope="row"
                      sx={{
                        fontSize: 14,
                        fontWeight: 400,
                        lineHeight: 1.5,
                        color: "#222222",
                      }}
                    >
                      {/* {multiLanguageDateFormat === "January" ? "Shani" : null} */}
                      {multiLanguageDateFormat === "January"
                        ? monthList[0].concat(" ", dayYearFormat)
                        : multiLanguageDateFormat === "February"
                        ? monthList[1].concat(" ", dayYearFormat)
                        : multiLanguageDateFormat === "March"
                        ? monthList[2].concat(" ", dayYearFormat)
                        : multiLanguageDateFormat === "April"
                        ? monthList[3].concat(" ", dayYearFormat)
                        : multiLanguageDateFormat === "May"
                        ? monthList[4].concat(" ", dayYearFormat)
                        : multiLanguageDateFormat === "June"
                        ? monthList[5].concat(" ", dayYearFormat)
                        : multiLanguageDateFormat === "July"
                        ? monthList[6].concat(" ", dayYearFormat)
                        : multiLanguageDateFormat === "August"
                        ? monthList[7].concat(" ", dayYearFormat)
                        : multiLanguageDateFormat === "September"
                        ? monthList[8].concat(" ", dayYearFormat)
                        : multiLanguageDateFormat === "October"
                        ? monthList[9].concat(" ", dayYearFormat)
                        : multiLanguageDateFormat === "November"
                        ? monthList[10].concat(" ", dayYearFormat)
                        : multiLanguageDateFormat === "December"
                        ? monthList[11].concat(" ", dayYearFormat)
                        : ""}
                    </StyledTableCell>
                    <StyledTableCell
                      sx={{ fontWeight: "700", color: "#2c3058" }}
                    >
                      <Link href={row?.attendance_log}>
                        <a target="_blank">
                          {t(
                            "office_management_attendance_table_data_view_log"
                          )}
                        </a>
                      </Link>
                    </StyledTableCell>
                  </TableRow>
                );
              })}
            </TableBody>
          </Table>
        </TableContainer>
      </Box>
      {/* Empty State when data not available  */}
      <Box>
        {result.length > 0 ? null : (
          <NoOfficeData
            title={`${t("attendance_empty_screen_title")}`}
            imgName="Illust-4"
          />
        )}
      </Box>
      {/* Pagination for Team Expenses List   */}
      {count > 10 ? (
        <Grid container spacing={1}>
          <Grid item xs={12}>
            <Box sx={{ display: "flex", justifyContent: "center" }}>
              <Stack
                direction="row"
                alignItems="center"
                justifyContent="center"
                paddingTop={5}
                paddingBottom={3}
              >
                <Pagination
                  count={pageNumber}
                  color="secondary"
                  onChange={(e, value) => setAttendanceLogListPage(value)}
                  sx={{
                    background: "#ECEDF4",
                    borderRadius: "10px",
                    padding: { xs: "5px", sm: "10px" },
                  }}
                />
              </Stack>
            </Box>
          </Grid>
        </Grid>
      ) : (
        ""
      )}
    </Box>
  );
}

const mapStateToProps = (state: RootState) => ({
  result: state.attendanceLog.results.slice(0).sort(),
  count: state.attendanceLog.count,
});

const mapDispatchToProps = (dispatch: Dispatch) => {
  return {
    teamAttendanceLogList: (params: any) =>
      teamAttendanceLogList(dispatch, params),
  };
};

export default connect(mapStateToProps, mapDispatchToProps)(AttendanceLog);
