// React, Next packages
import React, { useState, useEffect } from "react";
import router from "next/router";
import dynamic from "next/dynamic";
import Link from "next/link";
import { connect } from "react-redux";
import { Dispatch } from "redux";
// Mui packages
import {
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  Paper,
  Typography,
  styled,
  Stack,
  Box,
  Button,
  Grid,
  Pagination,
  Tooltip,
  IconButton,
} from "@mui/material";

// 3Rd Party Component/Packages
import { useTranslation } from "react-i18next";
import "translation/i18n";
import { useSnackbar } from "notistack";
import moment from "moment";

// Custom packages
import { ToolTipIconColor } from "@common/Icon";
import ReadMore from "@common/ReadMore";
import { RootState } from "reducers";
import { teamPerformanceList } from "reducers/teamPerformanceSlice";
import { AddCommentDialog } from "./Dialog";
import { TeamChevronDown, TeamChevronRight } from "@common/Icon";
import { AddDateDialog } from "./AddDateDialog";
import {
  postTeamPerformance,
  putTeamPerformanceHrAction,
} from "@api/teamPerformance";

import NoOfficeData from "./NoOfficeData";
import HRActions from "features/officeExpenses/HrActions";
import { employeeList } from "@reducers/employeeListSlice";

const CustomContainer = styled("div")(({ theme }) => ({
  display: "flex",
  flexDirection: "column",
  // marginTop: "50px",
}));
const CustomTableContainer = styled("div")(({ theme }) => ({
  display: "flex",
}));

const StyledTableRow = styled(TableRow)(({ theme }) => ({
  "&:nth-of-type(odd)": {
    // backgroundColor: theme.palette.action.hover,
  },
  // hide last border
  "&:last-child td, &:last-child th": {
    border: 0,
  },
}));

const StyledTableCell = styled(TableCell)(({ theme }) => ({
  fontSize: 14,
}));

const CustomSelectContainer = styled("div")(({ theme }) => ({
  display: "flex",
  justifyContent: "space-between",
  paddingBottom: "20px",
  [theme.breakpoints.down("sm")]: {
    display: "flex",
    flexDirection: "column",
  },
}));

function Testing(props: any) {
  // // Team Performance data -- Props
  const { isName, date, feedback, score } = props;
  const { enqueueSnackbar } = useSnackbar();

  //** Language translation hooks */
  const { t } = useTranslation();

  /** props - actions */
  const { teamPerformanceList } = props;
  /** props - states */
  const { result, count, performanceList } = props;
  const pageNumber = Math.ceil(count / 10);
  const rowsPerPage = 10;
  const [teamPerformanceListPage, setTeamPerformanceListPage] = useState(1);
  const [tableOpen, setTableOpen] = useState(false);
  const [selectedIndex, setSelectedIndex] = useState(0);
  const [open, setOpen] = React.useState(false);
  const [openComment, setOpenComment] = React.useState(null);
  const [performanceData, setPerformanceData] = React.useState();
  const [performanceId, setPerformanceId] = React.useState();
  const [employee, setEmployee] = React.useState("");
  const [page, setPage] = useState(1);
  const [internalTablePage, setInternalTablePage] = useState(1);

  /** props - actions */
  const { employeeList } = props;
  /** props - states */
  const { teamResult, teamCount } = props;

  /** useEffect hooks */
  useEffect(() => {
    const roaster = async () => {
      await employeeList({ page: 1, page_size: 0, job_status: "current" });
    };

    try {
      roaster();
    } catch (error: any) {
      enqueueSnackbar(error.toString(), { variant: "error" });
    }
  }, [teamResult.length === 0]);

  /** get employee list */
  const roaster = async () => {
    await employeeList({ page: 1, page_size: 0, job_status: "current" });
  };

  /** useEffect hooks */
  useEffect(() => {
    const performance = async () => {
      await teamPerformanceList({
        page: teamPerformanceListPage,
        page_size: 1000000,
      });
    };

    try {
      performance();
    } catch (error: any) {
      enqueueSnackbar(error.toString(), { variant: "error" });
    }
  }, [teamPerformanceListPage]);

  const handleSubmitComment = async (
    isName: any,
    date: any,
    score: any,
    feedback: any
  ) => {
    try {
      // Create form payload
      const payload = {
        performance_employee: isName,
        performance_date: performanceData,
        performance_score: score,
        performance_comments: feedback,
      };
      const teamPerformance =
        employee !== "-"
          ? await postTeamPerformance(payload)
          : putTeamPerformanceHrAction(performanceId, payload);
      enqueueSnackbar(`${t("team_performance_submit_rating")}`, {
        variant: "info",
      });
      setOpen(false);
      setTimeout(() => {
        router.reload();
      }, 500);
      // setSelectedJob(undefined);
      // toggleJobForm();
    } catch (error: any) {
      enqueueSnackbar("Unexpected error occurred. Please try again.");
    }
  };
  const handleSubmitdate = async (
    isName: any,
    date: any,
    score: any,
    feedback: any
  ) => {
    try {
      // Create form payload
      const payload = {
        performance_employee: isName,
        performance_date: date,
        performance_score: score,
        performance_comments: feedback,
      };
      const teamPerformance = await postTeamPerformance(payload);
      enqueueSnackbar(`${t("team_performance_date_added")}`, {
        variant: "info",
      });
      setOpen(false);
      router.reload();
      // setSelectedJob(undefined);
      // toggleJobForm();
    } catch (error: any) {
      enqueueSnackbar("Unexpected error occurred. Please try again.");
    }
  };

  //** team performance month pagination  */
  const objectLength = Object.keys(performanceList).length;
  const pageObject = Math.ceil(objectLength / rowsPerPage);

  console.log(pageObject, "pageObject final value");

  //** month list */
  const monthList = [
    `${t("january_title")}`,
    `${t("february_title")}`,
    `${t("march_title")}`,
    `${t("april_title")}`,
    `${t("may_title")}`,
    `${t("june_title")}`,
    `${t("july_title")}`,
    `${t("august_title")}`,
    `${t("september_title")}`,
    `${t("october_title")}`,
    `${t("november_title")}`,
    `${t("december_title")}`,
  ];

  return (
    <CustomContainer>
      {/* [FAQ Button] */}
      <Box
        sx={{
          position: "fixed",
          right: 48,
          bottom: 48,
          cursor: "pointer",
          zIndex: 9999,
        }}
        onClick={() => router.push("/help_center/performance-evaluation")}
      >
        <img
          src="/svg/helpCenterFloatingButton.svg"
          alt="helpCenterFloatingButton"
          style={{ height: 56, width: 56 }}
        />
      </Box>

      {/* [Select] */}
      <CustomSelectContainer>
        <Box sx={{ paddingBottom: { xs: "20px", sm: "0px" } }}>
          <Typography component="h4" variant="h4" color="#2c3058">
            {t("offie_management_performance_title")}
          </Typography>
        </Box>
        <Button
          component="a"
          variant="contained"
          rel="noopener noreferrer"
          target="_blank"
          size="medium"
          sx={{
            border: "1px solid #8A8EBA",
            background: "#fff",
            color: "#2c3058",
            width: "232px",
            cursor: "pointer",
            "&:hover": {
              background: "none",
            },
          }}
          onClick={() => {
            setOpen(true);
          }}
        >
          {t("offie_management_eveluation_button_title")}
        </Button>
        <AddDateDialog
          // jobData={selectedJob}
          teamRoaster={roaster}
          onSubmit={(isName, date, score, feedback) =>
            handleSubmitdate(isName, date, score, feedback)
          }
          open={open}
          onClose={() => setOpen(false)}
        />
      </CustomSelectContainer>
      {Object.entries(performanceList)
        .slice(page * rowsPerPage - rowsPerPage, page * rowsPerPage)
        .map(([performance_date, rows]: any, index: number) => {
          //const date define
          const multiLanguageDateFormat =
            moment(performance_date).format("MMMM");
          // day and year format
          const dayYearFormat = moment(performance_date).format("DD, YYYY");
          return (
            <Box
              sx={{
                padding: "16px 0px",
                backgroundColor: "#FFFFFF",
                borderRadius: "10px 10px 0px 0px",
                borderBottom: "0.5px solid #C7C8D7",
              }}
              key={index}
            >
              <Box sx={{ padding: { xs: "0px", sm: "0px 16px 0px 16px" } }}>
                <Box
                  sx={{
                    display: "flex",
                    flexDirection: { xs: "column", sm: "row" },
                    justifyContent: "space-between",
                    alignItems: { xs: "start", sm: "center" },
                  }}
                >
                  <Box
                    //   onClick={() => setTableOpen(!tableOpen)}
                    onClick={() => {
                      if (!tableOpen) {
                        setTableOpen(performance_date);
                      } else {
                        setTableOpen(false);
                      }
                      setInternalTablePage(1);
                    }}
                    sx={{
                      display: "flex",
                      alignItems: "center",
                      cursor: "pointer",
                      marginBottom: { xs: "8px", sm: "unset" },
                    }}
                  >
                    {tableOpen === performance_date ? (
                      <TeamChevronDown />
                    ) : (
                      <TeamChevronRight />
                    )}

                    <Typography
                      sx={{
                        marginLeft: "13px",
                        fontSize: "14px",
                        lineHeight: "22px",
                        fontWeight: 600,
                        color: "#2c3058",
                      }}
                    >
                      {/* {moment(performance_date).format("MMMM DD, YYYY")} */}
                      {multiLanguageDateFormat === "January"
                        ? monthList[0].concat(" ", dayYearFormat)
                        : multiLanguageDateFormat === "February"
                        ? monthList[1].concat(" ", dayYearFormat)
                        : multiLanguageDateFormat === "March"
                        ? monthList[2].concat(" ", dayYearFormat)
                        : multiLanguageDateFormat === "April"
                        ? monthList[3].concat(" ", dayYearFormat)
                        : multiLanguageDateFormat === "May"
                        ? monthList[4].concat(" ", dayYearFormat)
                        : multiLanguageDateFormat === "June"
                        ? monthList[5].concat(" ", dayYearFormat)
                        : multiLanguageDateFormat === "July"
                        ? monthList[6].concat(" ", dayYearFormat)
                        : multiLanguageDateFormat === "August"
                        ? monthList[7].concat(" ", dayYearFormat)
                        : multiLanguageDateFormat === "September"
                        ? monthList[8].concat(" ", dayYearFormat)
                        : multiLanguageDateFormat === "October"
                        ? monthList[9].concat(" ", dayYearFormat)
                        : multiLanguageDateFormat === "November"
                        ? monthList[10].concat(" ", dayYearFormat)
                        : multiLanguageDateFormat === "December"
                        ? monthList[11].concat(" ", dayYearFormat)
                        : ""}
                    </Typography>
                  </Box>
                  <Box>
                    <Button
                      component="a"
                      variant="contained"
                      rel="noopener noreferrer"
                      target="_blank"
                      size="medium"
                      sx={{
                        border: "1px solid #8A8EBA",
                        background: "#fff",
                        color: "#2c3058",
                        width: "232px",
                        cursor: "pointer",
                        "&:hover": {
                          background: "none",
                        },
                      }}
                      onClick={(e) => {
                        if (index !== openComment) {
                          setOpenComment(index);
                        } else {
                          setOpenComment(null);
                        }
                        setPerformanceId(rows[selectedIndex]?.id);
                        setPerformanceData(
                          rows[selectedIndex]?.performance_date
                        );
                        setEmployee(rows[selectedIndex]?.performance_employee);
                        setSelectedIndex(index);
                        roaster();
                      }}
                    >
                      {t("office_management_performance_popup_title")}
                    </Button>
                    <AddCommentDialog
                      teamResultData={teamResult}
                      teamRoaster={roaster}
                      onSubmit={(isName, performance_date, score, feedback) =>
                        handleSubmitComment(
                          isName,
                          performance_date,
                          score,
                          feedback
                        )
                      }
                      open={openComment === index}
                      onClose={() => setOpenComment(null)}
                    />
                  </Box>
                </Box>
              </Box>
              {tableOpen === performance_date && (
                <Box sx={{ marginTop: "8px" }}>
                  <CustomTableContainer>
                    <TableContainer
                      component={Paper}
                      sx={{
                        boxShadow: "none",
                        borderRadius: "4px",
                        mx: "20px",
                      }}
                    >
                      <Table sx={{ minWidth: 1080 }} aria-label="simple table">
                        <TableHead sx={{ background: "#ECEDF4" }}>
                          {rows[selectedIndex]?.performance_employee === "-" ? (
                            <NoOfficeData
                              title={`${t(
                                "team_performance_empty_date_added"
                              )}`}
                              imgName="Illust-3"
                            />
                          ) : (
                            <StyledTableRow>
                              <StyledTableCell
                                sx={{
                                  fontSize: 16,
                                  lineHeight: 1.5,
                                  fontWeight: 700,
                                  minWidth: 230,
                                }}
                              >
                                {t(
                                  "office_management_performance_table_head_emp"
                                )}
                              </StyledTableCell>
                              <StyledTableCell
                                sx={{
                                  fontSize: 16,
                                  lineHeight: 1.5,
                                  fontWeight: 700,
                                  minWidth: 140,
                                }}
                              >
                                {t(
                                  "office_management_performance_table_head_score"
                                )}
                              </StyledTableCell>
                              <StyledTableCell
                                sx={{
                                  fontSize: 16,
                                  lineHeight: 1.5,
                                  fontWeight: 700,
                                  maxWidth: 200,
                                  wordWrap: "break-word",
                                }}
                              >
                                {t(
                                  "office_management_performance_table_head_comments"
                                )}
                              </StyledTableCell>
                              <StyledTableCell
                                sx={{
                                  fontSize: 16,
                                  lineHeight: 1.5,
                                  fontWeight: 700,
                                  display: "flex",
                                  justifyContent: "flex-end",
                                  alignItems: "center",
                                  marginRight: "81px",
                                }}
                              >
                                {t(
                                  "office_management_performance_table_head_action"
                                )}
                                <Tooltip
                                  title={`${t(
                                    "team_performance_hr_actions_tooltip"
                                  )}`}
                                  arrow
                                  enterTouchDelay={0}
                                >
                                  <IconButton aria-label="hr_actions">
                                    <ToolTipIconColor
                                      sx={{ fontSize: "18px" }}
                                    />
                                  </IconButton>
                                </Tooltip>
                              </StyledTableCell>
                            </StyledTableRow>
                          )}
                        </TableHead>
                        <TableBody>
                          {/* {result.filter(item => !arr2.includes(item))} */}
                          {rows
                            .slice(
                              internalTablePage * 10 - rowsPerPage,
                              internalTablePage * rowsPerPage
                            )
                            .map((row: any) => (
                              // {row.filter(item => item?.performance_date == row[index].performance_date)}
                              <TableRow
                                key={row.id}
                                sx={{
                                  "&:last-child td, &:last-child th": {
                                    border: 0,
                                  },
                                }}
                              >
                                {row.performance_employee === "-" ? null : (
                                  <StyledTableCell
                                    component="th"
                                    scope="row"
                                    sx={{
                                      fontSize: 14,
                                      fontWeight: 600,
                                      lineHeight: 1.5,
                                      color: "#222222",
                                    }}
                                  >
                                    {row.performance_employee}
                                  </StyledTableCell>
                                )}
                                {row.performance_employee === "-" ? null : (
                                  <StyledTableCell>
                                    {row.performance_score}
                                  </StyledTableCell>
                                )}
                                {row.performance_employee === "-" ? null : (
                                  <StyledTableCell
                                    sx={{
                                      maxWidth: 200,
                                      wordWrap: "break-word",
                                    }}
                                  >
                                    <Box>
                                      {row.performance_comments.length > 40 ? (
                                        <ReadMore sliceTextLength="40">
                                          {row.performance_comments}
                                        </ReadMore>
                                      ) : (
                                        <Typography
                                          component="p"
                                          sx={{
                                            fontSize: 14,
                                            color: "#222222",
                                          }}
                                        >
                                          {row.performance_comments}
                                        </Typography>
                                      )}
                                    </Box>
                                  </StyledTableCell>
                                )}
                                {row.performance_employee === "-" ? null : (
                                  <StyledTableCell
                                    sx={{
                                      display: "flex",
                                      justifyContent: "flex-end",
                                    }}
                                  >
                                    <HRActions
                                      status={row.hR_actions}
                                      id={row.id}
                                    />
                                  </StyledTableCell>
                                )}
                              </TableRow>
                            ))}
                        </TableBody>
                      </Table>
                      {/* Table pagination  */}
                      {rows.length > 10 ? (
                        <Stack
                          direction="row"
                          alignItems="center"
                          justifyContent="center"
                          paddingTop={5}
                          paddingBottom={3}
                        >
                          <Pagination
                            count={Math.ceil(rows.length / rowsPerPage)}
                            page={internalTablePage}
                            color="secondary"
                            onChange={(e, value) => setInternalTablePage(value)}
                            sx={{
                              background: "#ECEDF4",
                              borderRadius: "10px",
                              padding: { xs: "5px", sm: "10px" },
                            }}
                          />
                        </Stack>
                      ) : (
                        ""
                      )}
                    </TableContainer>
                  </CustomTableContainer>
                </Box>
              )}
            </Box>
          );
        })}

      {/* Empty State when data not available  */}
      <Box>
        {result.length > 0 ? null : (
          <NoOfficeData
            title={`${t("team_performance_empty_screen_title")}`}
            imgName="Illust-3"
          />
        )}
      </Box>

      {rowsPerPage >= 10 ? (
        <Stack
          direction="row"
          alignItems="center"
          justifyContent="center"
          paddingTop={5}
          paddingBottom={3}
        >
          <Pagination
            count={pageObject}
            color="secondary"
            page={page}
            // onChange={(e, value) => setTeamPerformanceListPage(value)}
            onChange={(e, value) => setPage(value)}
            sx={{
              background: "#ECEDF4",
              borderRadius: "10px",
              padding: { xs: "5px", sm: "10px" },
            }}
          />
        </Stack>
      ) : (
        ""
      )}
    </CustomContainer>
  );
}

const mapStateToProps = (state: RootState) => ({
  performanceList: state.results.performanceList,
  result: state.results.results,
  count: state.results.count,
  teamResult: state.employeeList.results,
  teamCount: state.employeeList.count,
});

const mapDispatchToProps = (dispatch: Dispatch) => {
  return {
    teamPerformanceList: (params: any) => teamPerformanceList(dispatch, params),
    employeeList: (params: any) => employeeList(dispatch, params),
  };
};

export default connect(mapStateToProps, mapDispatchToProps)(Testing);
