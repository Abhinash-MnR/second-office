// React, Next Js packages
import React, { useState, useEffect } from "react";
import Link from "next/link";
// MUI Packages
import {
  Box,
  Stack,
  Typography,
  Grid,
  Pagination,
  Avatar,
} from "@mui/material";
// Third party packages
import { useTranslation } from "react-i18next";
import "translation/i18n";
import moment from "moment";
// Custom components
import useCurrency from "@lib/useCurrency";
import useCompany from "@lib/useCompany";
import {
  EURIconColor,
  INRIconColor,
  KRWIconColor,
  USDIconColor,
} from "@common/Icon";
import TeamRoasterHrActions from "features/officeExpenses/TeamRoasterHrActions";

function TeamRoasterInCardView(props) {
  /** third-party hooks */
  const { company } = useCompany();
  //** useCurrency hooks */
  const { currency } = useCurrency();
  //** props from component */
  const { cardView, handlePagination, pageNumber } = props;
  //** props from redux  */
  const { teamRoaster, count } = props;
  //** Language translation hooks */
  const { t } = useTranslation();
  //** month list */
  const monthList = [
    `${t("january_title")}`,
    `${t("february_title")}`,
    `${t("march_title")}`,
    `${t("april_title")}`,
    `${t("may_title")}`,
    `${t("june_title")}`,
    `${t("july_title")}`,
    `${t("august_title")}`,
    `${t("september_title")}`,
    `${t("october_title")}`,
    `${t("november_title")}`,
    `${t("december_title")}`,
  ];
  return (
    <Box>
      <Grid container spacing={3}>
        {teamRoaster.map((data, index) => {
          //const date define
          const multiLanguageDateFormat = moment(
            data.employee_join_date
          ).format("MMMM");
          // day and year format
          const dayYearFormat = moment(data.employee_join_date).format(
            "DD, YYYY"
          );
          // resigned date
          const multiLanguageDateFormatResign = moment(
            data.employee_resigned_date
          ).format("MMMM");
          // day and year format
          const dayYearFormatResign = moment(
            data.employee_resigned_date
          ).format("DD, YYYY");
          return (
            <Grid item xs={12} sm={3} key={index}>
              <Box bgcolor={`grey.100`} py={2.5} px={1.1} borderRadius={1.25}>
                <Stack direction={`column`} alignItems={`center`}>
                  {data.employee_avatar ? (
                    <Avatar
                      src={data.employee_avatar}
                      alt="profile"
                      sx={{ width: 66, height: 66 }}
                    />
                  ) : (
                    <Avatar
                      sx={{
                        fontWeight: 600,
                        color: "grey.100",
                        width: 66,
                        height: 66,
                        bgcolor: "#DFA718",
                      }}
                    >
                      {data.employee_name.charAt(0).toUpperCase()}
                    </Avatar>
                  )}

                  {/* candidate Name */}
                  <Typography
                    variant="body1"
                    pt={1.5}
                    sx={{
                      fontWeight: 600,
                      color: "primary.main",
                      textTransform: "capitalize",
                    }}
                  >
                    {data.employee_name}
                  </Typography>
                  <Typography
                    variant="body2"
                    mt={0.5}
                    sx={{ fontWeight: 400, color: "#878787" }}
                  >
                    {data.employee_role}
                  </Typography>
                </Stack>
                <Box
                  bgcolor={`#ECEDF4`}
                  p={1}
                  mt={1}
                  borderRadius={0.5}
                  flexDirection={`row`}
                >
                  <Stack direction={`row`} justifyContent={`space-between`}>
                    <Typography
                      variant="body2"
                      sx={{ fontWeight: 400, color: "#696E9C" }}
                    >
                      {t(
                        "office_management_expected_newjoiners_table_head_hired"
                      )}
                    </Typography>
                    <Typography
                      variant="body2"
                      sx={{ fontWeight: 400, color: "#222222" }}
                    >
                      {/* {data.employee_join_date} */}
                      {multiLanguageDateFormat === "January"
                        ? monthList[0].concat(" ", dayYearFormat)
                        : multiLanguageDateFormat === "February"
                        ? monthList[1].concat(" ", dayYearFormat)
                        : multiLanguageDateFormat === "March"
                        ? monthList[2].concat(" ", dayYearFormat)
                        : multiLanguageDateFormat === "April"
                        ? monthList[3].concat(" ", dayYearFormat)
                        : multiLanguageDateFormat === "May"
                        ? monthList[4].concat(" ", dayYearFormat)
                        : multiLanguageDateFormat === "June"
                        ? monthList[5].concat(" ", dayYearFormat)
                        : multiLanguageDateFormat === "July"
                        ? monthList[6].concat(" ", dayYearFormat)
                        : multiLanguageDateFormat === "August"
                        ? monthList[7].concat(" ", dayYearFormat)
                        : multiLanguageDateFormat === "September"
                        ? monthList[8].concat(" ", dayYearFormat)
                        : multiLanguageDateFormat === "October"
                        ? monthList[9].concat(" ", dayYearFormat)
                        : multiLanguageDateFormat === "November"
                        ? monthList[10].concat(" ", dayYearFormat)
                        : multiLanguageDateFormat === "December"
                        ? monthList[11].concat(" ", dayYearFormat)
                        : ""}
                    </Typography>
                  </Stack>

                  {/* Salary and resignation row */}
                  <Box
                    display={`flex`}
                    justifyContent={`space-between`}
                    mt={1.5}
                  >
                    <Stack direction={`column`}>
                      <Typography
                        variant="body2"
                        sx={{ fontWeight: 400, color: "#696E9C" }}
                      >
                        {t("office_management_historic_emp_table_head_salary")}
                      </Typography>
                      <Typography
                        variant="body2"
                        mt={0.5}
                        sx={{
                          fontWeight: 400,
                          color: "#222222",
                          display: "flex",
                          alignItems: "center",
                        }}
                      >
                        {company && currency && company.currency === "KRW" ? (
                          <KRWIconColor sx={{ fontSize: "14px" }} />
                        ) : company &&
                          currency &&
                          company.currency === "USD" ? (
                          <USDIconColor sx={{ fontSize: "14px" }} />
                        ) : company &&
                          currency &&
                          company.currency === "EUR" ? (
                          <EURIconColor sx={{ fontSize: "14px" }} />
                        ) : (
                          <INRIconColor sx={{ fontSize: "14px" }} />
                        )}

                        {company && currency && company.currency === "KRW"
                          ? Math.round(
                              data?.employee_salary * currency.currency_krw
                            ).toLocaleString()
                          : company && currency && company.currency === "USD"
                          ? Math.round(
                              (data?.employee_salary * currency.currency_usd) /
                                1000
                            ).toLocaleString()
                          : company && currency && company.currency === "EUR"
                          ? Math.round(
                              (data?.employee_salary * currency.currency_eur) /
                                1000
                            ).toLocaleString()
                          : (data?.employee_salary / 100000).toFixed(2)}

                        {company && currency && company.currency === "KRW"
                          ? ""
                          : company && currency && company.currency === "USD"
                          ? " K"
                          : company && currency && company.currency === "EUR"
                          ? "K"
                          : " LPA"}
                      </Typography>
                    </Stack>
                    <Stack direction={`column`}>
                      <Typography
                        variant="body2"
                        sx={{ fontWeight: 400, color: "#696E9C" }}
                      >
                        {t(
                          "office_management_historic_emp_table_head_resign_on"
                        )}
                      </Typography>
                      <Typography
                        variant="body2"
                        mt={0.5}
                        textAlign={`center`}
                        sx={{ fontWeight: 400, color: "#222222" }}
                      >
                        {data.employee_resigned_date == null
                          ? `-`
                          : multiLanguageDateFormatResign === "January"
                          ? monthList[0].concat(" ", dayYearFormatResign)
                          : multiLanguageDateFormatResign === "February"
                          ? monthList[1].concat(" ", dayYearFormatResign)
                          : multiLanguageDateFormatResign === "March"
                          ? monthList[2].concat(" ", dayYearFormatResign)
                          : multiLanguageDateFormatResign === "April"
                          ? monthList[3].concat(" ", dayYearFormatResign)
                          : multiLanguageDateFormatResign === "May"
                          ? monthList[4].concat(" ", dayYearFormatResign)
                          : multiLanguageDateFormatResign === "June"
                          ? monthList[5].concat(" ", dayYearFormatResign)
                          : multiLanguageDateFormatResign === "July"
                          ? monthList[6].concat(" ", dayYearFormatResign)
                          : multiLanguageDateFormatResign === "August"
                          ? monthList[7].concat(" ", dayYearFormatResign)
                          : multiLanguageDateFormatResign === "September"
                          ? monthList[8].concat(" ", dayYearFormatResign)
                          : multiLanguageDateFormatResign === "October"
                          ? monthList[9].concat(" ", dayYearFormatResign)
                          : multiLanguageDateFormatResign === "November"
                          ? monthList[10].concat(" ", dayYearFormatResign)
                          : multiLanguageDateFormatResign === "December"
                          ? monthList[11].concat(" ", dayYearFormatResign)
                          : "-"}
                      </Typography>
                    </Stack>
                  </Box>
                </Box>

                {/* Hr actions section  */}
                <Stack direction={`column`} mt={1} alignItems={`center`}>
                  {/* team Roaster hr actions */}
                  <TeamRoasterHrActions
                    status={data.hr_action}
                    id={data.id}
                    cardView={cardView}
                  />
                  <Link href={data.employee_resume}>
                    <a target={`_blank`}>
                      <Typography
                        variant="body2"
                        mt={1}
                        color={`primary.main`}
                        sx={{ fontWeight: 600 }}
                      >
                        {t("view_candidate_view_resume_title")}
                      </Typography>
                    </a>
                  </Link>
                </Stack>
              </Box>
            </Grid>
          );
        })}
      </Grid>
      {/* pagination */}
      {count > 8 ? (
        <Stack
          direction="row"
          alignItems="center"
          justifyContent="center"
          paddingTop={5}
          paddingBottom={3}
        >
          <Pagination
            count={pageNumber}
            color="secondary"
            onChange={(e, value) => handlePagination(value)}
            sx={{
              background: "#ECEDF4",
              borderRadius: "10px",
              padding: { xs: "5px", sm: "10px" },
            }}
          />
        </Stack>
      ) : (
        ""
      )}
    </Box>
  );
}

export default TeamRoasterInCardView;
