// React, Next packages
import React, { useState, useEffect, FC } from "react";
// Mui packages
import {
  Box,
  Button,
  Chip,
  Skeleton,
  Stack,
  styled,
  Grid,
  TextField,
  Autocomplete,
} from "@mui/material";
// Custom packages
import { DialogForm, DialogFormProps } from "@common/DialogForm";
// import { formatUnderscore } from "@lib/formatter";
import { JobListResponse } from "types/JobResponse";
// 3Rd Party Component/Packages
import { useSnackbar } from "notistack";
import { options as initialOptions } from "@common/Options";
import { useTranslation } from "react-i18next";
import "translation/i18n";

export type AddCommentDialogProps = {
  /** Callback triggered when close job button is clicked */
  // onDelete?: (...params: any) => void;
  /** Callback triggered when edit button is clicked  */
  onSubmit?: (...params: any) => void;
  teamRoaster();
  /** Job data from API */
} & DialogFormProps;

const StackItem = styled("div")(({ theme }) => ({
  alignItems: "center",
  color: theme.palette.grey[500],
  display: "flex",
  marginBottom: 15,
  marginRight: 30,

  "& :first-of-type": {
    color: theme.palette.grey[600],
    fontSize: 14,
    marginRight: 10,
  },
}));
const onSubmitRating = () => {
  console.log("submit tapped");
};

var q = new Date();
var m = q.getMonth();
var d = q.getDay() + 10;
var y = q.getFullYear();

var date = new Date(y, m, d);

export const AddCommentDialog: FC<AddCommentDialogProps> = (props: any) => {
  /** props */
  const { open, onClose, onSubmit, teamResultData, teamRoaster } = props;
  const [isName, setIsName] = useState("");
  const [score, setScore] = useState("");
  const [feedback, setFeedback] = useState("");
  const { enqueueSnackbar } = useSnackbar();
  const [options, setOptions] = React.useState(initialOptions);
  const [employeeOptions, setEmployeeOptions] = React.useState(
    teamResultData?.filter(
      (item: any) =>
        item?.employee_resigned_date === null ||
        date < new Date(item?.employee_resigned_date)
    )
  );

  //** Language translation hooks */
  const { t } = useTranslation();

  useEffect(() => {
    console.log("isName:-", teamResultData);
  }, [teamResultData]);

  // Drodwon Menu Props
  const ITEM_HEIGHT = 30;
  const ITEM_PADDING_TOP = 8;
  const MenuProps = {
    PaperProps: {
      style: {
        maxHeight: ITEM_HEIGHT * 4.5 + ITEM_PADDING_TOP,
        width: 126,
      },
    },
  };

  return (
    <DialogForm
      open={open}
      onClose={onClose}
      title={`${t("office_management_performance_popup_title1")}`}
      subtitle={`${t("office_management_performance_popup_desc")}`}
      footer={
        <Stack
          alignItems="center"
          direction="row"
          justifyContent="center"
          width={{ xs: "100%", md: "100%" }}
          // sx={{ padding: { xs: "20px 0px", sm: "1px 45px 30px 45px" } }}
        >
          <Button
            //   disabled={!jobData}
            color="primary"
            fullWidth
            variant="contained"
            onClick={() => {
              if (isName) {
                if (score) {
                  if (Number(score) <= 10) {
                    if (feedback) {
                      onSubmit(isName, date, score, feedback);
                    } else {
                      enqueueSnackbar("Employee feedback required", {
                        variant: "error",
                      });
                    }
                  } else {
                    console.log("length:-", score.length);
                    enqueueSnackbar(
                      "Please enter the score under 10 and it can also be a decimal.",
                      {
                        variant: "error",
                      }
                    );
                  }
                } else {
                  enqueueSnackbar("Employee score required", {
                    variant: "error",
                  });
                }
              } else {
                enqueueSnackbar("Employee name required", {
                  variant: "error",
                });
              }
            }}
          >
            {t("office_management_performance_popup_button_title")}
          </Button>
        </Stack>
      }
    >
      <Stack direction="row" flexWrap="wrap" sx={{ paddingTop: "5px" }}>
        {/* Employee Name TextField */}
        <Grid container spacing={2}>
          <Grid item xs={12}>
            <Autocomplete
              options={employeeOptions}
              noOptionsText={`${t(
                "team_performance_popup_form_emp_name_label"
              )}`}
              getOptionLabel={(option: any) => option?.employee_name}
              onInputChange={(e, newValue) => {
                setIsName(newValue);
              }}
              ListboxProps={{
                style: {
                  maxHeight: "200px",
                },
              }}
              onOpen={(e) => {
                teamRoaster();
              }}
              renderInput={(params) => (
                <TextField
                  {...params}
                  SelectProps={{ MenuProps }}
                  label={`${t("team_performance_popup_form_emp_name_label")}`}
                  name="name"
                  variant="outlined"
                  fullWidth
                  onKeyDown={(e) => {
                    if (
                      e.key === "Enter" &&
                      employeeOptions?.findIndex(
                        (o) => o?.employee_name === isName
                      ) === -1
                    ) {
                      setEmployeeOptions((o) =>
                        o?.concat({ employee_name: isName })
                      );
                    }
                  }}
                />
              )}
            />
          </Grid>
          {/* Score TextField */}
          <Grid item xs={12}>
            <Autocomplete
              options={options}
              noOptionsText={`${t("team_performance_popup_form_score_label")}`}
              getOptionLabel={(option) => option.title}
              onInputChange={(e, newValue) => {
                setScore(newValue);
              }}
              ListboxProps={{
                style: {
                  maxHeight: "170px",
                },
              }}
              renderInput={(params) => (
                <TextField
                  {...params}
                  label={`${t("team_performance_popup_form_score_label")}`}
                  name="Score"
                  variant="outlined"
                  fullWidth
                  onKeyDown={(e) => {
                    if (
                      e.key === "Enter" &&
                      options.findIndex((o) => o.title === score) === -1
                    ) {
                      setOptions((o) => o.concat({ title: score }));
                    }
                  }}
                />
              )}
            />
          </Grid>
          {/* Feedback TextField*/}
          <Grid item xs={12} sm={12}>
            <TextField
              id="outlined-multiline-static"
              label={`${t("team_performance_popup_form_feedback_label")}`}
              multiline
              rows="6"
              onChange={(e) => {
                setFeedback(e.target.value);
              }}
              value={feedback}
              fullWidth
              variant="outlined"
            />
          </Grid>
        </Grid>
      </Stack>
    </DialogForm>
  );
};
