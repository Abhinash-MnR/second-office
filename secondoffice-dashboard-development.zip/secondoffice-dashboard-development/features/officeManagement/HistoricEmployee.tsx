// React, Next packages
import React, { useState, useEffect } from "react";
import dynamic from "next/dynamic";
import Link from "next/link";
import { connect } from "react-redux";
import { Dispatch } from "redux";
import router from "next/router";
// Mui packages
import {
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  Paper,
  Typography,
  styled,
  Stack,
  Grid,
  Box,
  Pagination,
  Tooltip,
} from "@mui/material";
// Third party packages
import { useTranslation } from "react-i18next";
import "translation/i18n";
import { useSnackbar } from "notistack";
import moment from "moment";
// custom packages
import { RootState } from "reducers";
import { historicTeamRoasterList } from "@reducers/historicTeamRoasterSlice";
import NoOfficeData from "./NoOfficeData";
import {
  EURIconColor,
  INRIconColor,
  KRWIconColor,
  USDIconColor,
} from "@common/Icon";

import useCompany from "@lib/useCompany";
import useCurrency from "@lib/useCurrency";

const CustomContainer = styled("div")(({ theme }) => ({
  display: "flex",
  flexDirection: "column",
}));
const CustomTableContainer = styled("div")(({ theme }) => ({
  display: "flex",
}));

const StyledTableRow = styled(TableRow)(({ theme }) => ({
  "&:nth-of-type(odd)": {
    // backgroundColor: theme.palette.action.hover,
  },
  // hide last border
  "&:last-child td, &:last-child th": {
    border: 0,
  },
}));

const StyledTableCell = styled(TableCell)(({ theme }) => ({
  fontSize: 14,
  width: "17%",
}));

function HistoricEmployee(props: any) {
  //SnackBar
  const { enqueueSnackbar } = useSnackbar();
  /** props - actions */
  const { historicTeamRoasterList } = props;
  /** props - states */
  const { result, count } = props;
  const pageNumber = Math.ceil(count / 10);
  const [jobListPage, setJobListPage] = useState(1);

  /** third-party hooks */
  const { company } = useCompany();

  //** Language translation hooks */
  const { t } = useTranslation();

  const { currency } = useCurrency();

  var q = new Date();
  var m = q.getMonth();
  var d = q.getDay() + 10;
  var y = q.getFullYear();

  var date = new Date(y, m, d);

  // Convert number with commas
  const numberWithCommas = (x: string) => {
    return x.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",");
  };

  /** useEffect hooks */
  useEffect(() => {
    const roaster = async () => {
      await historicTeamRoasterList({
        page: jobListPage,
        page_size: 10,
        job_status: "history",
      });
    };

    try {
      roaster();
    } catch (error: any) {
      enqueueSnackbar(error.toString(), { variant: "error" });
    }
  }, [jobListPage]);

  //** month list */
  const monthList = [
    `${t("january_title")}`,
    `${t("february_title")}`,
    `${t("march_title")}`,
    `${t("april_title")}`,
    `${t("may_title")}`,
    `${t("june_title")}`,
    `${t("july_title")}`,
    `${t("august_title")}`,
    `${t("september_title")}`,
    `${t("october_title")}`,
    `${t("november_title")}`,
    `${t("december_title")}`,
  ];

  return (
    <CustomContainer>
      <CustomTableContainer>
        <TableContainer component={Paper} sx={{ boxShadow: "none" }}>
          <Table sx={{ minWidth: 1050 }} aria-label="simple table">
            <TableHead sx={{ background: "#ECEDF4", opacity: "1" }}>
              <StyledTableRow>
                <StyledTableCell
                  sx={{ fontSize: 16, lineHeight: 1.5, fontWeight: 700 }}
                >
                  {t("office_management_historic_emp_table_head_emp")}
                </StyledTableCell>
                <StyledTableCell
                  sx={{ fontSize: 16, lineHeight: 1.5, fontWeight: 700 }}
                >
                  {t("office_management_historic_emp_table_head_position")}
                </StyledTableCell>
                <StyledTableCell
                  sx={{ fontSize: 16, lineHeight: 1.5, fontWeight: 700 }}
                >
                  {t("office_management_historic_emp_table_head_salary")}
                </StyledTableCell>
                <StyledTableCell
                  sx={{ fontSize: 16, lineHeight: 1.5, fontWeight: 700 }}
                >
                  {t("office_management_historic_emp_table_head_joining")}
                </StyledTableCell>
                <StyledTableCell
                  sx={{ fontSize: 16, lineHeight: 1.5, fontWeight: 700 }}
                >
                  {t("office_management_historic_emp_table_head_resign")}
                </StyledTableCell>
                <StyledTableCell
                  sx={{ fontSize: 16, lineHeight: 1.5, fontWeight: 700 }}
                >
                  {t("office_management_historic_emp_table_head_resume")}
                </StyledTableCell>
              </StyledTableRow>
            </TableHead>

            <TableBody>
              {result
                .filter(
                  (item: any) =>
                    date > new Date(item.employee_resigned_date) &&
                    item.employee_resigned_date !== null
                )
                .map((row: any) => {
                  //const date define
                  const multiLanguageDateFormatJoin = moment(
                    row?.employee_join_date
                  ).format("MMMM");
                  // day and year format
                  const dayYearFormatJoin = moment(
                    row?.employee_join_date
                  ).format("DD, YYYY");
                  // resigned date
                  const multiLanguageDateFormatResign = moment(
                    row?.employee_resigned_date
                  ).format("MMMM");
                  // day and year format
                  const dayYearFormatResign = moment(
                    row?.employee_resigned_date
                  ).format("DD, YYYY");
                  return (
                    <TableRow
                      key={row.id}
                      sx={{
                        "&:last-child td, &:last-child th": { border: 0 },
                      }}
                    >
                      <StyledTableCell
                        component="th"
                        scope="row"
                        sx={{
                          fontSize: 14,
                          fontWeight: 600,
                          lineHeight: 1.5,
                          color: "#222222",
                        }}
                      >
                        {row.employee_name}
                      </StyledTableCell>
                      <StyledTableCell>{row?.employee_role}</StyledTableCell>
                      <StyledTableCell>
                        {company && currency && company.currency === "KRW" ? (
                          <KRWIconColor sx={{ fontSize: "10px" }} />
                        ) : company &&
                          currency &&
                          company.currency === "USD" ? (
                          <USDIconColor sx={{ fontSize: "10px" }} />
                        ) : company &&
                          currency &&
                          company.currency === "EUR" ? (
                          <EURIconColor sx={{ fontSize: "10px" }} />
                        ) : (
                          <INRIconColor sx={{ fontSize: "10px" }} />
                        )}

                        {company && currency && company.currency === "KRW"
                          ? numberWithCommas(
                              (
                                row?.employee_salary * currency.currency_krw
                              ).toFixed(2)
                            )
                          : company && currency && company.currency === "USD"
                          ? numberWithCommas(
                              (
                                (row?.employee_salary * currency.currency_usd) /
                                1000
                              ).toFixed(2)
                            )
                          : company && currency && company.currency === "EUR"
                          ? numberWithCommas(
                              (
                                (row?.employee_salary * currency.currency_eur) /
                                1000
                              ).toFixed(2)
                            )
                          : numberWithCommas(
                              (row?.employee_salary / 100000).toFixed(2)
                            )}

                        {company && currency && company.currency === "KRW"
                          ? ""
                          : company && currency && company.currency === "USD"
                          ? " K"
                          : company && currency && company.currency === "EUR"
                          ? "K"
                          : " LPA"}
                      </StyledTableCell>
                      <StyledTableCell>
                        {/* {row?.employee_join_date} */}

                        {/* {moment(row?.employee_join_date).format(
                          "MMMM DD, YYYY"
                        )} */}
                        {multiLanguageDateFormatJoin === "January"
                          ? monthList[0].concat(" ", dayYearFormatJoin)
                          : multiLanguageDateFormatJoin === "February"
                          ? monthList[1].concat(" ", dayYearFormatJoin)
                          : multiLanguageDateFormatJoin === "March"
                          ? monthList[2].concat(" ", dayYearFormatJoin)
                          : multiLanguageDateFormatJoin === "April"
                          ? monthList[3].concat(" ", dayYearFormatJoin)
                          : multiLanguageDateFormatJoin === "May"
                          ? monthList[4].concat(" ", dayYearFormatJoin)
                          : multiLanguageDateFormatJoin === "June"
                          ? monthList[5].concat(" ", dayYearFormatJoin)
                          : multiLanguageDateFormatJoin === "July"
                          ? monthList[6].concat(" ", dayYearFormatJoin)
                          : multiLanguageDateFormatJoin === "August"
                          ? monthList[7].concat(" ", dayYearFormatJoin)
                          : multiLanguageDateFormatJoin === "September"
                          ? monthList[8].concat(" ", dayYearFormatJoin)
                          : multiLanguageDateFormatJoin === "October"
                          ? monthList[9].concat(" ", dayYearFormatJoin)
                          : multiLanguageDateFormatJoin === "November"
                          ? monthList[10].concat(" ", dayYearFormatJoin)
                          : multiLanguageDateFormatJoin === "December"
                          ? monthList[11].concat(" ", dayYearFormatJoin)
                          : ""}
                      </StyledTableCell>
                      <StyledTableCell>
                        {row?.employee_resigned_date == null
                          ? "-"
                          : multiLanguageDateFormatResign === "January"
                          ? monthList[0].concat(" ", dayYearFormatResign)
                          : multiLanguageDateFormatResign === "February"
                          ? monthList[1].concat(" ", dayYearFormatResign)
                          : multiLanguageDateFormatResign === "March"
                          ? monthList[2].concat(" ", dayYearFormatResign)
                          : multiLanguageDateFormatResign === "April"
                          ? monthList[3].concat(" ", dayYearFormatResign)
                          : multiLanguageDateFormatResign === "May"
                          ? monthList[4].concat(" ", dayYearFormatResign)
                          : multiLanguageDateFormatResign === "June"
                          ? monthList[5].concat(" ", dayYearFormatResign)
                          : multiLanguageDateFormatResign === "July"
                          ? monthList[6].concat(" ", dayYearFormatResign)
                          : multiLanguageDateFormatResign === "August"
                          ? monthList[7].concat(" ", dayYearFormatResign)
                          : multiLanguageDateFormatResign === "September"
                          ? monthList[8].concat(" ", dayYearFormatResign)
                          : multiLanguageDateFormatResign === "October"
                          ? monthList[9].concat(" ", dayYearFormatResign)
                          : multiLanguageDateFormatResign === "November"
                          ? monthList[10].concat(" ", dayYearFormatResign)
                          : multiLanguageDateFormatResign === "December"
                          ? monthList[11].concat(" ", dayYearFormatResign)
                          : ""}
                      </StyledTableCell>
                      <StyledTableCell>
                        <Stack
                          direction="row"
                          alignItems="center"
                          justifyContent="start"
                        >
                          <Typography
                            component="span"
                            sx={{
                              fontSize: 14,
                              fontWeight: 700,
                              lineHeight: 1.5,
                              color: "#2c3058",
                            }}
                          >
                            <Link href={row.employee_resume}>
                              <a target="_blank">
                                {t("view_candidate_view_resume_title")}
                              </a>
                            </Link>
                          </Typography>
                        </Stack>
                      </StyledTableCell>
                    </TableRow>
                  );
                })}
            </TableBody>
          </Table>
        </TableContainer>
      </CustomTableContainer>
      {/* Empty State when data not available  */}
      <Box>
        {result.filter(
          (item: any) =>
            date > new Date(item.employee_resigned_date) &&
            item.employee_resigned_date !== null
        ).length > 0 ? null : (
          <NoOfficeData
            title={`${t("formerEmployee_empty_screen_title")}`}
            imgName="Illust-2"
          />
        )}
      </Box>
      {/* Pagination for Team Roaster List   */}
      {count > 10 ? (
        <Grid container spacing={1}>
          <Grid item xs={12}>
            <Box sx={{ display: "flex", justifyContent: "center" }}>
              <Stack
                direction="row"
                alignItems="center"
                justifyContent="center"
                paddingTop={5}
                paddingBottom={3}
              >
                <Pagination
                  count={pageNumber}
                  color="secondary"
                  onChange={(e, value) => setJobListPage(value)}
                  sx={{
                    background: "#ECEDF4",
                    borderRadius: "10px",
                    padding: { xs: "5px", sm: "10px" },
                  }}
                />
              </Stack>
            </Box>
          </Grid>
        </Grid>
      ) : (
        ""
      )}
    </CustomContainer>
  );
}

const mapStateToProps = (state: RootState) => ({
  result: state.historicRoaster.results,
  count: state.historicRoaster.count,
});

const mapDispatchToProps = (dispatch: Dispatch) => {
  return {
    historicTeamRoasterList: (params: any) =>
      historicTeamRoasterList(dispatch, params),
  };
};

export default connect(mapStateToProps, mapDispatchToProps)(HistoricEmployee);
