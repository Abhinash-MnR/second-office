module.exports = {
  reactStrictMode: false,
  webpack: (config, { isServer }) => {
    // (1) https://github.com/jsdom/jsdom/issues/3042
    // config.plugins.IgnorePlugin(new options.webpack.IgnorePlugin(/^canvas$/));
    // config.module.rules.push(new webpack.IgnorePlugin(/canvas/));
    // (2) https://github.com/react-pdf-viewer/react-pdf-viewer/issues/497
    if (!isServer) {
      config.resolve.fallback.fs = false;
      config.resolve.fallback.child_process = false;
      config.resolve.fallback.net = false;
      config.resolve.fallback.tls = false;
    }
    config.module.rules.unshift({
      test: /canvas/,
      use: "null-loader",
    });
    return config;
  },

  images: {
    domains: [
      "raw.githubusercontent.com",
      "mckinleyrice.com",
      "drive.google.co",
    ],
    minimumCacheTTL: 31536000,
  },
  env: {
    ENVIRONMENT: process.env.ENVIRONMENT,
    NEXT_PUBLIC_GA_ID: process.env.NEXT_PUBLIC_GA_ID,
    OAUTH_CLIENT_ID: process.env.OAUTH_CLIENT_ID,
    SENTRY_KEY: process.env.SENTRY_KEY,
  },
};
