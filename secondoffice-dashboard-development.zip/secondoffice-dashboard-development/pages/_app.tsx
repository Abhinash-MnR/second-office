// React, Next packages
import React, { useEffect } from "react";
import Script from "next/script";
import { AppProps } from "next/app";
import { useRouter } from "next/router";
import { Provider } from "react-redux";
// Mui packages
import { CssBaseline } from "@mui/material";
import { ThemeProvider } from "@mui/material/styles";
// Third-party packages
import { CacheProvider, EmotionCache } from "@emotion/react";
import createCache from "@emotion/cache";
import { SnackbarProvider } from "notistack";
import dayjs from "dayjs";
import relativeTime from "dayjs/plugin/relativeTime";
import localizedFormat from "dayjs/plugin/localizedFormat";
// Custom packages
import * as gtag from "lib/gtag";
import store from "reducers";
import theme from "themes";
import "styles/globals.css";

const cache = createCache({ key: "css" });

interface CareerChatRecruitersProps extends AppProps {
  emotionCache?: EmotionCache;
}

// Dayjs setup
dayjs.extend(relativeTime);
dayjs.extend(localizedFormat);

const CareerChatRecruiters = (props: CareerChatRecruitersProps) => {
  /** props */
  const { Component, emotionCache = cache, pageProps } = props;

  /** custom hooks */
  const router = useRouter();

  /** useEffect hooks */
  useEffect(() => {
    const handleRouteChange = (url: string) => {
      gtag.pageview(url);
    };

    router.events.on("routeChangeComplete", handleRouteChange);

    return () => {
      router.events.off("routeChangeComplete", handleRouteChange);
    };
  }, [router.events]);

  return (
    <Provider store={store}>
      <CacheProvider value={cache}>
        {/* Material UI theme injection */}
        <ThemeProvider theme={theme}>
          <SnackbarProvider
            anchorOrigin={{
              vertical: "top",
              horizontal: "center",
            }}
            autoHideDuration={2000}
          >
            {/* CssBaseline == Normalize.css */}
            <CssBaseline />
            {/* Global Site Tag (gtag.js) - Google Analytics */}
            <Script
              strategy="afterInteractive"
              src={`https://www.googletagmanager.com/gtag/js?id=${gtag.GA_TRACKING_ID}`}
            />
            <Script
              id="gtag-init"
              strategy="afterInteractive"
              dangerouslySetInnerHTML={{
                __html: `
                window.dataLayer = window.dataLayer || [];
                function gtag(){dataLayer.push(arguments);}
                gtag('js', new Date());
                gtag('config', '${gtag.GA_TRACKING_ID}', {
                  page_path: window.location.pathname,
                });
              `,
              }}
            />
            <Component {...pageProps} />
          </SnackbarProvider>
        </ThemeProvider>
      </CacheProvider>
    </Provider>
  );
};

export default CareerChatRecruiters;
