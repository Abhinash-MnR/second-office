// React, Next packages
import React, { useState } from "react";
import Link from "next/link";
import { connect } from "react-redux";
import { Dispatch } from "redux";
// Mui packages
import {
  Grid,
  TextField,
  OutlinedInput,
  InputAdornment,
  IconButton,
  FormControl,
  InputLabel,
  Button,
  Checkbox,
  FormControlLabel,
  styled,
  Typography,
  Box,
} from "@mui/material";
import { login, loginGoogle } from "api/auth";
import { useRouter } from "next/router";
//Custom Packages
import { updateCompany } from "reducers/profileSlice";
import { RootState } from "reducers";
// Third-party packages
import { useTranslation } from "react-i18next";
import { Formik } from "formik";
import { useSnackbar } from "notistack";
import { Visibility, VisibilityOff } from "@mui/icons-material";
import GoogleIcon from "@mui/icons-material/Google";
import { GoogleLogin } from "react-google-login";

const CustomContainer = styled("div")(({ theme }) => ({
  display: "flex",
  justifyContent: "center",
  alignItems: "center",
  [theme.breakpoints.down("sm")]: {
    display: "flex",
    flexDirection: "row",
    width: "100%",
  },
}));

const LoginWrapper = styled("div")(({ theme }) => ({
  width: 552,
  // height: 584,
  background: "#fff",
  padding: "36px",
  borderRadius: 10,
  [theme.breakpoints.down("sm")]: {
    display: "flex",
    flexDiraction: "column",
    maxWidth: "600px",
    padding: 20,
  },
}));

const ContentContainer = styled("div")(({ theme }) => ({
  display: "flex",
  flexDirection: "column",
  // padding: "36px 36px 20px 36px",
  paddingBottom: "20px",
  color: "#2C3058",
  [theme.breakpoints.down("sm")]: {
    display: "flex",
    flexDirection: "column",
    // padding: "40px 20px 40px 20px",
    paddingBottom: 20,
  },
}));

const FormContainer = styled("div")(({ theme }) => ({
  display: "flex",
  justifyContent: "center",
  alignItems: "center",
  // padding: "0px 36px",
  [theme.breakpoints.down("sm")]: {
    display: "flex",
    flexDirection: "column",
    alignItem: "center",
    justifyContent: "center",
  },
}));

function Login(props: any) {
  /** third-party hooks */
  const { enqueueSnackbar } = useSnackbar();
  const router = useRouter();
  //** Language translation hooks */
  const { t } = useTranslation();
  const [showPassword, setshowPassword] = useState(false);
  /** useState hooks */
  const [isUpdating, setIsUpdating] = useState<boolean>(false);

  /** props - actions */
  const { updateCompany } = props;

  /** custom handlers  */
  const handleSubmitNew = async (data: any) => {
    try {
      setIsUpdating(true);
      // Create form payload
      const payload = {
        email: data.email,
        password: data.password,
      };
      const loginData = await login(payload);
      enqueueSnackbar("Login Successfully", {
        variant: "info",
      });
      console.log(
        "access_token",
        JSON.stringify(loginData.data.auth_token),
        "access_token1:-",
        JSON.stringify(loginData.data)
      );
      localStorage.setItem("access_token", loginData.data.auth_token);
      const email = localStorage.getItem("email");
      const companyName = localStorage.getItem("company_name");
      if (email !== null && email !== "" && data.email === email) {
        const payload = {
          company_email: data.email,
          company_name: companyName,
        };
        await updateCompany(payload);
        localStorage.removeItem("email");
      }
      router.push("/dashboard");
    } catch (error: any) {
      console.log("error:-", error);
      enqueueSnackbar("Please enter correct email and password.", {
        // Unable to log in with provided credentials.
        variant: "error",
      });
      // enqueueSnackbar(error.toString(), { variant: "error" });
      setIsUpdating(false);
    }
  };
  // Google Success Handler
  const responseGoogleSuccess = (response: any) => {
    console.log(response);
    const data = {
      email: response.profileObj.email,
      password: localStorage.getItem("pass_token")
        ? window.atob(localStorage.getItem("pass_token"))
        : "",
    };
    handleSubmitNew(data);
    console.log(
      "Email",
      response.profileObj.email,
      "name",
      response.profileObj.name
    );
    // router.push("/dashboard");
  };

  // Google Error Handler
  const responseGoogleError = (response: any) => {
    console.log(response);
  };
  const continueWithGoogle = async () => {
    try {
      const loginData = await loginGoogle();
      enqueueSnackbar(`${t("login_success")}`, {
        variant: "info",
      });
      window.location.replace(loginData.data.authorization_url);
    } catch (error: any) {
      console.log("error:-", error);
      enqueueSnackbar("Please enter correct email and password.", {
        // Unable to log in with provided credentials.
        variant: "error",
      });
      // enqueueSnackbar(error.toString(), { variant: "error" });
      setIsUpdating(false);
    }
  };

  return (
    <CustomContainer>
      <LoginWrapper>
        <Grid container>
          <Grid item xs={12}>
            <ContentContainer>
              <Typography component="h3" variant="h3" color="primary.main">
                Log In
              </Typography>
              <Typography component="p" variant="body1">
                Enter your details below
              </Typography>
            </ContentContainer>

            <FormContainer>
              <Formik
                initialValues={{ email: "", password: "" }}
                validate={(values) => {
                  const errors: any = {};
                  if (!values.email) {
                    errors.email = "*Required";
                  } else if (
                    !/^[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}$/i.test(
                      values.email
                    )
                  ) {
                    errors.email =
                      "Incorrect Email. Try with your registered email id.";
                  }
                  if (!values.password) {
                    errors.password = "*Required";
                  } else if (!/^(?=.{8,})/i.test(values.password)) {
                    errors.password = "Password must be 8 digits.";
                  }
                  return errors;
                }}
                onSubmit={(values, { setSubmitting }) => {
                  try {
                    console.log("sucess");
                  } catch (error: any) {
                    console.log("error");
                  }
                  console.log("LoginTapped");
                  handleSubmitNew(values);
                  // setTimeout(() => {
                  //   alert(JSON.stringify(values, null, 2));
                  //   setSubmitting(false);
                  // }, 400);
                }}
              >
                {({
                  values,
                  errors,
                  touched,
                  handleChange,
                  handleBlur,
                  handleSubmit,
                  isSubmitting,
                  /* and other goodies */
                }) => (
                  <form onSubmit={handleSubmit}>
                    <Grid container spacing={2}>
                      <Grid item xs={12}>
                        <TextField
                          type="email"
                          name="email"
                          onChange={handleChange}
                          onBlur={handleBlur}
                          value={values.email}
                          error={
                            !(errors.email && touched.email && errors.email)
                              ? false
                              : true
                          }
                          label="Email Address"
                          variant="outlined"
                          margin="none"
                          fullWidth
                        />

                        <Box color="#D20000" fontSize="12px" height="8px">
                          {errors.email && touched.email && errors.email}
                        </Box>
                      </Grid>
                      <Grid item xs={12}>
                        <FormControl variant="outlined" fullWidth>
                          <InputLabel htmlFor="outlined-adornment-password">
                            Password
                          </InputLabel>
                          <OutlinedInput
                            name="password"
                            onChange={handleChange}
                            onBlur={handleBlur}
                            value={values.password}
                            error={
                              !(
                                errors.password &&
                                touched.password &&
                                errors.password
                              )
                                ? false
                                : true
                            }
                            label="Password"
                            type={showPassword ? "text" : "password"}
                            endAdornment={
                              <InputAdornment position="end">
                                <IconButton
                                  onClick={() => setshowPassword(!showPassword)}
                                  edge="end"
                                >
                                  {showPassword ? (
                                    <VisibilityOff />
                                  ) : (
                                    <Visibility />
                                  )}
                                </IconButton>
                              </InputAdornment>
                            }
                          />
                        </FormControl>
                        <Box color="#D20000" fontSize="12px" height="8px">
                          {errors.password &&
                            touched.password &&
                            errors.password}
                        </Box>
                      </Grid>
                      <Grid item xs={12}>
                        <Grid container alignItems="center">
                          <Grid item xs={6}>
                            <FormControlLabel
                              control={<Checkbox />}
                              label="Remember Me"
                            />
                          </Grid>
                          <Grid item xs={6}>
                            <Link href="/auth/register/ForgotPass">
                              <a>
                                <Typography
                                  sx={{
                                    fontSize: "14px",
                                    fontWeight: "bold",
                                    lineHeight: "150%",
                                    textAlign: "right",
                                    color: "#2C3058",
                                  }}
                                >
                                  Forgot Password?
                                </Typography>
                              </a>
                            </Link>
                          </Grid>
                        </Grid>
                      </Grid>
                      <Grid item xs={12}>
                        <Button variant="contained" fullWidth type="submit">
                          Log In
                        </Button>
                      </Grid>
                      <Grid
                        item
                        xs={12}
                        sx={{ display: "flex", justifyContent: "center" }}
                      >
                        <Typography
                          component="span"
                          sx={{
                            fontSize: 14,
                            lineHeight: 1.5,
                            paddingRight: 0.5,
                          }}
                        >
                          Don’t have an account?
                        </Typography>
                        <Typography
                          component="span"
                          sx={{
                            fontSize: 14,
                            lineHeight: 1.5,
                            fontWeight: "bold",
                            color: "#2C3058",
                          }}
                        >
                          <Link href="/auth/register/Signup">
                            <a>Create Account</a>
                          </Link>
                        </Typography>
                      </Grid>
                      <Grid
                        item
                        xs={12}
                        sx={{
                          display: "flex",
                          justifyContent: "center",
                          fontSize: 14,
                          lineHeight: 1.5,
                        }}
                      >
                        OR
                      </Grid>
                      <Grid item xs={12}>
                        <GoogleLogin
                          clientId="107695082191-19bjqqbjerocb9q2lv83v9vvjrsajq52.apps.googleusercontent.com"
                          render={(renderProps) => (
                            <Button
                              onClick={renderProps.onClick}
                              disabled={renderProps.disabled}
                              variant="outlined"
                              fullWidth
                              startIcon={<GoogleIcon />}
                            >
                              Continue via Google
                            </Button>
                          )}
                          buttonText="Login"
                          onSuccess={(response) =>
                            responseGoogleSuccess(response)
                          }
                          onFailure={(response) =>
                            responseGoogleError(response)
                          }
                          cookiePolicy={"single_host_origin"}
                        />
                      </Grid>
                    </Grid>
                  </form>
                )}
              </Formik>
            </FormContainer>
          </Grid>
        </Grid>
      </LoginWrapper>
    </CustomContainer>
  );
}

const mapStateToProps = (state: RootState) => ({
  company: state.profile.company,
});

const mapDispatchToProps = (dispatch: Dispatch) => {
  return {
    updateCompany: (payload: any) => updateCompany(dispatch, payload),
  };
};

export default connect(mapStateToProps, mapDispatchToProps)(Login);
