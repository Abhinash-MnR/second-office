// React, Next packages
import { useRouter } from "next/router";
import { useEffect, useState } from "react";
import { connect } from "react-redux";
import { Dispatch } from "redux";
// Mui packages
import { Box, Grid, Stack, Typography, useMediaQuery } from "@mui/material";
// Third party packages
import i18next from "i18next";
import { useTranslation } from "react-i18next";
import "translation/i18n";
// Custom packages
import { Layout } from "@common/Layout";
import useCompany from "@lib/useCompany";
import { ManagementMenu } from "features/home/ManagementMenu";
import { OfficeDetail } from "features/home/OfficeDetail";
import { OfficeList } from "features/home/OfficeList";
import { WorldMap } from "features/home/WorldMap";
import { RootState } from "reducers/index";
import { teamRoasterList } from "reducers/teamRoasterSlice";

function HomePage(props) {
  /** props - actions */
  const { teamRoasterList } = props;

  /** props - states */
  const { employees, employeesCount } = props;

  /** custom hooks */
  const router = useRouter();
  const { t } = useTranslation();
  const { company } = useCompany();
  const isMobile = useMediaQuery("(max-width:600px)");

  /** useState hooks */
  const [selectedCity, setSelectedCity] = useState("Noida");

  /** useEffect hooks */
  useEffect(() => {
    i18next.changeLanguage(company?.language);
    company &&
      teamRoasterList({
        job_status: "current",
      });
  }, [company]);

  /** custom handlers */
  const handleChangeCity = (city) => setSelectedCity(city);

  /** custom renderers */
  const renderManagementMenu = (menu) => {
    return (
      <Grid key={menu.label} item xs={12} sm={6} md={3}>
        <ManagementMenu label={menu.label} href={menu.href} icon={menu.icon} />
      </Grid>
    );
  };

  const managementMenus = [
    {
      label: `${t("dashboard_management_menu_title1")}`,
      icon: "/tmp/1.svg",
      href: "/applications/jobs/add",
    },
    {
      label: `${t("dashboard_management_menu_title2")}`,
      icon: "/tmp/2.svg",
      href: "https://calendly.com/secondoffice/booking?month=2022-09&back=1",
    },
    // {
    //   label: `${t("dashboard_management_menu_title3")}`,
    //   icon: "/tmp/3.svg",
    //   href: "/officeManagement/attendance",
    // },
    {
      label: `${t("dashboard_management_menu_title4")}`,
      icon: "/tmp/4.svg",
      href: "/store",
    },
    {
      label: `${t("dashboard_management_menu_title5")}`,
      icon: "/tmp/5.svg",
      href: "/officeManagement/performance",
    },
    {
      label: `${t("dashboard_management_menu_title6")}`,
      icon: "/tmp/6.svg",
      href: "/expenses",
    },
  ];

  return (
    <Layout companyName="StrongArm" ogTitle="Dashboard | SecondOffice">
      <Stack
        display={{ xs: "none", md: "block" }}
        position="relative"
        marginBottom={5}
      >
        <WorldMap
          selectedCity={selectedCity}
          onCityClicked={handleChangeCity}
        />
        <Box sx={{ position: "absolute", top: 20, right: 20 }}>
          <OfficeDetail employees={employees} selectedCity={selectedCity} />
        </Box>
        <Box sx={{ position: "absolute", bottom: 20, left: 20 }}>
          <OfficeList
            selectedCity={selectedCity}
            onCityClicked={handleChangeCity}
          />
        </Box>
      </Stack>
      <Typography variant="h4" marginBottom={2.5}>
        {t("dashboard_management_title")}
      </Typography>
      <Grid container spacing={2.5}>
        {managementMenus.map(renderManagementMenu)}
      </Grid>
    </Layout>
  );
}
const mapStateToProps = (state: RootState) => ({
  employees: state.roaster.results,
  employeesCount: state.roaster.count,
});

const mapDispatchToProps = (dispatch: Dispatch) => {
  return {
    teamRoasterList: (params: any) => teamRoasterList(dispatch, params),
  };
};

export default connect(mapStateToProps, mapDispatchToProps)(HomePage);
