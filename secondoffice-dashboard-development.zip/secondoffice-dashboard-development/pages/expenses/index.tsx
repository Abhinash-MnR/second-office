// React, Next packages
import React from "react";
import dynamic from "next/dynamic";
import Link from "next/link";
// Mui packages
import { Grid, styled, Box } from "@mui/material";
import OfficeExpenses from "features/officeExpenses/OfficeExpenses";
import ExpenseCardSlider from "features/officeExpenses/ExpenseCardSlider";
import CurrentBalance from "features/officeExpenses/CurrentBalance";
import PremiumBanner from "features/officeExpenses/PremiumBanner";
import router from "next/router";

// Dynamic import packages
const Layout = dynamic(() =>
  import("@common/Layout").then((mod) => mod.Layout)
);
import useCompany from "@lib/useCompany";

const CustomContainer = styled("div")(({ theme }) => ({
  display: "flex",
  flexDirection: "column",
}));

function Expenses() {
  // Custom hooks
  const { company } = useCompany();

  return (
    <Layout companyName="StrongArm" ogTitle="Dashboard | SecondOffice">
      <CustomContainer>
        {/* [FAQ Button] */}
        <Box
          sx={{
            position: "fixed",
            right: 48,
            bottom: 48,
            cursor: "pointer",
            zIndex: 9999,
          }}
          onClick={() => router.push("/help_center/office-expenses")}
        >
          <img
            src="/svg/helpCenterFloatingButton.svg"
            alt="helpCenterFloatingButton"
            style={{ height: 56, width: 56 }}
          />
        </Box>

        {/* {company && company.premium_purchase_complete === "False" && (
          <PremiumBanner />
        )} */}

        <Grid container spacing={3} marginBottom={5}>
          <Grid item xs={12} sm={8}>
            <ExpenseCardSlider />
          </Grid>
          <Grid item xs={12} sm={4}>
            <CurrentBalance />
          </Grid>
        </Grid>
        <OfficeExpenses />
      </CustomContainer>
    </Layout>
  );
}

export default Expenses;
