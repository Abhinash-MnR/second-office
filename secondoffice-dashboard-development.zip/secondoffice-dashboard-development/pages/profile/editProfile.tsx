// React, Next packages
import React, { ChangeEvent, useEffect, useState } from "react";
import { Form, FormProps, Field } from "react-final-form";
import { connect } from "react-redux";
import Link from "next/link";
import dynamic from "next/dynamic";
import { Dispatch } from "redux";
// Third-party packages
import { useSnackbar } from "notistack";
import { useTranslation } from "react-i18next";
import "translation/i18n";
// MUI Packages
import {
  Grid,
  Stack,
  Typography,
  styled,
  Button,
  useMediaQuery,
  Box,
} from "@mui/material";
//Custom Packages
import { LayoutProps } from "@common/Layout";
import { SectionDivider } from "@common/Section";
import { AvatarFormCamera } from "features/profile/AvatarForm";
import { BackIcon } from "@common/Icon";
import { useRouter } from "next/router";
import { readCompany, updateCompany } from "reducers/profileSlice";
import { RootState } from "reducers";
import { TextField } from "@common/FormField";
import { StringValidator } from "@lib/form-validations";
import CircularProgress from "@mui/material/CircularProgress";

// Dynamic import packages
const Layout = dynamic<LayoutProps>(
  () => import("@common/Layout").then((mod) => mod.Layout),
  { ssr: false }
);

const ProfileContainer = styled("div")(({ theme }) => ({
  display: "flex",
  flexDirection: "column",

  [theme.breakpoints.down("sm")]: {
    width: "100%",
  },
}));

const ProfileTitle = styled("div")(({ theme }) => ({
  display: "flex",
  flexDirection: "row",
  marginBottom: 20,
  [theme.breakpoints.down("sm")]: {
    marginBottom: 10,
  },
}));

const ProfileSection = styled("div")(({ theme }) => ({
  display: "flex",
  flexDirection: "column",
  background: "#FFFFFF",
  // boxShadow: " 0px 16px 23px -4px rgba(145, 158, 171, 0.24)",
  borderRadius: theme.shape.borderRadius,
  padding: 30,
  [theme.breakpoints.down("sm")]: {
    boxShadow: "none",
    padding: "10px 15px",
  },
}));

function CompanyProfile(props: any) {
  //** Language translation hooks */
  const { t } = useTranslation();
  /** third-party hooks */
  const router = useRouter();
  // useMediaQuery for Mobile view
  const isMobile = useMediaQuery("(max-width:600px)");
  // useCompany({ redirectTo: "/" });
  const { enqueueSnackbar } = useSnackbar();
  const [selectedLogoPath, setSelectedLogoPath] = useState<string>("");

  /** useState hooks - global */
  const [isUpdating, setIsUpdating] = useState(false);

  /** props - actions */
  const { readCompany, updateCompany } = props;
  /** props - redux states */
  const { company } = props;

  const stringValidator = new StringValidator();

  /** useEffect hooks */
  useEffect(() => {
    const fetchCompany = async () => {
      try {
        await readCompany();
      } catch (error) {
        enqueueSnackbar("Please login first.", { variant: "info" });
      }
    };
    fetchCompany();
  }, []);

  useEffect(() => {
    console.log("company:-", company);
  }, [company]);

  const handleLogout = async () => {
    localStorage.removeItem("access_token");
    router.push("/");
  };

  /** custom handlers */
  const handleLogoChange = async (event: ChangeEvent) => {
    setIsUpdating(true);
    try {
      const target = event.target as HTMLInputElement;
      const file = target && target.files ? target.files[0] : null;
      const fileSize = file.size / 1024 / 1024;
      if (fileSize > 1) {
        enqueueSnackbar("Company Logo should be less than 1 MB", {
          variant: "error",
        });
        return;
      }
      setSelectedLogoPath(target.value);
      // If file was selected
      if (file) {
        const payload = {
          company_logo: file,
          company_name: company.company_name,
        };
        let op = await updateCompany(payload);
        setTimeout(() => {
          enqueueSnackbar("Your company image has been updated.", {
            variant: "info",
          });
        }, 2500);
      }
    } catch (error: any) {
      enqueueSnackbar(error.toString(), { variant: "error" });
    } finally {
      setTimeout(() => {
        setIsUpdating(false);
      }, 2500);
    }
  };

  /** custom handlers */
  const handleSubmitProfile = async (data: any) => {
    setIsUpdating(true);
    try {
      console.log(data);

      if (data.company_phone.length < 9 || data.company_phone.length > 15) {
        enqueueSnackbar(
          "Only number must be entered and minium 9 to 15 digits allowed.",
          {
            variant: "error",
          }
        );
      } else {
        await updateCompany({ ...data, create_profile_complete: "True" });
        enqueueSnackbar("Your company profile has been updated.", {
          variant: "info",
        });
        router.push("/profile");
      }
    } catch (error: any) {
      enqueueSnackbar(`Error: ${error.toString()}`, {
        variant: "error",
      });
    } finally {
      setIsUpdating(false);
    }
  };

  return (
    <Layout companyName="StrongArm" ogTitle="Profile | SecondOffice">
      <Box sx={{ position: "absolute", top: "50%", left: "50%", zIndex: 999 }}>
        {isUpdating ? <CircularProgress /> : null}
      </Box>
      <ProfileContainer>
        <ProfileTitle>
          <Link href="/profile">
            <a>
              <Typography component="span">
                <BackIcon sx={{ fontSize: "12px", marginRight: "10px" }} />
              </Typography>
              <Typography component="span" variant="h6">
                {t("edit_profile_button_title")}
              </Typography>
            </a>
          </Link>
        </ProfileTitle>
        <ProfileSection>
          {/* (1) Section - Company Logo  */}
          <Form
            onSubmit={handleSubmitProfile}
            initialValues={{
              company_description: company?.company_description,
              company_email: company?.company_email,
              company_location: company?.company_location,
              company_name: company?.company_name,
              company_phone: company?.company_phone,
            }}
          >
            {({ handleSubmit, valid, values }) => {
              const contentLength = values.company_description?.length;
              return (
                <form id="company_form" onSubmit={handleSubmit}>
                  <Stack
                    direction="row"
                    alignItems="center"
                    justifyContent="space-between"
                  >
                    <AvatarFormCamera
                      // src={company?.company_logo}
                      src={
                        company?.company_logo
                          ? company?.company_logo
                          : `/svg/DefaultLogo.svg`
                      }
                      onChange={(value) => {
                        handleLogoChange(value);
                      }}
                    />
                    <Typography>
                      <Button
                        // component="a"
                        disabled={!valid}
                        variant="contained"
                        type="submit"
                        // id="company_form"
                        // rel="noopener noreferrer"
                        // target="_blank"
                        size="medium"
                        sx={{
                          border: "1px solid #2c3058",
                          // width: "140px",
                          background: "primary.main",
                          color: "#fff",
                          display: { xs: "none", sm: "block" },
                        }}
                      >
                        {t("edit_profile_save")}
                      </Button>
                    </Typography>
                  </Stack>

                  <SectionDivider />

                  {/* (2) Section - Basic Information  */}
                  <Stack
                    alignItems="center"
                    direction="row"
                    justifyContent="space-between"
                    marginBottom={2.5}
                  >
                    <Typography variant="subtitle1">
                      {t("profile_basic_info")}
                    </Typography>
                  </Stack>
                  <Grid container columnSpacing={3.75}>
                    {/* Company Name */}
                    <Grid item xs={12} sm={2}>
                      <Typography
                        component="div"
                        fontWeight="bold"
                        variant="caption"
                        marginBottom={2}
                      >
                        {t("company_name")}
                      </Typography>
                      <Typography
                        color="grey.600"
                        marginBottom={3.75}
                        variant="body1"
                      >
                        <Field
                          component={TextField}
                          fullWidth
                          name="company_name"
                          // placeholder="Company Name"
                          size="small"
                          // title="Name of the Company"
                          validate={stringValidator.validateRequiredMax128}
                          variant="outlined"
                        />
                      </Typography>
                    </Grid>
                    {/* Company Location */}
                    <Grid item xs={12} sm={2}>
                      <Typography
                        component="div"
                        fontWeight="bold"
                        variant="caption"
                        marginBottom={2}
                      >
                        {t("comapny_location")}
                      </Typography>
                      <Typography
                        color="grey.600"
                        marginBottom={3.75}
                        variant="body1"
                      >
                        <Field
                          component={TextField}
                          fullWidth
                          name="company_location"
                          // placeholder="Company Name"
                          size="small"
                          // title="Name of the Company"
                          validate={stringValidator.validateNoNumber}
                          variant="outlined"
                        />
                      </Typography>
                    </Grid>
                    {/* Company Email */}
                    <Grid item xs={12} sm={4}>
                      <Typography
                        component="div"
                        fontWeight="bold"
                        variant="caption"
                        marginBottom={2}
                        marginRight={2}
                      >
                        {t("company_email")}
                      </Typography>
                      <Typography
                        color="grey.600"
                        marginBottom={3.75}
                        variant="body1"
                      >
                        <Field
                          component={TextField}
                          fullWidth
                          name="company_email"
                          // placeholder="Company Name"
                          size="small"
                          // title="Name of the Company"
                          validate={stringValidator.validateEmail}
                          variant="outlined"
                          disabled
                        />
                      </Typography>
                    </Grid>
                    {/* Company Contact */}
                    <Grid item xs={12} sm={3}>
                      <Typography
                        component="div"
                        fontWeight="bold"
                        variant="caption"
                        marginBottom={2}
                      >
                        {t("company_contact")}
                      </Typography>
                      <Typography
                        color="grey.600"
                        marginBottom={3.75}
                        variant="body1"
                      >
                        <Field
                          component={TextField}
                          fullWidth
                          name="company_phone"
                          // placeholder="Company Name"
                          size="small"
                          // title="Name of the Company"
                          validate={stringValidator.validateOnlyNumber}
                          variant="outlined"
                          // type="number"
                          inputProps={{ maxLength: 15 }}
                        />
                      </Typography>
                    </Grid>
                    {/* Company Description */}
                    <Grid item xs={12}>
                      <Typography
                        component="div"
                        fontWeight="bold"
                        variant="caption"
                        marginBottom={2}
                        marginRight={2}
                      >
                        {t("comapny_desc")}
                      </Typography>
                      <Field
                        component={TextField}
                        fullWidth
                        maxRows={4}
                        minRows={4}
                        multiline
                        name="company_description"
                        // placeholder="Introduce the company here."
                        // title="Description"
                        variant="outlined"
                        validate={stringValidator.validateMax4000}
                      />
                      <Typography
                        color={contentLength > 4000 ? "error" : "grey.500"}
                        marginTop={0.625}
                        marginBottom={6}
                        textAlign="right"
                        variant="body2"
                      >
                        {/* {contentLength ?? 0}/4,000 */}
                      </Typography>
                    </Grid>
                  </Grid>
                  <Typography>
                    <Button
                      // component="a"
                      disabled={!valid}
                      variant="contained"
                      type="submit"
                      // id="company_form"
                      // rel="noopener noreferrer"
                      // target="_blank"
                      size="medium"
                      sx={{
                        border: "1px solid #2c3058",
                        width: "140px",
                        background: "primary.main",
                        color: "#fff",
                        display: { xs: "block", sm: "none" },
                      }}
                    >
                      {t("edit_profile_save")}
                    </Button>
                  </Typography>
                </form>
              );
            }}
          </Form>
        </ProfileSection>
      </ProfileContainer>
    </Layout>
  );
}
const mapStateToProps = (state: RootState) => ({
  company: state.profile.company,
});

const mapDispatchToProps = (dispatch: Dispatch) => {
  return {
    readCompany: () => readCompany(dispatch),
    updateCompany: (payload: any) => updateCompany(dispatch, payload),
  };
};

export default connect(mapStateToProps, mapDispatchToProps)(CompanyProfile);
