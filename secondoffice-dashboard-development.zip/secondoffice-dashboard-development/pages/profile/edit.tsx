// React, Next packages
import React from "react";
import Link from "next/link";
import dynamic from "next/dynamic";
// MUI Packages
import { Grid, Stack, Typography, styled, Button } from "@mui/material";
//Custom Packages
import { LayoutProps } from "@common/Layout";
import { ProfileForm } from "features/profile/ProfileForm";
import { BackIcon } from "@common/Icon";

// Dynamic import packages
const Layout = dynamic<LayoutProps>(
  () => import("@common/Layout").then((mod) => mod.Layout),
  { ssr: false }
);

const ProfileContainer = styled("div")(({ theme }) => ({
  display: "flex",
  flexDirection: "column",
  padding: "24px",
}));

const ProfileTitle = styled("div")(({ theme }) => ({
  display: "flex",
  flexDirection: "row",
  marginBottom: 30,
}));

function CompanyProfile() {
  const handleSubmitProfile = () => {
    console.log("Console Log Form Data");
  };
  return (
    <Layout companyName="StrongArm" ogTitle="Edit Profile | SecondOffice">
      <ProfileContainer>
        <ProfileTitle>
          <Link href="/profile">
            <a>
              <Typography component="span">
                <BackIcon sx={{ fontSize: "14px", marginRight: "10px" }} />
              </Typography>
              <Typography component="span" variant="h3">
                Edit Profile
              </Typography>
            </a>
          </Link>
        </ProfileTitle>
        <ProfileForm
          initialValues={{
            company_name: "StrongArm",
            company_location: "California",
            company_description: "All Description Content",
          }}
          onSubmit={handleSubmitProfile}
        />
      </ProfileContainer>
    </Layout>
  );
}

export default CompanyProfile;
