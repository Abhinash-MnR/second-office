// React, Next packages
import React, { useEffect, useState } from "react";
import { connect } from "react-redux";
import { Dispatch } from "redux";
import dynamic from "next/dynamic";
// Third-party packages
import { useSnackbar } from "notistack";
// Custom packages
import useCompany from "@lib/useCompany";
import { Backdrop } from "@common/Backdrop";
import { ProfileForm } from "features/profile/ProfileForm";
import { RootState } from "reducers";
import { readCompany, updateCompany } from "reducers/profileSlice";
// #region - Dynamic import packages -https://nextjs.org/docs/advanced-features/dynamic-import
const Layout = dynamic(
  () => import("@common/Layout").then((mod) => mod.Layout),
  { ssr: false, loading: () => <Backdrop open invisible /> }
);

function CompanyProfile(props: any) {
  /** third-party hooks */
  useCompany({ redirectTo: "/" });
  const { enqueueSnackbar } = useSnackbar();

  /** useState hooks - global */
  const [isUpdating, setIsUpdating] = useState(false);

  /** props - actions */
  const { readCompany, updateCompany } = props;
  /** props - redux states */
  const { company } = props;

  /** useEffect hooks */
  useEffect(() => {
    const fetchCompany = async () => {
      try {
        await readCompany();
      } catch (error) {
        // enqueueSnackbar("Please login first.", { variant: "info" });
      }
    };
    fetchCompany();
  }, []);

  /** custom handlers */
  const handleSubmitProfile = async (data: any) => {
    setIsUpdating(true);
    try {
      console.log(data);
      await updateCompany(data);
      enqueueSnackbar("Your company profile has been updated.", {
        variant: "info",
      });
    } catch (error: any) {
      enqueueSnackbar(`Error: ${error.toString()}`, {
        variant: "error",
      });
    } finally {
      setIsUpdating(false);
    }
  };

  return (
    <Layout ogTitle="Edit Profile | CareerChat">
      <ProfileForm
        initialValues={{
          company_name: company?.company_name,
          company_location: company?.company_location,
          company_description: company?.company_description,
        }}
        onSubmit={handleSubmitProfile}
      />
      <Backdrop open={isUpdating} />
    </Layout>
  );
}

const mapStateToProps = (state: RootState) => ({
  company: state.profile.company,
});

const mapDispatchToProps = (dispatch: Dispatch) => {
  return {
    readCompany: () => readCompany(dispatch),
    updateCompany: (payload: any) => updateCompany(dispatch, payload),
  };
};

export default connect(mapStateToProps, mapDispatchToProps)(CompanyProfile);
