// React, Next packages
import React, { ChangeEvent, useEffect, useState } from "react";
import { connect } from "react-redux";
import Link from "next/link";
import dynamic from "next/dynamic";
import { Dispatch } from "redux";
// Third-party packages
import { useSnackbar } from "notistack";
import { useTranslation } from "react-i18next";
import "translation/i18n";
// MUI Packages
import {
  Grid,
  Stack,
  Typography,
  styled,
  Button,
  useMediaQuery,
} from "@mui/material";
//Custom Packages
import { LayoutProps } from "@common/Layout";
import { SectionDivider } from "@common/Section";
import { AvatarForm } from "features/profile/AvatarForm";
import { Description } from "features/profile/Description";
import { BackIcon, EditIcon } from "@common/Icon";
import { useRouter } from "next/router";
import { readCompany, updateCompany } from "reducers/profileSlice";
import useCompany from "@lib/useCompany";
import { RootState } from "reducers";

// Dynamic import packages
const Layout = dynamic<LayoutProps>(
  () => import("@common/Layout").then((mod) => mod.Layout),
  { ssr: false }
);

const ProfileContainer = styled("div")(({ theme }) => ({
  display: "flex",
  flexDirection: "column",

  [theme.breakpoints.down("sm")]: {
    width: "100%",
  },
}));

const ProfileTitle = styled("div")(({ theme }) => ({
  display: "flex",
  flexDirection: "row",
  marginBottom: 20,
  [theme.breakpoints.down("sm")]: {
    marginBottom: 10,
  },
}));

const ProfileSection = styled("div")(({ theme }) => ({
  display: "flex",
  flexDirection: "column",
  background: "#FFFFFF",
  // boxShadow: " 0px 16px 23px -4px rgba(145, 158, 171, 0.24)",
  borderRadius: theme.shape.borderRadius,
  padding: 30,
  [theme.breakpoints.down("sm")]: {
    boxShadow: "none",
    padding: "10px 15px",
  },
}));

function CompanyProfile(props: any) {
  /** third-party hooks */
  //** Language translation hooks */
  const { t } = useTranslation();

  const router = useRouter();
  // useMediaQuery for Mobile view
  const isMobile = useMediaQuery("(max-width:600px)");
  // useCompany({ redirectTo: "/" });
  const { enqueueSnackbar } = useSnackbar();

  /** useState hooks - global */
  const [isUpdating, setIsUpdating] = useState(false);

  /** props - actions */
  const { readCompany, updateCompany } = props;
  /** props - redux states */
  const { company } = props;

  /** useEffect hooks */
  useEffect(() => {
    const fetchCompany = async () => {
      try {
        await readCompany();
      } catch (error) {
        enqueueSnackbar("Please login first.", { variant: "info" });
      }
    };
    fetchCompany();
  }, []);

  const handleLogout = async () => {
    localStorage.removeItem("access_token");
    router.push("/");
  };

  return (
    <Layout companyName="StrongArm" ogTitle="Profile | SecondOffice">
      <ProfileContainer>
        <ProfileTitle>
          <Link href="/dashboard">
            <a>
              <Typography component="span">
                <BackIcon sx={{ fontSize: "12px", marginRight: "10px" }} />
              </Typography>
              <Typography component="span" variant="h6">
                {t("profile_backIcon_title")}
              </Typography>
            </a>
          </Link>
        </ProfileTitle>
        <ProfileSection>
          {/* (1) Section - Company Logo  */}
          <Stack
            direction="row"
            alignItems="center"
            justifyContent="space-between"
          >
            <AvatarForm
              // src={company?.company_logo}
              // src="/svg/DefaultLogo.svg"
              src={
                company?.company_logo
                  ? company?.company_logo
                  : `/svg/DefaultLogo.svg`
              }
            />
            <Typography>
              {isMobile ? (
                <EditIcon onClick={() => router.push("/profile/editProfile")} />
              ) : (
                <Button
                  component="a"
                  variant="contained"
                  rel="noopener noreferrer"
                  target="_blank"
                  size="medium"
                  sx={{
                    border: "1px solid #2c3058",
                    width: "136px",
                    background: "primary.main",
                    color: "#fff",
                  }}
                  onClick={() => router.push("/profile/editProfile")}
                >
                  {t("edit_profile_button_title")}
                </Button>
              )}
            </Typography>
          </Stack>

          <SectionDivider />

          {/* (2) Section - Basic Information  */}
          <Stack
            alignItems="center"
            direction="row"
            justifyContent="space-between"
            marginBottom={2.5}
          >
            <Typography variant="subtitle1">
              {t("profile_basic_info")}
            </Typography>
            {/* <Link href="/profile/edit" shallow>
              <a>
                <img src="/svg/edit.svg" />
              </a>
            </Link> */}
          </Stack>
          <Grid container columnSpacing={3.75} width="auto">
            {/* Company Name */}
            <Grid item xs={12} sm={2}>
              <Typography
                component="div"
                fontWeight="bold"
                variant="caption"
                marginBottom={2}
              >
                {t("company_name")}
              </Typography>
              <Typography color="grey.600" marginBottom={3.75} variant="body1">
                {company?.company_name}
              </Typography>
            </Grid>
            {/* Company Location */}
            <Grid item xs={12} sm={2}>
              <Typography
                component="div"
                fontWeight="bold"
                variant="caption"
                marginBottom={2}
              >
                {t("comapny_location")}
              </Typography>
              <Typography color="grey.600" marginBottom={3.75} variant="body1">
                {company?.company_location}
              </Typography>
            </Grid>
            {/* Company Email */}
            <Grid item xs={12} sm={4}>
              <Typography
                component="div"
                fontWeight="bold"
                variant="caption"
                marginBottom={2}
                marginRight={2}
              >
                {t("company_email")}
              </Typography>
              <Typography color="grey.600" marginBottom={3.75} variant="body1">
                {company?.company_email}
              </Typography>
            </Grid>
            {/* Company Contact */}
            <Grid item xs={12} sm={2}>
              <Typography
                component="div"
                fontWeight="bold"
                variant="caption"
                marginBottom={2}
              >
                {t("company_contact")}
              </Typography>
              <Typography color="grey.600" marginBottom={3.75} variant="body1">
                {company?.company_phone}
              </Typography>
            </Grid>
            {/* Company Description */}
            <Grid item xs={12}>
              <Description
                title={`${t("comapny_desc")}`}
                description={company?.company_description}
              />
            </Grid>
            <Grid item xs={12}>
              <Button
                onClick={handleLogout}
                component="a"
                variant="contained"
                rel="noopener noreferrer"
                target="_blank"
                size="medium"
                sx={{
                  border: "1px solid #2c3058",
                  width: "148px",
                  background: "none",
                  color: "#2c3058",
                  "&:hover": {
                    background: "none",
                  },
                }}
              >
                {t("profile_logout")}
              </Button>
            </Grid>
          </Grid>
        </ProfileSection>
      </ProfileContainer>
    </Layout>
  );
}
const mapStateToProps = (state: RootState) => ({
  company: state.profile.company,
});

const mapDispatchToProps = (dispatch: Dispatch) => {
  return {
    readCompany: () => readCompany(dispatch),
    updateCompany: (payload: any) => updateCompany(dispatch, payload),
  };
};

export default connect(mapStateToProps, mapDispatchToProps)(CompanyProfile);
