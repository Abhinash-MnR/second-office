// React, Next pages
import React, { useEffect } from "react";
import dynamic from "next/dynamic";
import Link from "next/link";
// Mui packages
import { Box, Button, Typography } from "@mui/material";
// Custom packages
import { LayoutProps } from "@common/Layout";
// import useUser from "@lib/useUser";
import { SECONDOFFICE } from "config/services";

// Dynamic import packages
const Layout = dynamic<LayoutProps>(
  () => import("@common/Layout").then((mod) => mod.Layout),
  { ssr: false }
);

function Logout() {
  return (
    <Box
      display="flex"
      alignItems="center"
      justifyContent="center"
      flexDirection="column"
      height="100vh"
    >
      <Box mt={2}>
        <img src="/svg/404.svg" width={306} height={306} />
      </Box>
      <Typography variant="h6" fontWeight="bold" mt={2} textAlign="center">
        You have succesfully logged out from Second office Dashboard.
      </Typography>
      <Box mt={2} mb={2} width={200}>
        <Link href={SECONDOFFICE} passHref>
          <Button component="a" fullWidth color="primary" variant="contained">
            Go to Homepage
          </Button>
        </Link>
      </Box>
    </Box>
  );
}

export default Logout;
