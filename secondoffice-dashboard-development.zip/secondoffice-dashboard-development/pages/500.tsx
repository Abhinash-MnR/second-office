// React, Next pages
import React from "react";
import dynamic from "next/dynamic";
import Link from "next/link";
// Mui packages
import { Box, Button, Typography } from "@mui/material";
// Custom packages
import { LayoutProps } from "@common/Layout";
import { SECONDOFFICE } from "config/services";

// Dynamic import packages
const Layout = dynamic<LayoutProps>(
  () => import("@common/Layout").then((mod) => mod.Layout),
  { ssr: false }
);

function Custom500(errorCode: any) {
  return (
    <Layout>
      <Box
        mt={2}
        display="flex "
        alignItems="center"
        flexDirection="column"
        height={`calc(100vh - 180px)`}
      >
        <Box mt={2}>
          <img src="/svg/404.svg" width={306} height={306} />
        </Box>
        <Typography variant="h6" fontWeight="bold" mt={2}>
          Sorry! Something must have gone wrong from our end. Please try again.
        </Typography>
        <Box mt={2} mb={2} width={200}>
          <Link href={SECONDOFFICE} passHref>
            <Button component="a" fullWidth color="primary" variant="contained">
              Go to Homepage
            </Button>
          </Link>
        </Box>
      </Box>
    </Layout>
  );
}

export default Custom500;
