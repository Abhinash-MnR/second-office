// React, Next packages
import React from "react";
import dynamic from "next/dynamic";
import { useRouter } from "next/router";
// Mui packages
import { Grid, Box } from "@mui/material";
// Third party packages
import { useTranslation } from "react-i18next";
import "translation/i18n";
// Custom packages
import StoreComingSoon from "features/Store/StoreComingSoon";
import ApprovedDeviceList from "features/Store/ApprovedDeviceList";
// Dynamic import packages
const Layout = dynamic(() =>
  import("@common/Layout").then((mod) => mod.Layout)
);

function Store() {
  //** Language translation hooks */
  const { t } = useTranslation();

  //** useRouter hooks */
  const router = useRouter();

  return (
    <Layout>
      <Box>
        {/* faq button */}
        <Box
          sx={{
            position: "fixed",
            right: 48,
            bottom: 48,
            cursor: "pointer",
            zIndex: 9999,
          }}
          onClick={() => router.push("/help_center/performance-evaluation")}
        >
          <img
            src="/svg/helpCenterFloatingButton.svg"
            alt="helpCenterFloatingButton"
            style={{ height: 56, width: 56 }}
          />
        </Box>
        {/* Device management component */}
        <ApprovedDeviceList />
      </Box>
    </Layout>
  );
}

export default Store;
