// React , Next js packages
import React, { useEffect, useState } from "react";
import { useRouter } from "next/router";
import { connect } from "react-redux";
import { Dispatch } from "redux";
import dynamic from "next/dynamic";
// Mui packages
import { Box, Typography } from "@mui/material";
// Third party packages
import { useTranslation } from "react-i18next";
import "translation/i18n";
import { useSnackbar } from "notistack";
import { useScrollTo } from "react-use-window-scroll";
// Custom packages
import { RootState } from "reducers";
import { deviceList } from "@reducers/deviceSlice";
import { currentEmployeeList } from "@reducers/getCurrentEmployeeListSlice";
import { BackIcon } from "@common/Icon";
import { postRequestDevice } from "@api/deviceMangement";
import RequestDeviceList from "features/Store/RequestDeviceList";
import RequestForm from "features/Store/RequestForm";

// Dynamic import packages
const Layout = dynamic(() =>
  import("@common/Layout").then((mod) => mod.Layout)
);

type Props = {};

function DeviceRequest(props) {
  //** useSnackbar hooks */
  const { enqueueSnackbar } = useSnackbar();
  //**useRouter hooks */
  const router = useRouter();
  //** useScroll hooks */
  const scrollTo = useScrollTo();
  //** Language translation hooks */
  const { t } = useTranslation();
  /** props - actions */
  const { deviceList, currentEmployeeList } = props;
  /** props - states */
  const { result, count, employeeListData } = props;

  const [initalOptions, setinitialOptions] = useState({
    category: "",
    brand: "",
    quantity: "",
    employee: "",
    description: "",
  });

  /** useState hooks */
  const [isUpdating, setIsUpdating] = useState<boolean>(false);

  //** employee list api re render */
  useEffect(() => {
    const employeeName = async () => {
      currentEmployeeList({ page: 1, job_status: "current" });
    };
    try {
      employeeName();
    } catch (error: any) {
      enqueueSnackbar(error.toString(), { variant: "error" });
    }
  }, [currentEmployeeList]);

  //**employee list filter data  */
  const employeeList = employeeListData.map((item) => item.employee_name);
  // console.log(employeeList, "employee list data getting ");

  const handleFormOnSubmit = async (data: any, form) => {
    try {
      setIsUpdating(true);
      const payload = {
        category_name: data.category,
        brand_name: data.brand,
        quantity: data.quantity,
        employee_name: data.employee,
        description: data.description,
      };
      const requestDevice = await postRequestDevice(payload);
      enqueueSnackbar(`${t("request_device_added")}`, {
        variant: "info",
      });
      Object.keys(data).forEach((key) => {
        form.change(key, undefined);
        form.resetFieldState(key);
      });

      // device list api rerender
      device();
      // page scroll on form submit
      scrollTo(500, 800);
      // router.reload();
    } catch (error: any) {
      enqueueSnackbar("Unexpected error occurred. Please try again.", {
        variant: "error",
      });
      setIsUpdating(false);
    }
  };

  //** device list get api re render on form submit */
  const device = async () => {
    deviceList({ page: 1, page_size: 10 });
  };

  return (
    <Layout>
      <Box>
        {/* back icon */}
        <Typography
          variant="h6"
          display={`flex`}
          alignItems={`center`}
          sx={{ cursor: "pointer" }}
          onClick={() => {
            router.replace("/store");
          }}
        >
          <BackIcon
            sx={{
              fontSize: { xs: "11px", sm: "12px" },
              marginRight: { xs: "5px", sm: "10px" },
              marginTop: "0.5px",
            }}
          />
          {t("store_request_back_icon_title")}
        </Typography>

        {/* faq button */}

        <Box
          sx={{
            position: "fixed",
            right: 48,
            bottom: 48,
            cursor: "pointer",
            zIndex: 9999,
          }}
          onClick={() => router.push("/help_center/performance-evaluation")}
        >
          <img
            src="/svg/helpCenterFloatingButton.svg"
            alt="helpCenterFloatingButton"
            style={{ height: 56, width: 56 }}
          />
        </Box>

        {/* submit request form component */}
        <Box bgcolor="grey.100" borderRadius={1.25} px={2.5} py={3} mt={3.75}>
          <Typography variant="h4" mb={3.75}>
            {t("store_new_request_form_title")}
          </Typography>
          {/* Request device form  */}
          <RequestForm
            onSubmit={handleFormOnSubmit}
            employeeDataList={employeeList}
            intialOptions={initalOptions}
          />
        </Box>
        {/* Requested device list */}
        <RequestDeviceList />
      </Box>
    </Layout>
  );
}

const mapStateToProps = (state: RootState) => ({
  result: state.requestDevice.results,
  count: state.requestDevice.count,
  employeeListData: state.currentEmployeeList.results,
});

const mapDispatchToProps = (dispatch: Dispatch) => {
  return {
    deviceList: (params: any) => deviceList(dispatch, params),
    currentEmployeeList: (params: any) => currentEmployeeList(dispatch, params),
  };
};
export default connect(mapStateToProps, mapDispatchToProps)(DeviceRequest);
