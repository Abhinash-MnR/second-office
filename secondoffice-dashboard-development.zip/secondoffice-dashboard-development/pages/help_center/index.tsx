// React, Next packages
import React from "react";
import dynamic from "next/dynamic";
import Link from "next/link";
// Mui packages
import { styled } from "@mui/material";
// Third party packages
import { useTranslation } from "react-i18next";
import "translation/i18n";
// Dynamic import packages
const Layout = dynamic(() =>
  import("@common/Layout").then((mod) => mod.Layout)
);
import useCompany from "@lib/useCompany";
import { FaqList } from "features/helpCenter/FaqList";
import { TutorialBlogs } from "features/helpCenter/TutorialBlogs";

const CustomContainer = styled("div")(({ theme }) => ({
  display: "flex",
  flexDirection: "column",
}));

function HelpCenter() {
  //**Custom hooks */
  const { company } = useCompany();
  //** Language translation hooks */
  const { t } = useTranslation();

  return (
    <Layout companyName="StrongArm" ogTitle="Help Center | SecondOffice">
      <CustomContainer>
        <FaqList />
        <TutorialBlogs />
      </CustomContainer>
    </Layout>
  );
}

export default HelpCenter;
