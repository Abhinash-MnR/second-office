// React, Next packages
import React from "react";
import dynamic from "next/dynamic";

// Mui packages
import { styled } from "@mui/material";

// Dynamic import packages
const Layout = dynamic(() =>
  import("@common/Layout").then((mod) => mod.Layout)
);

import { TutorialBlogsDetail } from "features/helpCenter/TutorialBlogsDetail";

const CustomContainer = styled("div")(({ theme }) => ({
  display: "flex",
  flexDirection: "column",
}));

function HelpCenterDetail() {
  return (
    <Layout companyName="StrongArm" ogTitle="Help Center | SecondOffice">
      <CustomContainer>
        <TutorialBlogsDetail />
      </CustomContainer>
    </Layout>
  );
}

export default HelpCenterDetail;
