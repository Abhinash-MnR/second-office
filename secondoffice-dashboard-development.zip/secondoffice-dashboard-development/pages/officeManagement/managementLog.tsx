// React, Next packages
import React from "react";
import dynamic from "next/dynamic";

// Dynamic import packages
const Layout = dynamic(() =>
  import("@common/Layout").then((mod) => mod.Layout)
);

import ManagementLogSheet from "features/managementLog/ManagementLogSheet";

function managementLog() {
  return (
    <Layout companyName="StrongArm" ogTitle="Dashboard | SecondOffice">
      <ManagementLogSheet />
    </Layout>
  );
}

export default managementLog;
