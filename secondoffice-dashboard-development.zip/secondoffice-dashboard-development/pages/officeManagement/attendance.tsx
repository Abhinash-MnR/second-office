// React, Next packages
import React, { useEffect, useState } from "react";
import dynamic from "next/dynamic";
import { connect } from "react-redux";
import { Dispatch } from "redux";
// Mui packages
import { Box, Typography, Stack } from "@mui/material";
// Third party packages
import { useTranslation } from "react-i18next";
import "translation/i18n";
import { useSnackbar } from "notistack";
// custom Component
import AttendanceLog from "features/officeManagement/AttendanceLog";
import SummaryCard from "@common/SummaryCard";
import {
  CalendarIcon,
  CardViewIcon,
  CardViewIconColor,
  EmployeeOnLeave,
  EmployeePresent,
  TableViewIcon,
  TableViewIconColor,
  TotalCandidates,
} from "@common/Icon";
import AttendanceInCardView from "features/officeManagement/AttendanceInCardView";
import { RootState } from "reducers";
import {
  teamAttendanceCountList,
  teamAttendanceLogList,
} from "@reducers/teamAttendanceLogSlice";
import { employeeList } from "@reducers/employeeListSlice";
import { teamRoasterList } from "@reducers/teamRoasterSlice";
import NoOfficeData from "features/officeManagement/NoOfficeData";

// Dynamic import packages
const Layout = dynamic(() =>
  import("@common/Layout").then((mod) => mod.Layout)
);

function Attendance(props) {
  //** Language translation hooks */
  const { t } = useTranslation();
  //SnackBar
  const { enqueueSnackbar } = useSnackbar();
  /** props - actions */
  const { teamAttendanceLogList, teamAttendanceList, teamRoasterList } = props;
  /** props - states */
  const { result, count, attendanceCount, dailyAttendance, teamRoasterCount } =
    props;
  const pageNumber = Math.ceil(count / 10);
  //** useState hooks */
  const [cardView, setCardView] = useState(false);
  const [tableView, setTableView] = useState(true);
  const [jobListPage, setJobListPage] = useState(1);
  const [employee, setEmployee] = useState([]);

  /** useEffect hooks */
  useEffect(() => {
    const attendanceList = async () => {
      await teamAttendanceLogList({
        page: jobListPage,
        page_size: 12,
      });
    };
    //** team attendance count */
    const teamCount = async () => {
      await teamAttendanceList();
    };
    //** team total employee count */
    const totalEmployeeCount = async () => {
      await teamRoasterList({ job_status: "current" });
    };
    try {
      attendanceList();
      teamCount();
      totalEmployeeCount();
    } catch (error: any) {
      enqueueSnackbar(error.toString(), { variant: "error" });
    }
  }, [jobListPage]);

  //** handle pagination */
  const handlePagination = (page: any) => {
    setJobListPage(page);
  };

  //** teams data  */
  const teamsData = [
    {
      icon: <TotalCandidates sx={{ fontSize: "30px" }} />,
      title: `${t("office_management_team_attendance_summarycard_title1")}`,
      count: teamRoasterCount,
      tooltipStatus: false,
    },
    {
      icon: <EmployeePresent sx={{ fontSize: "30px" }} />,
      title: `${t("office_management_team_attendance_summarycard_title2")}`,
      count: dailyAttendance[0]?.present_employee
        ? dailyAttendance[0]?.present_employee
        : 0,
      tooltipStatus: true,
    },
    {
      icon: <EmployeeOnLeave sx={{ fontSize: "30px" }} />,
      title: `${t("office_management_team_attendance_summarycard_title3")}`,
      count: dailyAttendance[0]?.employee_on_leave
        ? dailyAttendance[0]?.employee_on_leave
        : 0,
      tooltipStatus: true,
    },
  ];

  console.log(teamRoasterCount, "check tecam roaster count");

  return (
    <Layout companyName="StrongArm" ogTitle="Dashboard | SecondOffice">
      <Typography component="h3" variant="h3" paddingBottom={3.5}>
        {/* {t("office_management_attendance_title")} */}
      </Typography>

      {/* Team Roaster summary card */}
      {/* <SummaryCard cardData={teamsData} cardGridSize={4} /> */}
      {/*  */}
      <Box mt={5}>
        <Stack direction={`row`} justifyContent={`space-between`}>
          <Typography
            component="h4"
            variant="h4"
            color="primary.main"
            paddingBottom={2.5}
          >
            {/* {t("attendance_logs_title")} */}
            {t("office_management_attendance_title")}
          </Typography>
          {/*  card view and table view icons */}
          <Box display={`flex`} flexDirection={`row`}>
            {cardView === true ? (
              <CardViewIconColor sx={{ cursor: "pointer", marginRight: 2 }} />
            ) : (
              <CardViewIcon
                onClick={() => {
                  setCardView(true);
                  setTableView(false);
                }}
                sx={{ cursor: "pointer", marginRight: 2 }}
              />
            )}

            {tableView === true ? (
              <TableViewIconColor sx={{ cursor: "pointer", marginRight: 2 }} />
            ) : (
              <TableViewIcon
                onClick={() => {
                  setTableView(true);
                  setCardView(false);
                }}
                sx={{ cursor: "pointer", marginRight: 2 }}
              />
            )}
          </Box>
        </Stack>
        {/* card  view and Roaster view render */}
        {cardView ? (
          <Box>
            {count > 0 ? (
              <AttendanceInCardView
                attendanceData={result}
                count={count}
                pageNumber={pageNumber}
                handlePagination={handlePagination}
              />
            ) : (
              <NoOfficeData
                title={`${t("attendance_empty_screen_title")}`}
                imgName="Illust-4"
              />
            )}
          </Box>
        ) : (
          <AttendanceLog />
        )}
      </Box>
    </Layout>
  );
}

const mapStateToProps = (state: RootState) => ({
  result: state.attendanceLog.results,
  teamRoasterCount: state.roaster.count,
  count: state.attendanceLog.count,
  //** attendance count */
  attendanceCount: state.attendanceLog.teamAttendanceCount,
  dailyAttendance: state.attendanceLog.teamAttendance,
});

const mapDispatchToProps = (dispatch: Dispatch) => {
  return {
    teamAttendanceLogList: (params: any) =>
      teamAttendanceLogList(dispatch, params),
    teamAttendanceList: (params: any) =>
      teamAttendanceCountList(dispatch, params),
    teamRoasterList: (params: any) => teamRoasterList(dispatch, params),
  };
};

export default connect(mapStateToProps, mapDispatchToProps)(Attendance);
