// React, Next packages
import React from "react";
import dynamic from "next/dynamic";
import Link from "next/link";
// Mui packages
import { Box } from "@mui/material";
// custom Component
import TeamPerformance from "features/officeManagement/TeamPerformance";
// Dynamic import packages
const Layout = dynamic(() =>
  import("@common/Layout").then((mod) => mod.Layout)
);

function performance() {
  return (
    <Layout companyName="StrongArm" ogTitle="Dashboard | SecondOffice">
      <Box>
        <TeamPerformance />
      </Box>
    </Layout>
  );
}

export default performance;
