// React, Next packages
import React, { useEffect, useState } from "react";
import dynamic from "next/dynamic";
import Link from "next/link";

// Mui packages
import { styled } from "@mui/material";
import TeamRoaster from "features/officeManagement/TeamRoaster";
import TeamPerformance from "features/officeManagement/TeamPerformance";

// Dynamic import packages
const Layout = dynamic(() =>
  import("@common/Layout").then((mod) => mod.Layout)
);

const CustomContainer = styled("div")(({ theme }) => ({
  display: "flex",
  flexDirection: "column",
  marginTop: "50px",
}));

function officeManagement(props: any) {
  return (
    <Layout companyName="StrongArm" ogTitle="Dashboard | SecondOffice">
      <TeamRoaster />
      <CustomContainer>
        <TeamPerformance />
      </CustomContainer>
    </Layout>
  );
}

export default officeManagement;
