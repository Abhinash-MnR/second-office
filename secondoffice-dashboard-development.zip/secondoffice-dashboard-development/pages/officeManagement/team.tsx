// React, Next packages
import React, { useEffect, useState } from "react";
import dynamic from "next/dynamic";
import Link from "next/link";
import { connect } from "react-redux";
import { Dispatch } from "redux";
// Mui packages
import { Box, Stack, Typography } from "@mui/material";
// Third party packages
import { useTranslation } from "react-i18next";
import "translation/i18n";
import { useSnackbar } from "notistack";
// custom Component
import { RootState } from "reducers";
import { teamRoasterList } from "@reducers/teamRoasterSlice";
import { teamExpectedNewJoinersList } from "@reducers/teamExpectedNewJoinersSlice";
import TeamRoaster from "features/officeManagement/TeamRoaster";
import ExpectedNewJoiners from "features/officeManagement/ExpectedNewJoiners";
import HistoricEmployee from "features/officeManagement/HistoricEmployee";
import SummaryCard from "@common/SummaryCard";
import {
  CardViewIcon,
  CardViewIconColor,
  ExpectedJoiners,
  FormerEmployee,
  TableViewIcon,
  TableViewIconColor,
  TotalEmployees,
} from "@common/Icon";
import TeamRoasterInCardView from "features/officeManagement/TeamRoasterInCardView";
import ExpectedNewJoinersInCardView from "features/officeManagement/ExpectedNewJoinersInCardView";
import CardViewHistoricEmployee from "features/officeManagement/CardViewHistoricEmployee";
import { historicTeamRoasterList } from "@reducers/historicTeamRoasterSlice";
import NoOfficeData from "features/officeManagement/NoOfficeData";

// Dynamic import packages
const Layout = dynamic(() =>
  import("@common/Layout").then((mod) => mod.Layout)
);

function Team(props) {
  //** Language translation hooks */
  const { t } = useTranslation();
  /** props - actions */
  const { teamRoasterList, teamExpectedNewJoinersList, employeeHistory } =
    props;
  /** props - states */
  const {
    result,
    count,
    newJoinersCount,
    newJoinersResult,
    employeeHistoryCount,
    employeeHistoryResult,
  } = props;
  //** page size */
  const pageNumber = Math.ceil(count / 8);

  //** useState hooks */
  const [cardView, setCardView] = useState(false);
  const [tableView, setTableView] = useState(true);
  const [jobListPage, setJobListPage] = useState(1);
  //SnackBar
  const { enqueueSnackbar } = useSnackbar();
  /** useEffect hooks */
  useEffect(() => {
    const roaster = async () => {
      await teamRoasterList({
        page: jobListPage,
        page_size: 8,
        job_status: "current",
      });
    };
    //** expected new joiners list action */
    const expectedNewJoinList = async () => {
      await teamExpectedNewJoinersList();
    };
    //** employee history list action */
    const historyEmployeeList = async () => {
      await employeeHistory({
        page: jobListPage,
        page_size: 8,
        job_status: "history",
      });
    };
    try {
      roaster();
      expectedNewJoinList();
      historyEmployeeList();
    } catch (error: any) {
      enqueueSnackbar(error.toString(), { variant: "error" });
    }
  }, [jobListPage]);

  //** handle pagination */
  const handlePagination = (page: any) => {
    setJobListPage(page);
  };

  //** teams data  */
  const teamsData = [
    {
      icon: <TotalEmployees sx={{ fontSize: "30px" }} />,
      title: `${t("office_management_team_summarycard_title1")}`,
      count: count,
    },
    {
      icon: <ExpectedJoiners sx={{ fontSize: "30px" }} />,
      title: `${t("office_management_team_summarycard_title2")}`,
      count: newJoinersCount,
    },
    {
      icon: <FormerEmployee sx={{ fontSize: "30px" }} />,
      title: `${t("office_management_team_summarycard_title3")}`,
      count: employeeHistoryCount,
    },
  ];
  return (
    <Layout companyName="StrongArm" ogTitle="Dashboard | SecondOffice">
      <Typography component="h3" variant="h3" paddingBottom={3.5}>
        {t("office_management_team_title")}
      </Typography>

      {/* Team Roaster summary card */}
      <SummaryCard cardData={teamsData} cardGridSize={4} />
      <Box mt={5}>
        <Stack direction={`row`} justifyContent={`space-between`}>
          <Typography
            component="h4"
            variant="h4"
            color="primary.main"
            paddingBottom={2.5}
          >
            {t("office_management_team_roaster_title")}
          </Typography>
          {/* <Box display={`flex`} flexDirection={`row`}>
            <CardViewIconColor
              onClick={() => setCardView(true)}
              sx={{ cursor: "pointer", marginRight: 2 }}
            />

            <TableViewIconColor
              onClick={() => setCardView(false)}
              sx={{ cursor: "pointer", marginRight: 2 }}
            />
          </Box> */}
          {/*  card view and table view icons */}
          <Box display={`flex`} flexDirection={`row`}>
            {cardView === true ? (
              <CardViewIconColor sx={{ cursor: "pointer", marginRight: 2 }} />
            ) : (
              <CardViewIcon
                onClick={() => {
                  setCardView(true);
                  setTableView(false);
                }}
                sx={{ cursor: "pointer", marginRight: 2 }}
              />
            )}

            {tableView === true ? (
              <TableViewIconColor sx={{ cursor: "pointer", marginRight: 2 }} />
            ) : (
              <TableViewIcon
                onClick={() => {
                  setTableView(true);
                  setCardView(false);
                }}
                sx={{ cursor: "pointer", marginRight: 2 }}
              />
            )}
          </Box>
        </Stack>
        {/* card  view and Roaster view render */}
        {cardView ? (
          <Box>
            {count > 0 ? (
              <TeamRoasterInCardView
                teamRoaster={result}
                count={count}
                cardView={cardView}
                pageNumber={pageNumber}
                handlePagination={handlePagination}
              />
            ) : (
              <NoOfficeData
                title={`${t("teamRoaster_empty_screen_title")}`}
                imgName="Illust-2"
              />
            )}
          </Box>
        ) : (
          <TeamRoaster />
        )}
      </Box>
      <Box>
        <Typography
          component="h4"
          variant="h4"
          paddingBottom={3.5}
          marginTop={5}
          color="primary.main"
        >
          {t("office_management_expected_newjoiners_title")}
        </Typography>
        {/* expected new joiners render in card view */}
        {cardView ? (
          <Box>
            {newJoinersCount > 0 ? (
              <ExpectedNewJoinersInCardView
                newJoinerList={newJoinersResult}
                count={newJoinersCount}
                pageNumber={pageNumber}
                handlePagination={handlePagination}
              />
            ) : (
              <NoOfficeData
                title={`${t("expectedJoiners_empty_screen_title")}`}
                imgName="Illust-2"
              />
            )}
          </Box>
        ) : (
          <ExpectedNewJoiners />
        )}
      </Box>
      <Box>
        <Typography
          component="h4"
          variant="h4"
          paddingBottom={3.5}
          marginTop={5}
          color="primary.main"
        >
          {t("office_management_historic_emp_title")}
        </Typography>
        {/* Historic Employee render in card view */}
        {cardView ? (
          <Box>
            {employeeHistoryCount > 0 ? (
              <CardViewHistoricEmployee
                exEmployee={employeeHistoryResult}
                count={employeeHistoryCount}
                pageNumber={pageNumber}
                handlePagination={handlePagination}
              />
            ) : (
              <NoOfficeData
                title={`${t("formerEmployee_empty_screen_title")}`}
                imgName="Illust-2"
              />
            )}
          </Box>
        ) : (
          <HistoricEmployee />
        )}
      </Box>
    </Layout>
  );
}

const mapStateToProps = (state: RootState) => ({
  result: state.roaster.results,
  count: state.roaster.count,
  newJoinersCount: state.newJoiners.count,
  newJoinersResult: state.newJoiners.results,
  employeeHistoryCount: state.historicRoaster.count,
  employeeHistoryResult: state.historicRoaster.results,
});

const mapDispatchToProps = (dispatch: Dispatch) => {
  return {
    teamRoasterList: (params: any) => teamRoasterList(dispatch, params),
    teamExpectedNewJoinersList: (params: any) =>
      teamExpectedNewJoinersList(dispatch, params),
    employeeHistory: (params: any) => historicTeamRoasterList(dispatch, params),
  };
};
export default connect(mapStateToProps, mapDispatchToProps)(Team);
