// React, Next packages
import React from "react";
import dynamic from "next/dynamic";
import router from "next/router";
// MUI Packages
import { Box } from "@mui/material";
// Custom Component
import JobsList from "features/applications/JobsList";

import SummaryCard from "@common/SummaryCard";

// Dynamic import packages
const Layout = dynamic(() =>
  import("@common/Layout").then((mod) => mod.Layout)
);

function jobsListPage() {
  return (
    <Layout companyName="StrongArm" ogTitle="Dashboard | SecondOffice">
      {/* [FAQ Button] */}
      <Box
        sx={{
          position: "fixed",
          right: 48,
          bottom: 48,
          cursor: "pointer",
          zIndex: 9999,
        }}
        onClick={() =>
          router.push("/help_center/post-a-job-to-recruit-your-team")
        }
      >
        <img
          src="/svg/helpCenterFloatingButton.svg"
          alt="helpCenterFloatingButton"
          style={{ height: 56, width: 56 }}
        />
      </Box>

      {/* Parent Component */}
      <JobsList />
    </Layout>
  );
}

export default jobsListPage;
