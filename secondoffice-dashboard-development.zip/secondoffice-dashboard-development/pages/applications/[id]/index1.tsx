// React, Next packages
import React, { useEffect, useState } from "react";
import { Dispatch } from "redux";
import { connect } from "react-redux";
import { RootState } from "reducers";
import dynamic from "next/dynamic";
import Link from "next/link";
// Mui packages
import {
  Box,
  Grid,
  Typography,
  styled,
  Stack,
  Tooltip,
  IconButton,
  Select,
  MenuItem,
  Button,
  useMediaQuery,
  Pagination,
  TableCell,
} from "@mui/material";
// Third-party packages
import { useSnackbar } from "notistack";
import { createTheme, MuiThemeProvider } from "@material-ui/core/styles";
import { useRouter } from "next/router";
import { useTranslation } from "react-i18next";
import "translation/i18n";
// Custom Component
import { fetchJob } from "reducers/jobsSlice";
import {
  clearApplications,
  editApplication,
  listApplication,
} from "reducers/applicationsSlice";
import {
  BackIcon,
  ToolTipIconColor,
  FilterIcon,
  ViewColumnIcon,
  SearchIcon,
} from "@common/Icon";
import ReadMore from "@common/ReadMore";
import AllApplicants from "features/applications/AllApplicants";
// Import the chip component frfom Material UI or a
// custom component of your choosing:
import Chip from "@material-ui/core/Chip";
// Import the TableFilterList from mui-datatables:
import MUIDataTable, {
  MUIDataTableMeta,
  TableFilterList,
} from "mui-datatables";
import JobsApplicantActions from "features/applications/JobsApplicantActions";
import useCompany from "@lib/useCompany";
import useCurrency from "@lib/useCurrency";
import { capitalize } from "lodash";
import moment from "moment";
import NoOfficeData from "features/officeManagement/NoOfficeData";

// Dynamic import packages
const Layout = dynamic(() =>
  import("@common/Layout").then((mod) => mod.Layout)
);

const AplicationContainer = styled("div")(({ theme }) => ({
  display: "flex",
  flexDirection: "column",
}));

const JobsTitle = styled("div")(({ theme }) => ({
  display: "flex",
  flexDirection: "row",
  alignItems: "center",
}));

const JobsTitleSecond = styled("div")(({ theme }) => ({
  display: "flex",
  flexDirection: "row",
  color: "#2c3058",
  fontSize: 18,
  lineHeight: "150%",
  fontWeight: 700,
  marginTop: 15,
  marginBottom: 30,
  alignItems: "center",
  [theme.breakpoints.down("sm")]: {
    display: "flex",
    fontSize: 14,
  },
}));

const CustomTableHead = styled("th")(({ theme }) => ({
  fontSize: 14,
  lineHeight: 1.5,
  fontWeight: 700,
  color: "#222222",
  minWidth: "170px",
  paddingLeft: 16,
  textAlign: "left",
}));

const SubContainer = styled("div")(({ theme }) => ({
  display: "flex",
  flexDirection: "row",
  margin: "45px 0px 20px 0px",
}));
function AplicationList(props: any) {
  //** Language translation hooks */
  const { t } = useTranslation();

  /** props - actions */
  const { fetchJob } = props;
  /** props - states */
  const [job, setJob] = useState<any>();
  const [jobSkills, setJobSkills] = useState();
  const [index, setIndex] = useState<any>();

  /** third-party hooks */
  const isMobile = useMediaQuery("(max-width:600px)");
  useCompany({ redirectTo: "/" });
  const { enqueueSnackbar } = useSnackbar();
  const router = useRouter();
  const { job_title, is_open } = router.query;

  /** props - states */
  const { jobs } = props;

  const [value, setValue] = React.useState("1");

  const handleChange = (event: React.SyntheticEvent, newValue: string) => {
    setValue(newValue);
  };

  // Convert number with commas
  const numberWithCommas = (x: string) => {
    return x.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",");
  };

  /** third-party hooks */
  const { company } = useCompany({
    redirectTo: "/",
  });

  const { currency } = useCurrency();

  /** class variables */
  const { job_post, jobTitle, application_status, userId } = router.query;

  /** props - actions */
  const { clearApplications, editApplication, listApplication } = props;
  /** props - states */
  const { applications, applicationsNext, applicationsLength } = props;

  /** useState hooks */
  const [isUpdating, setIsUpdating] = useState(false);

  // Total page number
  const pageNumber = Math.ceil(applicationsLength / 9);

  const [jobApplicantPage, setJobApplicantPage] = useState(1);

  const [isActionSelected, setIsActionSelected] = useState("");

  const [data, setData] = useState();

  /** useEffect hooks */
  useEffect(() => {
    const initializeApplicationList = async () => {
      clearApplications();
      await listApplication({
        ...router.query,
        page: jobApplicantPage,
        page_size: 9,
        // applicant_status: "pending",
        job_post: location.href.split("/")[4],
      });
    };
    try {
      initializeApplicationList();
    } catch (error) {
      console.log(error);
    }
  }, [jobApplicantPage]);

  useEffect(() => {
    setData(
      applications.map((row, index) => [
        row.applicant_name,
        row?.applicant_notice_period ? `${row?.applicant_notice_period}` : "",
        row?.year_of_experience ? `${row?.year_of_experience} Years` : "",
        (company && currency && company.currency === "KRW"
          ? "₩"
          : company && currency && company.currency === "USD"
          ? "$"
          : company && currency && company.currency === "EUR"
          ? "€"
          : "₹") +
          (company && currency && company.currency === "KRW"
            ? numberWithCommas((row?.cTC * currency.currency_krw).toFixed(2))
            : company && currency && company.currency === "USD"
            ? numberWithCommas(
                ((row?.cTC * currency.currency_usd) / 1000).toFixed(2)
              )
            : company && currency && company.currency === "EUR"
            ? numberWithCommas(
                ((row?.cTC * currency.currency_eur) / 1000).toFixed(2)
              )
            : numberWithCommas((row?.cTC / 100000).toFixed(2))) +
          (company && currency && company.currency === "KRW"
            ? ""
            : company && currency && company.currency === "USD"
            ? " K"
            : company && currency && company.currency === "EUR"
            ? "K"
            : " LPA"),
        (company && currency && company.currency === "KRW"
          ? "₩"
          : company && currency && company.currency === "USD"
          ? "$"
          : company && currency && company.currency === "EUR"
          ? "€"
          : "₹") +
          (company && currency && company.currency === "KRW"
            ? numberWithCommas((row?.eCTC * currency.currency_krw).toFixed(2))
            : company && currency && company.currency === "USD"
            ? numberWithCommas(
                ((row?.eCTC * currency.currency_usd) / 1000).toFixed(2)
              )
            : company && currency && company.currency === "EUR"
            ? numberWithCommas(
                ((row?.eCTC * currency.currency_eur) / 1000).toFixed(2)
              )
            : numberWithCommas((row?.eCTC / 100000).toFixed(2))) +
          (company && currency && company.currency === "KRW"
            ? ""
            : company && currency && company.currency === "USD"
            ? " K"
            : company && currency && company.currency === "EUR"
            ? "K"
            : " LPA"),
        row?.applicant_resume
          ? [row?.applicant_resume, row?.applicant_portfolio]
          : "",
        row?.cvr_status === "priority_2"
          ? "Pending"
          : row?.cvr_status === "na"
          ? "Pending"
          : capitalize(row?.cvr_status),
        row?.additional_comments,
        row?.technical_round,
        row?.applicant_actions,
        row?.applicant_status
          ? row?.applicant_status === "pending"
            ? "Resume Review"
            : `${humanize(row?.applicant_status)}`
          : "",
        row?.offer_date === null
          ? "-"
          : moment(row?.offer_date).format("MMMM DD, YYYY hh:mm A"),
      ])
    );
  }, [applications]);

  /** custom handlers */
  const handleApplicantAction = async (id: any, applicantStatus: String) => {
    setIsUpdating(true);
    try {
      await editApplication(id, { applicant_status: applicantStatus });
      if (applicantStatus === "accepted") {
        enqueueSnackbar("Applicant Accepted successfully.", {
          variant: "info",
        });
      } else if (applicantStatus === "rejected") {
        enqueueSnackbar("Applicant Rejected Successfully.", {
          variant: "info",
        });
      }
      setIsActionSelected(id);
      setIsUpdating(false);
    } catch (error: any) {
      enqueueSnackbar(`Error: ${error.toString()}`, {
        variant: "error",
      });
    } finally {
      setIsUpdating(false);
    }
  };

  useEffect(() => {
    console.log("applications:-", applications);
  }, [applications]);

  useEffect(() => {
    const initializeApplicationList = async () => {
      clearApplications();
      await listApplication({
        ...router.query,
        page: 1,
        page_size: 9,
        // applicant_status: "pending",
        job_post: location.href.split("/")[4],
      });
    };
    try {
      setTimeout(() => {
        initializeApplicationList();
      }, 30);
    } catch (error) {
      console.log(error);
    }
  }, [isActionSelected]);

  const handleClick = async (userId: string) => {
    router.push(
      {
        pathname: location.pathname,
        query: {
          ...router.query,
          userId: userId,
        },
      },
      undefined,
      { shallow: true }
    );
  };

  const handleClose = () => {
    const newQuery = { ...router.query };
    delete newQuery.userId;

    router.push(
      {
        pathname: location.pathname,
        query: newQuery,
      },
      undefined,
      { shallow: true }
    );
  };

  function humanize(str: string) {
    var i,
      frags = str?.split("_");
    for (i = 0; i < frags?.length; i++) {
      frags[i] = frags[i]?.charAt(0)?.toUpperCase() + frags[i]?.slice(1);
    }
    return frags?.join(" ");
  }

  const handleLoadApplications = async () => {
    await listApplication({ ...router.query, page: applicationsNext });
  };

  // const handleChange = (event: SelectChangeEvent) => {
  //   console.log("menu slected");
  // };

  console.log("applications: ", applications);

  /** useEffect hooks */
  useEffect(() => {
    const initializeJob = async () => {
      await fetchJob(location.href.split("/")[4]);
    };

    try {
      initializeJob();
    } catch (error: any) {
      enqueueSnackbar(error.toString(), { variant: "error" });
    }
  }, []);

  useEffect(() => {
    for (var i = 0; i < jobs.length; i++) {
      if (jobs[i].id === location.href.split("/")[4]) {
        setJob(jobs[i]);
        setIndex(i);
        setJobSkills(jobs[i].job_skills);
      }
    }
    // console.log(navObj("applicant_name: ",jobs, 'applicant_name', -1))
  }, [jobs]);
  const columns = [
    {
      name: `${t("view_candidates_table_head_candidate")}`,
      options: {
        filter: false,
        sort: false,
        customHeadRender: (columnMeta, updateDirection) => {
          return (
            <Box sx={{ width: "120px", display: "contents" }}>
              <CustomTableHead key={1}>{columnMeta.name}</CustomTableHead>
            </Box>
          );
        },
      },
    },
    {
      name: `${t("view_candidates_table_head_notice")}`,
      options: {
        filter: false,
        sort: false,
        customHeadRender: (columnMeta, updateDirection) => {
          return (
            <Box sx={{ width: "120px", display: "contents" }}>
              <CustomTableHead key={2}>
                <Typography component={`span`} variant="button">
                  {columnMeta.name}
                </Typography>
                <Tooltip
                  title="It is the period between receiving the letter of dismissal and the end of the last working day."
                  arrow
                  enterTouchDelay={0}
                >
                  <IconButton aria-label="hr_actions">
                    <ToolTipIconColor />
                  </IconButton>
                </Tooltip>
              </CustomTableHead>
            </Box>
          );
        },
      },
    },
    {
      name: `${t("view_candidates_table_head_exp")}`,
      options: {
        filter: false,
        sort: false,
        customHeadRender: (columnMeta, updateDirection) => {
          return (
            <Box sx={{ width: "120px", display: "contents" }}>
              <CustomTableHead key={3}>{columnMeta.name}</CustomTableHead>
            </Box>
          );
        },
      },
    },
    {
      name: `${t("view_candidates_table_head_ctc")}`,
      options: {
        filter: false,
        sort: false,
        customHeadRender: (columnMeta, updateDirection) => {
          return (
            <Box sx={{ width: "120px", display: "contents" }}>
              <CustomTableHead key={4}>
                <Typography component={`span`} variant="button">
                  {columnMeta.name}
                </Typography>
                <Tooltip
                  title="It is the cost a company incurs when hiring an employee, and includes all monthly components such as basic pay, reimbursements, various allowances, etc."
                  arrow
                  enterTouchDelay={0}
                >
                  <IconButton aria-label="hr_actions">
                    <ToolTipIconColor />
                  </IconButton>
                </Tooltip>
              </CustomTableHead>
            </Box>
          );
        },
      },
    },
    {
      name: `${t("view_candidates_table_head_ectc")}`,
      options: {
        filter: false,
        sort: false,
        customHeadRender: (columnMeta, updateDirection) => {
          return (
            <Box sx={{ width: "120px", display: "contents" }}>
              <CustomTableHead key={5}>
                <Typography component={`span`} variant="button">
                  {columnMeta.name}
                </Typography>
                <Tooltip
                  title="It is a term used to understand
                    what a candidate is expecting
                    from the organization in terms of
                    their all-inclusive CTC."
                  arrow
                  enterTouchDelay={0}
                >
                  <IconButton aria-label="hr_actions">
                    <ToolTipIconColor />
                  </IconButton>
                </Tooltip>
              </CustomTableHead>
            </Box>
          );
        },
      },
    },
    {
      name: `${t("view_candidates_table_head_resume")}`,
      options: {
        filter: false,
        sort: false,
        customBodyRender: (value, tableMeta) => (
          <>
            {/* onClick={(event) => this.handleTooltipOpen(event, tableMeta, tableMeta.rowData)}> */}
            <Link href={value[0]}>
              <a target="_blank">
                <Typography variant="subtitle2" color="primary.main">
                  {"View Resume"}
                </Typography>
              </a>
            </Link>
            {value[1] !== "" ? (
              <Link href={value[1]}>
                <a target="_blank">
                  <Typography variant="subtitle2" color="primary.main">
                    {"View Portfolio"}
                  </Typography>
                </a>
              </Link>
            ) : (
              <Typography
                variant="subtitle2"
                sx={{
                  color: "#2c3058",
                  opacity: 0.8,
                }}
              >
                {"View Portfolio"}
              </Typography>
            )}
          </>
        ),
        customHeadRender: (columnMeta, updateDirection) => {
          return (
            <Box sx={{ width: "120px", display: "contents" }}>
              <CustomTableHead key={5}>{columnMeta.name}</CustomTableHead>
            </Box>
          );
        },
      },
    },
    {
      name: `${t("view_candidates_table_head_cultural")}`,
      options: {
        filter: false,
        sort: false,
        customBodyRender: (value) => {
          switch (value) {
            case "Pass":
              return (
                <Chip
                  style={{
                    padding: "5px 10px",
                    borderColor: "#54D62C",
                    borderRadius: "18px",
                    backgroundColor: "#EDFDDB",
                    color: "#54D62C",
                    fontWeight: 700,
                  }}
                  variant="outlined"
                  label={value}
                />
              );
              break;
            case "Fail":
              return (
                <Chip
                  style={{
                    padding: "5px 10px",
                    borderColor: "#EC0C0C",
                    borderRadius: "18px",
                    backgroundColor: "#FFEFE5",
                    color: "#EC0C0C",
                    fontWeight: 700,
                  }}
                  variant="outlined"
                  label={value}
                />
              );
              break;
            default:
              return (
                <Chip
                  style={{
                    padding: "5px 10px",
                    borderColor: "#2C3058",
                    borderRadius: "18px",
                    backgroundColor: "#FFFFFF",
                    color: "#2C3058",
                    fontWeight: 700,
                  }}
                  variant="outlined"
                  label={value}
                />
              );
          }
        },
        customHeadRender: (columnMeta, updateDirection) => {
          return (
            <Box sx={{ width: "120px", display: "contents" }}>
              <CustomTableHead key={6}>
                <Typography component={`span`} variant="button">
                  {columnMeta.name}
                </Typography>
                <Tooltip
                  title="The operations team can either shortlist or reject a candidate, post which, you can check the Cultural Round here. No further action will be possible."
                  arrow
                  enterTouchDelay={0}
                >
                  <IconButton aria-label="hr_actions">
                    <ToolTipIconColor />
                  </IconButton>
                </Tooltip>
              </CustomTableHead>
            </Box>
          );
        },
      },
    },
    {
      name: `${t("view_candidates_table_head_commnets")}`,
      options: {
        filter: false,
        sort: false,
        customBodyRender: (value) => {
          return (
            <Box>
              {value.length > 30 ? (
                <ReadMore sliceTextLength="30">{value}</ReadMore>
              ) : (
                <Typography component="p" variant="body2">
                  {value}
                </Typography>
              )}
            </Box>
          );
        },
        customHeadRender: (columnMeta, updateDirection) => {
          return (
            <Box sx={{ width: "120px", display: "contents" }}>
              <CustomTableHead key={7}>{columnMeta.name}</CustomTableHead>
            </Box>
          );
        },
      },
    },
    {
      name: `${t("view_candidates_table_head_technical")}`,
      options: {
        filter: false,
        sort: false,
        customBodyRender: (value) => {
          return (
            <Box>
              {value.length > 30 ? (
                <ReadMore sliceTextLength="30">{value}</ReadMore>
              ) : (
                <Typography component="p" variant="body2">
                  {value}
                </Typography>
              )}
            </Box>
          );
        },
        customHeadRender: (columnMeta, updateDirection) => {
          return (
            <Box>
              <CustomTableHead key={8}>{columnMeta.name}</CustomTableHead>
            </Box>
          );
        },
      },
    },
    {
      name: `${t("view_candidates_table_head_action")}`,
      options: {
        filter: false,
        sort: false,
        customBodyRender: (
          value: any,
          rowData,
          tableMeta: MUIDataTableMeta,
          updateValue: (value: string) => void
        ) => {
          console.log(applications[rowData?.rowIndex]?.id, "hi vicky");
          return (
            <JobsApplicantActions
              cvrStatus={rowData?.rowData[6]}
              status={value}
              applicationId={applications[rowData?.rowIndex]?.id}
            />
          );
        },
        customHeadRender: (columnMeta, updateDirection) => {
          return (
            <Box sx={{ width: "120px", display: "contents" }}>
              <CustomTableHead key={9}>
                <Typography component={`span`} variant="button">
                  {columnMeta.name}
                </Typography>
                <Tooltip
                  title="You can shortlist or reject a candidate from the dropdown list in the column. Note: If the Cultural Round shows that the candidate has been rejected, no further action can be taken here."
                  arrow
                  enterTouchDelay={0}
                >
                  <IconButton aria-label="hr_actions">
                    <ToolTipIconColor />
                  </IconButton>
                </Tooltip>
              </CustomTableHead>
            </Box>
          );
        },
      },
    },
    {
      name: `${t("view_candidates_table_head_status")}`,
      options: {
        filter: true,
        sort: false,
        customHeadRender: (columnMeta, updateDirection) => {
          return (
            <CustomTableHead key={10}>
              <Typography component={`span`} variant="button">
                {columnMeta.name}
              </Typography>
              <Tooltip
                title="The status of the candidate will be visible here after recruiter chooses the appropriate action such as 'shortlist', 'pending', 'client review', 'offer made', 'withdrew application', and more."
                arrow
                enterTouchDelay={0}
              >
                <IconButton aria-label="hr_actions">
                  <ToolTipIconColor />
                </IconButton>
              </Tooltip>
            </CustomTableHead>
          );
        },
      },
    },
    {
      name: "Offered Date",
      options: {
        filter: false,
        sort: false,
        customHeadRender: (columnMeta, updateDirection) => {
          return (
            <Box sx={{ width: "200px", textAlign: "center" }}>
              <CustomTableHead key={11}>{columnMeta.name}</CustomTableHead>
            </Box>
          );
        },
      },
    },
  ];
  const navObj = (obj, currentKey, direction) => {
    return Object.values(obj)[Object.keys(obj).indexOf(currentKey) + direction];
  };
  const CustomTooltip = ({ children, ...props }) => {
    return (
      <Tooltip
        title="It is the period between receiving the letter of dismissal and the end of the last working day."
        arrow
        enterTouchDelay={0}
      >
        <IconButton aria-label="hr_actions">
          <ToolTipIconColor />
        </IconButton>
      </Tooltip>
    );
  };
  const options = {
    textLabels: {
      body: {
        noMatch: "",
      },
    },
    setRowProps: (row: any) => {
      switch (row[10]) {
        case "Online Technical Assessment":
        case "Cultural Round":
        case "Client Review":
        case "Client Round":
        case "Shortlisted":
        case "Technical Round":
          return {
            style: {
              "&:last-child td, &:last-child th": { border: 0 },
              backgroundColor: "#FFF7CD",
              borderLeft: "4px solid #DFA718",
              width: "100%",
            },
          };
          break;
        case "Rejected":
        case "Withdrew Application":
          return {
            style: {
              "&:last-child td, &:last-child th": { border: 0 },
              backgroundColor: "#FFE7D9",
              borderLeft: "4px solid #EC0C0C",
              width: "100%",
            },
          };
          break;
        case "Reconsideration":
          return {
            style: {
              "&:last-child td, &:last-child th": { border: 0 },
              backgroundColor: "#FFE7D9",
              borderLeft: "4px solid #EC0C0C",
            },
          };
          break;
        case "Offer Made":
          return {
            style: {
              "&:last-child td, &:last-child th": { border: 0 },
              backgroundColor: "#D6F4FF",
              borderLeft: "4px solid #00B8FF",
              width: "100%",
            },
          };
          break;
        case "Hired":
          return {
            style: {
              "&:last-child td, &:last-child th": { border: 0 },
              backgroundColor: "#E4FCCA",
              borderLeft: "4px solid #54D62C",
            },
          };
          break;
        case "Hired":
          return {
            style: {
              "&:last-child td, &:last-child th": { border: 0 },
              backgroundColor: "#E4FCCA",
              borderLeft: "4px solid #54D62C",
            },
          };
          break;
        default:
          if (row[6].props.label === "Fail") {
            return {
              style: {
                "&:last-child td, &:last-child th": { border: 0 },
                backgroundColor: "#FFE7D9",
                borderLeft: "4px solid #EC0C0C",
              },
            };
          } else {
            return {
              style: {
                "&:last-child td, &:last-child th": { border: 0 },
                backgroundColor: "#FFFFFF",
              },
            };
          }
      }
    },
    sort: true,
    filter: true,
    filterType: "checkbox",
    download: false,
    print: false,
    // viewColumns: false,
    selectableRows: false,
    // info: false,
    // ordering: false,
    responsive: "vertical",
    pagination: false,
    elevation: 0,
    labelDisplayedRows: {},
  };
  const getMuiTheme = () =>
    createTheme({
      overrides: {
        MuiChip: {
          root: {
            backgroundColor: "#ECEDF4",
            color: "#222222",
          },
        },
      },
    });

  const CustomTooltip1 = ({ children, ...props }) => {
    return (
      <Tooltip
        {...props}
        title={props.title === "Filter Table" ? "Filter" : props.title}
      >
        {children}
      </Tooltip>
    );
  };
  // Here is the custom chip component. For this example, we are
  // using the outlined chip from Material UI:
  const CustomChip = ({ label, onDelete }) => {
    return (
      <Chip color="default" label={label} onDelete={onDelete} />
      // <Chip
      //     variant="outlined"
      //     color="secondary"
      //     label={label}
      //     onDelete={onDelete}
      // />
    );
  };

  // Here is the custom filter list component that will display
  // the custom filter chips:
  const CustomFilterList = (props) => {
    return <TableFilterList {...props} ItemComponent={CustomChip} />;
  };

  return (
    <Layout companyName="StrongArm" ogTitle="ApplicationList | SecondOffice">
      <AplicationContainer>
        <Link href="/applications">
          <a>
            <JobsTitle>
              <Typography component="span">
                <BackIcon
                  sx={{
                    fontSize: { xs: "11px", sm: "12px" },
                    marginRight: { xs: "5px", sm: "10px" },
                    marginTop: "0.5px",
                  }}
                />
              </Typography>
              <Typography component="h6" variant="h6">
                {t("view_candiates_backIcon_title")}
              </Typography>
            </JobsTitle>
          </a>
        </Link>
        <JobsTitleSecond></JobsTitleSecond>
        <MuiThemeProvider theme={getMuiTheme()}>
          <MUIDataTable
            title={
              <JobsTitleSecond>
                <Typography component="h4" variant="h4">
                  {t("view_candidates_job_application_title")}
                </Typography>
                <Typography
                  component="h4"
                  variant="h4"
                  color="#DFA718"
                  paddingLeft={0.5}
                  paddingRight={0.5}
                >
                  {" "}
                  {job?.job_title}
                </Typography>
                <Typography component="h4" variant="h4">
                  {t("view_candidates_job_application_position_title")}
                </Typography>
              </JobsTitleSecond>
            }
            data={data}
            columns={columns}
            options={options}
            components={{
              Tooltip: CustomTooltip1,
              TableFilterList: CustomFilterList,
              // icons: {
              //   FilterIcon,
              //   ViewColumnIcon,
              //   SearchIcon,
              // },
            }}
          />
        </MuiThemeProvider>
        {/* Empty State when data not available  */}
        {applications.length > 0 ? (
          <Grid container spacing={1}>
            <Grid item xs={12}>
              <Box sx={{ display: "flex", justifyContent: "center" }}>
                <Stack
                  direction="row"
                  alignItems="center"
                  justifyContent="center"
                  paddingTop={5}
                  paddingBottom={3}
                >
                  <Pagination
                    count={pageNumber}
                    page={jobApplicantPage}
                    color="secondary"
                    onChange={(e, value) => setJobApplicantPage(value)}
                    sx={{
                      background: "#ECEDF4",
                      borderRadius: "10px",
                      padding: { xs: "5px", sm: "10px" },
                    }}
                  />
                </Stack>
              </Box>
            </Grid>
          </Grid>
        ) : null}
        <Box>
          {applications.length > 0 ? null : (
            <NoOfficeData
              title={`${t("view_candidates_emptybox_title")}`}
              imgName="Illust-5"
            />
          )}
        </Box>
      </AplicationContainer>
    </Layout>
  );
}

const mapStateToProps = (state: RootState) => ({
  jobs: state.jobs.jobs,
  applications: state.applications.applications,
  applicationsLength: state.applications.applicationsLength,
  applicationsNext: state.applications.applicationsNext,
});

const mapDispatchToProps = (dispatch: Dispatch) => {
  return {
    fetchJob: (id: string) => fetchJob(dispatch, id),
    clearApplications: () => dispatch(clearApplications()),
    editApplication: (id: string, payload: any) =>
      editApplication(dispatch, id, payload),
    listApplication: (params: any) => listApplication(dispatch, params),
  };
};

export default connect(mapStateToProps, mapDispatchToProps)(AplicationList);
