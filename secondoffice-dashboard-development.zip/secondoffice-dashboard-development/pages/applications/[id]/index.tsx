// React , Next js packages
import React, { useState, useEffect, useCallback } from "react";
import Link from "next/link";
import { Dispatch } from "redux";
import { connect } from "react-redux";
import { RootState } from "reducers";
import { useRouter } from "next/router";
// MUI Packages
import {
  Box,
  Grid,
  Stack,
  Typography,
  TextField,
  InputAdornment,
  IconButton,
} from "@mui/material";
// Third party packages
import { useTranslation } from "react-i18next";
import "translation/i18n";
// Custom components
import {
  BackIcon,
  CardViewIcon,
  CardViewIconColor,
  CloseIcon,
  FilterIcon,
  HiredCandidates,
  OfferMadeCandidates,
  ShortlistedCandidates,
  TableViewIcon,
  TableViewIconColor,
  TotalCandidates,
} from "@common/Icon";
import { Layout } from "@common/Layout";
import { fetchJob } from "reducers/jobsSlice";
import {
  HiredCandidateApplication,
  listApplication,
  offerMadeApplication,
  shortListApplication,
  listSearchApplication,
} from "reducers/applicationsSlice";
import SummaryCard from "@common/SummaryCard";
import CandidateListCard from "features/applications/CandidateListCard";
import ViewCandidateListCard from "features/applications/ViewCandidateListCard";
import ViewCandidateListTableView from "features/applications/ViewCandidateListTableView";
import NoOfficeData from "features/officeManagement/NoOfficeData";
import CardViewJobsFilter from "features/applications/CardViewJobsFilter";

function CandidateList(props) {
  //** useRouter */
  const { query } = useRouter();
  //** Language translation hooks */
  const { t } = useTranslation();
  /** props - actions */
  const {
    shortListApplication,
    listApplication,
    hiredCandidatesList,
    offeredMadeApplicationList,
    fetchJob,
    searchCandidateApplication,
  } = props;

  /** props - states */
  const {
    jobs,
    applications,
    shortListCount,
    applicationsCount,
    hiredCount,
    offerCandidateCount,
    searchResult,
    searchResultCount,
  } = props;

  //** useState hooks */
  const [cardView, setCardView] = useState(false);
  const [tableView, setTableView] = useState(true);
  const [activeTab, setActiveTab] = useState(0);
  const [searchTerm, setSearchTerm] = useState("");
  const [job, setJob] = useState<any>();
  const [data, setData] = useState(searchResult);
  const [checkBoxFilter, setCheckBoxFilter] = useState(false);
  const [filterPagi, setFilterPagi] = useState([]);
  const [jobApplicantPage, setJobApplicantPage] = useState(1);
  const [cusines, setCusines] = useState([
    {
      id: 1,
      checked: false,
      label: `${t("candidate_status_pending")}`,
      value: "pending",
    },
    {
      id: 2,
      checked: false,
      label: `${t("candidate_status_shortlisted")}`,
      value: "shortlisted",
    },
    {
      id: 3,
      checked: false,
      label: `${t("candidate_status_hired")}`,
      value: "hired",
    },
    {
      id: 4,
      checked: false,
      label: `${t("candidate_status_rejected")}`,
      value: "rejected",
    },
    {
      id: 5,
      checked: false,
      label: `${t("candidate_status_offer_made")}`,
      value: "offer_made",
    },
    {
      id: 6,
      checked: false,
      label: `${t("candidate_status_tech_round")}`,
      value: "technical_round",
    },
    {
      id: 7,
      checked: false,
      label: `${t("candidate_status_client_round")}`,
      value: "client_round",
    },
    {
      id: 8,
      checked: false,
      label: `${t("candidate_status_client_review")}`,
      value: "client_review",
    },
  ]);

  //** handle candidates */
  const handleCandidates = (tab) => {
    setActiveTab(tab);
  };

  //** handle search clear */
  const handleClear = () => {
    setSearchTerm("");
  };

  //** handle pagination */
  const handlePagination = (value) => {
    setJobApplicantPage(value);
  };

  console.log(query.id, "query data passed id");

  /** useEffect hooks */
  useEffect(() => {
    // const initializeAllApplicationList = async () => {
    //   await listApplication({ job_post: query.id, page: 1, page_size: 1000 });
    // };
    const shortListApplicationList = async () => {
      await shortListApplication({ job_post: query.id });
    };
    const hiredApplicationList = async () => {
      await hiredCandidatesList({ job_post: query.id });
    };
    const offeredCandidateList = async () => {
      await offeredMadeApplicationList({ job_post: query.id });
    };
    //** search api  */
    const initializeSearchApplicationList = async () => {
      await searchCandidateApplication({
        search: searchTerm,
        job_post: query.id,
        page: jobApplicantPage,
        page_size: 9,
      });
    };

    try {
      // initializeAllApplicationList();
      shortListApplicationList();
      hiredApplicationList();
      offeredCandidateList();
      initializeSearchApplicationList();
    } catch (error) {
      console.log(error);
    }
  }, [query.id, searchTerm, jobApplicantPage]);

  //** useEffect */
  // useEffect(() => {
  //   for (var i = 0; i < jobs.length; i++) {
  //     if (jobs[i].id === location.href.split("/")[4]) {
  //       setJob(jobs[i]);
  //       // setIndex(i);
  //       // setJobSkills(jobs[i].job_skills);
  //     }
  //   }
  //   // console.log(navObj("applicant_name: ",jobs, 'applicant_name', -1))
  // }, [jobs]);

  //** teams data  */
  const candidateData = [
    {
      icon: <TotalCandidates sx={{ fontSize: "30px" }} />,
      title: `${t("view_candidate_summary_card_tittle1")}`,
      count: applicationsCount,
    },
    {
      icon: <ShortlistedCandidates sx={{ fontSize: "30px" }} />,
      title: `${t("view_candidate_summary_card_tittle2")}`,
      count: shortListCount,
    },
    {
      icon: <OfferMadeCandidates sx={{ fontSize: "30px" }} />,
      title: `${t("view_candidate_summary_card_tittle3")}`,
      count: offerCandidateCount,
    },
    {
      icon: <HiredCandidates sx={{ fontSize: "30px" }} />,
      title: `${t("view_candidate_summary_card_tittle4")}`,
      count: hiredCount,
    },
  ];

  //** handle filter */
  const handleChangeChecked = (id) => {
    const cusinesStateList = cusines;
    const changeCheckedCusines = cusinesStateList.map((item) =>
      item.id === id ? { ...item, checked: !item.checked } : item
    );
    // setCheckBoxFilter(true);
    setCusines(changeCheckedCusines);
  };

  //** checkbox filter apply  */

  const applyFilters = () => {
    let updatedList = searchResult;

    //** checkbox filter */
    const cusineChecked = cusines
      .filter((item) => item.checked)
      .map((item) => item.value.toLowerCase());
    if (cusineChecked.length) {
      updatedList = updatedList.filter((item) =>
        cusineChecked.includes(item.applicant_status)
      );
    }
    // setFilterPagi(cusineChecked);
    if (cusineChecked.length > 0) {
      setCheckBoxFilter(true);
    } else {
      setCheckBoxFilter(false);
    }
    setData(updatedList);
  };

  //** filters data rerender on states changes */
  useEffect(() => {
    applyFilters();
  }, [searchResult, cusines, checkBoxFilter, applications]);

  return (
    <Layout companyName="StrongArm" ogTitle="ApplicationList | SecondOffice">
      {/* back icon with title */}
      <Box mb={3.75}>
        <Link href="/applications">
          <a>
            <Stack direction={`row`}>
              <Typography component="span">
                <BackIcon
                  sx={{
                    fontSize: { xs: "11px", sm: "12px" },
                    marginRight: { xs: "5px", sm: "10px" },
                    marginTop: "0.5px",
                  }}
                />
              </Typography>
              <Typography component="h6" variant="h6">
                {t("view_candiates_backIcon_title")}
              </Typography>
            </Stack>
          </a>
        </Link>
      </Box>
      {/* Jobs title */}
      {cardView === true && (
        <Box display={`flex`} mb={3.75}>
          <Typography component="h4" variant="h4">
            {t("view_candidates_job_application_title")}
          </Typography>
          <Typography
            component="h4"
            variant="h4"
            color="#DFA718"
            paddingLeft={0.5}
            paddingRight={0.5}
          >
            {jobs?.job_title}
          </Typography>
          <Typography component="h4" variant="h4">
            {t("view_candidates_job_application_position_title")}
          </Typography>
        </Box>
      )}
      {/* View candidates summary card */}
      <SummaryCard cardData={candidateData} cardGridSize={3} />
      {/* Search field components */}
      <Box mt={5}>
        <Stack
          direction={`row`}
          justifyContent={cardView === true ? `space-between` : "end"}
          alignItems={`center`}
        >
          {/* Search form */}
          {cardView === true && (
            <Box flexDirection={`row`} display={`flex`} position={`relative`}>
              <Stack direction={`column`}>
                <TextField
                  placeholder="Search term"
                  size="small"
                  value={searchTerm}
                  sx={{ width: { xs: "auto", sm: "400px" } }}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  InputProps={{
                    endAdornment: (
                      <IconButton onClick={handleClear}>
                        {searchTerm === "" ? null : <CloseIcon />}
                      </IconButton>
                    ),
                  }}
                />

                {searchTerm && (
                  <Typography variant="body1">{t("search_message")}</Typography>
                )}
              </Stack>
              {/* jobs filter */}
              {searchResultCount > 0 && (
                <CardViewJobsFilter
                  cusines={cusines}
                  changeChecked={handleChangeChecked}
                />
              )}
            </Box>
          )}

          {/*  card view and table view icons */}
          <Box display={`flex`} flexDirection={`row`}>
            {cardView === true ? (
              <CardViewIconColor sx={{ cursor: "pointer", marginRight: 2 }} />
            ) : (
              <CardViewIcon
                onClick={() => {
                  setCardView(true);
                  setTableView(false);
                }}
                sx={{ cursor: "pointer", marginRight: 2 }}
              />
            )}

            {tableView === true ? (
              <TableViewIconColor sx={{ cursor: "pointer", marginRight: 2 }} />
            ) : (
              <TableViewIcon
                onClick={() => {
                  setTableView(true);
                  setCardView(false);
                }}
                sx={{ cursor: "pointer", marginRight: 2 }}
              />
            )}
          </Box>
        </Stack>
        {/* candidate list card */}
        <Box mt={3.75} position={`relative`}>
          {cardView ? (
            <Box>
              {data.length > 0 ? (
                <Box
                  display={`flex`}
                  flexDirection={{ xs: "column", sm: "row" }}
                  justifyContent={{ xs: "unset", sm: `space-between` }}
                >
                  {/* candidate list card render */}
                  <Stack direction={`column`} width={{ xs: "100%", sm: "50%" }}>
                    <CandidateListCard
                      handleCandidates={handleCandidates}
                      searchTerm={searchTerm}
                      candidateList={data}
                      checkBoxFilter={checkBoxFilter}
                      candidateListCount={searchResultCount}
                      handlePagination={handlePagination}
                    />
                    {/* <ProductsList products={state.products} /> */}
                  </Stack>
                  {/* view candidate details card */}
                  <Stack direction={`column`} width={{ xs: "100%", sm: "49%" }}>
                    <ViewCandidateListCard
                      activeTab={activeTab}
                      application={data}
                      applicationCount={applicationsCount}
                    />
                  </Stack>
                </Box>
              ) : (
                <NoOfficeData
                  title={
                    searchResultCount === 0
                      ? `${t("view_candidates_emptybox_title")}`
                      : `${t("view_candidate_list_not_found")}`
                  }
                  imgName={searchResultCount === 0 ? "Illust-5" : `Illust-7`}
                />
              )}
            </Box>
          ) : (
            <ViewCandidateListTableView jobsById={jobs} />
          )}
        </Box>
      </Box>
    </Layout>
  );
}

const mapStateToProps = (state: RootState) => ({
  jobs: state.jobs.jobsById,
  applications: state.applications.applications,
  applicationsCount: state.applications.applicationsLength,
  //** shortlisted count */
  shortListCount: state.applications.shortListedCandidateCount,
  //** offer made count */
  offerCandidateCount: state.applications.offerMadeCount,
  //** Hired candidate count */
  hiredCount: state.applications.hiredCandidateCount,
  //** search data */
  searchResult: state.applications.searchResult,
  searchResultCount: state.applications.searchCount,
});

const mapDispatchToProps = (dispatch: Dispatch) => {
  return {
    fetchJob: (id: string) => fetchJob(dispatch, id),
    listApplication: (params: any) => listApplication(dispatch, params),
    shortListApplication: (params: any) =>
      shortListApplication(dispatch, params),
    //** offer made */
    offeredMadeApplicationList: (params: any) =>
      offerMadeApplication(dispatch, params),
    //** hired candidate list */
    hiredCandidatesList: (params: any) =>
      HiredCandidateApplication(dispatch, params),
    searchCandidateApplication: (params: any) =>
      listSearchApplication(dispatch, params),
  };
};

export default connect(mapStateToProps, mapDispatchToProps)(CandidateList);
