// React, Next packages
import React, { useEffect, useState } from "react";
import Link from "next/link";
import dynamic from "next/dynamic";
import { useRouter } from "next/router";
import { connect } from "react-redux";
import { Dispatch } from "redux";
// Mui packages
import { Box, LinearProgress, Typography } from "@mui/material";
// Third-party packages
import { useSnackbar } from "notistack";
import InfiniteScroll from "react-infinite-scroll-component";
// Custom packages
import useCompany from "@lib/useCompany";
import { Backdrop } from "@common/Backdrop";
import { Table } from "@common/Table";
import { Tabs } from "@common/Tabs";
import {
  clearApplications,
  editApplication,
  listApplication,
} from "reducers/applicationsSlice";
import { postJobChatChannel } from "api/applications";
import { RootState } from "reducers";

// Dynamic import packages
const ResumeDialog = dynamic(
  () => import("@common/ResumeDialog").then((mod) => mod.ResumeDialog),
  { ssr: false, loading: () => <Backdrop open invisible /> }
);
const Layout = dynamic(
  () => import("@common/Layout").then((mod) => mod.Layout),
  { ssr: false, loading: () => <Backdrop open invisible /> }
);

function ApplicationListPage(props: any) {
  /** third-party hooks */
  const { company } = useCompany({
    redirectTo: "/",
  });
  const { enqueueSnackbar } = useSnackbar();
  const router = useRouter();

  /** class variables */
  const { job_post, jobTitle, application_status, userId } = router.query;

  /** props - actions */
  const { clearApplications, editApplication, listApplication } = props;
  /** props - states */
  const { applications, applicationsNext } = props;

  /** useState hooks */
  const [isUpdating, setIsUpdating] = useState(false);

  /** class constants */
  const tabs = [
    {
      path: "/applications/list",
      query: {
        ...router.query,
        application_status: "applied",
      },
      label: `Pending Applicants`,
      value: "applied",
    },
    {
      path: "/applications/list",
      query: {
        ...router.query,
        application_status: "accepted",
      },
      label: `Accepted Applicants`,
      value: "accepted",
    },
    {
      path: "/applications/list",
      query: {
        ...router.query,
        application_status: "rejected",
      },
      label: `Rejected Applicants`,
      value: "rejected",
    },
  ];

  /** useEffect hooks */
  useEffect(() => {
    const initializeApplicationList = async () => {
      clearApplications();
      await listApplication({ ...router.query, page: 1, page_size: 9});
    };

    try {
      job_post && application_status && initializeApplicationList();
    } catch (error) {
      console.log(error);
    }
  }, [job_post, application_status]);

  /** custom handlers */
  const handleAccept = async (id: string, payload: any) => {
    try {
      await editApplication(id, payload);
      enqueueSnackbar(
        <Typography>
          You have accepted this application. Please check the&nbsp;
          <Link
            href={{
              pathname: "/applications/list",
              query: { ...router.query, application_status: "accepted" },
            }}
          >
            <a>
              <u>Accepted Applicants</u>
            </a>
          </Link>
          &nbsp;tab once done reviewing other applications.
        </Typography>,
        { variant: "info" }
      );
    } catch (error: any) {
      enqueueSnackbar(error.toString(), { variant: "error" });
    }
  };

  const handleReject = async (id: string, payload: any) => {
    try {
      await editApplication(id, payload);
      enqueueSnackbar(
        <Typography>
          You have rejected this application. You can navigate to&nbsp;
          <Link
            href={{
              pathname: "/applications/list",
              query: { ...router.query, application_status: "rejected" },
            }}
          >
            <a>
              <u>Rejected Applicants</u>
            </a>
          </Link>
          &nbsp;tab to review them again.
        </Typography>,
        { variant: "info" }
      );
    } catch (error: any) {
      enqueueSnackbar(error.toString(), { variant: "error" });
    }
  };

  const handleRetrieve = async (id: string, payload: any) => {
    try {
      await editApplication(id, payload);
      enqueueSnackbar(
        <Typography>
          You have retrieved this application back to the&nbsp;
          <Link
            href={{
              pathname: "/applications/list",
              query: { ...router.query, application_status: "applied" },
            }}
          >
            <a>
              <u>Pending Applicants</u>
            </a>
          </Link>
          &nbsp;list.
        </Typography>,
        { variant: "info" }
      );
    } catch (error: any) {
      enqueueSnackbar(error.toString(), { variant: "error" });
    }
  };

  const handleClick = async (userId: string) => {
    router.push(
      {
        pathname: location.pathname,
        query: {
          ...router.query,
          userId: userId,
        },
      },
      undefined,
      { shallow: true }
    );
  };

  const handleChat = async (id: string, applicantId: string, payload: any) => {
    try {
      setIsUpdating(true);
      await postJobChatChannel(applicantId, job_post as string);
      enqueueSnackbar("Redirecting to Chat Page", { variant: "success" });
      return router.push("/chat");
    } catch (error: any) {
      enqueueSnackbar(error.toString(), { variant: "error" });
    } finally {
      setIsUpdating(false);
    }
  };

  const handleClose = () => {
    const newQuery = { ...router.query };
    delete newQuery.userId;

    router.push(
      {
        pathname: location.pathname,
        query: newQuery,
      },
      undefined,
      { shallow: true }
    );
  };

  const handleLoadApplications = async () => {
    await listApplication({ ...router.query, page: applicationsNext, page_size: 9,});
  };

  return (
    <Layout
      pageTitle={
        jobTitle ? (
          <>
            Job Applications for <b>{jobTitle}</b> Position
          </>
        ) : (
          "Job Applications"
        )
      }
      ogTitle={`${jobTitle} Applications | CareerChat Recruiters`}
    >
      {/* Tabs, sort filter */}
      <Tabs tabs={tabs} value={application_status as string} />
      {applications && (
        <div id="application-list">
          <InfiniteScroll
            dataLength={applications.length}
            next={handleLoadApplications}
            hasMore={applicationsNext}
            loader={<LinearProgress sx={{ width: "100%", marginY: 2 }} />}
            endMessage={
              <Box display="flex" justifyContent="center" m={2}>
                <Typography color="primary" variant="body1" fontWeight="600">
                  You have seen all applications.
                </Typography>
              </Box>
            }
          >
            <Table
              applicationStatus={application_status as string}
              // @ts-ignore
              onAccept={application_status === "applied" && handleAccept}
              onClick={handleClick}
              // @ts-ignore
              onReject={application_status === "applied" && handleReject}
              // @ts-ignore
              onRetrieve={application_status === "rejected" && handleRetrieve}
              rows={applications}
              // onChat={handleChat}
            />
          </InfiniteScroll>
        </div>
      )}
      {userId && (
        <ResumeDialog onClose={handleClose} open userId={userId as string} />
      )}
      <Backdrop open={isUpdating} />
    </Layout>
  );
}

const mapStateToProps = (state: RootState) => ({
  applications: state.applications.applications,
  applicationsLength: state.applications.applicationsLength,
  applicationsNext: state.applications.applicationsNext,
});

const mapDispatchToProps = (dispatch: Dispatch) => {
  return {
    clearApplications: () => dispatch(clearApplications()),
    editApplication: (id: string, payload: any) =>
      editApplication(dispatch, id, payload),
    listApplication: (params: any) => listApplication(dispatch, params),
  };
};

export default connect(
  mapStateToProps,
  mapDispatchToProps
)(ApplicationListPage);
