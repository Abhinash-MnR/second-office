// React, Next packages
import React from "react";
import dynamic from "next/dynamic";
import Link from "next/link";
// Mui packages
import { Grid } from "@mui/material";
// Custom Packages

function add() {
  return (
    <>
      <Grid container>Code Removed</Grid>
    </>
  );
}

export default add;
