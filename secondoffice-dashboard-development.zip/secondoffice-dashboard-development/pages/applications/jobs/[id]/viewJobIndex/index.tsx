// React, Next packages
import React, { useEffect, useState } from "react";
import { Dispatch } from "redux";
import { connect } from "react-redux";
import { useRouter } from "next/router";
// Mui packages
import { Grid } from "@mui/material";
// Custom Packages
import ViewJobCard from "features/jobs/ViewJobsCard";
import { RootState } from "reducers";
import { fetchJob } from "reducers/jobsSlice";
import { Layout } from "@common/Layout";
import ViewJobCardSection from "features/jobs/ViewJobCardSection";
// Third-party packages
import { useSnackbar } from "notistack";

function View(props: any) {
  /** third-party hooks */
  const { enqueueSnackbar } = useSnackbar();
  const router = useRouter();

  /** props - actions */
  const { fetchJob } = props;
  /** props - states */
  const { jobs } = props;

  /** useState hooks */
  const [isUpdating, setIsUpdating] = useState<boolean>(false);
  const [job, setJob] = useState();
  const [jobSkills, setJobSkills] = useState();
  const [index, setIndex] = useState<any>();

  /** useEffect hooks */
  useEffect(() => {
    const initializeJob = async () => {
      await fetchJob(location.href.split("/")[5]);
    };

    try {
      initializeJob();
    } catch (error: any) {
      enqueueSnackbar(error.toString(), { variant: "error" });
    }
  }, []);

  useEffect(() => {
    for (var i = 0; i < jobs.length; i++) {
      if (jobs[i].id === location.href.split("/")[5]) {
        setJob(jobs[i]);
        setIndex(i);
        setJobSkills(jobs[i].job_skills);
      }
    }
  }, [jobs]);

  return (
    <Layout ogTitle="SecondOffice| View Jobs">
      <Grid container spacing={1}>
        <ViewJobCardSection jobs={jobs} index={0} />
        <ViewJobCard jobs={jobs} index={0} />
      </Grid>
    </Layout>
  );
}
const mapStateToProps = (state: RootState) => ({
  jobs: state.jobs.jobs,
});

const mapDispatchToProps = (dispatch: Dispatch) => {
  return {
    fetchJob: (id: string) => fetchJob(dispatch, id),
  };
};

export default connect(mapStateToProps, mapDispatchToProps)(View);
