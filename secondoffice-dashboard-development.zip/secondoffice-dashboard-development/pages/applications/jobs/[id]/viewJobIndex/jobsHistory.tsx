// React, Next packages
import React from "react";
import dynamic from "next/dynamic";
// Mui packages
import { Box, Grid, Typography, styled } from "@mui/material";
// Custom Component

import JobEditHistory from "features/jobs/JobEditHistory";
// Dynamic import packages
const Layout = dynamic(() =>
  import("@common/Layout").then((mod) => mod.Layout)
);

function jobsHistory() {
  return (
    <Layout companyName="StrongArm" ogTitle="Dashboard | SecondOffice">
      <Grid container spacing={2}>
        <JobEditHistory />
      </Grid>
    </Layout>
  );
}

export default jobsHistory;
