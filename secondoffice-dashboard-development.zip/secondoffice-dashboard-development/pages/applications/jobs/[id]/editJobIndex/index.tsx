// React, Next packages
import React, { useEffect, useState } from "react";
import dynamic from "next/dynamic";
import { useRouter } from "next/router";
import Link from "next/link";
import { Dispatch } from "redux";
import { connect } from "react-redux";
// Mui packages
import { Typography, Button, styled } from "@mui/material";
// Third-party packages
import { useSnackbar } from "notistack";
import { useTranslation } from "react-i18next";
import "translation/i18n";
// Custom packages
import { BackIcon } from "@common/Icon";
import useCompany from "@lib/useCompany";
import { getOAuthLink } from "@lib/oauth-handler";
import { Section } from "@common/Section";
import { putJobDetail } from "api/jobs";
import { JobForm } from "features/jobs/JobForm";
import { TagResponse } from "types/TagResponse";
import { fetchJob } from "reducers/jobsSlice";
import { RootState } from "reducers";

// #region - Dynamic import packages -https://nextjs.org/docs/advanced-features/dynamic-import
const Layout = dynamic(
  () => import("@common/Layout").then((mod) => mod.Layout),
  { ssr: false }
);
const ViewJobsContainer = styled("div")(({ theme }) => ({
  display: "flex",
  flexDirection: "column",
}));

const ViewJobsTitle = styled("div")(({ theme }) => ({
  display: "flex",
  flexDirection: "row",
  marginBottom: 20,
  alignItems: "center",
}));

function JobsFormPage(props: any) {
  /** third-party hooks */
  const { enqueueSnackbar } = useSnackbar();
  const router = useRouter();

  const { isLoading: isAuthenticating } = useCompany({
    redirectTo: getOAuthLink(router.asPath),
  });
  /** props - actions */
  const { fetchJob } = props;
  /** props - states */
  const { jobs } = props;

  //**language translation hooks */
  const { t } = useTranslation();

  /** useState hooks */
  const [isUpdating, setIsUpdating] = useState<boolean>(false);
  const [job, setJob] = useState();
  const [jobSkills, setJobSkills] = useState();

  function postStringCreate(str: string) {
    var i,
      frags = str?.split(" ");
    for (i = 0; i < frags?.length; i++) {
      frags[i] = frags[i]?.charAt(0)?.toLowerCase() + frags[i]?.slice(1);
    }
    return frags?.join("_");
  }

  /** useEffect hooks */
  useEffect(() => {
    const initializeJob = async () => {
      await fetchJob(location.href.split("/")[5]);
    };

    try {
      initializeJob();
    } catch (error: any) {
      enqueueSnackbar(error.toString(), { variant: "error" });
    }
  }, []);
  useEffect(() => {
    for (const i of jobs) {
      if (i.id === location.href.split("/")[5]) {
        setJob(i);
        setJobSkills(i.job_skills);
      }
    }
  }, [jobs]);

  /** custom handlers  */
  const handleSubmitJob = async (data: any) => {
    try {
      setIsUpdating(true);
      const {
        salary_max,
        salary_min,
        experience_range,
        job_tags,
        priority,
        salaryNoLimit,
        salaryLimitCondition,
      } = data;
      // Format salary, experience range as arrays
      const experience = experience_range.split("-");
      // Format job_tags as an array of ids
      const tags = job_tags?.map((tag: TagResponse) => {
        return tag.id;
      });

      // const {jobSkill} = data.job_skills.split(',');
      // Create form payload
      const payload = {
        ...data,
        experience_max: Number(experience[1]),
        experience_min: Number(experience[0]),
        job_notice_period:
          data?.job_notice_period === "Immediate Joiner"
            ? 0
            : data.job_notice_period.length === 7
            ? Number(data.job_notice_period.slice(0, 2))
            : Number(data.job_notice_period.value),
        job_skill_update:
          jobSkills === data.job_skills
            ? data.job_skill_update
            : data.job_skills,
        job_skills:
          jobSkills === data.job_skills ? jobSkills : [data.job_skills],
        salary_max:
          localStorage?.getItem("salaryLimitStatus") === "true"
            ? !salaryNoLimit && salary_max
              ? Number(salary_max)
              : 0
            : salary_max === 0
            ? 0
            : Number(salary_max),
        salary_min:
          localStorage?.getItem("salaryLimitStatus") === "true"
            ? !salaryNoLimit && salary_min
              ? Number(salary_min)
              : 0
            : salary_min === 0
            ? 0
            : Number(salary_min),
        priority: postStringCreate(priority),
        edited_by_admin: false,
      };
      const job = await putJobDetail(location.href.split("/")[5], payload);
      enqueueSnackbar(`${t("jobs_post_added")}`, {
        variant: "info",
      });
      router.push(`/applications?is_open=true&job_post=${job.data?.id}`);
    } catch (error: any) {
      enqueueSnackbar(error.toString(), { variant: "error" });
      setIsUpdating(false);
    }
  };

  const handleBack = () => router.back();

  return (
    <Layout companyName="StrongArm" ogTitle="Job Applications | SeconOffice ">
      <ViewJobsContainer>
        <Link href="/applications">
          <a>
            <ViewJobsTitle>
              <Typography component="span">
                <BackIcon
                  sx={{
                    fontSize: { xs: "11px", sm: "12px" },
                    marginRight: { xs: "5px", sm: "10px" },
                    marginTop: "0.5px",
                  }}
                />
              </Typography>
              <Typography component="h6" variant="h6">
                {t("view_candiates_backIcon_title")}
              </Typography>
            </ViewJobsTitle>
          </a>
        </Link>
        <Section
          title={`${t("office_management_team_attendance_summarycard_title1")}`}
          footer={
            <>
              <Button
                onClick={handleBack}
                size="medium"
                sx={{
                  width: "165px",
                  marginRight: "30px",
                }}
              >
                {t("edit_jobs_discard_button_title")}
              </Button>
              <Button
                color="primary"
                form="job_position_form"
                fullWidth
                type="submit"
                variant="contained"
                size="medium"
                sx={{
                  border: "1px solid white",
                  width: "172px",
                }}
              >
                {t("edit_jobs_save_changes_title")}
              </Button>
            </>
          }
        >
          <JobForm job={job} onSubmit={handleSubmitJob} />
        </Section>
      </ViewJobsContainer>
    </Layout>
  );
}
const mapStateToProps = (state: RootState) => ({
  jobs: state.jobs.jobs,
});

const mapDispatchToProps = (dispatch: Dispatch) => {
  return {
    fetchJob: (id: string) => fetchJob(dispatch, id),
  };
};

export default connect(mapStateToProps, mapDispatchToProps)(JobsFormPage);
