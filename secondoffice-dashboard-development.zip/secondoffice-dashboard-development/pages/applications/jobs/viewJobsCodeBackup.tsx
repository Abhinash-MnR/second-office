// React, Next packages
import React from "react";
import dynamic from "next/dynamic";
import Link from "next/link";
import { useRouter } from "next/router";
// import { useRouter } from "next/router";
import { connect } from "react-redux";
import { Dispatch } from "redux";
// Mui packages
import { Box, Grid, Button, Typography, styled, Stack } from "@mui/material";
// Third-party packages
// import { useSnackbar } from "notistack";
// Custom Packages
import { BackIcon } from "@common/Icon";
import ViewJobCard from "features/jobs/ViewJobsCard";
import { fetchJob } from "reducers/jobsSlice";
import { RootState } from "reducers";
import { renderRelativeDate } from "lib/formatter";
// Dynamic import packages
const Layout = dynamic(() =>
  import("@common/Layout").then((mod) => mod.Layout)
);

const ViewJobsContainer = styled("div")(({ theme }) => ({
  display: "flex",
  flexDirection: "column",
  [theme.breakpoints.down("sm")]: {
    display: "flex",
    flexDirection: "column",
  },
}));

const ViewJobsTitle = styled("div")(({ theme }) => ({
  display: "flex",
  flexDirection: "row",
  marginBottom: 30,
  alignItems: "center",
  [theme.breakpoints.down("sm")]: {
    display: "flex",
    flexDirection: "row",
  },
}));

const ViewJobsCustomCard = styled("div")(({ theme }) => ({
  display: "flex",
  flexDirection: "column",
  background: "#ECEDF4",
  borderRadius: theme.shape.borderRadius,
  padding: "30px 20px 30px 20px ",
}));

function ViewJobs(props: any) {
  /** third-party hooks */
  // const { enqueueSnackbar } = useSnackbar();
  // const router = useRouter();
  // const { id } = router.query;
  const router = useRouter();
  /** props - actions */
  const { fetchJob } = props;
  /** props - states */
  const { jobs } = props;
  const { index } = props;

  /** useState hooks */
  // const [isUpdating, setIsUpdating] = useState<boolean>(false);
  // const [job, setJob] = useState();
  // const [jobSkills, setJobSkills] = useState();
  // const [index, setIndex] = useState<any>();

  /** useEffect hooks */
  // useEffect(() => {
  //   const initializeJob = async () => {
  //     await fetchJob(location.href.split('/')[5]);
  //   };

  //   try {
  //     initializeJob();
  //   } catch (error: any) {
  //     // enqueueSnackbar(error.toString(), { variant: "error" });
  //   }
  // }, []);
  // useEffect(() => {
  //   for (var i = 0; i < jobs.length; i++) {
  //       if ( jobs[i].id === location.href.split('/')[5] ) {
  //       setJob(jobs[i]);
  //       setIndex(i)
  //       setJobSkills(jobs[i].job_skills)
  //     }
  //   }
  // }, [jobs]);
  return (
    <Layout companyName="StrongArm" ogTitle="Job Applications | SeconOffice ">
      <ViewJobsContainer>
        <Link href="/applications">
          <a>
            <ViewJobsTitle>
              <Typography component="span">
                <BackIcon sx={{ fontSize: 13, marginRight: "10px" }} />
              </Typography>
              <Typography component="h3" variant="h3">
                {jobs[index]?.job_title} Job Post
              </Typography>
            </ViewJobsTitle>
          </a>
        </Link>
        <ViewJobsCustomCard>
          <Grid container spacing={4}>
            <Grid item xs={12} sm={8}>
              <Stack direction="column">
                <Typography component="h3" variant="h3">
                  {jobs[index]?.job_title}
                </Typography>
                <Typography component="p" variant="body1" paddingTop="10px">
                  StrongArm : {jobs[index]?.job_location}
                </Typography>
                <Typography component="p" variant="body1" paddingTop="10px">
                  {jobs[index]?.job_nature} : {jobs[index]?.job_openings}{" "}
                  openings
                </Typography>
              </Stack>
            </Grid>
            <Grid item xs={7} sm={2}>
              <Box sx={{ display: "flex", justifyContent: "space-between" }}>
                <Button
                  component="a"
                  variant="contained"
                  rel="noopener noreferrer"
                  target="_blank"
                  size="medium"
                  sx={{
                    border: "1px solid #2c3058",
                    width: { xs: "172px", sm: "170px" },
                    background: "primary.main",
                    color: "#fff",
                  }}
                  onClick={() => router.push("/applications/applicationList")}
                >
                  View Candidates
                </Button>
              </Box>
            </Grid>
            <Grid item xs={5} sm={2}>
              <Button
                component="a"
                variant="contained"
                rel="noopener noreferrer"
                target="_blank"
                size="medium"
                sx={{
                  border: "1px solid #2c3058",
                  background: "none",
                  color: "#2c3058",
                  width: { xs: "115px", sm: "150px" },
                  "&:hover": {
                    background: "none",
                  },
                }}
                onClick={() =>
                  router.push(
                    "/applications/jobs/" + jobs[index]?.id + "/editJobIndex/"
                  )
                }
              >
                Edit Job Post
              </Button>
            </Grid>
          </Grid>
          <Typography
            component="p"
            variant="body1"
            textAlign="end"
            paddingTop="10px"
          >
            Posted : {renderRelativeDate(jobs[index]?.created_at)}
          </Typography>
        </ViewJobsCustomCard>
        <ViewJobCard jobs={jobs} index={0} />
      </ViewJobsContainer>
    </Layout>
  );
}

const mapStateToProps = (state: RootState) => ({
  jobs: state.jobs.jobs,
});

const mapDispatchToProps = (dispatch: Dispatch) => {
  return {
    fetchJob: (id: string) => fetchJob(dispatch, id),
  };
};

export default connect(mapStateToProps, mapDispatchToProps)(ViewJobs);
