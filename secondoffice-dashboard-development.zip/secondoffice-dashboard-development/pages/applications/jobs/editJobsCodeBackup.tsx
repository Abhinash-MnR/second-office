// React, Next packages
import React, { useEffect, useState } from "react";
import dynamic from "next/dynamic";
import { useRouter } from "next/router";
import Link from "next/link";
import { Dispatch } from "redux";
import { connect } from "react-redux";
// Mui packages
import { Typography, Button, styled } from "@mui/material";
// Third-party packages
import { useSnackbar } from "notistack";
// Custom packages
import { BackIcon } from "@common/Icon";
import useCompany from "@lib/useCompany";
import { getOAuthLink } from "@lib/oauth-handler";
import { Backdrop } from "@common/Backdrop";
import { Section } from "@common/Section";
import { putJobDetail } from "api/jobs";
import { JobForm } from "features/jobs/JobForm";
import { TagResponse } from "types/TagResponse";
import { fetchJob } from "reducers/jobsSlice";
import { RootState } from "reducers";

// #region - Dynamic import packages -https://nextjs.org/docs/advanced-features/dynamic-import
const Layout = dynamic(
  () => import("@common/Layout").then((mod) => mod.Layout),
  { ssr: false, loading: () => <Backdrop open invisible /> }
);
const ViewJobsContainer = styled("div")(({ theme }) => ({
  display: "flex",
  flexDirection: "column",
  padding: "24px",
}));

const ViewJobsTitle = styled("div")(({ theme }) => ({
  display: "flex",
  flexDirection: "row",
  marginBottom: 20,
  alignItems: "center",
}));

function JobsFormPage(props: any) {
  /** third-party hooks */
  const { enqueueSnackbar } = useSnackbar();
  const router = useRouter();

  const { isLoading: isAuthenticating } = useCompany({
    redirectTo: getOAuthLink(router.asPath),
  });
  /** props - actions */
  const { fetchJob } = props;
  /** props - states */
  const { jobs } = props;

  /** useState hooks */
  const [isUpdating, setIsUpdating] = useState<boolean>(false);
  const [job, setJob] = useState();
  const [jobSkills, setJobSkills] = useState();

  /** useEffect hooks */
  useEffect(() => {
    const initializeJob = async () => {
      await fetchJob(location.href.split("/")[5]);
    };

    try {
      initializeJob();
    } catch (error: any) {
      enqueueSnackbar(error.toString(), { variant: "error" });
    }
  }, []);
  useEffect(() => {
    for (const i of jobs) {
      if (i.id === location.href.split("/")[5]) {
        setJob(i);
        setJobSkills(i.job_skills);
      }
    }
  }, [jobs]);

  /** custom handlers  */
  const handleSubmitJob = async (data: any) => {
    try {
      setIsUpdating(true);
      const { salary_range, experience_range, job_tags } = data;
      // Format salary, experience range as arrays
      const salary = salary_range.split("-");
      const experience = experience_range.split("-");
      // Format job_tags as an array of ids
      const tags = job_tags?.map((tag: TagResponse) => {
        return tag.id;
      });
      // const {jobSkill} = data.job_skills.split(',');
      // Create form payload
      const payload = {
        ...data,
        experience_max: Number(experience[1]),
        experience_min: Number(experience[0]),
        job_notice_period: Number(data.job_notice_period.slice(0, 2)),
        job_skills:
          jobSkills === data.job_skills ? jobSkills : [data.job_skills],
        salary_max: Number(salary[1]),
        salary_min: Number(salary[0]),
      };
      const job = await putJobDetail(location.href.split("/")[5], payload);
      enqueueSnackbar("Your job post has been updated.", {
        variant: "info",
      });
      router.push(`/applications?is_open=true&job_post=${job.data?.id}`);
    } catch (error: any) {
      enqueueSnackbar(error.toString(), { variant: "error" });
      setIsUpdating(false);
    }
  };

  const handleBack = () => router.back();

  return (
    <Layout companyName="StrongArm" ogTitle="Job Applications | SeconOffice ">
      <ViewJobsContainer>
        <Link href="/applications">
          <a>
            <ViewJobsTitle>
              <Typography component="span">
                <BackIcon
                  sx={{ fontSize: 14, marginRight: "10px", marginTop: 1 }}
                />
              </Typography>
              <Typography component="h3" variant="h3">
              Recruit Your Team
              </Typography>
            </ViewJobsTitle>
          </a>
        </Link>
        <Section
          title="Edit Job Post"
          footer={
            <>
              <Button
                onClick={handleBack}
                size="medium"
                sx={{
                  border: "1px solid white",
                  width: "165px",
                  marginRight: "30px",
                }}
              >
                Discard Changes
              </Button>
              <Button
                color="primary"
                form="job_position_form"
                fullWidth
                type="submit"
                variant="contained"
                size="medium"
                sx={{
                  border: "1px solid white",
                  width: "172px",
                }}
              >
                Save Changes
              </Button>
            </>
          }
        >
          <JobForm job={job} onSubmit={handleSubmitJob} />
        </Section>
      </ViewJobsContainer>
    </Layout>
  );
}
const mapStateToProps = (state: RootState) => ({
  jobs: state.jobs.jobs,
});

const mapDispatchToProps = (dispatch: Dispatch) => {
  return {
    fetchJob: (id: string) => fetchJob(dispatch, id),
  };
};

export default connect(mapStateToProps, mapDispatchToProps)(JobsFormPage);
