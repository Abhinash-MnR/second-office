// React, Next packages
import React from "react";
import dynamic from "next/dynamic";
import Link from "next/link";
// Mui packages
import { Box, Grid, Typography, styled, Stack } from "@mui/material";

// Custom Component

import { BackIcon } from "@common/Icon";
import LabTabs from "@common/CustomUnstyledTab";

// Dynamic import packages
const Layout = dynamic(() =>
  import("@common/Layout").then((mod) => mod.Layout)
);

const AplicationContainer = styled("div")(({ theme }) => ({
  display: "flex",
  flexDirection: "column",
}));

const JobsTitle = styled("div")(({ theme }) => ({
  display: "flex",
  flexDirection: "row",
  alignItems: "center",
}));

const JobsTitleSecond = styled("div")(({ theme }) => ({
  display: "flex",
  flexDirection: "row",
  color: "#2c3058",
  fontSize: 20,
  lineHeight: "150%",
  fontWeight: 700,
  marginTop: 30,
  alignItems: "center",
  [theme.breakpoints.down("sm")]: {
    display: "flex",
    fontSize: 14,
  },
}));

const SubContainer = styled("div")(({ theme }) => ({
  display: "flex",
  flexDirection: "row",
  margin: "45px 0px 20px 0px",
}));

function AplicationList() {
  return (
    <Layout companyName="StrongArm" ogTitle="ApplicationList | SecondOffice">
      <AplicationContainer>
        <Link href="/applications">
          <a>
            <JobsTitle>
              <Typography component="span">
                <BackIcon
                  sx={{ fontSize: 12, marginRight: "10px", marginTop: 1 }}
                />
              </Typography>
              <Typography component="h6" variant="h6">
                Recruit Your Team
              </Typography>
            </JobsTitle>
          </a>
        </Link>
        <JobsTitleSecond>
          Job Applications for
          <Typography
            component="h5"
            variant="h5"
            color="#DFA718"
            paddingLeft={0.5}
            paddingRight={0.5}
            sx={{ fontWeight: 700 }}
          >
            {" "}
            UI/UX Designer{" "}
          </Typography>
          Position
        </JobsTitleSecond>
        <LabTabs />
      </AplicationContainer>
    </Layout>
  );
}

export default AplicationList;
