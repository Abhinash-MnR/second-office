// React, Next packages
import React, { useState, useEffect } from "react";
import dynamic from "next/dynamic";
import Link from "next/link";
import { useRouter } from "next/router";
// Mui packages
import {
  Grid,
  styled,
  TextField,
  Box,
  Typography,
  Button,
  Stack,
  Divider,
} from "@mui/material";
// Custom Packages
import OthersSettings from "features/settings/OthersSettings";
import SettingsSwtich from "features/settings/SettingsSwtich";
import SettingsHistory from "features/settings/SettingsHistory";
import useCompany from "@lib/useCompany";
import { putSettingsDetail } from "@api/expenses";
import LanguageSwitch from "features/settings/LanguageSwitch";
// Third-party packages
import { useSnackbar } from "notistack";
import i18next from "i18next";
import { useTranslation } from "react-i18next";
import "translation/i18n";
// Dynamic import packages
const Layout = dynamic(() =>
  import("@common/Layout").then((mod) => mod.Layout)
);

const SettingsContainer = styled("div")(({ theme }) => ({
  display: "flex",
  flexDirection: "column",
  background: "#fff",
  borderRadius: 10,
  padding: 20,
  [theme.breakpoints.down("sm")]: {
    display: "flex",
    padding: 15,
  },
}));

const SettingsInnerContainer = styled("div")(({ theme }) => ({
  display: "flex",
  flexDirection: "column",
  paddingTop: 0,
  [theme.breakpoints.down("sm")]: {
    display: "flex",
  },
}));

function Index() {
  /** third-party hooks */
  const { company, isLoading, isError } = useCompany();
  const { enqueueSnackbar } = useSnackbar();
  const router = useRouter();
  //**useState hooks */
  const [logLink, setLogLink] = useState(company?.management_log_link);
  const [clientRound, setClientRound] = useState("");
  const [currency, setCurrency] = useState("");
  const [performanceReview, setPerformanceReview] = useState("");
  const [technicalRound, setTechnicalRound] = useState("");
  const [culturalRound, setCulturalRound] = useState("");
  const [technicalAssesmentRound, setTechnicalAssesmentRound] = useState("");
  const [lang, setLang] = useState(company?.language);

  /** useState hooks */
  const [isUpdating, setIsUpdating] = useState<boolean>(false);

  //**language translation hooks */
  const { t } = useTranslation();

  /** useEffect hooks */
  useEffect(() => {
    i18next.changeLanguage(lang);
    setLogLink(company?.management_log_link);
  }, [company, lang]);

  const clientRoundSelected = (data: string) => {
    setClientRound(data);
  };
  const currencySelected = (data: string) => {
    setCurrency(data);
  };
  const performanceReviewSelected = (data: string) => {
    setPerformanceReview(data);
  };
  const technicalRoundSelected = (data: string) => {
    setTechnicalRound(data);
  };
  const culturalRoundSelected = (data: string) => {
    setCulturalRound(data);
  };
  const technicalAssesmentSelected = (data: string) => {
    setTechnicalAssesmentRound(data);
  };
  const handleLanguage = (data: string) => {
    setLang(data);
  };
  /** custom handlers  */
  const handleSaveSettings = async (data: any) => {
    try {
      setIsUpdating(true);
      // Create form payload
      const payload = {
        client_round: clientRound ? clientRound : company?.client_round,
        currency: currency ? currency : company?.currency,
        language: lang,
        management_log_link: logLink,
        performance_review_frequency: performanceReview
          ? performanceReview
          : company?.performance_review_frequency,
        technical_round: technicalRound
          ? technicalRound
          : company?.technical_round,
        cultural_round: culturalRound ? culturalRound : company?.cultural_round,
        online_technical_assessment: technicalAssesmentRound
          ? technicalAssesmentRound
          : company?.online_technical_assessment,
      };
      const job = await putSettingsDetail(payload);
      enqueueSnackbar(`${t("setting_updated")}`, {
        variant: "info",
      });
    } catch (error: any) {
      enqueueSnackbar(error.toString(), { variant: "error" });
      setIsUpdating(false);
    }
  };

  // console.log(lang, "settings index page");
  return (
    <Layout companyName="NA" ogTitle="Dashboard | SecondOffice">
      <Box>
        <Typography component="h3" variant="h3" marginBottom={3.75}>
          {t("settings")}
        </Typography>
      </Box>
      <Grid container>
        <Grid item sm={12} xs={12}>
          <SettingsContainer>
            <SettingsSwtich
              clientRoundSelected={clientRoundSelected}
              technicalRoundSelected={technicalRoundSelected}
              culturalRoundSelected={culturalRoundSelected}
              technicalAssesmentSelected={technicalAssesmentSelected}
            />
            <Divider sx={{ margin: "20px 0px" }} />
            <OthersSettings
              currencySelected={currencySelected}
              performanceReviewSelected={performanceReviewSelected}
            />
            <Divider sx={{ margin: "20px 0px" }} />
            <LanguageSwitch language={lang} languageSelected={handleLanguage} />
            <Divider sx={{ margin: "20px 0px" }} />
            <SettingsInnerContainer>
              <Grid container>
                <Grid item xs={12} sm={6}>
                  <Typography
                    component="h6"
                    variant="h6"
                    sx={{ marginBottom: "10px" }}
                  >
                    {t("customize_usefull_link_title")}
                  </Typography>
                  <Typography
                    component="p"
                    variant="body1"
                    sx={{
                      width: { sm: "436px", xs: "100%" },
                      marginBottom: { xs: "30px", sm: "0px" },
                    }}
                  >
                    {t("customize_usefull_link_desc")}
                  </Typography>
                </Grid>
                <Grid item sm={6} xs={12}>
                  <Box sx={{ display: "flex", flexDirection: "column" }}>
                    <Typography
                      component="p"
                      sx={{
                        fontSize: "12px",
                        lineHeight: "150%",
                        marginBottom: "8px",
                      }}
                    >
                      {t("management_log_link_title")}
                    </Typography>
                    <TextField
                      required
                      id="outlined-required"
                      disabled
                      value={
                        company && company.management_log_link
                          ? company.management_log_link
                          : "-"
                      }
                      // onChange={(e) => {
                      //   setLogLink(e.target.value);
                      // }}
                      sx={{ width: { sm: "100%", xs: "100%" } }}
                    />
                    <Stack
                      direction="row"
                      justifyContent="flex-end"
                      sx={{ width: { sm: "100%", xs: "100%" } }}
                    >
                      <Button
                        component="a"
                        variant="contained"
                        rel="noopener noreferrer"
                        size="medium"
                        sx={{
                          marginTop: 3.75,
                          width: "134px",
                        }}
                        onClick={handleSaveSettings}
                      >
                        {t("settings_save")}
                      </Button>
                    </Stack>
                  </Box>
                </Grid>
              </Grid>
            </SettingsInnerContainer>
          </SettingsContainer>
        </Grid>

        {/* <Grid item xs={12}>
          <SettingsHistory />
        </Grid> */}
      </Grid>
    </Layout>
  );
}

export default Index;
