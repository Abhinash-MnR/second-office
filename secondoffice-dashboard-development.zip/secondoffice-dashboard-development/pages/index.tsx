// React, Next packages
import React, { useEffect } from "react";
import Head from "next/head";
import { useRouter } from "next/router";
// Mui packages
import { Grid, Hidden, Box, useMediaQuery } from "@mui/material";
import Login from "./auth/login/Login";
import { SliderSection } from "@common/Slider";
import PageLayout from "@common/PageLayout";

function Index() {
  const router = useRouter();

  useEffect(() => {
    if (
      typeof window !== "undefined" &&
      localStorage.getItem("access_token") !== null
    ) {
      router.push("/dashboard");
    }
  }, []);

  return (
    <>
      <Head>
        <meta charSet="utf-8" />
        <meta httpEquiv="X-UA-Compatible" content="IE=edge" />
        <meta
          name="viewport"
          content="width=device-width,initial-scale=1,minimum-scale=1,maximum-scale=1,user-scalable=no"
        />
        <title>SecondOffice | Login</title>
        <link rel="manifest" href="/manifest.json" />
        <link href="/faviconSO.ico" rel="icon" type="image/svg" sizes="16x16" />
        <link href="/faviconSO.ico" rel="icon" type="image/svg" sizes="32x32" />
        <link rel="apple-touch-icon" href="/faviconSO.ico"></link>
        <link rel="shortcut icon" href="/faviconSO.ico" />
      </Head>

      {typeof window !== "undefined" && (
        <Box sx={{ background: "#f5f5f5", minHeight: "100vh" }}>
          {localStorage.getItem("access_token") === null ? (
            <PageLayout LoginComponent={<Login />} />
          ) : (
            <Grid container>
              <Grid
                item
                xs={12}
                sm={12}
                sx={{
                  height: "100vh",
                  width: "100vw",
                  backgroundColor: "#ffffff",
                  display: "flex",
                  justifyContent: "center",
                  alignItems: "center",
                }}
              >
                <img
                  src="/svg/logo.svg"
                  style={{ width: "167px", height: "auto" }}
                />
              </Grid>
            </Grid>
          )}
        </Box>
      )}
    </>
  );
}
export default Index;
