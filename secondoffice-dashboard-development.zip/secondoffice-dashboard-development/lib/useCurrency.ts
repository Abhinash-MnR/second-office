/**
 * Custom hook used to fetch company profile.
 */
// React, Next packages
import { useEffect } from "react";
import Router from "next/router";

// Third-party packages
import useSWR from "swr";

// Custom packages
import { ApiHandler } from "@lib/api-handler";

const handler = new ApiHandler({
  context: undefined,
});

async function fetcher(url: string) {
  // TODO - implement type check for AxiosResponse<T>
  // @ts-ignore
  const response = await handler.get(url);
  return response.data;
}

export default function useCurrency({
  redirectTo = "",
  redirectIfFound = false,
} = {}) {
  const {
    data: currency,
    error,
    mutate: mutateCurrency,
  } = useSWR("/expenses/currency/", fetcher, {
    onError: (error, key) => {},
    onErrorRetry: (error, key, config, revalidate, { retryCount }) => {
      if (error?.response?.status === 401 || error?.response?.status === 403)
        return;
    },
  });

  useEffect(() => {
    if (!redirectTo || (!error && !currency)) return;

    if (
      (redirectTo && !redirectIfFound && (!currency || error)) ||
      (redirectIfFound && currency)
    ) {
      Router.push(redirectTo);
    }
  }, [currency, error, redirectIfFound, redirectTo]);

  return {
    currency,
    isLoading: !error && !currency,
    isError: error,
    mutateCurrency,
  };
}
