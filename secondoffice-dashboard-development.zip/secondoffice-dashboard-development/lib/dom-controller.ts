export function openNewTab(link: string) {
  window.open(link, "_blank");
}
