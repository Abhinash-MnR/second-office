export function isStringEmpty(str?: string | undefined) {
  if (
    typeof str === "undefined" ||
    str === null ||
    str === "" ||
    str.length === 0
  ) {
    return true;
  } else {
    return false;
  }
}

export function isObjectEmpty(obj: Object) {
  for (var key in obj) {
    if (obj.hasOwnProperty(key)) return false;
  }
  return true;
}

export function isArrayEmpty(array: Array<any>) {
  if (!Array.isArray(array) || !array.length) {
    return true;
  }
  return false;
}
