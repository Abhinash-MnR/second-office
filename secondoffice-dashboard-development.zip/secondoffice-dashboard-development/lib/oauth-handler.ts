export function getOAuthLink(redirectURL?: string): string {
  let authServer = "https://dev.accounts.careerchat.me";
  if (process.env.ENVIRONMENT === "production") {
    authServer = "https://accounts.careerchat.me";
  }

  const clientId = process.env.OAUTH_CLIENT_ID;

  const originServer = typeof window !== "undefined" && origin;

  return `${authServer}/o/authorize/?client_id=${clientId}&redirect_uri=${originServer}&response_type=code&state=${redirectURL}`;
}
