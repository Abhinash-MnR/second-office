import dayjs from "dayjs";
import { isStringEmpty } from "./checkEmpty";

export class ArrayValidator {
  validateRequired = (value: string) => {
    if (isStringEmpty(value)) {
      return "This field cannot be empty";
    } else if (value.length > 5) {
      return "You can add up to 5 max.";
    }
  };

  validateMin1 = (value: string) => {
    if (isStringEmpty(value)) {
      return "This field cannot be empty";
    } else if (value.length < 1) {
      return "Please add at least 1 item.";
    } else if (value.length > 5) {
      return "You can add up to 5 max.";
    }
  };

  validateMin3 = (value: string) => {
    if (isStringEmpty(value)) {
      return "This field cannot be empty";
    } else if (value.length < 3) {
      return "Please add at least 3 items.";
    } else if (value.length > 5) {
      return "You can add up to 5 max.";
    }
  };
}

export class DateValidator {
  validateFutureMax3 = (date: string) => {
    const dayjsDate = dayjs(date);
    if (isStringEmpty(date)) {
      return "This field cannot be empty";
    } else if (dayjsDate.diff(dayjs(), "days") < 0) {
      console.log(dayjsDate.diff(dayjs(), "days"));
      return "This field cannot have past dates.";
    } else if (dayjsDate.diff(dayjs(), "months") >= 3) {
      return "This field cannot exceed 3 months from today.";
    }
  };

  validateStartDate = (startDate: string, allValues: any) => {
    try {
      const { ongoing, end_date } = allValues;
      const startdayjs = dayjs(startDate);
      const enddayjs = dayjs(end_date);
      const now = dayjs();
      if (isStringEmpty(startDate)) {
        return "This field cannot be empty";
      } else if (startdayjs.diff(now) > 0) {
        return "This field cannot have future dates.";
      } else if (!ongoing && end_date && startdayjs.diff(enddayjs) > 0) {
        return "This field cannot be greater than end date.";
      }
    } catch (error) {
      console.log("ERROR", error);
      return undefined;
    }
  };

  validateEndDate = (endDate: string, allValues: any) => {
    try {
      const { ongoing, start_date } = allValues;
      const startdayjs = dayjs(start_date);
      const enddayjs = dayjs(endDate);
      const now = dayjs();
      if (ongoing) {
        return undefined;
      } else if (isStringEmpty(endDate)) {
        return "This field cannot be empty";
      } else if (enddayjs.diff(now) > 0) {
        return "This field cannot have future dates.";
      } else if (!ongoing && start_date && startdayjs.diff(enddayjs) > 0) {
        return "This field cannot be less than start date.";
      }
    } catch (error) {
      console.log("ERROR", error);
      return undefined;
    }
  };
}

export class FileValidator {
  validateMax1MB = (value?: any) => {
    const file = value?.file;
    if (file && file.size > 1024000) {
      return "File is too large. File should be less than 1MB.";
    }
  };

  validateMax3MB = (value?: any) => {
    const file = value?.file;
    if (file && file.size > 3072000) {
      return "File is too large. File should be less than 3MB.";
    }
  };

  validateMax5MB = (value?: any) => {
    const file = value?.file;
    if (file && file.size > 5120000) {
      return "File is too large. File should be less than 5MB.";
    }
  };

  validateImageMax1MB = (value?: any) => {
    const file = value?.file;
    if (!file || !file.name) {
      return undefined;
    }
    const sizeInvalid = this.validateMax1MB(value);
    if (sizeInvalid) {
      return sizeInvalid;
    }
    const extension = file.name.split(".").pop();
    if (!["PNG", "JPG", "JPEG", "GIF"].includes(extension.toUpperCase())) {
      return "File is not an image. Try png, jpg, jpeg, or gif.";
    }
  };

  validateImageRequiredMax1MB = (value?: any) => {
    const file = value?.file;
    const thumbnail = value?.thumbnail;
    if (!(file || thumbnail)) {
      return "This field cannot be empty";
    } else if (file && file?.name) {
      const sizeInvalid = this.validateMax1MB(value);
      if (sizeInvalid) {
        return sizeInvalid;
      }
      const extension = file.name.split(".").pop();
      if (!["PNG", "JPG", "JPEG", "GIF"].includes(extension.toUpperCase())) {
        return "File is not an image. Try png, jpg, jpeg, or gif.";
      }
    }
  };

  validateDocumentMax1MB = (value?: any) => {
    const file = value?.file;
    if (!file || !file.name) {
      return undefined;
    }
    const sizeInvalid = this.validateMax1MB(value);
    if (sizeInvalid) {
      return sizeInvalid;
    }
    const extension = file.name.split(".").pop();
    if (!["PDF", "DOC", "DOCX", "TXT"].includes(extension.toUpperCase())) {
      return "File is not a document. Try pdf, doc, docx, or txt.";
    }
  };
}

export class StringValidator {
  validateEmail = (email: string) => {
    const re =
      /^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
    const isEmpty = this.validateRequired(email);
    if (isEmpty) {
      return isEmpty;
    } else if (!re.test(String(email).toLowerCase())) {
      return "Please enter a valid email address.";
    }
  };

  validateTagCount = (Tag: string) => {
    const isEmpty = this.validateRequired(Tag);
    if (isEmpty) {
      return isEmpty;
    } else if (((Tag?.toString()).split(",")?.length - 1) > 4) {
      return "Please enter only five skills.";
    }
  };

  validateStringCount = (notice: string) => {
    const isEmpty = this.validateRequired(notice);
    if (isEmpty) {
      return isEmpty;
    } else if (((notice?.toString())?.length) < 7) {
      return "Please select only given options.";
    }
  };

  validateNoNumber = (location: string) => {
    const isEmpty = this.validateRequired(location);
    const reg = /\d+/g;
    if (isEmpty) {
      return isEmpty;
    } else if (reg.test(String(location))) {
      return "Numbers are not allowed in this field.";
    }
  };
  onlyValidateNoNumber = (location: string) => {
    const isEmpty = this.validateRequired(location);
    const reg = /\d+/g;
    if (reg.test(String(location))) {
      return "Numbers are not allowed in this field.";
    }
  };

  validateLocationNoNumber = (location: string) => {
    const isEmpty = this.validateRequired(location);
    const reg = /\d+/g;
    if (reg.test(String(location))) {
      return "Numbers are not allowed in this field.";
    }
  };

  validateOnlyNumber = (location: string) => {
    const isEmpty = this.validateRequired(location);
    const regex = /^\d+$/;
    if (isEmpty) {
      return isEmpty;
    } else if (!regex.test(String(location))) {
      return "Numbers are only allowed in this field.";
    }
  };
  
  validatePassword = (password: string, allValues: any) => {
    // Handle password reset form validation
    const { new_password1, new_password2 } = allValues;

    const isEmpty = this.validateRequired(password);
    if (isEmpty) {
      return isEmpty;
    } else if (password.length < 8) {
      return "Your password should be at least 8 characters.";
    } else if (
      new_password1 &&
      new_password2 &&
      new_password1 !== new_password2
    ) {
      return "Your confirm password does not match your password.";
    }
  };

  validateMax64(text: string) {
    if (text && text.length > 64) {
      return "Text should be less than 64 characters";
    }
  }

  validateMax128(text: string) {
    if (text && text.length > 128) {
      return "Text should be less than 128 characters";
    }
  }

  validateMax256(text: string) {
    if (text && text.length > 256) {
      return "Text should be less than 256 characters";
    }
  }

  validateMax2024(text: string) {
    if (text && text.length > 2024) {
      return "Text should be less than 2024 characters";
    }
  }

  validateMax4000(text: string) {
    if (text && text.length > 4048) {
      return "Text should be less than 4000 characters";
    }
  }
  validateMax10240(text: string) {
    if (text && text.length > 10240) {
      return "Text should be less than 10240 characters";
    }
  }

  validateRequired(value: string) {
    if (isStringEmpty(value)) {
      return "This field cannot be empty";
    }
  }

  validateRequiredMax64 = (text: string) => {
    return this.validateRequired(text) || this.validateMax64(text);
  };

  validateRequiredMax128 = (text: string) => {
    return this.validateRequired(text) || this.validateMax128(text);
  };

  validateRequiredMax256 = (text: string) => {
    return this.validateRequired(text) || this.validateMax256(text);
  };

  validateRequiredMax2024 = (text: string) => {
    return this.validateRequired(text) || this.validateMax2024(text);
  };

  validateRequiredMax4000 = (text: string) => {
    return this.validateRequired(text) || this.validateMax4000(text);
  };
  validateRequiredMax10240 = (text: string) => {
    return this.validateRequired(text) || this.validateMax10240(text);
  };
}

export class URLValidator {
  validateURL(url: string) {
    const pattern =
      /^(?:(?:(?:https?|ftp):)?\/\/)(?:\S+(?::\S*)?@)?(?:(?!(?:10|127)(?:\.\d{1,3}){3})(?!(?:169\.254|192\.168)(?:\.\d{1,3}){2})(?!172\.(?:1[6-9]|2\d|3[0-1])(?:\.\d{1,3}){2})(?:[1-9]\d?|1\d\d|2[01]\d|22[0-3])(?:\.(?:1?\d{1,2}|2[0-4]\d|25[0-5])){2}(?:\.(?:[1-9]\d?|1\d\d|2[0-4]\d|25[0-4]))|(?:(?:[a-z\u00a1-\uffff0-9]-*)*[a-z\u00a1-\uffff0-9]+)(?:\.(?:[a-z\u00a1-\uffff0-9]-*)*[a-z\u00a1-\uffff0-9]+)*(?:\.(?:[a-z\u00a1-\uffff]{2,})))(?::\d{2,5})?(?:[/?#]\S*)?$/i;
    if (!url) {
      return undefined;
    } else if (pattern.test(url)) {
      return undefined;
    } else {
      return "Please enter a valid a link.";
    }
  }

  validateRequiredURL(url: string) {
    const pattern =
      /^(?:(?:(?:https?|ftp):)?\/\/)(?:\S+(?::\S*)?@)?(?:(?!(?:10|127)(?:\.\d{1,3}){3})(?!(?:169\.254|192\.168)(?:\.\d{1,3}){2})(?!172\.(?:1[6-9]|2\d|3[0-1])(?:\.\d{1,3}){2})(?:[1-9]\d?|1\d\d|2[01]\d|22[0-3])(?:\.(?:1?\d{1,2}|2[0-4]\d|25[0-5])){2}(?:\.(?:[1-9]\d?|1\d\d|2[0-4]\d|25[0-4]))|(?:(?:[a-z\u00a1-\uffff0-9]-*)*[a-z\u00a1-\uffff0-9]+)(?:\.(?:[a-z\u00a1-\uffff0-9]-*)*[a-z\u00a1-\uffff0-9]+)*(?:\.(?:[a-z\u00a1-\uffff]{2,})))(?::\d{2,5})?(?:[/?#]\S*)?$/i;
    if (!url) {
      return "This link cannot be blank.";
    } else if (pattern.test(url)) {
      return undefined;
    } else {
      return "Please enter a valid a link.";
    }
  }

  validateYouTube(url: string) {
    const pattern = /^https:\/\/((w){3}.)?youtu(be|.be)?(\.com)?\/.+/gm;
    if (isStringEmpty(url)) {
      return undefined;
    } else if (pattern.test(url)) {
      return undefined;
    } else {
      return "Please enter a valid YouTube link.";
    }
  }

  validateFacebook(url: string) {
    const pattern = /^https:\/\/((w{3}\.)?)facebook.com\/.+/gm;
    if (isStringEmpty(url)) {
      return undefined;
    } else if (pattern.test(url)) {
      return undefined;
    } else {
      return "Please enter a valid Facebook link.";
    }
  }

  validateTwitter(url: string) {
    const pattern = /^https:\/\/((w{3}\.)?)twitter.com\/.+/gm;
    if (isStringEmpty(url)) {
      return undefined;
    } else if (pattern.test(url)) {
      return undefined;
    } else {
      return "Please enter a valid Twitter link.";
    }
  }

  validateInstagram(url: string) {
    const pattern = /^https:\/\/((w){3}.)?instagram?(\.com)?\/.+/gm;
    if (isStringEmpty(url)) {
      return undefined;
    } else if (pattern.test(url)) {
      return undefined;
    } else {
      return "Please enter a valid Instagram link.";
    }
  }
}
