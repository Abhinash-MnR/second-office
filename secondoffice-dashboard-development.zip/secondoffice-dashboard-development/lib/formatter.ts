import dayjs from "dayjs";

export const formatUnderscore = (text: string): string => {
  const formatted = text.split("_").join(" ");
  return formatted.replace(/\w\S*/g, function (txt) {
    return txt.charAt(0).toUpperCase() + txt.substr(1).toLowerCase();
  });
};

export const renderChatDate = (timestamp: string | Date) => {
  const today = dayjs();
  const chatTime = dayjs(timestamp);

  if (chatTime.isBefore(today, "day")) {
    return chatTime.format("L");
  } else {
    return chatTime.format("LT");
  }
};

export const formatDeadline = (startDate: string | Date) => {
  const diffDays = dayjs(startDate).diff(dayjs(), "days");
  return diffDays;
};

export const renderRelativeDate = (timestamp: string | Date) => {
  const today = dayjs();
  const postedAt = dayjs(timestamp);
  if (today.diff(postedAt, "m") < 60) {
    return " Just now";
  } else if (today.diff(postedAt, "h") >= 1 && today.diff(postedAt, "h") < 24) {
    return ` ${today.diff(postedAt, "h")} h ago`;
  } else if (today.diff(postedAt, "d") >= 1 && today.diff(postedAt, "d") < 7) {
    return ` ${today.diff(postedAt, "d")} days ago`;
  } else if (
    today.diff(postedAt, "d") >= 7 &&
    today.diff(postedAt, "d") <= 31
  ) {
    return ` ${Math.ceil(today.diff(postedAt, "d") / 7)} weeks ago`;
  } else if (today.diff(postedAt, "M") > 0) {
    return ` ${today.diff(postedAt, "M")} months ago`;
  }
};
