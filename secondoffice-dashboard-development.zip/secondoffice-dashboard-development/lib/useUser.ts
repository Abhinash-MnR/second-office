// React, Next packages
import { useEffect } from "react";
import Router from "next/router";

// Third-party packages
import useSWR from "swr";

// Custom packages
import { ApiHandler } from "@lib/api-handler";

const handler = new ApiHandler({
  context: undefined,
});

async function fetcher(url: string) {
  // TODO - implement type check for AxiosResponse<T>
  // @ts-ignore
  const response = await handler.get(url);
  return response.data;
}

export default function useUser({
  redirectTo = "",
  redirectIfFound = false,
} = {}) {
  const {
    data: user,
    error,
    mutate: mutateUser,
  } = useSWR("/accounts/detail/", fetcher, {
    onError: (error, key) => {
      // We can send the error to Sentry,
      // or show a notification UI.
    },
    onErrorRetry: (error, key, config, revalidate, { retryCount }) => {
      // Never retry on 401 or 403.
      if (error?.response?.status === 401 || error?.response?.status === 403)
        return;

      // Never retry for a specific key.
      // if (key === '/api/user') return

      // Only retry up to 10 times.
      // if (retryCount >= 10) return

      // Retry after 5 seconds.
      // setTimeout(() => revalidate({ retryCount }), 5000)
    },
  });

  /**
   * Comparing by user.id is arbitrary.
   * However, the key is populated by the backend to consume.
   * So that it will complicate manipulation via browser consoles.
   */
  useEffect(() => {
    // if no redirect needed, just return (example: already on /dashboard)
    // if user data not yet there (fetch in progress, logged in or not) then don't do anything yet
    if (!redirectTo || (!error && !user)) return;

    if (
      // If redirectTo is set, redirect if the user was not found or errored.
      (redirectTo && !redirectIfFound && (!user?.id || error)) ||
      // If redirectIfFound is also set, redirect if the user was found
      (redirectIfFound && user?.id)
    ) {
      Router.push(redirectTo);
    }
  }, [user, error, redirectIfFound, redirectTo]);

  return {
    user,
    isLoading: !error && !user,
    isError: error,
    mutateUser,
  };
}
