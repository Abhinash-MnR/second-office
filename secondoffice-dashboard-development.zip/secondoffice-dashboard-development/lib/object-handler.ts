export function convertJSONToFormData(payload: any) {
  const formData = new FormData();
  Object.keys(payload).forEach((key) => {
    formData.append(key, payload[key]);
  });
  return formData;
}

export function findIndexById(array: Array<any>, targetId: string) {
  const targetIndex = array?.findIndex((item) => item.id === targetId);
  return targetIndex;
}
