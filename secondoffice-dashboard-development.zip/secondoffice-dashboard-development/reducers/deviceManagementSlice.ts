import { createSlice, Dispatch } from "@reduxjs/toolkit";
import { getEmployeeDeviceList } from "@api/deviceMangement";

const deviceMangementSlice = createSlice({
  name: "results",
  initialState: {
    count: 0,
    results: [],
    next: 1,
  },
  reducers: {
    deviceMangementSucess: (state, action) => {
      // state.results = unionBy(state.results, action.payload.results, "id");
      state.results = action.payload.results;
      state.count = action.payload.count;
      state.next = action.payload.next;
    },
  },
});

export const deviceMangementList = (dispatch: Dispatch, params: any) => {
  getEmployeeDeviceList(params).then((results) =>
    dispatch(deviceMangementSucess(results.data))
  );
};

export const { deviceMangementSucess } = deviceMangementSlice.actions;

export default deviceMangementSlice.reducer;
