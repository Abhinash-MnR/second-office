
import { createSlice, Dispatch } from "@reduxjs/toolkit";
import { readJobDetailHistory } from "@api/jobs";
// import unionBy from "lodash/unionBy";

const jobsHistorySlice = createSlice({
  name: "jobsHistory",
  initialState: {
    count: 0,
    results: [],
    next: 1,
  },
  reducers: {
    jobsHistory: (state, action) => {
      // state.results = unionBy(state.results, action.payload.results, "id");
      state.results = action.payload.results;
      state.count = action.payload.count;
      state.next = action.payload.next;
    },
  },
});

export const jobsHistoryList = (dispatch: Dispatch,params: any) => {
  readJobDetailHistory(params).then((results) => dispatch(jobsHistory(results.data)));
};

export const { jobsHistory } = jobsHistorySlice.actions;

export default jobsHistorySlice.reducer;