import { createSlice, Dispatch } from "@reduxjs/toolkit";
import { getTeamCount } from "api/analytics";
import {
  deleteTeamDetail,
  deleteTeamInvitation,
  getTeamList,
  getTeamInvitationList,
  postTeamInvitation,
  putTeamDetail,
} from "api/teams";
import { findIndexById } from "@lib/object-handler";

const teamSlice = createSlice({
  name: "teams",
  initialState: {
    members: [],
    membersCount: 0,
    membersNext: undefined,
    invitations: [],
    invitationsCount: 0,
    invitationsNext: undefined,
  },
  reducers: {
    readTeamCountSuccess: (state, action) => {
      state.membersCount = action.payload.data?.members;
      state.invitationsCount = action.payload.data?.invitations;
    },
    listTeamSuccess: (state, action) => {
      state.membersCount = action.payload.data?.count;
      state.members = action.payload.data?.results;
      state.membersNext = action.payload.data?.next;
    },
    deleteTeamSuccess: (state, action) => {
      const member = action.payload.data;
      const memberIndex = findIndexById(state.members, member.id);
      state.members.splice(memberIndex, 1);
      state.membersCount -= 1;
    },
    updateTeamSuccess: (state, action) => {
      const member = action.payload.data;
      const memberIndex = findIndexById(state.members, member.id);
      // @ts-ignore
      state.members[memberIndex] = member;
    },
    createInvitationSuccess: (state, action) => {
      // @ts-ignore
      state.invitations.push(action.payload.data);
      state.invitationsCount += 1;
    },
    listInvitationSuccess: (state, action) => {
      state.invitationsCount = action.payload.data?.count;
      state.invitations = action.payload.data?.results;
      state.invitationsNext = action.payload.data?.next;
    },
  },
});

export const readTeamCount = async (dispatch: Dispatch) => {
  const response = await getTeamCount();
  dispatch(readTeamCountSuccess(response));
};

export const removeTeam = async (dispatch: Dispatch, id: string) => {
  const response = await deleteTeamDetail(id);
  dispatch(deleteTeamSuccess(response));
};

export const editTeam = async (dispatch: Dispatch, payload?: any) => {
  const formData = new FormData();
  Object.keys(payload).forEach((key) => {
    formData.append(key, payload[key]);
  });
  const response = await putTeamDetail(payload.id, payload);
  dispatch(updateTeamSuccess(response));
};

export const listTeam = async (dispatch: Dispatch, params?: any) => {
  const response = await getTeamList(params);
  dispatch(listTeamSuccess({ ...response, params }));
};

export const inviteTeam = async (dispatch: Dispatch, payload: any) => {
  const formData = new FormData();
  Object.keys(payload).forEach((key) => {
    formData.append(key, payload[key]);
  });
  const response = await postTeamInvitation(payload);
  dispatch(createInvitationSuccess(response));
};

export const listInvitation = async (dispatch: Dispatch, params?: any) => {
  const response = await getTeamInvitationList(params);
  dispatch(listInvitationSuccess({ ...response, params }));
};

export const {
  readTeamCountSuccess,
  listTeamSuccess,
  deleteTeamSuccess,
  createInvitationSuccess,
  updateTeamSuccess,
  listInvitationSuccess,
} = teamSlice.actions;

export default teamSlice.reducer;
