import { createSlice, Dispatch } from "@reduxjs/toolkit";
import unionBy from "lodash/unionBy";
import {
  getCompany,
  putCompany,
  getGalleryList,
  postGallery,
  putGallery,
  deleteGallery,
} from "api/profile";
import { convertJSONToFormData, findIndexById } from "@lib/object-handler";

const profileSlice = createSlice({
  name: "profile",
  initialState: {
    company: undefined,
    // Gallery
    gallery: [],
    galleryCount: 0,
    galleryNext: 1,
  },
  reducers: {
    readCompanySuccess: (state, action) => {
      state.company = action.payload;
    },
    updateCompanySuccess: (state, action) => {
      const company = state.company ? state.company : {};

      state.company = {
        ...company,
        ...action.payload,
      };
    },
    listGallerySuccess: (state, action) => {
      state.gallery = unionBy(state.gallery, action.payload.results, "id");
      state.galleryCount = action.payload.count;
      state.galleryNext = action.payload.next;
    },
    addGallerySuccess: (state, action) => {
      state.gallery.unshift(action.payload);
      state.galleryCount += 1;
    },
    updateGallerySuccess: (state, action) => {
      const galleryId = action.payload.id;
      const galleryIndex = findIndexById(state.gallery, galleryId);
      state.gallery[galleryIndex] = action.payload;
    },
    deleteGallerySuccess: (state, action) => {
      const galleryId = action.payload;
      const galleryIndex = findIndexById(state.gallery, galleryId);
      state.gallery.splice(galleryIndex, 1);
      state.galleryCount -= 1;
    },
  },
});

export const readCompany = (dispatch: Dispatch) => {
  getCompany().then((company) => dispatch(readCompanySuccess(company.data)));
};

export const updateCompany = (dispatch: Dispatch, payload?: any) => {
  const formData = convertJSONToFormData(payload);
  putCompany(formData).then((company) =>
    dispatch(updateCompanySuccess(company.data))
  );
};

/** Gallery */
export const listGallery = (dispatch: Dispatch, params?: any) => {
  getGalleryList(params).then((gallery) =>
    dispatch(listGallerySuccess(gallery.data))
  );
};

export const addGallery = (dispatch: Dispatch, payload: any) => {
  const formData = convertJSONToFormData(payload);
  postGallery(formData).then((gallery) =>
    dispatch(addGallerySuccess(gallery.data))
  );
};

export const updateGallery = (
  dispatch: Dispatch,
  id: string,
  payload?: any
) => {
  const formData = convertJSONToFormData(payload);
  putGallery(id, formData).then((gallery) =>
    dispatch(updateGallerySuccess(gallery))
  );
};

export const removeGallery = (dispatch: Dispatch, id: string) => {
  deleteGallery(id).then((gallery) => dispatch(deleteGallerySuccess(id)));
};

export const {
  readCompanySuccess,
  updateCompanySuccess,
  // Gallery
  listGallerySuccess,
  addGallerySuccess,
  updateGallerySuccess,
  deleteGallerySuccess,
} = profileSlice.actions;

export default profileSlice.reducer;
