import { createSlice, Dispatch } from "@reduxjs/toolkit";
import unionBy from "lodash/unionBy";
import { getJobCount } from "api/analytics";
import {
  deleteJobDetail,
  getJobList,
  readJobDetail,
  postJobDetail,
  putJobDetail,
  getOpenJobList,
  getClosedJobList,
  getTotalCandidate,
} from "api/jobs";
import { findIndexById } from "@lib/object-handler";

const jobsSlice = createSlice({
  name: "jobs",
  initialState: {
    jobs: [],
    jobsCount: 0,
    jobsNext: 1,
    jobsById: {},
    // Job count summary
    jobsClosedCount: 0,
    jobsOpenCount: 0,
    openJobs: [],
    openJobsCount: 0,
    closedJobs: [],
    closedJobsCount: 0,
    totalCandidateCount: 0,
  },
  reducers: {
    readJobCountSuccess: (state, action) => {
      state.jobsOpenCount = action.payload.open_positions;
      state.jobsClosedCount = action.payload.closed_positions;
    },
    //** open jobs reducer */
    getOpenJobs: (state, action) => {
      state.openJobs = action.payload.results;
      state.openJobsCount = action.payload.count;
    },
    //** closed jobs reducer */
    getClosedJobs: (state, action) => {
      state.closedJobs = action.payload.results;
      state.closedJobsCount = action.payload.count;
    },
    //** total candidate applied for  jobs reducer */
    getTotalCandidates: (state, action) => {
      state.totalCandidateCount = action.payload.count;
    },
    listJobSuccess: (state, action) => {
      //debugger;
      // state.jobs = unionBy(state.jobs, action.payload.results, "id");
      state.jobs = action.payload.results;
      state.jobsCount = action.payload.count;
      state.jobsNext = action.payload.next;
    },
    jobSuccess: (state, action) => {
      // debugger;
      state.jobsById = action.payload;
      // state.jobs = unionBy(state.jobs, action.payload.results, "id");
      // state.jobsCount = action.payload.count;
      // state.jobsNext = action.payload.next;
    },
    deleteJobSuccess: (state, action) => {
      const job = action.payload;
      const jobIndex = findIndexById(state.jobs, job.id);
      // @ts-ignore
      state.jobs[jobIndex] = job;
    },
    createJobSuccess: (state, action) => {
      // @ts-ignore
      state.jobs.unshift(action.payload);
      state.jobsOpenCount += 1;
    },
    updateJobSuccess: (state, action) => {
      const job = action.payload;
      const jobIndex = findIndexById(state.jobs, job.id);
      // @ts-ignore
      state.jobs[jobIndex] = job;
    },
    clearJobs: (state) => {
      state.jobsNext = 1;
      state.jobs = [];
      console.log("clear", state.jobs);
    },
  },
});

export const readJobCount = (dispatch: Dispatch) => {
  getJobCount().then((counts) => dispatch(readJobCountSuccess(counts.data)));
};

export const addJob = (dispatch: Dispatch, payload: any) => {
  postJobDetail(payload).then((job) => dispatch(createJobSuccess(job.data)));
};

export const closeJob = (dispatch: Dispatch, id: string) => {
  deleteJobDetail(id).then((job) => dispatch(deleteJobSuccess(job.data)));
};

export const editJob = (dispatch: Dispatch, payload?: any) => {
  putJobDetail(payload.id, payload).then((job) =>
    dispatch(updateJobSuccess(job.data))
  );
};

export const listJob = (dispatch: Dispatch, params?: any) => {
  getJobList(params).then((job) => dispatch(listJobSuccess(job.data)));
};
export const fetchJob = (dispatch: Dispatch, id: string) => {
  readJobDetail(id).then((job) => dispatch(jobSuccess(job.data)));
};
//** open jobs api integration */
export const openJobsList = (dispatch: Dispatch, params?: any) => {
  getOpenJobList(params).then((job) => dispatch(getOpenJobs(job.data)));
};
//** closed jobs api integration  */
export const ClosedJobsList = (dispatch: Dispatch, params?: any) => {
  getClosedJobList(params).then((job) => dispatch(getClosedJobs(job.data)));
};
//** closed jobs api integration  */
export const totalCandidateList = (dispatch: Dispatch, params?: any) => {
  getTotalCandidate(params).then((job) =>
    dispatch(getTotalCandidates(job.data))
  );
};
export const {
  readJobCountSuccess,
  listJobSuccess,
  jobSuccess,
  deleteJobSuccess,
  createJobSuccess,
  updateJobSuccess,
  clearJobs,
  getOpenJobs,
  getClosedJobs,
  getTotalCandidates,
} = jobsSlice.actions;

export default jobsSlice.reducer;
