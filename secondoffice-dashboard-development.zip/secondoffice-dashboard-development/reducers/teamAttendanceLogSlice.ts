import { createSlice, Dispatch } from "@reduxjs/toolkit";
import { getTeamAttendanceLog, getTeamAttendance } from "@api/teams";
// import unionBy from "lodash/unionBy";

const teamAttendanceLogSlice = createSlice({
  name: "attendanceLog",
  initialState: {
    count: 0,
    results: [],
    next: 1,
    teamAttendanceCount: 0,
    teamAttendance: [],
  },
  reducers: {
    teamAttendanceLog: (state, action) => {
      // state.results = unionBy(state.results, action.payload.results, "id");
      state.results = action.payload.results;
      state.count = action.payload.count;
      state.next = action.payload.next;
    },
    //** team Attendance count */
    getTeamAttendanceCount: (state, action) => {
      state.teamAttendanceCount = action.payload.count;
      state.teamAttendance = action.payload.results;
    },
  },
});

export const teamAttendanceLogList = (dispatch: Dispatch, params: any) => {
  getTeamAttendanceLog(params).then((results) =>
    dispatch(teamAttendanceLog(results.data))
  );
};

//** team attendance count  */
export const teamAttendanceCountList = (dispatch: Dispatch, params: any) => {
  getTeamAttendance(params).then((results) =>
    dispatch(getTeamAttendanceCount(results.data))
  );
};

export const { teamAttendanceLog, getTeamAttendanceCount } =
  teamAttendanceLogSlice.actions;

export default teamAttendanceLogSlice.reducer;
