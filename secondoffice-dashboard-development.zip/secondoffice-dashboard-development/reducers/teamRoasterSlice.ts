import { createSlice, Dispatch } from "@reduxjs/toolkit";
import { getTeamRoaster } from "@api/teamPerformance";
// import unionBy from "lodash/unionBy";

const teamRoasterSlice = createSlice({
  name: "results",
  initialState: {
    count: 0,
    results: [],
    next: 1,
  },
  reducers: {
    teamRoaster: (state, action) => {
      // state.results = unionBy(state.results, action.payload.results, "id");
      state.results = action.payload.results;
      state.count = action.payload.count;
      state.next = action.payload.next;
    },
  },
});

export const teamRoasterList = (dispatch: Dispatch,params: any) => {
  getTeamRoaster(params).then((results) => dispatch(teamRoaster(results.data)));
};

export const { teamRoaster } = teamRoasterSlice.actions;

export default teamRoasterSlice.reducer;
