// Redux packages
import { combineReducers } from "redux";
import { DefaultRootState } from "react-redux";
import { configureStore } from "@reduxjs/toolkit";
// JP Reducers
import authReducer from "./authSlice";
import applicationsReducer from "./applicationsSlice";
import candidatesReducer from "./candidatesSlice";
import jobsReducer from "./jobsSlice";
import notificationsReducer from "./notificationsSlice";
import profileReducer from "./profileSlice";
import teamReducer from "./teamSlice";
import performanceReducer from "./teamPerformanceSlice";
import teamRoasterReducer from "./teamRoasterSlice";
import historicTeamRoasterReducer from "./historicTeamRoasterSlice";
import employeeListReducer from "./employeeListSlice";
import expenseReducer from "./expensesSlice";
import AppliedFundsReducer from "./appliedFundsSlice";
import teamExpectedNewJoiners from "./teamExpectedNewJoinersSlice";
import teamAttendanceLogSlice from "./teamAttendanceLogSlice";
import jobHistoryReducer from "./jobsHistorySlice";
import deviceSlice from "./deviceSlice";
import deviceManagementSlice from "./deviceManagementSlice";
import getCurrentEmployeeListSlice from "./getCurrentEmployeeListSlice";

export const rootReducer = combineReducers({
  auth: authReducer,
  applications: applicationsReducer,
  candidates: candidatesReducer,
  jobs: jobsReducer,
  notifications: notificationsReducer,
  profile: profileReducer,
  teams: teamReducer,
  results: performanceReducer,
  roaster: teamRoasterReducer,
  employeeList: employeeListReducer,
  historicRoaster: historicTeamRoasterReducer,
  expenses: expenseReducer,
  appliedFunds: AppliedFundsReducer,
  newJoiners: teamExpectedNewJoiners,
  attendanceLog: teamAttendanceLogSlice,
  jobsHistory: jobHistoryReducer,
  requestDevice: deviceSlice,
  employeeDeviceList: deviceManagementSlice,
  currentEmployeeList: getCurrentEmployeeListSlice,
});

// Redux store setup
function configureAppStore(preloadedState?: DefaultRootState) {
  const store = configureStore({
    reducer: rootReducer,
    preloadedState,
    devTools: true,
  });

  // Redux development tool and hot reload setup
  // @ts-ignore
  if (process.env.NODE_ENV !== "production" && module.hot) {
    // @ts-ignore
    module.hot.accept("./", () => store.replaceReducer(rootReducer));
  }

  return store;
}

const store = configureAppStore();

export default store;

// Infer the `RootState` and `AppDispatch` types from the store itself
export type RootState = ReturnType<typeof store.getState>;
// Inferred type: {posts: PostsState, comments: CommentsState, users: UsersState}
export type AppDispatch = typeof store.dispatch;
