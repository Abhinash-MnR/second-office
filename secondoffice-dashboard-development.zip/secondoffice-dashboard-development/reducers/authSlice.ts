import { createSlice, Dispatch } from "@reduxjs/toolkit";
// import { putUser } from "api/auth";
import { convertJSONToFormData } from "@lib/object-handler";

const authSlice = createSlice({
  name: "auth",
  initialState: {
    profile: undefined,
    skills: [],
    resume: undefined,
    loading: true,
  },
  reducers: {
    getUserSuccess: (state, action) => {
      const profile = action.payload.data;
      state.profile = profile;
    },
  },
});

// export const updateUser = async (dispatch: Dispatch, payload?: any) => {
//   try {
//     const formData = convertJSONToFormData(payload);
//     const response = await putUser(formData);
//   } catch (error) {
//     throw error;
//   }
// };

export default authSlice.reducer;
