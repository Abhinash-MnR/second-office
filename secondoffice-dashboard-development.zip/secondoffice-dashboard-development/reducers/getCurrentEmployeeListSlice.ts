import { createSlice, Dispatch } from "@reduxjs/toolkit";
import { getCurrentEmployeeList } from "@api/deviceMangement";

const currentEmployeeSlice = createSlice({
  name: "results",
  initialState: {
    count: 0,
    results: [],
  },
  reducers: {
    currentEmployeeSucess: (state, action) => {
      // state.results = unionBy(state.results, action.payload.results, "id");
      state.results = action.payload.results;
      state.count = action.payload.count;
    },
  },
});

export const currentEmployeeList = (dispatch: Dispatch, params: any) => {
  getCurrentEmployeeList(params).then((results) =>
    dispatch(currentEmployeeSucess(results.data))
  );
};

export const { currentEmployeeSucess } = currentEmployeeSlice.actions;

export default currentEmployeeSlice.reducer;
