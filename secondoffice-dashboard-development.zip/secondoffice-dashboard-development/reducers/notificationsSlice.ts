import { createSlice, Dispatch } from "@reduxjs/toolkit";
import unionBy from "lodash/unionBy";
import { findIndexById } from "@lib/object-handler";
import { getNotification, putNotification } from "api/notifications";

const notificationsSlice = createSlice({
  name: "notifications",
  initialState: {
    error: null,
    loading: true,
    notifications: [],
    notificationsCount: 0,
    notificationsNext: 1,
  },
  reducers: {
    listNotificationSuccess: (state, action) => {
      state.notifications = unionBy(
        state.notifications,
        action.payload?.results,
        "id"
      );
      state.notificationsCount = action.payload?.count;
      state.notificationsNext = action.payload?.next;
    },
    putNotificationSuccess: (state, action) => {
      const notificationId = action.payload.id;
      const notificationIndex = findIndexById(
        state.notifications,
        notificationId
      );
      // @ts-ignore
      state.notifications[notificationIndex] = action.payload;
    },
  },
});

export const listNotification = (dispatch: Dispatch, params?: any) => {
  getNotification(params).then((notifications) =>
    dispatch(listNotificationSuccess(notifications.data))
  );
};

export const updateNotification = (dispatch: Dispatch, data?: any) => {
  try {
    putNotification(data).then((notification) =>
      dispatch(putNotificationSuccess(notification.data))
    );
  } catch (error) {
    throw error;
  }
};

export const { listNotificationSuccess, putNotificationSuccess } =
  notificationsSlice.actions;

export default notificationsSlice.reducer;
