import { createSlice, Dispatch } from "@reduxjs/toolkit";
import { getteamPerformance } from "@api/teamPerformance";
// import unionBy from "lodash/unionBy";

const teamPerformanceSlice = createSlice({
  name: "results",
  initialState: {
    count: 0,
    results: [],
    performanceList: {},
    next: 1,
  },
  reducers: {
    teamPerformanceSucess: (state, action) => {
      // state.results = unionBy(state.results, action.payload.results, "id");
      state.results = action.payload.results;
      state.performanceList = action.payload.performanceList;
      state.count = action.payload.count;
      state.next = action.payload.next;
    },
  },
});

export const teamPerformanceList = (dispatch: Dispatch, params?: any) => {
  getteamPerformance(params).then((results) => {
    let performanceList = {};

    results.data.results.forEach((obj: any) => {
      let temp =
        performanceList?.[obj.performance_date]?.length > 0
          ? performanceList?.[obj.performance_date]
          : [];
      temp.push(obj);
      performanceList[obj.performance_date] = temp;
    });
    results.data['performanceList'] = performanceList
    dispatch(teamPerformanceSucess(results.data))
  });
};

export const { teamPerformanceSucess } = teamPerformanceSlice.actions;

export default teamPerformanceSlice.reducer;
