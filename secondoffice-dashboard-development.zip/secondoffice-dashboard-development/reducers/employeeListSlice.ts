import { createSlice, Dispatch } from "@reduxjs/toolkit";
import { getTeamRoaster } from "@api/teamPerformance";
// import unionBy from "lodash/unionBy";

const employeeListSlice = createSlice({
  name: "results",
  initialState: {
    count: 0,
    results: [],
    next: 1,
  },
  reducers: {
    historicTeamRoaster: (state, action) => {
      // state.results = unionBy(state.results, action.payload.results, "id");
      state.results = action.payload.results;
      state.count = action.payload.count;
      state.next = action.payload.next;
    },
  },
});

export const employeeList = (dispatch: Dispatch,params: any) => {
  getTeamRoaster(params).then((results) => dispatch(historicTeamRoaster(results.data)));
};

export const { historicTeamRoaster } = employeeListSlice.actions;

export default employeeListSlice.reducer;
