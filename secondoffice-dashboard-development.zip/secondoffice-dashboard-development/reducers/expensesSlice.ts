import { createSlice, Dispatch } from "@reduxjs/toolkit";
import { getExpensesInvoices } from "@api/expenses";
// import unionBy from "lodash/unionBy";

const expensesSlice = createSlice({
  name: "results",
  initialState: {
    count: 0,
    results: [],
    next: 1,
  },
  reducers: {
    expensesSucess: (state, action) => {
      // state.results = unionBy(state.results, action.payload.results, "id");
      state.results = action.payload.results;
      state.count = action.payload.count;
      state.next = action.payload.next;
    },
  },
});

export const expensesList = (dispatch: Dispatch, params: any) => {
  getExpensesInvoices(params).then((results) =>
    dispatch(expensesSucess(results.data))
  );
};

export const { expensesSucess } = expensesSlice.actions;

export default expensesSlice.reducer;
