import { createSlice, Dispatch } from "@reduxjs/toolkit";
import { getTeamExpectedNewJoiners } from "@api/teams";
// import unionBy from "lodash/unionBy";

const teamExpectedNewJoinersSlice = createSlice({
  name: "newJoiners",
  initialState: {
    count: 0,
    results: [],
    next: 1,
  },
  reducers: {
    teamExpectedNewJoiners: (state, action) => {
      // state.results = unionBy(state.results, action.payload.results, "id");
      state.results = action.payload.results;
      state.count = action.payload.count;
      state.next = action.payload.next;
    },
  },
});

export const teamExpectedNewJoinersList = (dispatch: Dispatch,params: any) => {
  getTeamExpectedNewJoiners(params).then((results) => dispatch(teamExpectedNewJoiners(results.data)));
};

export const { teamExpectedNewJoiners } = teamExpectedNewJoinersSlice.actions;

export default teamExpectedNewJoinersSlice.reducer;
