import { createSlice, Dispatch } from "@reduxjs/toolkit";
// import unionBy from "lodash/unionBy";
import {
  getApplicationList,
  putApplicationDetail,
  getShortListedApplicationList,
  getOfferedMadeList,
  getHiredCandidateList,
  getSearchApplicationList,
} from "api/applications";
import { findIndexById } from "@lib/object-handler";

const applicationsSlice = createSlice({
  name: "applications",
  initialState: {
    applications: [],
    applicationsLength: 0,
    applicationsNext: 1,
    shortListedCandidateCount: 0,
    offerMadeCount: 0,
    hiredCandidateCount: 0,
    searchResult: [],
    searchCount: 0,
  },
  reducers: {
    clearApplications: (state) => {
      state.applications = [];
      state.applicationsNext = 1;
    },
    //** shortlisted candidate list */
    getShortListCandidate: (state, action) => {
      state.shortListedCandidateCount = action.payload.count;
    },
    //** offer made candidate list   */
    getOfferedMadeCandidateList: (state, action) => {
      state.offerMadeCount = action.payload.count;
    },
    //** hired candidate  */
    getHiredCandidatesList: (state, action) => {
      state.hiredCandidateCount = action.payload.count;
    },
    //** search result of application list */
    searchApplicationList: (state, action) => {
      state.searchResult = action.payload?.results;
      state.searchCount = action.payload?.count;
    },
    listApplicationSuccess: (state, action) => {
      // state.applications = unionBy(
      //   state.applications,
      //   action.payload?.results,
      //   "id"
      // );
      state.applications = action.payload?.results;
      state.applicationsLength = action.payload?.count;
      state.applicationsNext = action.payload?.next;
    },
    editApplicationSuccess: (state, action) => {
      const applicationId = action.payload.id;
      const applicationIndex = findIndexById(state.applications, applicationId);
      state.applications[applicationIndex] = action.payload;
    },
  },
});

export const listApplication = (dispatch: Dispatch, params?: any) => {
  getApplicationList(params).then((applications) =>
    dispatch(listApplicationSuccess(applications.data))
  );
};

export const editApplication = (
  dispatch: Dispatch,
  id: string,
  payload?: any
) => {
  putApplicationDetail(id, payload).then((application) =>
    dispatch(editApplicationSuccess(application.data))
  );
};

//** search application list api */
export const listSearchApplication = (dispatch: Dispatch, params?: any) => {
  getSearchApplicationList(params).then((applications) =>
    dispatch(searchApplicationList(applications.data))
  );
};

//** shortlisted candidate api */
export const shortListApplication = (dispatch: Dispatch, params?: any) => {
  getShortListedApplicationList(params).then((applications) =>
    dispatch(getShortListCandidate(applications.data))
  );
};
//** offer made candidate api */
export const offerMadeApplication = (dispatch: Dispatch, params?: any) => {
  getOfferedMadeList(params).then((applications) =>
    dispatch(getOfferedMadeCandidateList(applications.data))
  );
};
//** Hired candidate api */
export const HiredCandidateApplication = (dispatch: Dispatch, params?: any) => {
  getHiredCandidateList(params).then((applications) =>
    dispatch(getHiredCandidatesList(applications.data))
  );
};
export const {
  clearApplications,
  editApplicationSuccess,
  listApplicationSuccess,
  getShortListCandidate,
  getOfferedMadeCandidateList,
  getHiredCandidatesList,
  searchApplicationList,
} = applicationsSlice.actions;

export default applicationsSlice.reducer;
