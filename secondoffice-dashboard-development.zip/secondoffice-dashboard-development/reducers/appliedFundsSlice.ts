import { createSlice, Dispatch } from "@reduxjs/toolkit";
import { getExpensesAppliedfund } from "@api/expenses";
// import unionBy from "lodash/unionBy";

const expensesAppliedFundSlice = createSlice({
  name: "results",
  initialState: {
    count: 0,
    results: [],
    next:1,
  },
  reducers: {
    expensesAppliedFundSucess: (state, action) => {
      // state.results = unionBy(state.results, action.payload.results, "id");
      state.results = action.payload.results;
      state.count = action.payload.count;
      state.next = action.payload.next;
    },
  },
});

export const expensesAppliedFundList = (dispatch: Dispatch, params: any) => {
    getExpensesAppliedfund(params).then((results) =>
    dispatch(expensesAppliedFundSucess(results.data))
  );
};

export const { expensesAppliedFundSucess } = expensesAppliedFundSlice.actions;

export default expensesAppliedFundSlice.reducer;