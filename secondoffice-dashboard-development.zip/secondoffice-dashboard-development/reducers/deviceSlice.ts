import { createSlice, Dispatch } from "@reduxjs/toolkit";
import { getRequestDevice } from "@api/deviceMangement";

const deviceSlice = createSlice({
  name: "results",
  initialState: {
    count: 0,
    results: [],
    next: 1,
  },
  reducers: {
    deviceSucess: (state, action) => {
      // state.results = unionBy(state.results, action.payload.results, "id");
      state.results = action.payload.results;
      state.count = action.payload.count;
      state.next = action.payload.next;
    },
  },
});

export const deviceList = (dispatch: Dispatch, params: any) => {
  getRequestDevice(params).then((results) =>
    dispatch(deviceSucess(results.data))
  );
};

export const { deviceSucess } = deviceSlice.actions;

export default deviceSlice.reducer;
