import { createSlice, Dispatch } from "@reduxjs/toolkit";
import unionBy from "lodash/unionBy";
import { deleteCandidateBookmark, postCandidateBookmark } from "api/bookmarks";
import { getCandidateList } from "api/candidates";
import { findIndexById } from "@lib/object-handler";

const candidatesSlice = createSlice({
  name: "candidates",
  initialState: {
    candidates: [],
    candidatesCount: 0,
    candidatesNext: 1,
  },
  reducers: {
    listCandidateSuccess: (state, action) => {
      state.candidates = unionBy(
        state.candidates,
        action.payload?.results,
        "id"
      );
      state.candidatesCount = action.payload?.count;
      state.candidatesNext = action.payload?.next;
    },
    addCandidateBookmarkSuccess: (state, action) => {
      const candidate_id = action.payload;
      const candidateIndex = findIndexById(state.candidates, candidate_id);
      // @ts-ignore
      state.candidates[candidateIndex].is_bookmarked = true;
    },
    removeCandidateBookmarkSuccess: (state, action) => {
      const candidate_id = action.payload;
      const candidateIndex = findIndexById(state.candidates, candidate_id);
      // @ts-ignore
      state.candidates[candidateIndex].is_bookmarked = false;
    },
    clearCandidates: (state) => {
      state.candidatesNext = 1;
      state.candidates = [];
    },
  },
});

export const listCandidate = (dispatch: Dispatch, params?: any) => {
  getCandidateList(params).then((candidates) =>
    dispatch(listCandidateSuccess(candidates.data))
  );
};

export const addCandidateBookmark = (
  dispatch: Dispatch,
  candidate: string,
  job: string
) => {
  postCandidateBookmark(candidate, job).then((candidate) =>
    dispatch(addCandidateBookmarkSuccess(candidate.data))
  );
};

export const removeCandidateBookmark = (
  dispatch: Dispatch,
  candidate: string,
  job: string
) => {
  deleteCandidateBookmark(candidate, job).then((candidate) =>
    dispatch(removeCandidateBookmarkSuccess(candidate.data))
  );
};

export const {
  addCandidateBookmarkSuccess,
  clearCandidates,
  listCandidateSuccess,
  removeCandidateBookmarkSuccess,
} = candidatesSlice.actions;

export default candidatesSlice.reducer;
