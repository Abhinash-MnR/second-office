const subdomain = process.env.ENVIRONMENT === "production" ? "" : "dev.";

export const CC_CAS = `https://${
  subdomain.split(".")[0]
}api.accounts.careerchat.me`;
export const CC_ACCOUNTS = `https://${subdomain}accounts.careerchat.me`;
export const CC_JOBS = `https://${subdomain}jobs.careerchat.me`;
export const CC_RECRUITERS = `https://${subdomain}recruiters.careerchat.me`;
export const CC_FORUM = `https://${subdomain}forum.careerchat.me`;
export const CC_REXPERT = `https://${subdomain}rexpert.careerchat.me`;
export const CC_CONNECT = `https://${subdomain}connect.careerchat.me`;
export const SECONDOFFICE = `https://${subdomain}secondoffice.co`;
