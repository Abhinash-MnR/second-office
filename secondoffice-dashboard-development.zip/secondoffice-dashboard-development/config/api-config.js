import { create } from "axios";

const ENVIRONMENT = process.env.ENVIRONMENT;
const PRODUCTION_API = "https://api.secondoffice.io/api";
const DEVELOPMENT_API = "https://devapi.secondoffice.io/api";
const LOCAL_API = "http://localhost:8000/api";

let API_BASE_URL = DEVELOPMENT_API;

switch (ENVIRONMENT) {
  case "production":
    API_BASE_URL = PRODUCTION_API;
    break;
  case "development":
    API_BASE_URL = DEVELOPMENT_API;
    break;
  default:
    break;
}

const API = create({
  baseURL: API_BASE_URL,
  headers: { Accept: "application/json; version=v2" },
});

export { API };
