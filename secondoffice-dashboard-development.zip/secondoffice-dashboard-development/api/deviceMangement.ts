import { ApiHandler } from "@lib/api-handler";

export async function postRequestDevice(payload: any) {
  const handler = new ApiHandler({
    context: undefined,
    path: `/teams/requestdevice/`,
    data: payload,
  });
  return handler.post();
}

export async function getRequestDevice(params?: any) {
  const handler = new ApiHandler({
    context: undefined,
    path: `/teams/requestdevice/`,
    params: params,
  });
  return handler.get();
}

export async function getEmployeeDeviceList(params?: any) {
  const handler = new ApiHandler({
    context: undefined,
    path: `/teams/devicemanagement/`,
    params: params,
  });
  return handler.get();
}

export async function getCurrentEmployeeList(params?: any) {
  const handler = new ApiHandler({
    context: undefined,
    path: `/teams/employees/`,
    params: params,
  });
  return handler.get();
}
