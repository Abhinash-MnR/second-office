import { ApiHandler } from "@lib/api-handler";

export function getUserDetail(id: string) {
  const handler = new ApiHandler({
    context: undefined,
    path: `/users/${id}/`,
  });
  return handler.get();
}
