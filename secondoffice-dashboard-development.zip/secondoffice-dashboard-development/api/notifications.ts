import { ApiHandler } from "@lib/api-handler";

export async function putNotification(id: string) {
  const handler = new ApiHandler({
    context: undefined,
    path: `/companies/company/notifications/${id}/`,
    data: { is_read: true },
  });
  return handler.put();
}

export async function getNotification(params?: any) {
  const handler = new ApiHandler({
    context: undefined,
    path: "/companies/company/notifications/",
    params: params,
  });
  return handler.get();
}
