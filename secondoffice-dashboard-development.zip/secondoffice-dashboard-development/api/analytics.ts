import { ApiHandler } from "@lib/api-handler";

export async function getApplicationCount(params?: any) {
  const handler = new ApiHandler({
    context: undefined,
    path: "/jp_analytics/applications/counts/",
    params: params,
  });
  return handler.get();
}

export async function getApplicationRecentList(params?: any) {
  const handler = new ApiHandler({
    context: undefined,
    path: "/jp_analytics/applications/recents/",
    params: params,
  });
  return handler.get();
}

export async function getJobCount(params?: any) {
  const handler = new ApiHandler({
    context: undefined,
    path: "/jp_analytics/jobs/counts/",
    params: params,
  });
  return handler.get();
}

export async function getJobDeadlineList(params?: any) {
  const handler = new ApiHandler({
    context: undefined,
    path: "/jp_analytics/jobs/deadlines/",
    params: params,
  });
  return handler.get();
}

export async function getVisitTrendList(params?: any) {
  const handler = new ApiHandler({
    context: undefined,
    path: "/jp_analytics/visits/trends/",
    params: params,
  });
  return handler.get();
}

export async function getTeamCount(params?: any) {
  const handler = new ApiHandler({
    context: undefined,
    path: "/jp_analytics/teams/counts/",
    params: params,
  });
  return handler.get();
}
