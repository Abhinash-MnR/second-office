import { ApiHandler } from "@lib/api-handler";
import axios from "axios";

export async function signup(payload: any) {
  const handler = new ApiHandler({
    context: undefined,
    path: "/auth/users/",
    data: payload,
  });
  return handler.post();
}

export async function login(payload: any) {
  const handler = new ApiHandler({
    context: undefined,
    path: "/auth/token/login/",
    data: payload,
  });
  return handler.post();
}
export async function loginGoogle() {
  const handler = new ApiHandler({
    context: undefined,
    path: "/auth/o/google-oauth2/?redirect_uri=http://127.0.0.1:8000",
    data: undefined,
  });
  return handler.post();
}

export async function forgotPassword(payload: any) {
  const handler = new ApiHandler({
    context: undefined,
    path: "/auth/users/reset_password/",
    data: payload,
  });
  return handler.post();
}

export async function resetPassword(payload: any) {
  const handler = new ApiHandler({
    context: undefined,
    path: "/auth/users/reset_password_confirm/",
    data: payload,
  });
  return handler.post();
}

export async function postAuthorizationCode(code: string) {
  const handler = new ApiHandler({
    context: undefined,
    path: "/accounts/login/",
    data: { code, redirect_uri: `${location.origin}` },
  });
  return handler.post();
}

export const googleAuthenticate = (state:any, code:string) => async dispatch => {
  // if (state && code && !localStorage.getItem('access_token')) {
    const config = {
      header: {
        'content-Type': 'application/x-www.form-urlencoded'
      }
    }
    const details = {
      'state': state,
      'code': code
    };
    const formBody = Object.keys(details).map(key => encodeURIComponent(key) + '=' + encodeURIComponent(details[key])).join('&');
  // }
  try {
    const res = await axios.post(`http://localhost:8000/api/auth/o/google-oauth2/?${formBody}`, config);
  }catch (err :any) {

  }
  
}

export function validateToken(token: string) {
  const handler = new ApiHandler({
    context: undefined,
    path: "/accounts/token/",
    data: { token: token },
  });
  return handler.post();
}

// export async function getUser() {
//   const handler = new ApiHandler({
//     context: undefined,
//     path: "/accounts/detail/",
//   });
//   return handler.get();
// }

// export async function putUser(payload?: any) {
//   const handler = new ApiHandler({
//     context: undefined,
//     path: "/accounts/detail/",
//     data: payload,
//   });
//   return handler.put();
// }
