import { ApiHandler } from "@lib/api-handler";

export async function deleteTeamDetail(id: string) {
  const handler = new ApiHandler({
    context: undefined,
    path: `/companies/company/teams/${id}/`,
  });
  return handler.delete();
}

export async function getTeamList(params?: any) {
  const handler = new ApiHandler({
    context: undefined,
    path: "/companies/company/teams/",
    params: params,
  });
  return handler.get();
}

export async function putTeamDetail(id: string, payload?: any) {
  const handler = new ApiHandler({
    context: undefined,
    path: `/companies/company/teams/${id}/`,
    data: payload,
  });
  return handler.put();
}

export async function deleteTeamInvitation(id: string) {
  const handler = new ApiHandler({
    context: undefined,
    path: `/companies/company/invitations/${id}/`,
  });
  return handler.delete();
}

export async function getTeamInvitationList(params?: any) {
  const handler = new ApiHandler({
    context: undefined,
    path: "/companies/company/invitations/",
    params: params,
  });
  return handler.get();
}

export async function postTeamInvitation(payload: any) {
  const handler = new ApiHandler({
    context: undefined,
    path: "/companies/company/invitations/",
    data: payload,
  });
  return handler.post();
}

export async function getTeamExpectedNewJoiners(params?: any) {
  const handler = new ApiHandler({
    context: undefined,
    path: `/teams/newjoiners/`,
    params: params,
  });
  return handler.get();
}

export async function getTeamAttendanceLog(params?: any) {
  const handler = new ApiHandler({
    context: undefined,
    path: `/teams/attendancelog/`,
    params: params,
  });
  return handler.get();
}

export async function postTeamEmployeeHrAction(id: string, payload: any) {
  const handler = new ApiHandler({
    context: undefined,
    path: `/teams/employees/${id}/`,
    data: payload,
  });
  return handler.patch();
}
export async function getTeamAttendance(params?: any) {
  const handler = new ApiHandler({
    context: undefined,
    path: `/teams/employees/attendance`,
    params: params,
  });
  return handler.get();
}
