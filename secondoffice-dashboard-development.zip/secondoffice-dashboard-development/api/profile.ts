import { ApiHandler } from "@lib/api-handler";

export async function getCompany() {
  const handler = new ApiHandler({
    context: undefined,
    path: "/companies/profile/",
  });
  return handler.get();
}

export async function getStatus() {
  const handler = new ApiHandler({
    context: undefined,
    path: "/companies/profile/",
  });
  return handler.get();
}

export async function putCompany(payload?: any) {
  const handler = new ApiHandler({
    context: undefined,
    path: "/companies/profile/",
    data: payload,
  });
  return handler.put();
}

export async function getGalleryList(params?: any) {
  const handler = new ApiHandler({
    context: undefined,
    path: "/companies/company/galleries/",
    params: params,
  });
  return handler.get();
}

export async function postGallery(payload: any) {
  const handler = new ApiHandler({
    context: undefined,
    path: "/companies/company/galleries/",
    data: payload,
  });
  return handler.post();
}

export async function putGallery(id: string, payload?: any) {
  const handler = new ApiHandler({
    context: undefined,
    path: `/companies/company/galleries/${id}/`,
    data: payload,
  });
  return handler.put();
}

export async function deleteGallery(id: string) {
  const handler = new ApiHandler({
    context: undefined,
    path: `/companies/company/galleries/${id}/`,
  });
  return handler.delete();
}
