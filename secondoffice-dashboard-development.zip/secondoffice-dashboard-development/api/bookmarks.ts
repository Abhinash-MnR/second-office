import { ApiHandler } from "@lib/api-handler";

/**
 * Adds a specified user to a bookmark for a specified job post.
 * @param candidate ID of a candidate user
 * @param job ID of a job post
 * @returns axios post request promise
 */
export async function postCandidateBookmark(candidate: string, job: string) {
  const handler = new ApiHandler({
    context: undefined,
    path: "/bookmarks/candidates/",
    data: {
      candidate,
      job,
    },
  });
  return handler.post();
}

/**
 * Deletes a specified user from a bookmark for a specified job post.
 * @param candidate ID of a candidate user
 * @param job ID of a job post
 * @returns axios delete request promise
 */
export async function deleteCandidateBookmark(candidate: string, job: string) {
  const handler = new ApiHandler({
    context: undefined,
    path: `/bookmarks/candidates/${candidate}/${job}/`,
  });
  return handler.delete();
}

export async function getCandidateBookmarkList(params?: any) {
  const handler = new ApiHandler({
    context: undefined,
    path: "/bookmarks/jobs/",
    params: params,
  });
  return handler.get();
}
