import { NextPageContext } from "next";
import { ApiHandler } from "@lib/api-handler";

export function fetchCompanyByLink(
  context: NextPageContext,
  companyLink: string
) {
  const handler = new ApiHandler({
    context: context,
    path: `/companies/${companyLink}/`,
  });
  return handler.get();
}

export function getGalleryList(companyLink: string, params?: any) {
  const handler = new ApiHandler({
    context: undefined,
    path: `/companies/${companyLink}/galleries/`,
    params: params,
  });
  return handler.get();
}

export function getJobList(companyLink: string, params?: any) {
  const handler = new ApiHandler({
    context: undefined,
    path: `/companies/${companyLink}/jobs/`,
    params: params,
  });
  return handler.get();
}
