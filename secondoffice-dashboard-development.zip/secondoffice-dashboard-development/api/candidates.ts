import { ApiHandler } from "@lib/api-handler";

export async function getCandidateList(params?: any) {
  const handler = new ApiHandler({
    context: undefined,
    path: "/companies/company/candidates/",
    params: params,
  });
  return handler.get();
}
