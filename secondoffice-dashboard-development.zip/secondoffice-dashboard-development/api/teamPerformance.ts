import { ApiHandler } from "@lib/api-handler";

export async function getteamPerformance(params?: any) {
  const handler = new ApiHandler({
    context: undefined,
    path: `/teams/performances/`,
    params: params,
  });
  return handler.get();
}

export async function postTeamPerformance(payload: any) {
  const handler = new ApiHandler({
    context: undefined,
    path: `/teams/performances/`,
    data: payload,
  });
  return handler.post();
}

export async function getTeamRoaster(params?: any) {
  const handler = new ApiHandler({
    context: undefined,
    path: `/teams/employees/`,
    params: params,
  });
  return handler.get();
}
export async function putTeamPerformanceHrAction(
  id: string,
  payload: any
) {
  const handler = new ApiHandler({
    context: undefined,
    path: `/teams/performances/${id}/`,
    data: payload,
  });
  return handler.patch();
}
