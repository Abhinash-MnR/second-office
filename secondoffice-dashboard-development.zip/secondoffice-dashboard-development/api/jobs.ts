import { ApiHandler } from "@lib/api-handler";

export function postJobApplication(jobId: string) {
  const handler = new ApiHandler({
    context: undefined,
    path: "/jobs/applications/",
    data: { job_post: jobId },
  });
  return handler.post();
}

export async function getJobList(params?: any) {
  const handler = new ApiHandler({
    context: undefined,
    path: "/jobs/posts/",
    params: params,
  });
  return handler.get();
}

export async function getOpenJobList(params?: any) {
  const handler = new ApiHandler({
    context: undefined,
    path: "/jobs/posts/open",
    params: params,
  });
  return handler.get();
}
export async function getClosedJobList(params?: any) {
  const handler = new ApiHandler({
    context: undefined,
    path: "/jobs/posts/closed",
    params: params,
  });
  return handler.get();
}
export async function getTotalCandidate(params?: any) {
  const handler = new ApiHandler({
    context: undefined,
    path: "/jobs/applications/count",
    params: params,
  });
  return handler.get();
}
export async function postJobDetail(payload: any) {
  const handler = new ApiHandler({
    context: undefined,
    path: "/jobs/posts/",
    data: payload,
  });
  return handler.post();
}

export async function readJobDetail(id: string) {
  const handler = new ApiHandler({
    context: undefined,
    path: `/jobs/posts/${id}/`,
  });
  return handler.get();
}

export async function readJobDetailHistory(payload: any) {
  const handler = new ApiHandler({
    context: undefined,
    path: "jobs/history/",
  });
  return handler.get();
}

export async function putJobDetail(id: string, payload: any) {
  const handler = new ApiHandler({
    context: undefined,
    path: `/jobs/posts/${id}/`,
    data: payload,
  });
  return handler.put();
}

export async function deleteJobDetail(id: string) {
  const handler = new ApiHandler({
    context: undefined,
    path: `/jobs/posts/${id}/`,
  });
  return handler.delete();
}
