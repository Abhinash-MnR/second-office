import { ApiHandler } from "@lib/api-handler";

export async function listTag(search: string) {
  const handler = new ApiHandler({
    context: undefined,
    path: "/tags/",
    params: { search },
  });
  return handler.get();
}
