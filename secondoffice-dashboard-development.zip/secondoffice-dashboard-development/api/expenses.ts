import { ApiHandler } from "@lib/api-handler";

export async function getExpensesInvoices(params?: any) {
  const handler = new ApiHandler({
    context: undefined,
    path: `/expenses/invoices/`,
    params: params,
  });
  return handler.get();
}
export async function getExpensesAppliedfund(params?: any) {
  const handler = new ApiHandler({
    context: undefined,
    path: `/expenses/appliedfund/`,
    params: params,
  });
  return handler.get();
}

export async function putSettingsDetail(
  payload: any
) {
  const handler = new ApiHandler({
    context: undefined,
    path: `/companies/profile/`,
    data: payload,
  });
  return handler.patch();
}