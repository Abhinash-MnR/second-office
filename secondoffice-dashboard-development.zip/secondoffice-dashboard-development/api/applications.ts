import { ApiHandler } from "@lib/api-handler";
import {
  ApplicationDetailPayload,
  ApplicationListParams,
} from "types/Application";

export async function getApplicationList(params?: ApplicationListParams) {
  const handler = new ApiHandler({
    context: undefined,
    path: "/jobs/applications/",
    params: params,
  });
  return handler.get();
}

export async function getSearchApplicationList(params?: ApplicationListParams) {
  const handler = new ApiHandler({
    context: undefined,
    path: "/jobs/applications/list",
    params: params,
  });
  return handler.get();
}

export async function getShortListedApplicationList(
  params?: ApplicationListParams
) {
  const handler = new ApiHandler({
    context: undefined,
    path: "/jobs/applications/shortlisted",
    params: params,
  });
  return handler.get();
}
export async function getOfferedMadeList(params?: ApplicationListParams) {
  const handler = new ApiHandler({
    context: undefined,
    path: "/jobs/applications/offermade",
    params: params,
  });
  return handler.get();
}
export async function getHiredCandidateList(params?: ApplicationListParams) {
  const handler = new ApiHandler({
    context: undefined,
    path: "/jobs/applications/hired",
    params: params,
  });
  return handler.get();
}
export async function putApplicationDetail(
  id: string,
  payload: ApplicationDetailPayload
) {
  const handler = new ApiHandler({
    context: undefined,
    path: `/jobs/applications/${id}/`,
    data: payload,
  });
  return handler.patch();
}

export async function postJobChatChannel(userId: string, jobId: string) {
  const handler = new ApiHandler({
    context: undefined,
    path: `/companies/company/chats/`,
    data: {
      job_seeker: userId,
      job_post: jobId,
    },
  });
  return handler.post();
}
